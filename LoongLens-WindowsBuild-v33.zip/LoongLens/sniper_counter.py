"""The user's game day starts at 16:00 in Europe/Sofia, not midnight."""
from datetime import datetime,time,timedelta
from zoneinfo import ZoneInfo
import time as clock
from contextlib import closing
from pathlib import Path
import sqlite3

ZONE=ZoneInfo('Europe/Sofia')


def game_day_window(now=None):
    local=datetime.fromtimestamp(clock.time() if now is None else now,ZONE)
    day=local.date() if local.hour>=16 else local.date()-timedelta(days=1)
    start=datetime.combine(day,time(16),ZONE).timestamp()
    end=datetime.combine(day+timedelta(days=1),time(16),ZONE).timestamp()
    return start,end


class SniperQuota:
    """Use the existing seen ledger from either the UI or patrol thread.

    Each operation owns its SQLite connection. The Tk-owned history connection
    must never be passed to the worker. Event IDs keep both writers idempotent.
    """
    limit=5
    collection_seconds=20.
    home=(241.,107.)

    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute('CREATE TABLE IF NOT EXISTS sniper_seen_events(event_id TEXT PRIMARY KEY,seen_at REAL NOT NULL)')
                db.execute('CREATE INDEX IF NOT EXISTS sniper_seen_time ON sniper_seen_events(seen_at)')

    def count(self,now):
        start,end=game_day_window(now)
        with closing(sqlite3.connect(self.path)) as db:
            return db.execute('SELECT COUNT(*) FROM sniper_seen_events WHERE seen_at>=? AND seen_at<?',(start,end)).fetchone()[0]

    def mark(self,event_id,stamp):
        with closing(sqlite3.connect(self.path)) as db:
            with db:db.execute('INSERT OR IGNORE INTO sniper_seen_events VALUES(?,?)',(event_id,stamp))
