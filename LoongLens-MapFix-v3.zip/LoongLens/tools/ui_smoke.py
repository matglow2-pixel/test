"""Exercise the real Tk panel on Linux with a simulated Windows overlay backend.

Run with DISPLAY pointing to an X server. This checks the panel, not Win32 APIs.
"""
import os
from pathlib import Path
import sys
import types
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from tkinter import ttk
import cv2
import numpy as np
from PIL import Image
from mss.linux import MSS
from pose import Match
import tracker
import loong_lens
import time
from tkinter import messagebox

OUT = Path(__file__).resolve().parents[1] / 'artifacts'
OUT.mkdir(exist_ok=True)
os.environ['XDG_CACHE_HOME'] = str(OUT / 'ui-settings')
opened=[]
messagebox.showinfo=lambda *args,**kwargs:None
os.startfile=lambda folder:opened.append(folder)

class Overlay:
    hwnd = 1
    excluded_from_capture = True
    def hide(self): pass
    def close(self): pass
    def show_image(self, rect, image):
        image.save(OUT / 'overlay-demo.png')

class Worker:
    fps = 30
    def __init__(self, *args, **kwargs): self.paused = False
    def start(self): pass
    def close(self): pass
    def pause(self, paused): self.paused = paused
    def request_scan(self): pass
    def get_diagnostics(self):
        frame=np.full((1029,570,3),(112,184,152),np.uint8)
        return frame,dict(rect=[0,0,570,1029],title_score=.92,state='Following map',
                          scale=12.45,source='mock diagnostics',age_reference=time.perf_counter())
    def get(self):
        return dict(open=not self.paused, match=Match(12.45, -1650, 2250, 150, .2, [], 'demo'),
                    rect=(0,0,570,1029), state='Following map' if not self.paused else 'Paused',
                    info='12.45 px/tile · 150 visual landmarks', fps=30., scan_ms=60.)

tracker.VisualWorker = Worker
sys.modules['win_overlay'] = types.SimpleNamespace(PixelAlphaOverlay=Overlay, find_emulator=lambda: None)
original = tk.Tk.__init__
errors = []

def descendants(root):
    result = []
    for widget in root.winfo_children():
        result.append(widget)
        result.extend(descendants(widget))
    return result

def start(self, *args, **kwargs):
    original(self, *args, **kwargs)
    self.report_callback_exception = lambda *args: errors.append(args)
    def interact():
        widgets = descendants(self)
        buttons = {w.cget('text'): w for w in widgets if isinstance(w, ttk.Button)}
        buttons['Pause'].invoke()
        buttons['Save debug'].invoke()
        assert opened
        assert (OUT/'ui-settings/LoongLens/map-debug.png').exists()
        assert (OUT/'ui-settings/LoongLens/map-debug.json').exists()
        assert buttons['Pause'].cget('text') == 'Resume'
        buttons['Pause'].invoke()
        for w in widgets:
            if isinstance(w, ttk.Checkbutton) and w.cget('text') in ['Beans / Crisp Beans', 'Bamboo Shoots', 'Giant Crab / Crab King']:
                w.invoke()
            if isinstance(w, ttk.Scale):
                w.set(6 if float(w.cget('to')) > 1 else .8)
        self.after(400, screenshot)
    def screenshot():
        self.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            pixels = screen.grab(dict(left=self.winfo_rootx(), top=self.winfo_rooty(),
                                      width=self.winfo_width(), height=self.winfo_height()))
            Image.frombytes('RGB', pixels.size, pixels.rgb).save(OUT / 'panel-preview.png')
        widgets = descendants(self)
        # Ensure the last explanatory label fits inside the initial window.
        label = next(w for w in widgets if isinstance(w, ttk.Label) and str(w.cget('text')).startswith('Dots are candidate'))
        assert label.winfo_rooty() + label.winfo_height() <= self.winfo_rooty() + self.winfo_height()
        exit_button = next(w for w in widgets if isinstance(w, ttk.Button) and w.cget('text') == 'Exit')
        assert not errors, errors
        exit_button.invoke()
        print('Tk smoke check passed: panel layout, layer toggles, sliders, pause/resume, saved settings and exit.')
    self.after(300, interact)
    self.after(6000, self.destroy)

tk.Tk.__init__ = start
sys.platform = 'win32'
sys.argv = ['loong_lens.py']
loong_lens.main()
if errors:
    raise RuntimeError(errors)
