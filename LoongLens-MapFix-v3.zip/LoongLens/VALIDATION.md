# Validation of this source release

Tests were run in the Linux development environment with Python 3.12, OpenCV 4.12.0, and two OpenCV threads. The live application targets Windows 10 (2004+) / Windows 11 and BlueStacks at default map zoom.

## Map alignment v3

The additional map tests cover default-zoom portal geometry, false extra markers, rejection of insufficient/random/other-zoom constellations, synthetic portal pixels with an excluded legend icon, green/brown/snow terrain viewports, uniform-terrain rejection, calibration fallback dispatch and retained diagnostics after focus loss. A rendering regression checks that a gem at reference y=920 remains visible while navigation below y=938 is transparent. **82 automated tests pass** for the combined release.

Approximate portal centers read from the user's inline Nimbuville/Demonbind Tower map view fit the bundled portal coordinates with about 1.03 pixels mean error at 12.50 pixels/tile. This validates coordinate geometry, not pixel recognition of the original inline image, which was unavailable as a local file. Portal pixel recognition was exercised separately with synthetic markers.

Terrain matching was checked on seven crops of the packaged atlas, covering green, brown and snow areas. Accepted fits stayed within seven reference pixels of the expected crop pose. These are offline atlas checks and do not establish live-game readiness. The coarse terrain method can be less precise than feature or portal alignment. The original stitched atlas remains unchanged.

The full-map site `https://lootandwaifus.com/sword-x-staff-interactive-map/?map=14` returned proxy HTTP 403 in this environment. No new site data or coordinates were downloaded. The existing 86 candidate gem coordinates and ingredient data were preserved. Full-map pictures supplied inline were used as visual references, not imported as new pixel assets.

## Gem Watch addition

**64 automated tests passed** after the Gem Watch version 2 fix (the original 35 tests plus 29 Gem Watch tests). The tests check arbitrary screen positions, native-coordinate scaling, multiple gems, HUD/region exclusion, lookalike colors, confirmation, suppression of repeated alerts, disappearance, cooldown, pause and covered-window filtering. Version 2 adds regressions for wide sidebar layouts, actual image-mode detection and confirmation, negative photo tests, return to live mode and stale-source rejection.

The 19 supplied screenshots were evaluated against annotated gem positions: 19/19 piles found across 18 positive images, no extra detections, and zero detections in `MyLocationNoGems`. Three positive images supplied templates; the other 15 positives contained 16 piles and were held out from template extraction. The negative screenshot was used during development and is not an independent negative validation set.

The Gem Watch Tk panel passed a Linux virtual-display smoke check with simulated Windows backends, including start/pause, area selection, saved preferences, calls to the sound backend, layout and exit. Actual Windows sound, capture, visibility APIs and a live gameplay session remain untested. See `GEM_WATCH.md` for details.

The new Test image button was additionally exercised through the real image loader, detector, worker thread, confirmation gate and Tk panel, using `IMG_1427.png` and `MyLocationNoGems.png`. The positive photo produced a labeled confirmed test alert and calls to the simulated sound backend; the negative photo remained quiet; returning to live mode stopped photo scanning. Only Windows capture and audio were mocked in that check.

A reconstruction of the reported Media Manager layout (a 724-pixel-wide photo inside a 1377×1040 window, with a sidebar and dimming) reproduced zero detections in version 1. Version 2 detected both annotated piles with interface masking disabled. With the default HUD mask enabled the lower pile falls in the excluded bottom band. The dedicated Test image mode avoids that layout-specific exclusion. This is a reconstruction using the supplied source photograph, not validation on the user's actual desktop capture.

## Results

- **35 automated tests passed.** These exercise default-scale atlas alignment, rejection of nondefault zoom, motion tracking, title detection, cache recovery, CSV validation, rendering, transparent UI exclusion, background request limits, pause/focus handling, and rejection of recognition results from a previous map session.
- **Offline self-check passed:** 3/3 selected atlas viewports aligned, the packaged 86-gem dataset loaded, and transparent rendering completed.
- **Tk panel smoke check passed** on a virtual X display with a simulated Windows overlay backend. Layer toggles, dot size, opacity, pause/resume, preferences, initial layout, and exit were exercised. This does not test Windows native APIs.
- **Release archive CRC checked**, then extracted for the offline self-check and automated suite.

## Measured performance

These are microbenchmarks of **synthetic viewports cropped from the supplied atlas**. They do not establish detection accuracy on live screenshots or end-to-end latency on a user's PC. Each original matcher timing used six repetitions; each indexed matcher timing used twelve repetitions after warm-up.

| Atlas viewport origin | Original search median | Indexed search median | Ratio |
|---|---:|---:|---:|
| 900, 1300 | 304.56 ms | 52.12 ms | 5.84× |
| 1600, 1500 | 384.86 ms | 60.46 ms | 6.37× |
| 2000, 1700 | 308.11 ms | 51.78 ms | 5.95× |

At a 570×1029 render size with all four layers enabled, full rendering had a **0.659 ms median** over 60 repetitions. An unchanged frame returned the cached surface in **0.002 ms median** over 1,000 repetitions. Stationary optical flow had a **2.985 ms median** over 60 repetitions.

The measured index preparation run took 2.38 seconds; an earlier run took about 5 seconds. Later launches reuse an on-disk index. Performance varies with CPU, atlas cache state, map detail, emulator size, and other activity. Windows bitmap upload and screen capture costs were not measured here.

Reproduce the microbenchmarks using `python tools/benchmark.py`; detailed results are written into `artifacts/benchmark.json`.

## Required live checks still outstanding

These require the user's Windows / BlueStacks / game installation, which was unavailable here:

1. Launch with `RUN_LOONG_LENS.bat`, put the map at normal/default zoom, and bring BlueStacks to the foreground. Confirm that transparent markers appear at recognizable locations.
2. Pan across several areas. Confirm that dots and zone borders follow the terrain without persistent offsets.
3. Close/reopen the map, resize/move BlueStacks, switch to another app, and pause/resume. Confirm that markers disappear and reacquire correctly.
4. Confirm that mouse clicks pass through the overlay and that the overlay does not steal keyboard focus.
5. Compare candidate coordinates with the live map. The supplied community data is not a verified list of current spawns.

The game must be visible on the desktop for screenshot capture. Its title and fixed UI layout must match the supplied templates. If alignment is unavailable, restore normal zoom and use **Re-align**; inspect `%LOCALAPPDATA%\LoongLens\loonglens.log` for capture errors.

## Source availability

All location data and reference images were reused from the user's uploaded `SxSMapOverlay.rar`. Requests to the cited TapTap/HackMD guides and an interactive-map web search were blocked with proxy HTTP 403 responses. No additional online coordinates were downloaded or verified.
