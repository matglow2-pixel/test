"""Low-rate desktop capture and confirmed alert events; no gameplay input."""
from __future__ import annotations
from collections import deque
from datetime import datetime
import logging
import threading
import time
import cv2
import numpy as np
from gem_detector import GemDetector, AlertGate

class WatchWorker:
    def __init__(self, find_window, visible_at):
        self.find_window = find_window
        self.visible_at = visible_at
        self.detector = GemDetector()
        self.gate = AlertGate()
        self.lock = threading.Lock()
        self.paused = True
        self.region = None
        self.exclude_hud = True
        self.reset_requested = False
        self.stop_event = threading.Event()
        self.thread = None
        self.target = None
        self.snapshot = dict(state='Ready — press Start watching', frame=None,
                             detections=[], scan_ms=0., rect=None)
        self.alerts = deque(maxlen=20)

    def start(self):
        self.thread = threading.Thread(target=self.run, name='GemWatch-capture', daemon=True)
        self.thread.start()

    def configure(self, paused=None, region=None, threshold=None, reset=False, exclude_hud=None):
        with self.lock:
            if paused is not None:
                if paused != self.paused:
                    self.reset_requested = True
                self.paused = paused
            if reset:
                self.region = region
            if threshold is not None:
                self.detector.threshold = float(threshold)
            if exclude_hud is not None:
                self.exclude_hud = bool(exclude_hud)
                self.reset_requested = True
            self.reset_requested = self.reset_requested or reset

    def get(self):
        with self.lock:
            return self.snapshot.copy()

    def drain_alerts(self):
        with self.lock:
            alerts = list(self.alerts)
            self.alerts.clear()
            return alerts

    def publish(self, **values):
        with self.lock:
            self.snapshot.update(values)

    def run(self):
        import mss
        try:
            with mss.mss() as screen:
                while not self.stop_event.is_set():
                    started = time.perf_counter()
                    try:
                        self.step(screen, started)
                    except Exception as exc:
                        logging.exception('Gem watcher capture failed')
                        self.gate.reset()
                        self.publish(state=f'Capture interrupted: {str(exc)[:100]}', detections=[])
                    # A target of 2 scans/second; expensive frames naturally run slower.
                    self.stop_event.wait(max(.05,.5-(time.perf_counter()-started)))
        except Exception as exc:
            logging.exception('Gem watcher backend failed')
            self.publish(state=f'Screenshot capture unavailable: {str(exc)[:100]}', detections=[])

    def step(self, screen, now):
        with self.lock:
            paused, region, exclude_hud = self.paused, self.region, self.exclude_hud
            reset = self.reset_requested
            self.reset_requested = False
        if reset:
            self.gate.reset()
        if paused:
            self.publish(state='Paused — Start watching to scan', detections=[])
            return
        target = self.find_window()
        if target is None:
            self.gate.reset()
            self.target = None
            self.publish(state='Waiting for a visible BlueStacks window', frame=None, detections=[])
            return
        hwnd, rect = target
        x,y,w,h = rect
        if target != self.target:
            self.gate.reset()
            self.target = target
        # Require part of the gameplay area to remain unobscured. Candidate
        # centers/corners are separately checked before they can trigger an alert.
        if not any(self.visible_at(hwnd, x+w*fx, y+h*fy)
                   for fx,fy in [(.25,.4),(.5,.4),(.75,.4),(.25,.65),(.5,.65),(.75,.65)]):
            self.gate.reset()
            self.publish(state='BlueStacks is covered — keep the game visible', frame=None, detections=[])
            return
        frame = np.asarray(screen.grab(dict(left=x,top=y,width=w,height=h)))[:,:,:3].copy()
        start = time.perf_counter()
        detections = self.detector.detect(frame, region=region, exclude_hud=exclude_hud)
        scan_ms = (time.perf_counter()-start)*1000
        detections = [d for d in detections if all(self.visible_at(hwnd,x+px,y+py) for px,py in
                      [d.center,(d.x,d.y),(d.x+d.width-1,d.y),(d.x,d.y+d.height-1),
                       (d.x+d.width-1,d.y+d.height-1)])]
        confirmed = self.gate.update(detections, time.perf_counter())
        with self.lock:
            # If the user paused during a scan, do not enqueue an alert from it.
            if confirmed and not self.paused and not self.reset_requested:
                self.alerts.append(dict(time=datetime.now().strftime('%H:%M:%S'),
                                        count=len(detections), best=max(d.score for d in detections)))
        self.publish(state=f'Watching · {len(detections)} gem candidate(s)' if detections
                     else 'Watching · no gems detected', frame=frame, rect=rect,
                     detections=detections, scan_ms=scan_ms)

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=3.)
