import cv2
import numpy as np
import pytest
from gem_detector import GemDetector, AlertGate, Detection, ROOT
from gem_watch_worker import WatchWorker

@pytest.fixture(scope='module')
def detector():
    cv2.setNumThreads(2)
    return GemDetector()

def artificial_screen(position=(280,440),scale=1.):
    frame = np.full((1029,570,3),(95,145,105),np.uint8)
    template = cv2.imread(str(ROOT/'gem_templates/gem_0.png'))
    template = cv2.resize(template,None,fx=scale,fy=scale)
    x,y = position;h,w = template.shape[:2]
    frame[y:y+h,x:x+w] = template
    return frame

@pytest.mark.parametrize('position',[(70,250),(250,440),(430,650),(110,700)])
def test_scan_finds_crystals_at_arbitrary_positions(detector,position):
    result = detector.detect(artificial_screen(position))
    assert len(result)==1
    assert abs(result[0].x-position[0])<=2 and abs(result[0].y-position[1])<=2

def test_no_crystals_no_detection(detector):
    assert detector.detect(np.full((1029,570,3),(95,145,105),np.uint8))==[]

def test_purple_effect_and_yellow_pixels_are_not_enough(detector):
    frame = np.full((1029,570,3),(95,145,105),np.uint8)
    cv2.circle(frame,(270,430),8,(235,80,235),-1)
    cv2.circle(frame,(280,440),5,(30,220,240),-1)
    cv2.circle(frame,(266,450),6,(230,180,40),-1)
    assert detector.detect(frame)==[]

def test_native_resolution_boxes_are_scaled_back(detector):
    frame = artificial_screen()
    large = cv2.resize(frame,None,fx=2,fy=2)
    hits = detector.detect(large)
    assert len(hits)==1 and abs(hits[0].x-560)<4 and abs(hits[0].y-880)<4

def test_hud_and_selected_scan_area_are_excluded(detector):
    assert detector.detect(artificial_screen((470,100)))==[]
    assert len(detector.detect(artificial_screen((470,100)),exclude_hud=False))==1
    assert detector.detect(artificial_screen(),region=(0,.2,.3,.7))==[]

def test_multiple_gems_have_distinct_boxes(detector):
    frame = artificial_screen((100,400))
    another = artificial_screen((350,600))
    frame[600:622,350:382] = another[600:622,350:382]
    assert len(detector.detect(frame))==2

def test_invalid_scan_area_is_rejected(detector):
    with pytest.raises(ValueError):
        detector.detect(artificial_screen(),region=(.5,.1,.4,.9))

def hit(x=100,y=300):
    return Detection(x,y,32,22,.95)

def test_alert_needs_persistence_not_single_frame():
    gate = AlertGate()
    assert not gate.update([hit()],0.)
    assert not gate.update([hit()],.5)
    assert gate.update([hit()],1.)

def test_visible_gem_does_not_repeat_even_after_cooldown():
    gate = AlertGate()
    for t in [0.,.5]:assert not gate.update([hit()],t)
    assert gate.update([hit()],1.)
    for t in [1.5,2.,10.,40.,100.]:
        # Keep updating like the watcher; do not simulate a 30-second missing
        # capture gap that intentionally expires the object track.
        for now in np.arange(gate.tracks[0].last_seen+.5,t+.25,.5):
            assert not gate.update([hit()],float(now))

def test_flicker_does_not_rearm_already_alerted_gem():
    gate = AlertGate(cooldown=0.)
    gate.update([hit()],0.);gate.update([hit()],.5)
    assert gate.update([hit()],1.)
    assert not gate.update([],2.)
    assert not gate.update([hit()],3.)

def test_missed_frame_resets_unconfirmed_streak():
    gate = AlertGate()
    gate.update([hit()],0.);gate.update([hit()],.5)
    gate.update([],1.)
    assert not gate.update([hit()],1.5)
    assert not gate.update([hit()],2.)
    assert gate.update([hit()],2.5)

def test_slow_capture_can_still_confirm_three_consecutive_sightings():
    gate = AlertGate()
    assert not gate.update([hit()],0.)
    assert not gate.update([hit()],2.)
    assert gate.update([hit()],4.)

def test_disappearance_then_return_can_alert_again():
    gate = AlertGate(cooldown=0.)
    gate.update([hit()],0.);gate.update([hit()],.5);assert gate.update([hit()],1.)
    gate.update([],12.)
    assert not gate.update([hit()],13.)
    assert not gate.update([hit()],13.5)
    assert gate.update([hit()],14.)

def test_new_gem_waits_for_global_cooldown():
    gate = AlertGate(cooldown=5.)
    gate.update([hit()],0.);gate.update([hit()],.5);assert gate.update([hit()],1.)
    assert not gate.update([hit(),hit(350)],2.)
    assert not gate.update([hit(),hit(350)],2.5)
    assert not gate.update([hit(),hit(350)],3.)
    assert gate.update([hit(),hit(350)],6.)

class Capture:
    def __init__(self):self.calls=0
    def grab(self,_):
        self.calls+=1
        return np.zeros((1029,570,4),np.uint8)

def test_paused_worker_does_not_capture():
    worker = WatchWorker(lambda:(123,(0,0,570,1029)),lambda *args:True)
    capture = Capture();worker.step(capture,0.)
    assert capture.calls==0 and worker.drain_alerts()==[]

def test_fully_covered_game_does_not_capture_or_alert():
    worker = WatchWorker(lambda:(123,(0,0,570,1029)),lambda *args:False)
    worker.configure(paused=False);capture = Capture();worker.step(capture,0.)
    assert capture.calls==0 and 'covered' in worker.get()['state']

def test_covered_candidate_cannot_alert(monkeypatch):
    worker = WatchWorker(lambda:(123,(0,0,570,1029)),lambda hwnd,x,y:y<500)
    worker.configure(paused=False)
    worker.detector.detect = lambda *args,**kwargs:[hit(y=600)]
    capture = Capture()
    for t in [0.,.5,1.]:
        monkeypatch.setattr('gem_watch_worker.time.perf_counter',lambda:t)
        worker.step(capture,t)
    assert capture.calls==3 and worker.get()['detections']==[] and worker.drain_alerts()==[]

def test_visible_candidate_produces_one_confirmed_event(monkeypatch):
    worker = WatchWorker(lambda:(123,(0,0,570,1029)),lambda *args:True)
    worker.configure(paused=False)
    worker.detector.detect = lambda *args,**kwargs:[hit()]
    capture = Capture()
    for t in [0.,.5,1.,1.5,2.]:
        monkeypatch.setattr('gem_watch_worker.time.perf_counter',lambda:t)
        worker.step(capture,t)
    events = worker.drain_alerts()
    assert len(events)==1 and events[0]['count']==1
