# Loong Lens

**v31 adds Gem Spy and renames the tabs to Map Tweaker, Gem Sniper and Gem Spy.** Gem Watch is removed. Shared detection preferences, alerts and the existing history remain available through Gem Sniper. Gem Spy uses that selected route and settings, continuously observes without clicking gems, and keeps durable encounter and hourly histories. See [CHANGELOG-v31.md](CHANGELOG-v31.md).

**Edit route → Run route** switches saved routes. Default stays protected;
**Save as…** creates variants such as Busy zones, with their own removed points
and camera adjustments. Existing saved edits are imported as My route.

A Windows 10 (2004+) / Windows 11 companion for Sword x Staff in BlueStacks. Use Loong Haven's default map zoom.

## Start

Exit the previous app completely and run **LoongLens.exe** from this folder. The header must show **v31**. Python and separate icon files are not needed. The portable download contains the EXE and this guide; the full package also includes source, assets and development checks.

The EXE bundles its own code. To run edited Python files, use RUN_LOONG_LENS.bat; editing adjacent source does not alter the EXE. The launcher activates an existing instance, so exit that instance before changing launchers.

The EXE keeps the white gem badge in Explorer. Its window and taskbar use the original transparent gem artwork. Settings, history and screenshots remain in `%LOCALAPPDATA%\LoongLens` when upgrading.

## Map overlay

Open the large Loong Haven map with BlueStacks visible. Pink dots mark 86 possible gem locations; Ingredients groups the bean, bamboo and crab layers. Pause, Re-align and appearance controls affect only the overlay.

Recent sightings appear as teal dots with a 30-minute countdown from their original spotting time. Editing coordinates moves the dot without restarting its timer. Expired dots disappear; history stays saved. Manual pickups have their own Mark collected, Pickup history and timer controls.

## Gem Spy

Select the route and detection preferences in **Gem Sniper**, then open **Gem Spy**
and press **Start / Resume**. Spy has no route selector, route editor or settings
dialog of its own. Only one camera controller runs at a time. Spy continuously
repeats that route, saves new sightings and continues without clicking gems or
moving the character toward them. Stop or F10 always cancels automatic recovery.

**Time spent** accumulates active Spy time, including automatic recovery waits,
across runs and resumed sessions. **Gems found** counts distinct Spy encounters,
not repeat detections. Both counters and route progress survive closing the app.
A relaunch restores the checkpoint and waits for Start / Resume. Changing the
selected route starts a new route run while retaining totals and histories.

The existing standard history retains **Spotted, Source and Match score**.
Spy entries show **Gem Spy**, with a clickable link to the original screenshot.
A continuing gem adds no extra standard row or screenshot. Another distinct gem
in the same camera view can still create its own record.

**Spy history** is exclusive to this tab. It contains location/camera area,
last clear empty check, first and last sighting, appearance window, first
missing check, distinct runs seen and the original screenshot link. The check
log retains each visit as present, empty or unclear; only its latest 1,000 rows
are displayed, while the database retains all visits. Camera coordinates and
within-view gem positions are approximate, not verified gem tile coordinates.

Two successful empty observations in separate runs confirm an absence. Retries
or overlapping views in one run cannot provide both confirmations. Loading,
blank/changing scenes, unconfirmed candidates, locked views and capture failures
are unclear, not empty. Persistent matching uses approximate positions with a
small tolerance, including overlapping camera views. A visually identical gem
collected and replaced between visits cannot be distinguished reliably.

**Hourly history** groups new encounters by local date and the hour of their
first confirmed sighting. A gem remaining into later hours is not counted again.
UTC offsets distinguish repeated clock hours at daylight-saving changes. Counts
are observed new encounters, not inferred actual spawn-hour totals.

**Timing patterns** compares appearance windows by camera area and minutes of
the hour, with supporting-window counts and median observed gaps. It needs at
least three usable windows across two hours before showing candidate minute
ranges. Windows remain observation bounds; they are not midpoint guesses or
proof of a spawn schedule. Unknown first appearances and windows lasting an
hour or more cannot identify a minute of the hour. Other players and missed
appearances can affect the observed gaps.

Capture/alignment failures release the button, retain state and retry with a
short increasing delay. After two failed attempts, the point is recorded as
unclear and the next selected-route point is attempted using fresh recognition.
It is revisited on the next run. No blind reverse drags or guessed location
clicks are used. Storage/setup errors are reported rather than silently losing
data. This handles worker errors, not a hung or terminated Windows process.
Original screenshots already written before a crash are recovered on startup;
a later image is never substituted as the original first-sighting photo.

## Gem Sniper

This replaces the former Live patrol tab. The separate Patrol preview tab and its simulation controls have been removed; screenshot-based engine and UI checks remain in the development tools.

1. Open Loong Haven's map at default zoom. The fixed route always begins at **Emerald Corner (#1)**, so start there to minimise setup movement. Keep BlueStacks uncovered and move Loong Lens aside.
2. Press **Snipe** or **F8** to check the remaining route once. **Loop Sniping** repeats complete passes until a gem is found or **F10** stops it. Live controls are ready at launch; opening the app alone sends no input. Choose another Snipe key if a hotkey is already in use.
3. The saved path keeps the original diagram's order and numbers, with **#26 Forsaken Lotus Pond, #51 Jadetoad Isle and #72 Frosted Plain removed**. They are never inspected or included in completion totals. The default route has **76 camera checks / 83 spawn spots**. The original IDs keep their gaps. Wide vertical groups #40 and #64 are split into a/b checks so a spawn near the rectangle edge is not counted as clearly inspected.
4. Each check selects the next fixed camera destination, closes the map and inspects gameplay. Reopening normally recentres on the selected camera. The next destination is clicked directly when visible. The clickable surface is the game content except the four marked title, legend, zoom/portrait and bottom-control boxes; there is no added padding or broad right strip. Visible targets anywhere inside that surface are selected directly. If it is outside that surface, a held-button drag reveals it; the earlier B/R intermediate camera selections are not used. The fixed order is not replaced by nearest-dot selection.
5. Every click targets the saved map coordinate using fresh screenshot alignment. The actual mouse pixels and corrective drag length depend on the current map position, recentering, edge clamping and emulator size. Unconfirmed alignment stops input. Resuming keeps the first unfinished check; Reset checks returns to #1. Each completed loop returns to the same start and order.

The default-route documentation includes **GemSniping-Fixed-Route.png**, a zoomable SVG and a CSV listing all 76 checks. The data used by the app is **gem_sniping_route.json**. Pink spawn locations on the normal map overlay remain the original 86-location dataset; these exclusions apply to Gem Sniping. Existing history entries are kept.

**Edit route** opens the full Loong Haven map and stops sniping input. Select a numbered camera target to see its white camera rectangle and dashed suggested clear area, then drag it or enter X/Y. Pink dots remain the original spawn locations. Use the wheel or +/− to zoom, drag empty map to pan, and use Zoom to selected for fine changes; arrow keys nudge by 0.25 tile. Reset point restores a selected original point to its default position; for an extra it restores the position at which you opened or added it. Reset route to defaults removes extras and restores the bundled camera positions. **Add view after selected** inserts a separate camera target one tile beside the chosen point and selects it for adjustment. It runs immediately after that point, including when you add after another extra. Extra labels such as #12+1 keep the original map numbers intact. Drag the extra to cover the ground you want; **Remove selected** deletes an original point or an extra view from your personal route. Undo remove restores a removal before closing the editor; Restore originals brings back omitted originals at defaults while retaining surviving edits and extras. At least one view must remain. Removing an original leaves its extra views in place; remove those separately if you want to skip them too. Added views do not add spawn coordinates or change the excluded locations. **Save & reset checks** stores your camera positions and extra views locally, clears pass progress/timing and uses those positions on future launches and repeated passes. Closing without saving keeps the current route. Remaining route points keep their original order and labels; omitted targets are skipped. The editor shows omitted spawn totals, while the original spawn database stays unchanged. Extras keep their saved order within their original groups. Existing v21 camera adjustments load automatically. Warnings identify recorded centres outside the suggested clear area; manual adjustments can intentionally show ground beside the listed dots. Known portal coordinates are allowed; hide portal icons using the game map filter. One camera view cannot guarantee coverage of every possible 10-tile spawn offset.

Default startup is 0.5 seconds, scene loading is 0.5 seconds, and empty-view inspection is 1.2 seconds. A late gem candidate receives up to one extra second for the unchanged three-sighting / 0.8-second confirmation. Custom waits and map-button calibration are preserved. Increase the loading/check waits in **Sniper settings** if the game renders slowly.

Fixed-route map panning starts at reference pixel (285,530), near the map centre. The stroke direction is centre minus the next target's measured screen position: a lower-right target means an upper-left drag. The button stays held across fast movement and screenshot checks, with checks at most every 240 reference pixels. The stroke continues along the same direction until the target is available or the cursor reaches one of the four marked controls or the viewport edge. No additional padding is used. If another stroke is needed, the cursor settles, releases and returns to the centre before pressing again. Movement stops on the first verified screenshot with the target available; it does not keep pulling a visible target toward the centre. The cursor stays still for 0.18 seconds before release, then fresh settled alignment and a pre-click screenshot confirm the selection. Windows button state is checked before held movement; a lost hold stops delivery. Alignment recovery tries fresh recognition in place and stops if unsuccessful, without blind reverse sweeps. Focus, coverage, resize and F10 guards remain.

Other dark locked groups are still skipped from the current screenshot without changing the order of remaining targets. The bundled Crowcry camera position is retained, while personal camera targets can use former portal coordinates. Demonbind Tower is shifted lower and horizontally centred to show more ground above the chat. After a confirmed find, the enabled click action selects the gem once and stops.

On a confirmed gem, the default action captures its screenshot, confirms the gem again in a fresh frame, clicks the gem itself once, then stops. The click uses the latest detected centre with no tile offset. It avoids HUD buttons and cancels if the scene changes or F10 is pressed. Disable **On gem: click the gem itself once, then stop** in Sniping settings to retain the five-second photo hold instead. The legacy saved click setting is preserved; no further collection/dialog clicks are sent. A sniping history location identifies the selected camera area, not the character's minimap position or exact gem tile. Saving retains its 20-second cooldown across repeat passes.

**Time spent: 7:41** is cumulative during a Loop Sniping session. It does not reset on each pass, on a find, on F10, or when resuming; the wall clock continues through pauses until you explicitly reset checks. **Last 3 runs** shows the three most recent completed pass durations separately, newest first, such as #4 7:41 · #3 7:36 · #2 7:31. An incomplete pass does not replace a completed time. Gems found also stays cumulative. **Reset checks** clears total time, finds, pass history and progress; saving edits with **Save & reset checks** does the same. A standalone Snipe pass still freezes its timer after all saved views (including extra views and locked skips) are processed. History beside Sniper settings opens the shared log and stops mouse actions while the incomplete-pass clock continues. These runtime totals are not saved across closing the application.

The overlay stays visible during camera checks. Gem Sniper and Gem Spy share history and detection preferences, and keep exclusive ownership of mouse control. Existing history, screenshots and both icons are preserved.

## Files and privacy

The app uses ordinary desktop screenshots and Windows mouse input. It does not read game memory, inject DLLs or modify game files. Screenshots are saved locally and are not uploaded by the app.

Personal data is in `%LOCALAPPDATA%\LoongLens`: `settings.json`, `gemwatch-settings.json`, `patrol-live-settings.json`, `camera-route-adjustments.json`, `pickups.sqlite3`, `sightings.sqlite3` and `screenshots/`. Spy tables in sightings.sqlite3 store visits, encounters and checkpoints separately from the standard sightings table. Existing personal coordinates from earlier versions remain supported. Diagnostics use `loonglens.log`; Save debug writes the last map frame and alignment details to this same folder.

Do not delete that folder when updating. Old build archives, user data, caches, development screenshots and obsolete preview code are excluded from the new packages.

## Development

Use Python 3.12 and the pinned `requirements.txt`. Windows source launchers open the same combined app; RUN_GEM_SPY selects Gem Spy. The legacy RUN_GEM_WATCH launcher redirects to Gem Spy. The one-file EXE is built with PyInstaller 6.16.0 and has no console window.

```
python -m pip install -r requirements.txt pytest==8.4.2
python -m pytest -q
python loong_lens.py --self-check
# Windows build:
python -m pip install pyinstaller==6.16.0
python tools/build_windows_exe.py
```

`--tab map`, `--tab live` and `--tab spy` select a startup page. Tests use simulated desktop input and real atlas/detector fixtures; the Windows workflow additionally checks the frozen app, icons and native input against its own test window. These checks do not measure a live BlueStacks pass. See VALIDATION.md for the current verification scope. OCR model notices and licences are included in `ocr_models`.
