"""Local history of confirmed visual sightings, separate from manual pickups."""
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta, time as day_time
import csv
import math
import re
from pathlib import Path
import sqlite3
import time

SIGHTING_TIMER_SECONDS = 30 * 60


@dataclass(frozen=True)
class Sighting:
    id: int
    event_id: str
    seen_at: float
    screen_x: float
    screen_y: float
    score: float
    test_mode: bool
    zone: str | None = None
    game_x: int | None = None
    game_y: int | None = None
    screenshot_path: str | None = None
    capture_status: str = 'legacy'
    capture_note: str = ''
    captured_at: float | None = None
    manual_location: bool = False
    origin: str = ''

    @property
    def marker_x(self):
        return self.game_x

    @property
    def marker_y(self):
        return self.game_y

    @property
    def check_at(self):
        return self.seen_at + SIGHTING_TIMER_SECONDS

    def remaining(self, now):
        return max(0., self.check_at-now)

    def label(self, now):
        value = math.ceil(self.remaining(now))
        return f'{value//60:02d}:{value%60:02d}'

    def can_mark(self, now):
        return (not self.test_mode and self.game_x is not None and self.game_y is not None
                and 0 <= self.game_x < 280 and 0 <= self.game_y < 280
                and self.seen_at <= now < self.check_at)

    @property
    def local_time(self):
        return datetime.fromtimestamp(self.seen_at, timezone.utc).astimezone().strftime('%Y-%m-%d %H:%M:%S')

    @property
    def source(self):
        if self.test_mode:return 'Image test'
        if self.origin:return self.origin
        return 'Live game · Camera view' if self.capture_note.startswith('Camera view:') else 'Live game'

    @property
    def spotted(self):
        stamp = datetime.fromtimestamp(self.seen_at, timezone.utc).astimezone().strftime('%d/%m/%y %H:%M')
        if self.zone and self.game_x is not None and self.game_y is not None:
            return f'{self.zone} ({self.game_x},{self.game_y}) {stamp}'
        status = 'Location pending' if self.capture_status == 'pending' else 'Location unavailable'
        return f'{status} {stamp}'

    @property
    def source_label(self):
        if self.screenshot_path:
            return self.source + ' · Open screenshot'
        if self.capture_status == 'pending':
            return self.source + ' · Capture pending'
        return self.source + ' · No screenshot'


class SightingHistory:
    FIELDS = 'id,event_id,seen_at,screen_x,screen_y,score,test_mode,zone,game_x,game_y,screenshot_path,capture_status,capture_note,captured_at,manual_location,origin'
    CAPTURE_FIELDS = ('zone', 'game_x', 'game_y', 'screenshot_path', 'capture_status', 'capture_note', 'captured_at')
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.execute('''CREATE TABLE IF NOT EXISTS sightings (
            id INTEGER PRIMARY KEY, event_id TEXT NOT NULL UNIQUE,
            seen_at REAL NOT NULL, screen_x REAL NOT NULL, screen_y REAL NOT NULL,
            score REAL NOT NULL, test_mode INTEGER NOT NULL)''')
        columns = {row[1] for row in self.connection.execute('PRAGMA table_info(sightings)')}
        for name, definition in [('zone','TEXT'),('game_x','INTEGER'),('game_y','INTEGER'),('screenshot_path','TEXT'),
                                  ('capture_status',"TEXT NOT NULL DEFAULT 'legacy'"),('capture_note',"TEXT NOT NULL DEFAULT ''"),('captured_at','REAL'),
                                  ('manual_location','INTEGER NOT NULL DEFAULT 0'),('origin',"TEXT NOT NULL DEFAULT ''")]:
            if name not in columns:
                self.connection.execute(f'ALTER TABLE sightings ADD COLUMN {name} {definition}')
        self.connection.execute('CREATE INDEX IF NOT EXISTS sighting_time ON sightings(seen_at DESC,id DESC)')
        self.connection.commit()
        self._marker_cache_key = None
        self._marker_cache = []
        self._removed_events = set()

    def record(self, events):
        # Capture results enrich a row while preserving its original spotting
        # time. A replayed pending event must not erase a finished capture.
        columns = 'event_id,seen_at,screen_x,screen_y,score,test_mode,' + ','.join(self.CAPTURE_FIELDS)+',origin'
        updates = ','.join(f'{name}=CASE WHEN sightings.manual_location THEN sightings.{name} ELSE excluded.{name} END'
                          if name in ('zone','game_x','game_y') else f'{name}=excluded.{name}' for name in self.CAPTURE_FIELDS)
        values = []
        for event in events:
            if event['event_id'] in self._removed_events:
                continue
            values.append((event['event_id'],event['seen_at'],event['screen_x'],event['screen_y'],event['score'],bool(event['test_mode']),
                event.get('zone'),event.get('game_x'),event.get('game_y'),event.get('screenshot_path'),
                event.get('capture_status','legacy'),event.get('capture_note',''),event.get('captured_at'),event.get('origin','')))
        with self.connection:
            self.connection.executemany(f'''INSERT INTO sightings ({columns}) VALUES({','.join('?' for _ in range(14))})
                ON CONFLICT(event_id) DO UPDATE SET {updates}
                WHERE sightings.capture_status IN ('pending','legacy') AND excluded.capture_status NOT IN ('pending','legacy')''', values)

    def recover_pending(self):
        with self.connection:
            self.connection.execute("UPDATE sightings SET capture_status='interrupted',capture_note='The app stopped before this capture finished.' WHERE capture_status='pending'")

    def get(self, sighting_id):
        row = self.connection.execute(f'SELECT {self.FIELDS} FROM sightings WHERE id=?',(sighting_id,)).fetchone()
        return Sighting(*row) if row else None

    def edit_location(self, sighting_id, zone, x, y):
        zone = str(zone).strip()
        if not zone or len(zone)>80 or not zone[0].isalnum() or any(ord(char)<32 for char in zone):
            raise ValueError('Enter a zone name of 1–80 characters, starting with a letter or number.')
        zone = re.sub(r'\s+', ' ', zone)
        try:
            coordinates = [float(x), float(y)]
        except (ValueError, TypeError):
            raise ValueError('Enter whole-number X and Y from 0 to 279.') from None
        if not all(math.isfinite(value) and value.is_integer() and 0<=value<280 for value in coordinates):
            raise ValueError('Enter whole-number X and Y from 0 to 279.')
        with self.connection:
            cursor = self.connection.execute('UPDATE sightings SET zone=?,game_x=?,game_y=?,manual_location=1 WHERE id=?',
                (zone, int(coordinates[0]), int(coordinates[1]), sighting_id))
            if not cursor.rowcount:
                raise ValueError('This history entry was removed.')

    @staticmethod
    def date_filter(today_only, now=None):
        if not today_only:
            return [], []
        # Separate local midnights handle 23/25-hour daylight-saving days.
        today = (now or datetime.now()).date()
        start = datetime.combine(today, day_time.min).timestamp()
        end = datetime.combine(today+timedelta(days=1), day_time.min).timestamp()
        return ['seen_at>=?', 'seen_at<?'], [start, end]

    def list(self, include_tests=False, limit=None, today_only=False, now=None):
        query = f'SELECT {self.FIELDS} FROM sightings'
        conditions, parameters = self.date_filter(today_only, now)
        if not include_tests:
            conditions.append('test_mode=0')
        if conditions:
            query += ' WHERE ' + ' AND '.join(conditions)
        query += ' ORDER BY seen_at DESC,id DESC'
        if limit is not None:
            query += ' LIMIT ?'
            parameters.append(limit)
        return [Sighting(*row) for row in self.connection.execute(query, parameters)]

    def counts(self, today_only=False, now=None):
        conditions, parameters = self.date_filter(today_only, now)
        query = 'SELECT test_mode,COUNT(*) FROM sightings'
        if conditions:
            query += ' WHERE ' + ' AND '.join(conditions)
        return dict(self.connection.execute(query+' GROUP BY test_mode', parameters))

    def active_markers(self, now=None):
        now = time.time() if now is None else now
        # Query at most once per second, but edits/new captures/deletions on
        # this connection invalidate immediately, without polling every frame.
        key = (int(now), self.connection.total_changes)
        if key != self._marker_cache_key:
            query = f'''SELECT {self.FIELDS} FROM (
                SELECT *, ROW_NUMBER() OVER (
                    PARTITION BY game_x,game_y ORDER BY seen_at DESC,id DESC
                ) AS newest FROM sightings
                WHERE test_mode=0 AND seen_at>? AND seen_at<=?
                    AND game_x>=0 AND game_x<280 AND game_y>=0 AND game_y<280
                ) WHERE newest=1 ORDER BY seen_at DESC,id DESC'''
            self._marker_cache = [Sighting(*row) for row in self.connection.execute(
                query, (now-SIGHTING_TIMER_SECONDS, now))]
            self._marker_cache_key = key
        # Honour fractional-second expiry even inside the cached second.
        return [row for row in self._marker_cache if row.can_mark(now)]

    def pending_count(self):
        return self.connection.execute("SELECT COUNT(*) FROM sightings WHERE capture_status='pending'").fetchone()[0]

    def remove(self, sighting_id):
        row = self.connection.execute('SELECT event_id FROM sightings WHERE id=?', (sighting_id,)).fetchone()
        with self.connection:
            self.connection.execute('DELETE FROM sightings WHERE id=?', (sighting_id,))
        if row:
            # A delayed screenshot must not recreate a row the user removed.
            # Outstanding captures are local to this running app session.
            self._removed_events.add(row[0])

    def export_csv(self, path, include_tests=False):
        with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['id', 'spotted', 'seen_at_local', 'seen_at_utc', 'source', 'match_score', 'screen_x', 'screen_y',
                             'zone','game_x','game_y','screenshot_path','capture_status','capture_note','captured_at_utc'])
            for row in self.list(include_tests=include_tests):
                captured = datetime.fromtimestamp(row.captured_at,timezone.utc).isoformat() if row.captured_at is not None else ''
                writer.writerow([row.id, row.spotted, datetime.fromtimestamp(row.seen_at, timezone.utc).astimezone().isoformat(),
                                 datetime.fromtimestamp(row.seen_at, timezone.utc).isoformat(), row.source,
                                 row.score, row.screen_x, row.screen_y, row.zone, row.game_x, row.game_y, row.screenshot_path,
                                 row.capture_status, row.capture_note, captured])

    def close(self):
        self.connection.close()
