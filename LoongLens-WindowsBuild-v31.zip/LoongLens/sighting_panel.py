"""History window for confirmed sightings; test images are excluded by default."""
import sqlite3
import os
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox


class SightingControls:
    def __init__(self, root, history):
        self.root = root
        self.history = history
        self.window = None
        self.tree = None
        self.rows = {}
        self.edit_window = None
        self.date_scope = tk.StringVar(root, value='today')
        self.status = tk.StringVar(root)
        self.display_day = None
        self.day_job = None
        self.include_tests = tk.BooleanVar(root, value=False)
        self.summary = tk.StringVar(root)
        self.refresh()

    def refresh(self):
        today_only = self.date_scope.get() == 'today'
        self.display_day = datetime.now().date()
        counts = self.history.counts(today_only=today_only)
        pending = self.history.pending_count()
        suffix = f' · Captures pending: {pending}' if pending else ''
        scope = 'Today' if today_only else 'All dates'
        self.summary.set(f'{scope} · Live sightings: {counts.get(0, 0)} · Image tests: {counts.get(1, 0)}' + suffix)
        if self.tree is None or not self.tree.winfo_exists():
            return
        rows = self.history.list(include_tests=self.include_tests.get(), today_only=today_only)
        self.rows = {str(row.id): row for row in rows}
        existing = set(self.tree.get_children())
        wanted = {str(row.id) for row in rows}
        for removed in existing - wanted:
            self.tree.delete(removed)
        for index, row in enumerate(rows):
            values = (row.spotted, row.source_label, f'{row.score:.3f}')
            key = str(row.id)
            if key in existing:
                self.tree.item(key, values=values)
            else:
                self.tree.insert('', index, iid=key, values=values)
            self.tree.move(key, '', index)

    def show(self):
        if self.window is not None and self.window.winfo_exists():
            self.window.lift()
            return
        self.window = window = tk.Toplevel(self.root)
        window.title('Gem sighting history')
        window.transient(self.root)
        window.bind('<Destroy>', self.window_destroyed)
        window.geometry('880x480')
        window.minsize(660, 360)
        body = ttk.Frame(window, padding=18)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='Gems spotted', font=('Segoe UI', 14, 'bold')).pack(anchor='w')
        ttk.Label(body, textvariable=self.summary, style='Muted.TLabel').pack(anchor='w', pady=(5, 8))
        filters = ttk.Frame(body)
        filters.pack(fill='x')
        ttk.Checkbutton(filters, text='Include image tests', variable=self.include_tests,
                        command=self.refresh).pack(side='left')
        dates = ttk.Frame(filters)
        dates.pack(side='right')
        ttk.Radiobutton(dates, text='Today only', variable=self.date_scope, value='today',
                        command=self.refresh).pack(side='left', padx=(0,16))
        ttk.Radiobutton(dates, text='Show all', variable=self.date_scope, value='all',
                        command=self.refresh).pack(side='left')
        ttk.Label(body, text='Gem Spy: one screenshot per continuing encounter · Click Source to open\nCamera view = selected map area. Times use your PC clock. Gem Sniper saving cooldown: 20s.',
                  style='Muted.TLabel').pack(anchor='w', pady=(4, 10))
        table = ttk.Frame(body)
        table.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(table, columns=('time', 'source', 'score'), show='headings', selectmode='browse')
        for name, label, width in [('time', 'Spotted', 470), ('source', 'Source', 250),
                                   ('score', 'Match score', 100)]:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=width, minwidth=80)
        scrollbar = ttk.Scrollbar(table, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        self.tree.bind('<ButtonRelease-1>', self.source_click)
        self.tree.bind('<Motion>', self.source_hover)
        self.tree.bind('<Return>', lambda _: self.open_screenshot())
        footer = ttk.Frame(body)
        footer.pack(side='bottom', fill='x', pady=(8, 0), before=table)
        ttk.Label(footer, textvariable=self.status, style='Muted.TLabel', wraplength=620).pack(anchor='w')
        row = ttk.Frame(footer)
        row.pack(fill='x', pady=(4,0))
        ttk.Button(row, text='Open screenshot', command=self.open_screenshot).pack(side='left', padx=(0,8))
        ttk.Button(row, text='Edit location', command=self.edit_location).pack(side='left')
        ttk.Button(row, text='Remove selected', command=self.remove).pack(side='left', padx=8)
        ttk.Button(row, text='Close', command=window.destroy).pack(side='right')
        self.refresh()
        self.day_job = self.root.after(30_000, self.check_day)

    def window_destroyed(self, event):
        if event.widget == self.window:
            if self.day_job is not None:
                self.root.after_cancel(self.day_job)
                self.day_job = None
            self.window = self.tree = self.edit_window = None

    def check_day(self):
        self.day_job = None
        if self.window is None or not self.window.winfo_exists():
            return
        if datetime.now().date() != self.display_day:
            self.refresh()
        self.day_job = self.root.after(30_000, self.check_day)

    def edit_location(self):
        selected = self.tree.selection()
        row = self.history.get(int(selected[0])) if selected else None
        if row is None:
            self.status.set('Select a sighting first.')
            return
        if self.edit_window is not None and self.edit_window.winfo_exists():
            self.edit_window.lift()
            return
        win = self.edit_window = tk.Toplevel(self.window)
        win.title('Edit sighting location')
        win.transient(self.window)
        body = ttk.Frame(win, padding=18)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='Original spotting time: '+row.local_time).grid(row=0, column=0, columnspan=2, sticky='w', pady=(0,10))
        values = [tk.StringVar(win, value=row.zone or ''),
                  tk.StringVar(win, value='' if row.game_x is None else row.game_x),
                  tk.StringVar(win, value='' if row.game_y is None else row.game_y)]
        for index, (label, value) in enumerate(zip(('Zone', 'X', 'Y'), values), start=1):
            ttk.Label(body, text=label).grid(row=index, column=0, sticky='w', padx=(0,10), pady=4)
            entry = ttk.Entry(body, textvariable=value, width=32 if index==1 else 10)
            entry.grid(row=index, column=1, sticky='w', pady=4)
            if index==1:
                entry.focus_set()
        error = tk.StringVar(win)
        ttk.Label(body, textvariable=error, foreground='#f45bd0', wraplength=350).grid(row=4, column=0, columnspan=2, sticky='w', pady=8)
        def save():
            try:
                self.history.edit_location(row.id, *(value.get() for value in values))
            except (ValueError, sqlite3.Error) as exc:
                error.set(str(exc))
                return
            self.refresh()
            self.status.set('Location updated; original date, time and screenshot kept.')
            win.destroy()
        actions = ttk.Frame(body)
        actions.grid(row=5, column=0, columnspan=2, sticky='ew')
        ttk.Button(actions, text='Save location', command=save).pack(side='left')
        ttk.Button(actions, text='Cancel', command=win.destroy).pack(side='right')
        win.bind('<Return>', lambda _: save())
        win.bind('<Escape>', lambda _: win.destroy())

    def source_hover(self, event):
        row = self.rows.get(self.tree.identify_row(event.y))
        link = self.tree.identify_column(event.x) == '#2' and row and row.screenshot_path
        self.tree.configure(cursor='hand2' if link else '')

    def source_click(self, event):
        key = self.tree.identify_row(event.y)
        if key and self.tree.identify_column(event.x) == '#2':
            self.open_screenshot(key)

    def open_screenshot(self, key=None):
        selected = self.tree.selection()
        key = key or (selected[0] if selected else None)
        if key is None:
            return
        row = self.history.get(int(key))
        if row is None:
            return
        if not row.screenshot_path:
            detail = row.capture_note or ('Capture is still pending.' if row.capture_status == 'pending'
                                         else 'No screenshot was saved for this older sighting.')
            messagebox.showinfo('Sighting screenshot', detail, parent=self.window)
            return
        path = Path(row.screenshot_path).resolve()
        folder = (self.history.path.parent/'screenshots').resolve()
        if path.suffix.lower() != '.png' or not path.is_relative_to(folder):
            messagebox.showerror('Sighting screenshot', 'This image is outside the saved screenshots folder.', parent=self.window)
            return
        try:
            if not path.is_file():
                raise OSError(f'The screenshot is missing: {path}')
            os.startfile(str(path))
        except OSError as exc:
            messagebox.showerror('Could not open screenshot', str(exc), parent=self.window)

    def remove(self):
        selected = self.tree.selection()
        if not selected:
            return
        try:
            self.history.remove(int(selected[0]))
            self.refresh()
        except sqlite3.Error as exc:
            messagebox.showerror('Could not remove sighting', str(exc), parent=self.window)

