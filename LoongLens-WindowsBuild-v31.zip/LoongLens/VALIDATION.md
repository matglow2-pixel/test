# Verification — Loong Lens v31

The app targets Windows 10 (2004+) / Windows 11 and BlueStacks at default map
zoom. Local algorithm checks use pinned Python dependencies. The release
workflow runs the full tests, native GUI and input checks, and EXE build on
Windows. These checks do not run the live game.

## Route identity and coverage

The bundled route retains 76 checks and 83 spawn spots, in the approved order.
Original IDs 26, 51 and 72 are absent; #50 Loong Haven XIV is followed by #52
Reed Marsh. Groups #40 and #64 retain a/b views. Route edits, removed points,
extras and saved profiles retain their identities and persistence format.
The normal overlay retains the original 86 spawn locations.

The full-atlas simulation renders real atlas pixels and uses real overlapping
image registration. Every selected camera coordinate is checked against an
independent viewport transform. It requires exactly one camera selection per
saved view and no intermediate camera selections. Another check repeats two
complete passes with navigation carried between them, verifying 152 selections.
Initial/global poses are supplied by the simulated backend, so this does not
prove absolute recognition at every live viewpoint.

## Centre-start drag policy

Every new fixed-route hold begins at (285,530) in the 570x1029 reference. The
direction is centre minus the target's measured screen position. The stroke
keeps that direction, uses fast held movement, and checks screenshots at most
every 240 reference pixels. The cursor path ends at the first control or
viewport edge. If more movement is required, release occurs at rest before
another hold starts at the centre. The first verified visible target ends
movement; a fresh settled position and pre-click screenshot are still required.

The four unchanged blocked rectangles are title (28,54)-(191,98), legend
(422,58)-(554,231), zoom/portrait (490,641)-(569,923), and bottom controls
(3,929)-(551,1028). Game content bounds exclude window chrome and the outer
frame. No padding is added. Tests check blocked edges, immediately adjacent
available pixels, formerly blocked terrain and direct selection without drags.
Ray tests cover 24 directions, checking intermediate pixels and that each
stroke reaches its first exact exclusion/viewport boundary.

Transition regressions simulate #50 XIV to #52 Reed Marsh and the last
Celestship view #65 to #66 Mount Jade. They require one centre-start stroke,
correct up-left movement, no reverse recovery and the correct destination.
They do not establish the state of the user's custom 81-view route.

## Input and alignment failures

Native held movement has one down event, no release between screenshot checks,
a stationary 0.18-second endpoint hold and guaranteed release on exit. Windows
GetAsyncKeyState is checked before moving during a hold; a lost button stops
input. Tests cover a missing initial hold and release partway through motion.
The native Windows check uses actual delivered events on its own Tk window,
including F10 during a held movement. This is not a BlueStacks input test.

Fixed-route recovery recognises fresh frames in place and never sends guessed
reverse sweeps. A regression forces recognition failure after a 20-pixel
request and requires no recovery input, instead of the old 120-pixel reverse
sequence. A successful in-place recognition check retains the measured pose.
Legacy automatic-planner recovery tests remain separate.

Other checks cover stable-frame observation age, elapsed recognition time,
changed screenshots after release, fresh pre-click movement, map closure,
stalled motion, focus, coverage, moved/resized windows and F10 release.
Flat or unrecognisable terrain cannot authorize a guessed camera click.

## Portal restriction removal

Application code no longer has a coordinate blacklist, portal click validator,
planner portal filtering, runtime portal stop or portal warning in Edit route.
Tests select targets at (67.5,211), (70,211) and (184,138) directly without
substitution and retain saved framing at those coordinates. The default route
and spawn database are unchanged. Portal image recognition remains an optional
alignment aid, independently of whether the user hides portal icons.

## Existing behavior and packaging

Existing tests cover saved-route selection, Default protection, point removal,
undo/restore, extras, restart persistence and shared history. Detector tests
retain the three-hit/0.8-second confirmation, bounded late-candidate extension,
screenshot/history cooldown, one direct fresh gem click and optional photo hold.
Timer tests cover cumulative loop time, three recent passes and explicit reset.
The lock detector still classifies active targets from screenshot shading;
removed targets are absent from that loop and never selected for inspection.

The Windows workflow builds a new windowed one-file EXE, verifies all embedded
icon images, and checks frozen assets, the v31 GUI label and actual native input.
Fresh reports identify version 31. The complete folder includes the EXE,
source, assets, OCR models, launchers, tools, tests and validation reports.
Packaging extracts the completed 7z and verifies every payload file by SHA256.

The v30/v31 timings come from sequential runs on the same Windows machine with
simulated input/loading/detection and real atlas processing. Processing time,
modeled waits, per-view timings and movement counts are reported separately.
They are not measured live BlueStacks times. Live animation, loading, gesture
handling, map clamping, account locks and total run speed need game validation.


## v31 Gem Spy

The Windows workflow runs the full application suite and native Tk integration
with the real gem detector, persistent SQLite history and screenshot writer.
The camera backend is simulated; no live BlueStacks or game account is used.
The Spy integration exercises shared route and sensitivity settings, two passes
with continuing gems, one original photo per encounter, unique hourly totals,
retry without rescanning completed points, input ownership and F10 during retry.
The frozen GUI check verifies all three tab labels and the shared settings path.

Store and runner regressions cover history schema migration without losing old
rows, Gem Spy source and photo links, multiple gems, overlapping camera views,
restart persistence, date/hour boundaries, per-location appearance windows,
two separate clear absence checks and uncertain/loading frames. Capture recovery
links an already-written original photo or marks it interrupted. Timing patterns
require at least three bounded observations across two hours and expose supporting
windows; they do not claim exact spawn times or establish a game schedule.

The standard Sniper route is compared against v30 on the same Windows runner.
The v30 drag/exclusion and portal-removal regressions remain in the full suite.
Build reports identify this version and are included in the verified full archive.
