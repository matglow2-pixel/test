"""Build a self-contained Windows source zip without caches or user settings."""
from pathlib import Path
import argparse
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['GemSniping-Fixed-Route.png', 'GemSniping-Fixed-Route.svg', 'GemSniping-Fixed-Route.csv', 'README.md', 'VALIDATION.md', 'CHANGELOG-v26.md', 'CHANGELOG-v27.md', 'CHANGELOG-v28.md', 'CHANGELOG-v29.md', 'CHANGELOG-v30.md', 'CHANGELOG-v31.md', 'GEM_WATCH.md', 'RUN_LOONG_LENS.bat', 'RUN_GEM_WATCH.bat', 'requirements.txt',
         'LoongLens-WhiteIcon.ico', 'LoongLens-Original-Optimized.ico', 'desktop_entry.py',
         'loong_lens.py', 'camera_patrol.py', 'patrol_route.py', 'route_editor.py', 'route_profiles.py', 'gem_sniping_route.json', 'ui_theme.py', 'patrol_live.py', 'patrol_live_panel.py',
         'spy_history.py', 'spy_runner.py', 'spy_panel.py', 'sighting_service.py', 'RUN_GEM_SPY.bat', 'patrol_windows.py', 'patrol_input_check.py', 'resources.py', 'vision.py', 'tracker.py', 'pose.py',
         'win_overlay.py', 'sxs_atlas_tracker.py', 'atlas_metadata.json',
         'loong_haven_default_atlas.png', 'loong_title_template.png',
         'loong_haven_map_data.json', 'loong_haven_ingredients.json',
         'pytest.ini', 'gem_detector.py', 'gem_watch.py',
         'gem_watch_worker.py', 'tools/gem_examples.json', 'map_alignment.py',
         'terrain_alignment.py', 'loong_haven_terrain.json', 'pickup_history.py', 'history_panel.py',
         'gem_watch_panel.py', 'sighting_history.py', 'sighting_panel.py', 'launch_app.pyw',
         'location_ocr.py', 'sighting_capture.py', 'ocr_models/LICENSE.txt', 'ocr_models/NOTICE.txt',
         'ocr_models/SHA256.json', 'ocr_models/ch_PP-OCRv4_det_infer.onnx', 'ocr_models/ch_PP-OCRv4_rec_infer.onnx']

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT.parent/'LoongLens.zip')
    output = parser.parse_args().output
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            source = ROOT / name
            if source.suffix == '.bat':
                archive.writestr('LoongLens/' + name, source.read_text().replace('\n', '\r\n'))
            else:
                archive.write(source, 'LoongLens/' + name)
        for directory in ['tests', 'tools']:
            for source in sorted((ROOT / directory).glob('*.py')):
                archive.write(source, 'LoongLens/' + str(source.relative_to(ROOT)))
        for source in sorted((ROOT/'gem_templates').iterdir()):
            if source.suffix in ('.png','.txt'):
                archive.write(source,'LoongLens/'+str(source.relative_to(ROOT)))
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
    print(f'{output} ({output.stat().st_size:,} bytes)')

if __name__ == '__main__':
    main()
