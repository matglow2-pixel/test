"""Native Tk + real Spy/detector/storage; camera delivery uses a simulated backend."""
from datetime import datetime
import json
import logging
import os
from pathlib import Path
import sys
import tempfile
import traceback
import tkinter as tk
from tkinter import ttk
import cv2

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from test_spy_runner import SceneBackend
from test_live_patrol import Clock,Locator
from gem_detector import GemDetector
import loong_lens,patrol_live_panel,spy_panel


def main():
    if sys.platform!='win32':raise SystemExit('Run this native UI check on Windows.')
    temporary=tempfile.TemporaryDirectory(prefix='loonglens-spy-ui-')
    original_local=os.environ.get('LOCALAPPDATA');os.environ['LOCALAPPDATA']=temporary.name
    original=tk.Tk;panels={};errors=[];completed=[];state={}
    original_sniper=patrol_live_panel.LivePatrolPanel.__init__
    original_spy=spy_panel.SpyPanel.__init__
    def sniper(panel,*a,**kw):original_sniper(panel,*a,**kw);panels['sniper']=panel
    def spy(panel,*a,**kw):original_spy(panel,*a,**kw);panels['spy']=panel
    patrol_live_panel.LivePatrolPanel.__init__=sniper;spy_panel.SpyPanel.__init__=spy

    def descendants(widget):
        return [item for child in widget.winfo_children() for item in (child,*descendants(child))]

    class Window(original):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            def failed(kind,value,trace):errors.append(''.join(traceback.format_exception(kind,value,trace)));self.destroy()
            self.report_callback_exception=failed
            self.after(1800,self.begin);self.after(60000,self.destroy)
        def begin(self):
            sniper=panels['sniper'];spy=panels['spy'];services=sniper.services;services.sound.set(False)
            notebook=next(w for w in descendants(self) if isinstance(w,ttk.Notebook))
            assert [notebook.tab(t,'text') for t in notebook.tabs()]==['Map Tweaker','Gem Sniper','Gem Spy']
            assert 'gem_watch_panel' not in sys.modules,'Removed tab is still being instantiated/imported'
            old_mode=services.mode.get()
            sniper.show_settings();self.update_idletasks()
            settings=next(w for w in self.winfo_children() if isinstance(w,tk.Toplevel) and w.title()=='Gem Sniper settings')
            next(w for w in descendants(settings) if isinstance(w,ttk.Combobox)).set('Sensitive')
            next(w for w in descendants(settings) if isinstance(w,ttk.Button) and w.cget('text')=='Cancel').invoke()
            assert services.mode.get()==old_mode,'Cancel changed shared detection preferences'
            sniper.show_settings();self.update_idletasks()
            settings=next(w for w in self.winfo_children() if isinstance(w,tk.Toplevel) and w.title()=='Gem Sniper settings')
            next(w for w in descendants(settings) if isinstance(w,ttk.Combobox)).set('Sensitive')
            next(w for w in descendants(settings) if isinstance(w,ttk.Button) and w.cget('text')=='Save settings').invoke()
            assert services.mode.get()=='Sensitive'
            views=tuple(sniper.base_views[:2])
            sniper.routes.save_copy('Spy UI route',views);sniper.apply_route(views)
            clock=Clock();backend=SceneBackend(views,clock,fail_index=1);backend.cancel=spy.runner.cancel
            image=cv2.imread(str(ROOT/'gem_templates/gem_0.png'));h,w=image.shape[:2]
            backend.frame[400:400+h,240:240+w]=image
            runner=spy.runner;runner.backend_factory=lambda cancel:backend;runner.clock=clock
            runner.wall=lambda:datetime(2026,10,18,8).timestamp()+clock.now
            runner.detector=GemDetector();runner.locator=Locator(backend)
            from types import SimpleNamespace
            runner.title=SimpleNamespace(score=lambda f:float(f[0,0,0]))
            def wait(seconds):
                if runner.cancel.is_set():return True
                clock.now+=seconds;return runner.cancel.is_set()
            runner.retry_wait=wait
            emit=runner.emit
            def report(event):
                emit(event)
                if event['kind']=='spy_pass_complete' and event['run']>=2:runner.stop()
            runner.emit=report
            state.update(backend=backend,runner=runner,notebook=notebook)
            spy.start_button.invoke()
            assert services.owner=='spy' and sniper.route_box.instate(['disabled']) and sniper.edit_button.instate(['disabled'])
            notebook.select(notebook.tabs()[2]);self.after(100,self.first_done)
        def first_done(self):
            spy=panels['spy'];sniper=panels['sniper'];runner=state['runner'];backend=state['backend']
            if runner.running:self.after(100,self.first_done);return
            spy.drain();self.update_idletasks()
            assert sniper.services.owner is None and runner.snapshot()['gems']==2
            assert runner.detector.threshold==.70,'Spy did not use Sniper detection preferences'
            assert backend.selections==[0,1,1,0,1],backend.selections
            assert any(row['outcome']=='unclear' for row in spy.history.visits())
            assert len(spy.history.encounters())==2
            assert len(list((Path(temporary.name)/'LoongLens/screenshots').glob('*.png')))==2
            standard=sniper.services.sighting_history.list()
            assert len(standard)==2 and all(row.source=='Gem Spy' and row.screenshot_path for row in standard)
            spy.history_window.show('Sightings');self.update_idletasks()
            assert len(spy.history_window.tables['Sightings'].get_children())==2
            spy.history_window.show('Hourly');self.update_idletasks()
            table=spy.history_window.tables['Hourly']
            assert sum(int(table.item(k,'values')[3]) for k in table.get_children())==2
            spy.history_window.close()
            # F10 while automatically retrying must cancel, not create another
            # worker or reset encounters/timing.
            state['elapsed']=runner.snapshot()['elapsed'];backend.always_fail=True
            emit=spy.events.put
            def report(event):
                emit(event)
                if event['kind']=='status' and event['message'].startswith('Recovering'):sniper.emergency()
            runner.emit=report
            spy.start_button.configure(state='normal');spy.start_button.invoke();self.after(100,self.second_done)
        def second_done(self):
            spy=panels['spy'];sniper=panels['sniper'];runner=state['runner']
            if runner.running:self.after(100,self.second_done);return
            spy.drain();sniper.drain()
            assert runner.cancel.is_set() and sniper.services.owner is None
            assert runner.snapshot()['gems']==2 and runner.snapshot()['elapsed']>=state['elapsed']
            assert len(spy.history.encounters())==2
            completed.append(dict(passed=True,version=31,unique_gems=2,screenshots=2,
                                  passes=2,recovery_kept_progress=True,f10_stays_stopped=True))
            next(w for w in descendants(self) if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
    tk.Tk=Window
    try:loong_lens.main([],default_tab='spy')
    finally:
        tk.Tk=original;patrol_live_panel.LivePatrolPanel.__init__=original_sniper;spy_panel.SpyPanel.__init__=original_spy
        # Windows cannot remove the isolated directory while its FileHandler
        # owns loonglens.log, even after the app and SQLite stores are closed.
        logging.shutdown()
        if original_local is None:os.environ.pop('LOCALAPPDATA',None)
        else:os.environ['LOCALAPPDATA']=original_local
        temporary.cleanup()
    assert completed and not errors,errors
    (ROOT/'spy-ui-check.json').write_text(json.dumps(completed[0],indent=2)+'\n','utf-8')
    print('Native Spy UI: selected Sniper route, real detector, two passes, no duplicates, both histories, recovery and F10 passed.')


if __name__=='__main__':main()
