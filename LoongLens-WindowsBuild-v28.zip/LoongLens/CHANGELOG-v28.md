# v28 — reduce repeated map recognition

v27's narrower safe surface makes Acme Nexus (#46), for example, require a
short pan from Seal Stone (#45). That target otherwise lands in the protected
right-hand strip. The short pan remains necessary; this update reduces the
recognition work it triggers.

Map opening no longer adds a full fixed pause after expensive recognition: processing time counts toward the observation interval, while observations remain at least 0.15 seconds apart. Held cursor movement is faster, and progress checks can cover up to 240 reference pixels. The stationary 0.18-second endpoint hold before release remains. The extra 8-pixel target padding is removed as requested; input uses the marked boundary itself.

The last measured screenshot during a held drag now counts as the first map
alignment observation after the stationary endpoint pause. A fresh post-release
screenshot confirms it. If the map moved, recognition runs again and another
stable observation is required. A timestamp guard requires at least 0.15 seconds
between observations. Flat/unrecognisable frames still need actual recognition;
recovery and periodic absolute atlas refreshes are retained. Fresh pre-click
movement checks, loading waits, inspection and gem confirmation are retained.

The v27 safe input outline is unchanged. Map dragging and location selection
exclude the upper-left Loong Haven title, legend, entire right-hand strip,
shown character portrait bubble including its glow, zoom slider and bottom
Back/region controls. Regression checks explicitly cover the title and bubble.

The full-route comparison includes timing and matching/capture counts for each
route point. It requires the no additional held movements or map distance compared with v27 while
reducing repeated recognition and captures. These are simulated atlas results,
not measured live BlueStacks pass times.

Close the old app, extract the full folder and launch its LoongLens.exe. Saved
routes, settings, history and screenshots remain in %LOCALAPPDATA%\LoongLens.
The 7z includes the EXE, source, assets, models, tools, tests and validation.
