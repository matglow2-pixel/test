"""Build and round-trip verify the complete v28 Windows folder as one 7z."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

import py7zr

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exe',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if sys.platform!='win32':raise SystemExit('Assemble this package after the Windows build and native checks.')
    binary=args.exe.resolve();out=args.output.resolve()
    with binary.open('rb') as stream:
        if stream.read(2)!=b'MZ':raise SystemExit('Expected the newly built Windows EXE.')
    reports=[]
    for mode in ('self-check','gui-check','input-check'):
        report=ROOT/(mode+'.json')
        if json.loads(report.read_text('utf-8-sig')).get('passed') is not True:
            raise SystemExit(f'{mode} did not pass')
        reports.append(report)
    tests=ROOT/'tests-result.txt'
    result=re.findall(r'(\d+) passed(?:, (\d+) skipped)?',tests.read_text('utf-8-sig'))
    if not result:raise SystemExit('No successful test count found for this build.')
    passed,skipped=result[-1]
    reports.append(tests)
    comparisons={}
    for version in ('v27','v28'):
        path=ROOT/'artifacts'/f'benchmark-{version}.json'
        data=json.loads(path.read_text())
        if data.get('views_checked')!=76:raise SystemExit('Benchmark did not complete the default route.')
        comparisons[version]=data;reports.append(path)
    baseline=comparisons['v27'];latest=comparisons['v28']
    if latest.get('held_strokes',0)<1 or latest.get('held_moves',0)<latest['held_strokes']:
        raise SystemExit('Full-route benchmark did not exercise continuous held panning.')
    if latest['relative_matches']>=baseline['relative_matches'] or latest['captures']>=baseline['captures']:
        raise SystemExit('Observed-frame reuse did not reduce repeated recognition/captures.')
    if (latest['held_strokes']>baseline['held_strokes'] or latest['held_moves']>baseline['held_moves']
            or latest['pan_reference_pixels']>baseline['pan_reference_pixels']+1):
        raise SystemExit('The faster panning comparison added map movement.')
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='loonglens-v28-full-') as temporary:
        folder=Path(temporary);source_zip=folder/'source.zip'
        subprocess.run([sys.executable,str(ROOT/'tools/build_release.py'),'--output',str(source_zip)],check=True)
        with zipfile.ZipFile(source_zip) as archive:
            archive.extractall(folder)
        app=folder/'LoongLens'
        if (app/'patrol_adb.py').exists():raise SystemExit('Unexpected ADB backend in the v24-based package.')
        shutil.copy2(binary,app/'LoongLens.exe')
        validation=app/'validation';validation.mkdir()
        for report in reports:shutil.copy2(report,validation/report.name)
        info=dict(version=28,baseline=27,mouse_foundation=24,commit=os.environ.get('GITHUB_SHA','local build'),
                  windows_tests=dict(passed=int(passed),skipped=int(skipped or 0)),
                  exe_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                  speed_scope='76-view atlas simulation; not measured live BlueStacks performance')
        (app/'BUILD-INFO.json').write_text(json.dumps(info,indent=2)+'\n','utf-8')
        (app/'START-HERE-v28.txt').write_text(
            'Loong Lens v28 - reduce repeated map recognition after held movement\n\n'
            'Exit the old app completely. Extract this whole folder and run LoongLens.exe here.\n'
            'This build uses v24 Windows mouse control; keep BlueStacks visible and focused.\n\n'
            'Map panning keeps the button held between movement and screenshot checks.\n'
            'It starts with room to drag, stops when the next target is safely visible,\n'
            'holds the cursor still briefly, releases and verifies the position before clicking.\n'
            'Drag starts, cursor paths and targets stay inside the marked map surface.\n'
            'A window-edge re-anchor or alignment recovery can require another hold.\n\n'
            'This update reuses the last measured held frame as the first alignment observation.\n'
            'A fresh post-release frame confirms it after the stationary pause. Changed frames\n'
            'still require recognition and another stable observation before the location click.\n'
            'The Loong Haven title, portrait bubble, legend, right strip and bottom controls\n'
            'remain excluded from map panning and location selection.\n\n'
            'Open Edit route. Run route chooses the saved route that will be used for sniping.\n'
            'Default is protected. Save as creates variants such as Busy zones.\n'
            'Remove selected works on originals and extras. Use Undo remove or Restore originals.\n'
            'Save & reset checks applies edits. Switching routes resets pass progress and timing.\n'
            'Existing v24 edits are imported as My route; the old route file is retained.\n'
            'Removing points can omit spawn spots; totals are shown in the editor and panel.\n\n'
            'Default loading/inspection waits and gem confirmation are unchanged.\n'
            'Last view / Map-load / Inspect show timing on your PC. Offline Windows comparison\n'
            'and validation reports are included under validation; live game speed is not measured.\n'
            'Do not delete %LOCALAPPDATA%\\LoongLens; settings, screenshots and history stay there.\n',
            'utf-8')
        manifest={p.relative_to(app).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted(app.rglob('*')) if p.is_file()}
        (app/'PACKAGE-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n','utf-8')
        with py7zr.SevenZipFile(out,'w',filters=[{'id':py7zr.FILTER_LZMA2,'preset':6}]) as archive:
            archive.writeall(app,'LoongLens')
        with py7zr.SevenZipFile(out) as archive:archive.extractall(folder/'verified')
        for name,digest in manifest.items():
            if hashlib.sha256((folder/'verified/LoongLens'/name).read_bytes()).hexdigest()!=digest:
                raise RuntimeError(f'Archive verification failed: {name}')
    checksum=hashlib.sha256(out.read_bytes()).hexdigest()
    out.with_suffix('.7z.sha256').write_text(f'{checksum}  {out.name}\n','ascii')
    print(f'Verified complete Windows package: {out.name}, {out.stat().st_size:,} bytes, {len(manifest)+1} files')


if __name__=='__main__':main()
