"""Saved route identity, reduced totals and screenshot-guided fixed-order input."""
import contextlib
from dataclasses import replace
import json
import math
from types import SimpleNamespace
import threading
import cv2
import numpy as np
import pytest
from camera_patrol import Viewpoint
from patrol_live import LivePatrol,LiveRunner,LiveSettings
from patrol_route import load_fixed_route,route_pan_delta,clear_view_bounds,map_clickable
from resources import ROOT,ResourceStore
from pose import Match
from test_live_patrol import setup


@pytest.fixture(scope='module')
def route():return load_fixed_route(ResourceStore().data)


def test_saved_path_preserves_original_numbers_and_removes_exactly_the_requested_three(route):
    assert len(route)==76 and sum(len(v.cells) for v in route)==83
    assert [v.route_number for v in route]==[n for n in range(1,78) if n not in (26,51,72) for _ in range(2 if n in (40,64) else 1)]
    assert route[0].near_zone=='Emerald Corner'
    assert not ({(49,34),(121,163),(205,186)} & set().union(*(v.cells for v in route)))
    assert route[24].route_number==25 and route[25].route_number==27
    assert [v.route_number for v in route if v.route_number in (50,52)]==[50,52]
    assert [v.route_number for v in route if v.route_number in (71,73)]==[71,73]
    assert len(ResourceStore().data['gems'])==86  # Exclusions affect sniping, not history/overlay data.


def test_crowcry_click_is_left_of_the_portal_without_moving_the_spawn(route):
    from camera_patrol import camera_click_clear
    view=next(v for v in route if v.route_number==44)
    assert not camera_click_clear(68.25,211.05)  # Previous click opened the portal.
    assert view.x==66.25 and camera_click_clear(view.x,view.y)
    assert view.cells==frozenset({(67,210)})


def test_edge_groups_are_split_and_all_listed_spawns_have_vertical_context(route):
    for number,cells in ((40,{(75,175),(80,182)}),(64,{(134,251),(135,243)})):
        views=[v for v in route if v.route_number==number]
        assert [v.route_label for v in views]==[f'{number}a',f'{number}b']
        assert all(len(v.cells)==1 for v in views)
        assert set().union(*(v.cells for v in views))==cells
    for view in route:
        left,bottom,right,top=clear_view_bounds(view)
        assert all(left-1e-6<=x+.5<=right+1e-6 and bottom-1e-6<=y+.5<=top+1e-6 for x,y in view.cells)


def test_demonbind_camera_shifts_down_and_keeps_all_four_centres_clear_of_hud(route):
    from gem_detector import gameplay_mask
    view=next(v for v in route if v.route_number==12)
    assert view.y==68. and view.y<70.05 and len(view.cells)==4
    mask=gameplay_mask((1029,570,3))
    for x,y in view.cells:
        px=round(285+(x+.5-view.x)*570/6.7)
        py=round(514.5-(y+.5-view.y)*1029/12.1)
        assert mask[py,px]  # Upper dots remain outside the minimap/player HUD.
    # More ground is visible below the cluster, where offset gems may spawn.
    assert view.y-12.1/2<70.05-12.1/2-2


def test_fixed_order_does_not_choose_the_nearest_or_first_visible_remaining_point():
    engine,backend,events=setup()
    views=(Viewpoint(130.5,100.5,'First',frozenset({(130,100)}),1),
           Viewpoint(100.5,100.5,'Second',frozenset({(100,100)}),2))
    fixed=LivePatrol(views,engine.settings,engine.cancel,events.append,detector=engine.detector,
        locator=engine.locator,title=engine.title,clock=engine.clock)
    fixed.run(backend)
    assert [e['view'].route_number for e in events if e['kind']=='view']==[1,2]
    assert fixed.checked=={0,1} and any(i[0]=='drag' for i in backend.inputs)


@pytest.mark.parametrize('point',[(520,500),(10,500),(450,200),(280,100),(280,830)])
def test_gap_drag_pulls_toward_centre_instead_of_barely_exposing_target(point):
    delta=route_pan_delta(point,420)
    x,y=point[0]+delta[0],point[1]+delta[1]
    assert math.hypot(*delta)<=420.001
    assert map_clickable((x,y))
    assert math.hypot(*delta)==pytest.approx(min(420,math.dist(point,(285,500))))


def test_long_gap_drag_is_bounded_and_held_endpoints_avoid_controls():
    dx,dy=route_pan_delta((1100,-800),420)
    assert math.hypot(dx,dy)==pytest.approx(420)
    for x,y in [(285-dx/2,500-dy/2),(285+dx/2,500+dy/2)]:
        assert 75<=x<=495 and 290<=y<=710


def test_fixed_route_repeats_identical_order_and_can_resume_without_restarting_at_one():
    engine,backend,events=setup()
    views=tuple(replace(v,route_number=i+1) for i,v in enumerate(engine.views))
    def emit(event):
        events.append(event)
        if event['kind']=='pass_complete' and event['passes']==2:runner.stop()
    runner=LiveRunner(views,lambda cancel:contextlib.nullcontext(backend),emit,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title;backend.cancel=runner.cancel
    assert runner.start(LiveSettings(),auto=False);runner.thread.join(5)
    assert runner.checked=={0}
    assert runner.start(LiveSettings(),repeat=True);runner.thread.join(5)
    assert not runner.running and runner.passes==2
    assert [e['view'].route_number for e in events if e['kind']=='view']==[1,2,1,2]


def test_complete_fixed_route_uses_recentered_atlas_screenshots_and_no_transit_camera_clicks(route):
    cv2.setNumThreads(2)
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    class Backend:
        def __init__(self):
            self.center=(route[0].x,route[0].y);self.camera=self.center
            self.open=True;self.now=0.;self.visits=[];self.inputs=[];self.cache={}
            self.target=(123,(0,0,570,1029))
        def wait(self,t):self.now+=t
        def focus(self):pass
        def pose(self):return Match(12.45,285-self.center[0]*12.45,530+self.center[1]*12.45,20,0,[])
        def capture(self):
            if not self.open:return np.zeros((1029,570,3),np.uint8)
            key=tuple(self.center)
            if key not in self.cache:
                p=self.pose()
                f=cv2.warpAffine(atlas,np.float32([[1,0,p.tx],[0,1,p.ty-279*12.45]]),(570,1029))
                f[0,0]=255;self.cache[key]=f
            return self.cache[key]
        def click(self,p):
            self.inputs.append(('click',p))
            if not self.open:
                assert p==(480.,170.);self.open=True;self.center=self.camera;return
            if p==(64.,980.):self.open=False;return
            expected=route[len(self.visits)]
            known=self.pose();world=((p[0]-known.tx)/known.scale,(known.ty-p[1])/known.scale)
            assert math.dist(world,(expected.x,expected.y))<.4,(expected.route_number,world)
            assert map_clickable(p)
            self.visits.append(expected.route_number);self.camera=(expected.x,expected.y)
        def drag(self,a,b):
            self.inputs.append(('drag',a,b));self.wait(.4)
            assert math.dist(a,b)<=420.01
            for x,y in (a,b):assert 75<=x<=495 and 290<=y<=710
            self.center=(self.center[0]-(b[0]-a[0])/12.45,self.center[1]+(b[1]-a[1])/12.45)
        @contextlib.contextmanager
        def hold_drag(self,start):
            self.cursor=start;self.held=True
            try:
                self.wait(.025)
                yield
                self.wait(.18)
            finally:
                self.held=False;self.inputs.append(('drag',start,self.cursor))
        def drag_held_to(self,end):
            assert self.held
            for x,y in (self.cursor,end):assert 38<=x<=464 and 270<=y<=900
            self.wait(.004*max(1,math.ceil(math.dist(self.cursor,end)/40)))
            self.center=(self.center[0]-(end[0]-self.cursor[0])/12.45,
                         self.center[1]+(end[1]-self.cursor[1])/12.45)
            self.cursor=end
    backend=Backend();events=[]
    engine=LivePatrol(route,LiveSettings(),threading.Event(),events.append,
        detector=SimpleNamespace(detect=lambda *a,**kw:[]),
        locator=SimpleNamespace(locate=lambda f:backend.pose()),
        title=SimpleNamespace(score=lambda f:float(f[0,0,0]>0)),clock=lambda:backend.now)
    engine.run(backend)
    assert backend.visits==[v.route_number for v in route]
    assert len(engine.checked)==76
    # Exactly one camera selection per check; no B/R/removed-dot selections.
    assert sum(i[0]=='click' for i in backend.inputs)==76*3-1
    assert 0<sum(i[0]=='drag' for i in backend.inputs)<30
    assert engine.navigation.get('relative_updates',0)>0
    assert not any(e['kind']=='found' for e in events)


def test_pass_totals_finish_at_76_and_timer_stays_frozen(route):
    engine,backend,events=setup()
    runner=LiveRunner(route,lambda cancel:contextlib.nullcontext(backend),events.append,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title;backend.cancel=runner.cancel
    # Resume a pass at 75/76. The independent full-atlas test covers the whole
    # route; this case isolates the completion threshold and clock anchor.
    runner.checked.update(range(len(route)-1));backend.center=(route[-1].x,route[-1].y)
    runner.stats.start();backend.clock.now+=100
    assert runner.start(LiveSettings());runner.thread.join(5)
    if runner.running:runner.stop();runner.thread.join(3)
    assert len(runner.checked)==76 and runner.passes==1, events[-1]
    assert [e['view'].route_number for e in events if e['kind']=='view']==[77]
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=60
    assert elapsed>=100 and runner.stats.snapshot()['elapsed']==elapsed
    assert not runner.start(LiveSettings())


def test_fixed_route_centre_in_locked_shading_is_skipped_without_substitute_click():
    engine,backend,events=setup()
    view=Viewpoint(100.5,100.5,'Fixed',frozenset({(102,100)}),1)
    original=backend.capture
    def capture():
        f=original()
        if backend.open:f[470:535,250:320]=(44,47,46)
        return f
    backend.capture=capture
    fixed=LivePatrol((view,),engine.settings,engine.cancel,events.append,detector=engine.detector,
        locator=engine.locator,title=engine.title,clock=engine.clock)
    fixed.run(backend)
    assert fixed.checked==fixed.skipped=={0} and not backend.inputs


def test_map_recentring_again_before_fixed_click_stops_without_input():
    engine,backend,events=setup()
    fixed=LivePatrol((replace(engine.views[0],route_number=1),),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    original=backend.capture;move=[False]
    def capture():
        f=original()
        if move[0]:f[250:800,30:515]=200
        return f
    backend.capture=capture
    def emit(event):
        events.append(event)
        if event['kind']=='status' and event['message'].startswith('Clicking'):move[0]=True
    fixed.emit=emit
    with pytest.raises(RuntimeError,match='map moved'):fixed.run(backend)
    assert not backend.inputs and not fixed.checked


def test_custom_camera_on_known_portal_stops_instead_of_silently_changing_target():
    engine,backend,events=setup()
    view=Viewpoint(70.,211.,'Custom Crowcry',frozenset({(67,210)}),44)
    backend.center=(70.,211.)
    fixed=LivePatrol((view,),engine.settings,engine.cancel,events.append,detector=engine.detector,
        locator=engine.locator,title=engine.title,clock=engine.clock)
    with pytest.raises(RuntimeError,match='known portal'):fixed.run(backend)
    assert not backend.inputs and not fixed.checked
