"""Native Windows stubs used only by Linux GUI checks."""
import sys
import types
import tracker


class MapWorker:
    fps = 45
    def __init__(self, *args, **kwargs): self.paused = False
    def start(self): pass
    def close(self): pass
    def pause(self, paused): self.paused = paused
    def request_scan(self): pass
    def get_diagnostics(self): return None
    def get(self):
        return dict(open=False, match=None, rect=None, state='Map closed',
                    info='Open Loong Haven at default zoom', fps=45., scan_ms=0.)


class Overlay:
    hwnd = 1
    excluded_from_capture = True
    def hide(self): pass
    def close(self): pass
    def show_image(self, *args): pass


def install(find_visible=lambda: None, visible_at=lambda *args: True):
    import ctypes
    import tkinter as tk
    from PIL import Image, ImageTk
    ctypes.windll = types.SimpleNamespace(shell32=types.SimpleNamespace(
        SetCurrentProcessExplicitAppUserModelID=lambda value: 0))
    def iconbitmap(root, filename=None, **kwargs):
        if filename:
            root._smoke_icon_path = filename
            root._smoke_icon = ImageTk.PhotoImage(Image.open(filename).convert('RGBA').resize((32,32)))
            root.iconphoto(True, root._smoke_icon)
        return getattr(root, '_smoke_icon_path', '')
    tk.Tk.iconbitmap = iconbitmap
    tracker.VisualWorker = MapWorker
    sys.modules['win_overlay'] = types.SimpleNamespace(PixelAlphaOverlay=Overlay, find_emulator=lambda: None,
        find_visible_emulator=find_visible, window_visible_at=visible_at)
