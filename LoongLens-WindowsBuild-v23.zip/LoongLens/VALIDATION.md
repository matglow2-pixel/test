# Verification — Loong Lens v23

The app targets Windows 10 (2004+) / Windows 11 and BlueStacks at Loong Haven's default zoom. Linux checks use the pinned Python 3.12 environment and simulated desktop delivery. No live game input is sent by these checks.

## Fixed route and excluded totals

The bundled route follows the approved diagram's original order, beginning at Emerald Corner. Original route IDs 26 (Forsaken Lotus Pond), 51 (Jadetoad Isle) and 72 (Frosted Plain) are absent. The route has exactly 76 checks and 83 unique original spawn spots. Wide vertical groups #40 and #64 become separate a/b checks; every bundled centre has at least four tiles below it and 2.5 above it within the camera rectangle. Crowcry shifts left of its portal; Demonbind shifts lower, with four centres checked against the gameplay HUD mask. These margins do not guarantee coverage of arbitrary ten-tile spawn offsets. IDs are not renumbered; the default progress maximum is 76 and grows with saved extra camera views.

Route tests require this exact order even when a later target is closer or already visible, consistent repeated passes, resume from the first unfinished check, complete totals at 76, and a frozen completed-pass timer. The normal map overlay's original 86-location dataset and personal history are retained.

A full-route simulation renders actual atlas pixels, simulates map automatic recentering on reopening, uses real overlapping-screenshot registration and checks every camera click against an independent ground-truth viewport transform. It requires all 76 checks in order, exactly one camera selection per check, no selections at excluded points, fewer than 30 map drags and no B/R camera selections. Initial/global poses are supplied by the simulated backend; this is not a proof that absolute atlas recognition works at every viewpoint.

## Visible map click area

The old rectangle (X 32–510, Y 150–800) unnecessarily classified visible edge dots as offscreen. A shared eight-vertex polygon in 570×1029 reference coordinates now follows the supplied yellow outline, with a small inset, a legend notch and a zoom-control cutout. The lower boundary slopes upward toward the right above the map tabs. The patrol engine and route-map drag predictions use the same geometry. Parameterized engine checks place targets at independently specified screen pixels and require direct selection with no drag in the newly available top/left/right/bottom regions. Legend, zoom and tab targets must be panned into the map before selection. Nonfinite points are rejected. The full atlas route simulation verifies the complete fixed route with the expanded surface.

## Faster mouse dragging and alignment

Native drag sequence checks require one mouse-down held throughout movement, final movement to the requested endpoint, a stationary 0.18-second hold, and guaranteed mouse-up on cancellation. The motion now uses 4–18 waits of 0.02 seconds instead of 18 waits of 0.03 seconds. Input guard tests cover foreground loss, moved/resized windows, covered points and F10 cancellation.

Fixed-route drags pull offscreen targets toward the centre rather than just exposing an edge. Endpoints are centred around a safe map region. The initial pan is capped at 200 reference pixels until movement is measured; verified dense terrain can use up to 420 pixels, sparse terrain 220, and overshoot reduces later motion. Alignment requires fresh stable screenshots. Existing bounded reverse recovery retains progress and never clicks a target without recognition.

A reopened map uses its last selected camera to estimate overlap movement rather than assuming the previous map pose persists. Fixed-route absolute refreshes occur after at most six accepted relative alignments; failure to recognise overlap falls back to absolute recognition. A thread-local cache reuses source landmarks only when the exact reference image is immutable and its known pose matches. Destination screenshots are always processed freshly. A regression test checks one source extraction against two independently recognised destination images.

## Adjustable camera targets

The full-map editor supports selection, drag, zoom, pan, quarter-tile nudges, X/Y entry, reset and atomic local save. Add view after selected inserts a target one tile away, immediately after an original or extra view. Extras have stable IDs such as 12+1 or 40b+1, retain the parent group’s spawn cells, and support independent positioning and removal. Version 2 persistence saves the inserted order and imports previous version 1 positions without loss. Removing an extra reanchors subsequent extras when saved; Reset route to defaults removes them all. Progress and pass completion use the current route length while unique spawn totals deduplicate shared cells. Tests exercise multiple insertions, insertion before existing extras, restart persistence, removal, bad IDs/coordinates, no-drag nearby transitions, and repeated passes in the saved order. Adjustments preserve original spawn cells, fixed route identities and order. Opening the editor stops and waits for input delivery to finish; starting sniping is blocked until it closes. Save resets checked locations and pass statistics explicitly. Invalid saved data falls back to defaults without overwriting the file. Camera warnings flag portal overlap and listed centres outside the suggested clear area, while permitting intentional manual framing. At runtime a known portal target stops with an editor instruction instead of selecting a substituted point. Persistence tests reject malformed coordinates, unknown route IDs and changed spawn identities. Tk checks exercise real canvas dragging, extra insertion/removal, saving/reloading, unsaved cancellation and default reset. The Windows frozen GUI check opens the editor and exercises add/remove controls without saving diagnostics into user settings.

## Existing behavior

Coverage retains gem confirmation over three sightings and 0.8 seconds, a bounded late-candidate extension, the 20-second history/screenshot cooldown, the 30-second sound cooldown, screenshot-before-one-tile horizontal approach, optional five-second photo hold, and stopping on a find at the last view without restarting a loop. Pass timing continues through incomplete pauses/finds/errors and completes only at the reduced pass total.

Real Tk checks verify Map overlay, Gem Watch and Gem Sniping, Snipe/Loop Sniping/Stop controls, ready hotkeys without automatic startup input, the shared History window, settings, responsive layout, and the 76-check panel. Screenshot-driven checks exercise the actual detector, writer and SQLite history with simulated mouse delivery. Edited history coordinates must still move a map dot without resetting its 30-minute anchor.

## Windows release checks

The build workflow runs the full tests, builds the windowed one-file EXE, compares its embedded white badge against the supplied ICO, validates frozen atlas/OCR resources and opens the native GUI. The GUI check requires the exact fixed route, 76-check progress maximum, history editor/date filters, correct transparent window icon and clean shutdown. The native input check exercises guarded clicks/drags/hotkeys and capture exclusion on the app's own test window, not BlueStacks. Passing reports accompany the release downloads.

## Limits

The route order and world-coordinate destinations are fixed. Raw desktop pixel sequences can differ with map recentering, clamping and emulator size; input is based on the verified current map pose. Real game inertia, loading times, additional portal/icon interactions, account-specific locked regions and total pass speed still need BlueStacks validation. The updated map's dashed links predict likely drags from default-zoom geometry; they are not recorded live actions. Faster real-world completion is not guaranteed by a simulated route.
