"""The user's game day starts at 16:00 in Europe/Sofia, not midnight."""
from datetime import datetime,time,timedelta
from zoneinfo import ZoneInfo
import time as clock

ZONE=ZoneInfo('Europe/Sofia')


def game_day_window(now=None):
    local=datetime.fromtimestamp(clock.time() if now is None else now,ZONE)
    day=local.date() if local.hour>=16 else local.date()-timedelta(days=1)
    start=datetime.combine(day,time(16),ZONE).timestamp()
    end=datetime.combine(day+timedelta(days=1),time(16),ZONE).timestamp()
    return start,end
