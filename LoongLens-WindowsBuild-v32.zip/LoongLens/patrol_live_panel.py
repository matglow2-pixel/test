"""User-controlled real BlueStacks input and patrol status/history integration."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict,replace
import json
import queue
import time
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from pathlib import Path
import cv2
from PIL import Image,ImageDraw,ImageTk
from patrol_route import load_fixed_route
from patrol_live import LiveSettings,LiveRunner,load_live_config,LIVE_SETTINGS_VERSION
from patrol_windows import WindowsBackend,GlobalPatrolKeys
from route_profiles import RouteProfiles
from sighting_capture import SightingCapture
from resources import user_dir


class LivePatrolPanel:
    def __init__(self,parent,data,services,on_active=lambda active:None):
        self.parent=parent;self.root=parent.winfo_toplevel();self.services=services;self.on_active=on_active
        self.key=tk.StringVar(value='F8')
        self.status=tk.StringVar(value='Preparing live controls…')
        self.location=tk.StringVar(value='Fixed path starts at Emerald Corner. Route #26, #51 and #72 are excluded.')
        self.count=tk.StringVar(value='Preparing grouped camera checks…')
        self.pass_text=tk.StringVar(value='')
        self.performance=tk.StringVar(value='')
        self.stats_text=tk.StringVar(value='Time spent: 0:00\nGems found: 0')
        self.seen_text=tk.StringVar(value=f'{self.services.sighting_history.sniper_seen()}/5');self.seen_refresh=0.
        self.events=queue.Queue();self.keys=None;self.closed=False;self.busy=False
        self.job=None;self.photo=None;self.futures=[];self.editing=False;self.editor=None;self.switching=False
        self.path=user_dir()/'patrol-live-settings.json'
        try:
            config=json.loads(self.path.read_text('utf-8'))
            self.settings,key,migrated=load_live_config(config)
            self.key.set(key)
            if migrated:self.status.set('Updated Open map to the top-right minimap.')
        except (OSError,ValueError,KeyError,TypeError):self.settings=LiveSettings()
        self.settings=replace(self.settings,approach_gem=True)
        self.base_views=load_fixed_route(data);self.route_path=user_dir()/'camera-route-adjustments.json'
        self.routes=None;self.route_name=tk.StringVar(value='Default')
        warning=None
        try:
            self.routes=RouteProfiles(self.base_views,user_dir())
            views=self.routes.load(self.routes.active)
            self.route_name.set(self.routes.name(self.routes.active))
            if self.routes.active!=RouteProfiles.DEFAULT:self.route_path=self.routes.path(self.routes.active)
        except (OSError,ValueError,TypeError) as exc:
            self.routes=None;views=self.base_views;warning=f'Using Default; saved route list needs attention: {exc}'
        self.runner=LiveRunner(views,WindowsBackend,self.events.put)
        self.update_count()
        # Patrol captures already have their map location and bypass player OCR.
        self.capture_store=SightingCapture(user_dir(),reader=object())
        self.save_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='Patrol-screenshot')
        self.build_ui();self.bind_keys();self.job=self.root.after(100,self.poll)
        if warning:self.status.set(warning)

    def build_ui(self):
        from ui_theme import FONT, heading, card, row, CARD, MUTED
        body=ttk.Frame(self.parent,padding=(20,18));body.pack(fill='both',expand=True)
        title=ttk.Frame(body);title.pack(fill='x')
        ttk.Label(title,text='Gem Sniper',style='Title.TLabel').pack(side='left')
        self.seen_label=ttk.Label(title,textvariable=self.seen_text,style='Title.TLabel')
        self.seen_label.pack(side='right')
        ttk.Label(body,text='Check known gem spots without moving your character.',style='Muted.TLabel',wraplength=470).pack(anchor='w',pady=(3,14))
        controls=card(body, 'SNIPING CONTROLS')
        line=row(controls)
        ttk.Label(line,text='Ready when you are',style='Card.TLabel').pack(side='left')
        self.edit_button=ttk.Button(line,text='Edit route',command=self.show_route_editor,padding=(10,5));self.edit_button.pack(side='left',padx=10)
        ttk.Label(line,text='F10 · emergency stop',style='CardTitle.TLabel').pack(side='right')
        line=row(controls)
        ttk.Label(line,text='Snipe key',style='CardMuted.TLabel').pack(side='left')
        box=self.key_box=ttk.Combobox(line,textvariable=self.key,values=('F6','F7','F8','F9'),state='readonly',width=5)
        box.pack(side='left',padx=8);box.bind('<<ComboboxSelected>>',self.change_key)
        ttk.Button(line,text='Sniper settings',command=self.show_settings,padding=(10,7)).pack(side='right')
        self.history_button=ttk.Button(line,text='History',command=self.show_history,padding=(10,7))
        self.history_button.pack(side='right',padx=(0,6))
        line=row(controls)
        ttk.Label(line,text='Route',style='CardMuted.TLabel').pack(side='left')
        self.route_box=ttk.Combobox(line,textvariable=self.route_name,state='readonly',width=28)
        self.route_box.pack(side='left',fill='x',expand=True,padx=8)
        self.route_box.bind('<<ComboboxSelected>>',self.change_route)
        self.copy_route_button=ttk.Button(line,text='Save copy…',command=self.copy_route,padding=(10,5))
        self.copy_route_button.pack(side='right');self.refresh_routes()
        status=card(body)
        ttk.Label(status,textvariable=self.status,style='Status.TLabel',wraplength=450).pack(anchor='w')
        ttk.Label(status,textvariable=self.location,style='CardMuted.TLabel',wraplength=450).pack(anchor='w',pady=(5,7))
        ttk.Label(status,textvariable=self.count,style='CardMuted.TLabel').pack(anchor='w')
        ttk.Separator(status).pack(fill='x',pady=9)
        ttk.Label(status,textvariable=self.stats_text,style='Stats.TLabel').pack(anchor='w')
        ttk.Label(status,textvariable=self.pass_text,style='CardMuted.TLabel',wraplength=450).pack(anchor='w')
        ttk.Label(status,textvariable=self.performance,style='CardMuted.TLabel',wraplength=450).pack(anchor='w')
        self.progress=ttk.Progressbar(status,maximum=len(self.runner.views))
        self.progress.pack(fill='x',pady=(9,0))
        actions=ttk.Frame(body);actions.pack(fill='x',pady=(0,10))
        self.snipe=ttk.Button(actions,text='Snipe',style='Primary.TButton',command=lambda:self.start(False));self.snipe.pack(side='left')
        self.repeat=ttk.Button(actions,text='Loop Sniping',command=lambda:self.start(True));self.repeat.pack(side='left',padx=6)
        ttk.Button(actions,text='Stop (F10)',style='Stop.TButton',command=self.stop).pack(side='left')
        ttk.Button(actions,text='Reset checks',command=self.reset).pack(side='right')
        footer=ttk.Frame(body)
        footer.pack(side='bottom',fill='x',pady=(10,0))
        ttk.Label(footer,text='Snipe checks once. Loop Sniping repeats until a gem or F10.\nLocked areas are skipped. On a gem: save photo, click gem, stop.\nKeep BlueStacks visible. Click options: Sniping settings.',
                  style='Muted.TLabel',font=(FONT,9),wraplength=470).pack(anchor='w')
        viewport=tk.Frame(body,bg=CARD,height=220)
        viewport.pack(fill='both',expand=True);viewport.pack_propagate(False)
        self.preview=tk.Label(viewport,bg=CARD,fg=MUTED,text='Your latest camera check will appear here.')
        self.preview.pack(fill='both',expand=True)
        self.update_count();self.buttons()

    def show_history(self):
        if self.busy:self.runner.stop()
        self.services.flush_sightings()
        self.services.sighting_controls.show()

    def refresh_routes(self):
        items=self.routes.items() if self.routes is not None else [('default','Default')]
        self.profile_ids={name:ident for ident,name in items}
        self.route_box.configure(values=[name for _,name in items])
        if self.routes is not None:self.route_name.set(self.routes.name(self.routes.active))

    def apply_route(self,views):
        self.runner.views=tuple(views);self.runner.navigation.clear();self.reset()
        if self.routes is not None:
            self.refresh_routes()
            self.route_path=(self.routes.path(self.routes.active) if self.routes.active!=RouteProfiles.DEFAULT
                             else user_dir()/'camera-route-adjustments.json')
        self.status.set(f'Route: {self.route_name.get()}. Checks reset.')

    def change_route(self,event=None):
        ident=self.profile_ids.get(self.route_name.get())
        if self.routes is None or ident is None or self.editing or self.switching:return
        if ident==self.routes.active:return
        self.switching=True;self.runner.stop();self.buttons()
        self.status.set('Stopping sniping before changing routes…')
        def finish():
            if self.closed:return
            if self.runner.running:self.root.after(50,finish);return
            self.drain()
            try:self.apply_route(self.routes.activate(ident))
            except (OSError,ValueError,TypeError) as exc:
                self.refresh_routes();self.status.set(f'Could not change route: {exc}')
            finally:self.switching=False;self.buttons()
        finish()

    def ask_route_name(self,parent=None):
        return simpledialog.askstring('Save route copy','Name this route (Default stays unchanged):',
                                     parent=parent or self.root,initialvalue='My route' if self.routes and len(self.routes.items())==1 else '')

    def copy_route(self):
        if self.routes is None or self.busy or self.editing or self.switching:return
        name=self.ask_route_name()
        if name is None:return
        try:
            self.routes.save_copy(name,self.runner.views)
            self.apply_route(self.runner.views)
        except (OSError,ValueError,TypeError) as exc:messagebox.showerror('Could not save route',str(exc),parent=self.root)

    def show_route_editor(self):
        if self.editor is not None:self.editor.window.lift();return
        if self.editing or self.switching or self.services.owner=='spy':return
        self.editing=True;self.runner.stop();self.buttons()
        def open_when_stopped():
            if self.closed:return
            if self.runner.running:self.root.after(50,open_when_stopped);return
            self.drain()
            from route_editor import RouteEditor
            def close():
                self.editor=None;self.editing=False;self.buttons()
            def save(views):
                if self.routes is None:raise ValueError('Repair the saved route list before saving a route.')
                if self.routes.active==RouteProfiles.DEFAULT:
                    name=self.ask_route_name(self.editor.window)
                    if name is None:return False
                    self.routes.save_copy(name,views)
                else:self.routes.save(self.routes.active,views)
                self.apply_route(views)
                self.status.set('Camera targets saved. Checks reset; the next pass uses your adjusted route.')
            def select_profile(name):
                if self.routes is None:raise ValueError('Saved routes are unavailable.')
                ident=next((ident for ident,label in self.routes.items() if label==name),None)
                if ident is None:raise ValueError('Unknown saved route.')
                views=self.routes.activate(ident);self.apply_route(views)
                return views
            def save_copy(views):
                if self.routes is None:raise ValueError('Saved routes are unavailable.')
                name=self.ask_route_name(self.editor.window)
                if name is None:return None
                self.routes.save_copy(name,views);self.apply_route(views)
                return self.routes.name(self.routes.active),views
            self.editor=RouteEditor(self.root,self.base_views,self.runner.views,save,close,
                route_choices=lambda:[name for _,name in self.routes.items()] if self.routes else ['Default'],
                active_route=self.route_name.get(),on_route_change=select_profile,on_save_copy=save_copy)
        open_when_stopped()

    def buttons(self):
        available=self.services.owner in (None,'sniper')
        ready=self.keys is not None and available and not self.busy and not self.editing and not self.switching
        for button in (self.snipe,self.repeat):button.configure(state='normal' if ready else 'disabled')
        self.route_box.configure(state='readonly' if self.services.owner!='spy' and self.routes is not None and not self.editing and not self.switching else 'disabled')
        self.copy_route_button.configure(state='normal' if self.services.owner is None and self.routes is not None and not self.busy and not self.editing and not self.switching else 'disabled')

        self.edit_button.configure(state='normal' if self.services.owner!='spy' and not self.editing else 'disabled')
        self.key_box.configure(state='readonly' if self.services.owner!='spy' else 'disabled')

    def bind_keys(self):
        self.stop(silent=True)
        if self.keys is not None:self.keys.close();self.keys=None
        try:
            self.keys=GlobalPatrolKeys(lambda:self.events.put(dict(kind='advance')),
                self.emergency,key=self.key.get())
            self.status.set(f'Ready. {self.key.get()} starts the fixed path; F10 stops.')
        except Exception as exc:
            self.status.set(str(exc))
            messagebox.showerror('Live controls unavailable',str(exc),parent=self.root)
        self.buttons();self.save_config()

    def change_key(self,event=None):
        self.bind_keys()

    def emergency(self):
        self.runner.stop()  # Called directly on the hotkey thread, without Tk delay.
        if getattr(self,'spy_stop',None):self.spy_stop()
        self.events.put(dict(kind='panic'))

    def start(self,repeat=False):
        if self.keys is None or self.busy or self.editing or self.switching:return
        if not repeat and len(self.runner.checked)>=len(self.runner.views):
            self.status.set('Pass complete. Use Reset checks to start a new timed pass.');return
        if not self.services.acquire('sniper'):
            self.status.set('Stop Gem Spy before starting Gem Sniper.');return
        self.runner.cooldown['last']=max(self.runner.cooldown['last'],self.services.last_sighting)
        self.runner.cooldown['sound']=max(self.runner.cooldown.get('sound',-float('inf')),self.services.last_sound)
        settings=LiveSettings(self.settings.map_open,self.settings.map_close,
            self.settings.settle_seconds,self.settings.inspect_seconds,
            {'Conservative':.84,'Balanced':.77,'Sensitive':.70}[self.services.mode.get()],self.services.mask_hud.get(),True)
        
        self.on_active(True);self.busy=True;self.buttons()
        if not self.runner.start(settings,auto=True,repeat=repeat):
            self.busy=False;self.services.release('sniper');self.on_active(False);self.buttons()

    def stop(self,silent=False):
        self.runner.stop()
        if not silent:self.status.set('Stop requested. Mouse input is being released.')

    def reset(self):
        if self.busy:
            self.status.set('Stop patrol before resetting its checked locations.');return
        if not self.runner.reset_checks():
            self.status.set('Wait for sniping to stop before resetting checks.');return
        self.pass_text.set('');self.performance.set('');self.stats_text.set(self.runner.stats.text());self.update_count()
        self.status.set('Checks reset.')

    def update_count(self):
        views=self.runner.views
        checked=self.runner.checked.copy()
        covered=set().union(*(views[i].cells for i in checked)) if checked else set()
        total=set().union(*(view.cells for view in views))
        if hasattr(self,'progress'):self.progress.configure(value=len(checked),maximum=len(views))
        all_spots=set().union(*(view.cells for view in self.base_views))
        self.count.set(f'Processed: {len(self.runner.checked)} / {len(views)} views · Locked skips: {len(self.runner.skipped)}\nSpawn spots processed: {len(covered)} / {len(total)} · Omitted: {len(all_spots-total)}')

    def show_frame(self,frame,boxes=()):
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));pen=ImageDraw.Draw(image)
        for box in boxes:pen.rectangle((box.x,box.y,box.x+box.width,box.y+box.height),outline='#f45bd0',width=3)
        image.thumbnail((440,max(80,min(240,self.preview.winfo_height()-8))));self.photo=ImageTk.PhotoImage(image)
        self.preview.configure(image=self.photo,text='')

    def drain(self):
        while True:
            try:event=self.events.get_nowait()
            except queue.Empty:break
            kind=event['kind']
            if kind=='advance':
                if not self.closed:self.start(False)
            elif kind=='panic':self.status.set('F10 emergency stop.')
            elif kind=='status':self.status.set(event['message'])
            elif kind=='view':
                view=event['view']
                self.location.set(f'{"Route #"+view.route_label+" · " if view.route_number else ""}{view.near_zone} ({int(view.x)},{int(view.y)}) • {len(view.cells)} spawn spot(s) in this view')
            elif kind=='frame':self.show_frame(event['frame'],event['detections'])
            elif kind=='checked':self.update_count()
            elif kind=='view_timing':
                suffix=' · locked skip' if event['skipped'] else ''
                self.performance.set(f"Last view: {event['total_seconds']:.1f}s · Map/load {event['map_seconds']:.1f}s · Inspect {event['inspect_seconds']:.1f}s{suffix}")
            elif kind=='pass_complete':
                times=[]
                for run in event['recent_passes']:
                    minutes,seconds=divmod(int(run['elapsed']),60)
                    times.append(f"#{run['number']} {minutes}:{seconds:02d}")
                self.pass_text.set(f"Passes completed: {event['passes']}\nLast 3 runs: "+' · '.join(times));self.update_count()
            elif kind=='pass_started':self.update_count()
            elif kind=='found':
                self.status.set('GEM FOUND — saving the scene, then clicking the gem once…');self.seen_refresh=0.
                if event.get('seen_id'):
                    self.services.sighting_history.mark_sniper_seen(event['seen_id'],event['seen_at'])
                if self.services.sound.get() and event.get('sound',True):
                    self.services.last_sound=self.runner.cooldown.get('sound',self.services.last_sound);self.services.play_sound()
                if event['event'] is not None:
                    self.services.pending_sightings.append(event['event'])
                    self.services.last_sighting=self.runner.cooldown['last']
                else:self.status.set('Gem found — stopped. History is within the 20-second cooldown.')
            elif kind=='capture':
                captured_at=event.get('captured_at',__import__('time').time())
                self.futures.append((self.save_pool.submit(self.capture_store.save,event['event'],event['frame'],captured_at),event['event']))
            elif kind=='sighting':self.services.pending_sightings.append(event['event'])
            elif kind=='finished':
                self.services.release('sniper')
                self.busy=False;self.on_active(False);self.buttons()
                self.status.set(event['message'])
        waiting=[]
        for future,event in self.futures:
            if not future.done():waiting.append((future,event));continue
            try:self.services.pending_sightings.append(future.result())
            except Exception as exc:self.services.pending_sightings.append(self.capture_store.unavailable(event,str(exc),'save_error'))
        self.futures=waiting
        self.services.flush_sightings()

    def poll(self):
        self.job=None
        if self.closed:return
        try:
            self.drain()
            self.stats_text.set(self.runner.stats.text())
            if time.time()>=self.seen_refresh:
                self.seen_text.set(f'{self.services.sighting_history.sniper_seen()}/5');self.seen_refresh=time.time()+1
        except Exception:
            import logging
            self.runner.stop();logging.exception('Live patrol panel update failed')
            self.status.set('Patrol stopped after a display error; see loonglens.log.')
        self.job=self.root.after(100,self.poll)

    def save_config(self):
        try:
            tmp=self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps(dict(version=LIVE_SETTINGS_VERSION,settings=asdict(self.settings),key=self.key.get()),indent=2),'utf-8')
            tmp.replace(self.path)
        except OSError:
            import logging
            logging.exception('Could not save patrol settings')

    def show_settings(self):
        if self.busy or self.services.owner is not None:
            self.status.set('Stop Gem Sniper and Gem Spy before changing settings.');return
        win=tk.Toplevel(self.root);win.title('Gem Sniper settings');win.transient(self.root)
        body=ttk.Frame(win,padding=18);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Map button positions in the 570×1029 reference screenshot.',font=('Segoe UI',10,'bold')).grid(row=0,column=0,columnspan=3,sticky='w')
        ttk.Label(body,text='Open map: click the round minimap in the top-right during gameplay.\nFor Back: manually open the large map first, then pick its Back button.',style='Muted.TLabel').grid(row=1,column=0,columnspan=3,sticky='w',pady=8)
        fields={}
        for row,name,label in ((2,'map_open','Open map (minimap)'),(3,'map_close','Map Back button')):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=6)
            field=ttk.Entry(body,width=15);field.insert(0,','.join(str(v) for v in getattr(self.settings,name)))
            field.grid(row=row,column=1,padx=8);fields[name]=field
            ttk.Button(body,text='Pick on screenshot',command=lambda f=field:self.pick_button(win,f)).grid(row=row,column=2)
        for row,name,label in ((4,'settle_seconds','Scene loading wait (seconds)'),(5,'inspect_seconds','Empty-view check (seconds)')):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=6)
            field=ttk.Entry(body,width=15);field.insert(0,str(getattr(self.settings,name)));field.grid(row=row,column=1,padx=8);fields[name]=field
        ttk.Label(body,text='On confirmed gem: always click its centre once, then stop.').grid(row=6,column=0,columnspan=3,sticky='w')
        detection_mode=tk.StringVar(value=self.services.mode.get())
        mask_interface=tk.BooleanVar(value=self.services.mask_hud.get())
        sound_alerts=tk.BooleanVar(value=self.services.sound.get())
        ttk.Label(body,text='Detection sensitivity').grid(row=7,column=0,sticky='w',pady=6)
        ttk.Combobox(body,textvariable=detection_mode,values=('Conservative','Balanced','Sensitive'),state='readonly',width=15).grid(row=7,column=1,sticky='w',padx=8)
        ttk.Checkbutton(body,text='Mask interface areas',variable=mask_interface).grid(row=8,column=0,columnspan=2,sticky='w')
        ttk.Checkbutton(body,text='Sound alerts',variable=sound_alerts).grid(row=8,column=2,sticky='w')
        ttk.Label(body,text='Gem Spy uses these settings and the selected route. It never clicks gems.',wraplength=480).grid(row=9,column=0,columnspan=3,sticky='w',pady=6)
        error=tk.StringVar();ttk.Label(body,textvariable=error,wraplength=500).grid(row=10,column=0,columnspan=3,sticky='w')
        def apply():
            try:
                points={name:tuple(float(v.strip()) for v in fields[name].get().split(',')) for name in ('map_open','map_close')}
                self.settings=LiveSettings(**points,settle_seconds=float(fields['settle_seconds'].get()),inspect_seconds=float(fields['inspect_seconds'].get()),approach_gem=True)
            except (TypeError,ValueError):error.set('Enter X,Y pairs inside 570×1029. Loading wait: 0.2–10s. Check: 1.2–10s.');return
            self.services.mode.set(detection_mode.get());self.services.mask_hud.set(mask_interface.get());self.services.sound.set(sound_alerts.get())
            self.services.save();self.save_config();win.destroy()
        ttk.Button(body,text='Save settings',command=apply).grid(row=11,column=0,sticky='w',pady=10)
        ttk.Button(body,text='Cancel',command=win.destroy).grid(row=11,column=2,sticky='e')

    def pick_button(self,parent,field):
        try:frame=WindowsBackend.peek()
        except Exception as exc:messagebox.showerror('Capture unavailable',str(exc),parent=parent);return
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));image.thumbnail((500,760))
        picker=tk.Toplevel(parent);picker.title('Click the button in this screenshot')
        photo=ImageTk.PhotoImage(image)
        canvas=tk.Canvas(picker,width=image.width,height=image.height,highlightthickness=0)
        canvas.pack();canvas.create_image(0,0,image=photo,anchor='nw');canvas.photo=photo
        def select(event):
            field.delete(0,'end');field.insert(0,f'{event.x*570/image.width:.1f},{event.y*1029/image.height:.1f}');picker.destroy()
        canvas.bind('<Button-1>',select)

    def close(self):
        if self.closed:return
        self.closed=True;self.runner.stop()
        if self.job is not None:self.root.after_cancel(self.job);self.job=None
        if self.keys is not None:self.keys.close();self.keys=None
        if self.runner.thread is not None:self.runner.thread.join(timeout=3)
        self.drain();self.save_pool.shutdown(wait=True);self.drain()
        self.capture_store.close();self.save_config()
