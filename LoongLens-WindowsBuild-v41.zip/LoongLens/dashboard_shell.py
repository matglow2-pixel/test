"""Sidebar navigation backed by the existing notebook pages and controllers."""
from tkinter import ttk
from ui_assets import gem_image,line_image


class Sidebar:
    def __init__(self,parent,notebook,on_exit):
        self.notebook=notebook;self.images=[];self.buttons=[]
        self.frame=ttk.Frame(parent,style='Sidebar.TFrame',width=160,padding=(6,14,6,8))
        self.frame.pack(side='left',fill='y');self.frame.pack_propagate(False)
        brand=ttk.Frame(self.frame,style='Sidebar.TFrame');brand.pack(fill='x',padx=6)
        art=gem_image(self.frame,28);self.images.append(art)
        ttk.Label(brand,image=art,style='Sidebar.TLabel').pack(side='left',padx=(0,5))
        ttk.Label(brand,text='Loong Lens',style='Logo.TLabel').pack(side='left')
        ttk.Label(self.frame,text='v41',style='Sidebar.TLabel').pack(anchor='w',padx=40,pady=(4,0))
        ttk.Label(self.frame,text='Loong Haven companion',style='Sidebar.TLabel',wraplength=130).pack(anchor='w',padx=8,pady=(8,12))
        ttk.Separator(self.frame).pack(fill='x',padx=6,pady=(0,12))
        for index,(title,kind) in enumerate((('Map Tweaker','map'),('Gem Sniper','target'),('Gem Spy','gem'))):
            icon=gem_image(self.frame,22) if kind=='gem' else line_image(self.frame,kind,22)
            self.images.append(icon)
            button=ttk.Button(self.frame,text='  '+title,image=icon,compound='left',style='Nav.TButton',
                command=lambda i=index:self.notebook.select(i))
            button.pack(fill='x',pady=3);self.buttons.append(button)
        ttk.Button(self.frame,text='Exit',command=on_exit).pack(side='bottom',fill='x',padx=6)
        ttk.Label(self.frame,text='F10 · Emergency stop',style='Sidebar.TLabel').pack(side='bottom',anchor='w',padx=6,pady=10)
        self.notebook.bind('<<NotebookTabChanged>>',self.changed,add='+')

    def changed(self,event=None):
        selected=self.notebook.index(self.notebook.select())
        for i,button in enumerate(self.buttons):button.configure(style='Selected.Nav.TButton' if i==selected else 'Nav.TButton')
