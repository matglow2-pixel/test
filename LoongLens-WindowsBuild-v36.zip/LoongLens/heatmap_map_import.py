"""Register original map screenshots to the world grid and preserve native detail."""
import hashlib
import json
import math
import os
from pathlib import Path
import uuid
import cv2
import numpy as np
from PIL import Image
from resources import ROOT

MAP_SETTINGS='spy-heatmap-map.json'


def map_features(rgb):
    h,w=rgb.shape[:2];factor=min(1.,1600/max(h,w))
    small=cv2.resize(rgb,None,fx=factor,fy=factor,interpolation=cv2.INTER_AREA) if factor<1 else rgb
    gray=cv2.cvtColor(small,cv2.COLOR_RGB2GRAY)
    mask=(small.max(axis=2)>40).astype(np.uint8)*255
    points,descriptors=cv2.SIFT_create(nfeatures=10000,contrastThreshold=.015).detectAndCompute(gray,mask)
    xy=np.array([p.pt for p in points],np.float32).reshape(-1,2)/factor
    return xy,descriptors


def align_map(rgb,reference_features):
    points,descriptors=map_features(rgb);dest,reference=reference_features
    if descriptors is None or reference is None:raise ValueError('Not enough map detail to align this image.')
    pairs=cv2.BFMatcher().knnMatch(descriptors,reference,k=2)
    good=[a for pair in pairs if len(pair)==2 for a,b in [pair] if a.distance<.72*b.distance]
    if len(good)<20:raise ValueError('Could not recognise this map image. Use original Loong Haven map screenshots.')
    source=np.float32([points[m.queryIdx] for m in good]);target=np.float32([dest[m.trainIdx] for m in good])
    affine,inliers=cv2.estimateAffinePartial2D(source,target,method=cv2.RANSAC,ransacReprojThreshold=5.,maxIters=5000,confidence=.999)
    if affine is None or inliers is None or int(inliers.sum())<20:raise ValueError('Map alignment is uncertain; the current map was kept.')
    if abs(math.degrees(math.atan2(affine[1,0],affine[0,0])))>.5:raise ValueError('Use upright map screenshots without perspective or rotation.')
    keep=inliers[:,0].astype(bool);source=source[keep];target=target[keep]
    if np.ptp(source,axis=0).min()<min(rgb.shape[:2])*.15:raise ValueError('Recognised area is too small to safely place this map.')
    # Fit axis-aligned scale/translation only. This keeps the map north-up and
    # avoids introducing rotation/shear or silently moving history locations.
    a=source-source.mean(axis=0);b=target-target.mean(axis=0)
    scale=float((a*b).sum()/(a*a).sum());offset=np.median(target-source*scale,axis=0)
    error=np.linalg.norm(source*scale+offset-target,axis=1)
    if not .2<=scale<=8 or float(np.median(error))>4 or np.percentile(error,90)>9:
        raise ValueError('Map alignment is not accurate enough; the current map was kept.')
    return np.float32([[scale,0,offset[0]],[0,scale,offset[1]]])


def stitch_maps(paths,reference_path=None,cancel=None):
    def check():
        if cancel is not None and cancel.is_set():raise RuntimeError('Map import cancelled.')
    check()
    paths=tuple(Path(p) for p in paths)
    if not 1<=len(paths)<=6:raise ValueError('Choose one whole map or up to six original map screenshots.')
    reference_path=Path(reference_path or ROOT/'loong_haven_default_atlas.png')
    with Image.open(reference_path) as image:reference=np.asarray(image.convert('RGB'))
    if reference.shape[:2]!=(3486,3486):raise ValueError('Unexpected bundled map dimensions.')
    features=map_features(reference);images=[];matrices=[];pixels=0
    for path in paths:
        check()
        with Image.open(path) as image:
            w,h=image.size;pixels+=w*h
            if w*h>16_000_000 or pixels>48_000_000 or min(w,h)<200:raise ValueError('Use original map images, at least 200 px per side and up to 16 megapixels each (48 total).')
            rgb=np.asarray(image.convert('RGB'))
        try:matrix=align_map(rgb,features)
        except ValueError as exc:raise ValueError(f'{path.name}: {exc}') from exc
        images.append(rgb);matrices.append(matrix)
    # Choose the finest supplied pixel density, not a stretched preview size.
    atlas_scale=min(float(m[0,0]) for m in matrices)
    edge=round(3486/atlas_scale)
    if not 400<=edge<=5600:raise ValueError('The original resolution is outside the supported 400–5600 pixel whole-map range.')
    output=np.full((edge,edge,3),(13,18,24),np.uint8);best=np.zeros((edge,edge),np.float32)
    for rgb,matrix in zip(images,matrices):
        check()
        h,w=rgb.shape[:2];yy,xx=np.indices((h,w),dtype=np.float32)
        # Prefer the middle of each screenshot, with hard pixel ownership so
        # overlapping lettering is never averaged into blurry double labels.
        weight=np.minimum.reduce((xx+1,w-xx,yy+1,h-yy))
        valid=cv2.morphologyEx((rgb.max(axis=2)>40).astype(np.uint8),cv2.MORPH_CLOSE,np.ones((9,9),np.uint8))
        weight[valid==0]=0
        transform=matrix*(edge/3486)
        warped=cv2.warpAffine(rgb,transform,(edge,edge),flags=cv2.INTER_LANCZOS4)
        quality=cv2.warpAffine(weight,transform,(edge,edge),flags=cv2.INTER_LINEAR)
        use=quality>best;output[use]=warped[use];best[use]=quality[use]
    covered=cv2.resize((reference.max(axis=2)>40).astype(np.uint8),(edge,edge),interpolation=cv2.INTER_NEAREST)!=0
    completeness=float(((best>0)&covered).sum()/max(1,covered.sum()))
    if completeness<.86:raise ValueError(f'These images cover only {completeness:.0%} of the map. Choose all overlapping parts of the whole map.')
    check()
    return Image.fromarray(output),dict(width=edge,height=edge,world_size=280,source_count=len(paths))


def load_map(folder):
    folder=Path(folder);metadata=folder/MAP_SETTINGS
    if metadata.exists():
        try:
            info=json.loads(metadata.read_text('utf-8'));path=(folder/info['image']).resolve()
            if not path.is_relative_to(folder.resolve()) or not path.name.startswith('spy-map-') or path.suffix!='.png':raise ValueError('Invalid saved map path')
            if info['world_size']!=280 or not 400<=info['width']<=5600 or info['height']!=info['width']:raise ValueError('Invalid saved map size')
            if hashlib.sha256(path.read_bytes()).hexdigest()!=info['sha256']:raise ValueError('Saved map checksum mismatch')
            with Image.open(path) as image:
                if image.size!=(info['width'],info['height']):raise ValueError('Saved map size mismatch')
                return image.convert('RGB'),info
        except (OSError,ValueError,KeyError,TypeError,Image.DecompressionBombError):pass
    with Image.open(ROOT/'loong_haven_default_atlas.png') as image:base=image.convert('RGB')
    return base,dict(width=base.width,height=base.height,world_size=280,source_count=0)


def save_map(folder,image,metadata):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    generation=uuid.uuid4().hex;path=folder/f'spy-map-{generation}.png';temporary=folder/f'spy-map-{generation}.json.tmp'
    try:
        image.save(path,'PNG')
        info=dict(metadata,image=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        temporary.write_text(json.dumps(info,indent=2)+'\n','utf-8');os.replace(temporary,folder/MAP_SETTINGS)
    except Exception:
        path.unlink(missing_ok=True);temporary.unlink(missing_ok=True);raise
    # Keep earlier imports: an interrupted replacement must never erase a
    # usable map, and the originals remain available outside this app folder.
    return info
