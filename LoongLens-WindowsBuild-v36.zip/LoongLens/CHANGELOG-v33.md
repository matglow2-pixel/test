# v33 — map-settling recovery and daily gem collection

- Late movement after a map drag no longer immediately stops the fixed route.
  Reuse the pre-click screenshot, recognise the settled map, recalculate the
  same world target and reveal it again if needed. Stable checks add no fixed
  wait or extra screenshot. Unrecognisable or continuously moving maps still
  stop without marking an unchecked location complete.
- Gem Sniper runs continuously until five sightings in the current game day
  or Stop/F10. Both start buttons and the hotkey use this daily loop.
- After each confirmed gem, save its photo and click its centre, wait 20
  cancellable seconds, select Emerald Corner (241,107), confirm and close
  the map, then click the gameplay centre to return the character.
- Return after the fifth find too, then stop without starting a sixth pass,
  including when the collection wait crosses the 16:00 game-day reset.
  Earlier finds restart at the selected route's first point with fresh map
  recognition. Total elapsed time, finds and completed-pass times are retained.
- The worker uses the same persistent seen ledger as the header/history with
  its own SQLite connections. Existing counts, screenshot updates and UI event
  replays cannot bypass or double-increment the goal. Already 5/5 blocks input
  before starting. The game day still resets at 16:00 Europe/Sofia.
- F10 interrupts collection and return, releases mouse input and never
  restarts the worker. An unconfirmed return camera sends no character click.
- Teal sighting dots last exactly 1 hour and 15 seconds (3,615 seconds) from
  the original sighting, with hour-aware countdown labels. Editing coordinates,
  screenshot completion and restarting the app retain the original deadline.
- Gem Spy remains observation-only, retains its separate encounter/hourly
  histories, and does not increment or stop at the Sniper daily goal.
- v32 native cursor guards, confirmed gem edge clicks, four map-control boxes
  with no padding, removed portal restrictions, route editing/profiles and
  all assets are retained in the newly built EXE and complete source folder.

Validation covers delayed map frames using actual atlas terrain; quota,
collection, restart, exact return and cancellation simulations; native Windows
UI/storage/detector integration; real Win32 input against a test window; the
frozen EXE; and complete archive extraction/hash verification. These checks do
not constitute a live BlueStacks game run. No private recordings are packaged.
