# Loong Lens v36 — sidebar dashboard

- Replaces the top tab strip with a left sidebar for Map Tweaker, Gem Sniper and Gem Spy.
- Gem Sniper now has separate controls and run-status cards, four statistics tiles, a clickable Daily gems card, a portrait preview on the right and a bottom action bar.
- Uses the existing transparent Loong Lens gem artwork for the brand, daily count and gem statistics. No generic diamond or substitute gem icons.
- Loop sniping is a checkbox beside Start sniping. It starts enabled, preserving continuous scanning. Turning it off finishes a route without automatically repeating an empty pass. Endless mode continues beyond the daily quota; Stop/F10 remains immediate.
- Live preview fits its available space, preserves aspect ratio and redraws from the original frame on resize.
- Map Tweaker and Gem Spy use matching cards, spacing and sidebar navigation. Spy retains its clickable all-history heatmap and original-image import.
- Existing obtained choices, daily counter, 16:00 Sofia reset, saved settings/routes, histories, 20-second collection and Emerald Corner return are retained.
- Live recognition, map navigation, detector and route data are unchanged from v35.

Windows validation includes source and frozen layouts at 1000×820, 1200×860 and 1440×940, sidebar navigation, preview aspect ratio, native Spy/import and Sniper persistence/endless checks, input delivery, the full test suite and full-route timing comparison. Game input in diagnostics is simulated; live BlueStacks performance is not measured.
