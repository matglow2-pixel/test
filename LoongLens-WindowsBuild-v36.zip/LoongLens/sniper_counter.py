"""Durable obtained-gem ledger; the game day starts at 16:00 Europe/Sofia."""
from datetime import datetime,time,timedelta
from zoneinfo import ZoneInfo
import time as clock
from contextlib import closing
from pathlib import Path
import sqlite3

ZONE=ZoneInfo('Europe/Sofia')


def game_day_window(now=None):
    local=datetime.fromtimestamp(clock.time() if now is None else now,ZONE)
    day=local.date() if local.hour>=16 else local.date()-timedelta(days=1)
    start=datetime.combine(day,time(16),ZONE).timestamp()
    end=datetime.combine(day+timedelta(days=1),time(16),ZONE).timestamp()
    return start,end


def initialise_counter(db):
    # Leave the original two-column ledger compatible with earlier packages.
    db.execute('CREATE TABLE IF NOT EXISTS sniper_seen_events(event_id TEXT PRIMARY KEY,seen_at REAL NOT NULL)')
    db.execute('CREATE INDEX IF NOT EXISTS sniper_seen_time ON sniper_seen_events(seen_at)')
    db.execute('CREATE TABLE IF NOT EXISTS sniper_obtained(event_id TEXT PRIMARY KEY,obtained INTEGER NOT NULL CHECK(obtained IN (0,1)))')
    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sightings'").fetchone():
        # Older versions may have saved the photo/history but not the daily
        # ledger. Recover those IDs without changing times or manual choices.
        db.execute("""INSERT OR IGNORE INTO sniper_seen_events(event_id,seen_at)
            SELECT event_id,seen_at FROM sightings WHERE event_id LIKE 'patrol:%' AND test_mode=0""")


class SniperQuota:
    """Each operation commits through its own connection, never a Tk connection."""
    limit=5
    collection_seconds=20.
    home=(241.,107.)

    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            with db:initialise_counter(db)

    def count(self,now=None):
        start,end=game_day_window(now)
        with closing(sqlite3.connect(self.path)) as db:
            return db.execute('''SELECT COUNT(*) FROM sniper_seen_events e
                LEFT JOIN sniper_obtained o ON o.event_id=e.event_id
                WHERE e.seen_at>=? AND e.seen_at<? AND COALESCE(o.obtained,1)=1''',(start,end)).fetchone()[0]

    def mark(self,event_id,stamp,event=None):
        if event is not None:
            if event['event_id']!=event_id or event['seen_at']!=stamp:raise ValueError('Sighting identity does not match its ledger entry.')
            from sighting_history import SightingHistory
            history=SightingHistory(self.path)
            try:history.record([event])
            finally:history.close()
        else:
            with closing(sqlite3.connect(self.path)) as db:
                with db:db.execute('INSERT OR IGNORE INTO sniper_seen_events VALUES(?,?)',(event_id,stamp))

    def set_obtained(self,event_id,value):
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                if not db.execute('SELECT 1 FROM sniper_seen_events WHERE event_id=?',(event_id,)).fetchone():
                    raise ValueError('This daily gem entry no longer exists.')
                db.execute('''INSERT INTO sniper_obtained VALUES(?,?)
                    ON CONFLICT(event_id) DO UPDATE SET obtained=excluded.obtained''',(event_id,bool(value)))

    def entries(self,today_only=True,now=None):
        with closing(sqlite3.connect(self.path)) as db:
            db.row_factory=sqlite3.Row
            has_history=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sightings'").fetchone()
            details='s.zone,s.game_x,s.game_y,s.screenshot_path,s.score' if has_history else 'NULL AS zone,NULL AS game_x,NULL AS game_y,NULL AS screenshot_path,NULL AS score'
            query=f'''SELECT e.event_id,e.seen_at,COALESCE(o.obtained,1) AS obtained,{details}
                FROM sniper_seen_events e LEFT JOIN sniper_obtained o ON o.event_id=e.event_id'''
            if has_history:query+=' LEFT JOIN sightings s ON s.event_id=e.event_id'
            parameters=()
            if today_only:
                query+=' WHERE e.seen_at>=? AND e.seen_at<?';parameters=game_day_window(now)
            query+=' ORDER BY e.seen_at DESC,e.event_id'
            return [dict(row,obtained=bool(row['obtained'])) for row in db.execute(query,parameters)]
