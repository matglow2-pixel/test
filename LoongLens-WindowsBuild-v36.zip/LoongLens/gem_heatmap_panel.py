"""Clickable map overview and a viewport-rendered zoom/pan heatmap window."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import threading
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
from PIL import Image,ImageTk
from gem_heatmap import HeatmapHistory,compose_map
from heatmap_map_import import load_map,stitch_maps,save_map


class ZoomMap:
    def __init__(self,parent,image):
        self.frame=ttk.Frame(parent);self.frame.pack(fill='both',expand=True)
        self.image=image;self.zoom=1.;self.fitted=True;self.photo=None;self.job=None;self.alive=True;self.last_x=None;self.last_y=None;self.on_zoom=lambda value:None
        self.canvas=tk.Canvas(self.frame,bg='#0d1218',highlightthickness=0,cursor='fleur')
        self.xbar=ttk.Scrollbar(self.frame,orient='horizontal',command=self.canvas.xview)
        self.ybar=ttk.Scrollbar(self.frame,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.scrolled_x,yscrollcommand=self.scrolled_y)
        self.frame.rowconfigure(0,weight=1);self.frame.columnconfigure(0,weight=1)
        self.canvas.grid(row=0,column=0,sticky='nsew');self.ybar.grid(row=0,column=1,sticky='ns');self.xbar.grid(row=1,column=0,sticky='ew')
        self.item=self.canvas.create_image(0,0,anchor='nw')
        self.canvas.bind('<Configure>',self.configured)
        self.canvas.bind('<MouseWheel>',self.wheel)
        self.canvas.bind('<Enter>',lambda e:self.canvas.focus_set())
        self.canvas.bind('<Button-4>',lambda e:self.zoom_at(1.25,e.x,e.y))
        self.canvas.bind('<Button-5>',lambda e:self.zoom_at(.8,e.x,e.y))
        self.canvas.bind('<ButtonPress-1>',self.begin_pan)
        self.canvas.bind('<B1-Motion>',lambda e:self.canvas.scan_dragto(e.x,e.y,gain=1))
        self.canvas.bind('<Double-Button-1>',lambda e:self.fit())
        self.canvas.bind('<Destroy>',self.destroyed)

    def destroyed(self,event):
        if event.widget!=self.canvas:return
        self.alive=False
        if self.job is not None:
            self.canvas.after_cancel(self.job);self.job=None
        self.photo=None

    def scrolled_x(self,*args):
        self.xbar.set(*args)
        if args!=self.last_x:self.last_x=args;self.schedule()

    def scrolled_y(self,*args):
        self.ybar.set(*args)
        if args!=self.last_y:self.last_y=args;self.schedule()

    def schedule(self):
        if self.alive and self.job is None:self.job=self.canvas.after(16,self.render)

    def geometry(self):
        w=max(1,self.canvas.winfo_width());h=max(1,self.canvas.winfo_height())
        iw=self.image.width*self.zoom;ih=self.image.height*self.zoom
        return w,h,max(0.,(w-iw)/2),max(0.,(h-ih)/2),max(w,iw),max(h,ih)

    def configured(self,event=None):
        if self.fitted:self.fit()
        else:self.update_bounds()

    def update_bounds(self):
        _,_,_,_,w,h=self.geometry();self.canvas.configure(scrollregion=(0,0,w,h));self.schedule()
        self.on_zoom(self.zoom)

    def fit(self):
        self.zoom=min(max(1,self.canvas.winfo_width())/self.image.width,max(1,self.canvas.winfo_height())/self.image.height)
        self.fitted=True;self.canvas.xview_moveto(0);self.canvas.yview_moveto(0);self.update_bounds()

    def set_image(self,image,refit=False):
        self.image=image
        if refit or self.fitted:self.fit()
        else:self.update_bounds()

    def zoom_at(self,factor,x=None,y=None):
        w,h,padx,pady,_,_=self.geometry();x=w/2 if x is None else x;y=h/2 if y is None else y
        px=(self.canvas.canvasx(x)-padx)/self.zoom;py=(self.canvas.canvasy(y)-pady)/self.zoom
        fit=min(w/self.image.width,h/self.image.height)
        self.zoom=max(min(fit,.05),min(8.,self.zoom*factor));self.fitted=False
        self.update_bounds();_,_,padx,pady,sw,sh=self.geometry()
        self.canvas.xview_moveto(max(0.,px*self.zoom+padx-x)/sw)
        self.canvas.yview_moveto(max(0.,py*self.zoom+pady-y)/sh);self.schedule()

    def begin_pan(self,event):
        self.canvas.focus_set();self.canvas.scan_mark(event.x,event.y)

    def wheel(self,event):
        self.zoom_at(1.25 if event.delta>0 else .8,event.x,event.y);return 'break'

    def render(self):
        self.job=None
        if not self.alive:return
        w,h,padx,pady,_,_=self.geometry();sx=self.canvas.canvasx(0);sy=self.canvas.canvasy(0)
        left=max(0,int((sx-padx)/self.zoom));top=max(0,int((sy-pady)/self.zoom))
        right=min(self.image.width,int((sx+w-padx)/self.zoom)+2)
        bottom=min(self.image.height,int((sy+h-pady)/self.zoom)+2)
        if right<=left or bottom<=top:self.canvas.itemconfigure(self.item,state='hidden');return
        crop=self.image.crop((left,top,right,bottom))
        # Never allocate the whole map at e.g. 800%: only the visible source
        # rectangle is resized to viewport pixels, preserving original detail.
        crop=crop.resize((max(1,round(crop.width*self.zoom)),max(1,round(crop.height*self.zoom))),Image.Resampling.LANCZOS)
        self.photo=ImageTk.PhotoImage(crop,master=self.canvas)
        self.canvas.itemconfigure(self.item,image=self.photo,state='normal');self.canvas.coords(self.item,padx+left*self.zoom,pady+top*self.zoom)


class HeatmapPreview:
    def __init__(self,parent,root,history,folder):
        self.root=root;self.folder=Path(folder);self.model=HeatmapHistory(history)
        self.base,self.metadata=load_map(self.folder);self.snapshot=self.model.snapshot()
        self.window=None;self.viewer=None;self.composite=None;self.composite_key=None
        self.closed=False;self.photo=None;self.resize_job=None;self.import_job=None;self.future=None;self.pool=None;self.import_cancel=threading.Event();self.overview=None;self.overview_source=None
        self.show_heat=tk.BooleanVar(root,value=True);self.summary=tk.StringVar(root);self.zoom_text=tk.StringVar(root)
        self.frame=ttk.Frame(parent);self.frame.pack(fill='both',expand=True)
        self.preview=tk.Label(self.frame,bg='#192635',cursor='hand2',takefocus=True)
        self.preview.pack(fill='both',expand=True)
        ttk.Label(self.frame,text='Gem sightings map · Click to open heatmap',style='Muted.TLabel').pack(anchor='center',pady=(6,0))
        self.preview.bind('<Button-1>',lambda _:self.show());self.preview.bind('<Return>',lambda _:self.show())
        self.preview.bind('<space>',lambda _:self.show());self.preview.bind('<Configure>',self.schedule_thumbnail)
        self.refresh(force=True)

    def schedule_thumbnail(self,event=None):
        if self.closed:return
        if self.resize_job is not None:self.root.after_cancel(self.resize_job)
        self.resize_job=self.root.after(60,self.thumbnail)

    def thumbnail(self):
        self.resize_job=None
        if self.closed:return
        size=(max(40,self.preview.winfo_width()-12),max(40,self.preview.winfo_height()-12))
        if self.overview_source is not self.base:
            self.overview=self.base.copy();self.overview.thumbnail((1200,1200),Image.Resampling.LANCZOS);self.overview_source=self.base
        picture=(self.base if max(size)>1200 else self.overview).copy();picture.thumbnail(size,Image.Resampling.LANCZOS)
        self.photo=ImageTk.PhotoImage(picture,master=self.preview);self.preview.configure(image=self.photo,text='')

    def heat_image(self):
        key=(self.snapshot.revision,id(self.base),self.show_heat.get())
        if key!=self.composite_key:
            self.composite=compose_map(self.base,self.snapshot,self.show_heat.get());self.composite_key=key
        return self.composite

    def refresh(self,force=False):
        if self.closed:return
        snapshot=self.model.snapshot();changed=force or snapshot.revision!=self.snapshot.revision
        self.snapshot=snapshot
        self.summary.set(f'All dates · {snapshot.mapped} mapped sightings · {snapshot.missing} without coordinates')
        if changed and self.viewer is not None:self.viewer.set_image(self.heat_image())
        if force:self.schedule_thumbnail()

    def show(self):
        if self.closed:return
        self.refresh()
        if self.window is not None and self.window.winfo_exists():self.window.lift();return
        win=self.window=tk.Toplevel(self.root);win.title('Gem sightings heatmap');win.geometry('1120x860');win.minsize(680,500)
        win.transient(self.root);win.protocol('WM_DELETE_WINDOW',self.close_window);win.bind('<Destroy>',self.window_destroyed)
        body=ttk.Frame(win,padding=12);body.pack(fill='both',expand=True)
        title=ttk.Frame(body);title.pack(fill='x')
        ttk.Label(title,text='Gem sightings heatmap',style='Heading.TLabel').pack(side='left')
        ttk.Label(title,textvariable=self.zoom_text,style='Muted.TLabel').pack(side='right')
        ttk.Label(body,textvariable=self.summary,style='Muted.TLabel').pack(anchor='w',pady=(5,8))
        controls=ttk.Frame(body);controls.pack(fill='x',pady=(0,8))
        self.zoom_out=ttk.Button(controls,text='−',width=3,command=lambda:self.viewer.zoom_at(.8));self.zoom_out.pack(side='left')
        self.zoom_in=ttk.Button(controls,text='+',width=3,command=lambda:self.viewer.zoom_at(1.25));self.zoom_in.pack(side='left',padx=4)
        ttk.Button(controls,text='Fit map',command=lambda:self.viewer.fit()).pack(side='left',padx=(0,10))
        ttk.Checkbutton(controls,text='Heatmap',variable=self.show_heat,command=self.toggle_heat).pack(side='left')
        self.import_button=ttk.Button(controls,text='Import map images…',command=self.import_images);self.import_button.pack(side='right')
        ttk.Button(controls,text='Save PNG…',command=self.export).pack(side='right',padx=8)
        ttk.Label(body,text='Mouse wheel to zoom · Drag to pan · Double-click to fit · Warmer = more recorded sightings',style='Muted.TLabel').pack(anchor='w',pady=(0,7))
        self.viewer=ZoomMap(body,self.heat_image());self.viewer.on_zoom=lambda scale:self.zoom_text.set(f'{scale*100:.0f}%')
        ttk.Label(body,text='Locations use the saved history coordinates/camera views. Image tests are excluded; missed gems remain included.',
                  style='Muted.TLabel',wraplength=1040).pack(anchor='w',pady=(8,0))
        self.note=tk.StringVar(win,value=f'Original map resolution: {self.base.width} × {self.base.height}')
        ttk.Label(body,textvariable=self.note,style='Muted.TLabel',wraplength=1040).pack(anchor='w',pady=(4,0))
        win.update_idletasks();self.viewer.fit();self.viewer.canvas.focus_set()
        if self.future is not None:self.import_button.configure(state='disabled')

    def toggle_heat(self):
        if self.viewer is not None:self.viewer.set_image(self.heat_image())

    def export(self):
        path=filedialog.asksaveasfilename(parent=self.window,title='Save full-resolution heatmap',defaultextension='.png',filetypes=[('PNG image','*.png')])
        if not path:return
        try:self.heat_image().save(path,'PNG')
        except OSError as exc:messagebox.showerror('Could not save map',str(exc),parent=self.window)

    def import_images(self):
        if self.future is not None:return
        paths=filedialog.askopenfilenames(parent=self.window,title='Choose the original map screenshots (one whole map or overlapping parts)',
            filetypes=[('Map images','*.png *.jpg *.jpeg *.webp'),('All files','*.*')])
        if paths:self.begin_import(paths)

    def begin_import(self,paths):
        if self.closed or self.future is not None:return
        if self.pool is None:self.pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='Spy-map-import')
        self.import_cancel.clear();self.future=self.pool.submit(stitch_maps,paths,cancel=self.import_cancel)
        if self.window is not None:
            self.note.set('Aligning original map images… The current map stays available.');self.import_button.configure(state='disabled')
        self.import_job=self.root.after(100,self.finish_import)

    def finish_import(self):
        self.import_job=None
        if self.closed:return
        if not self.future.done():self.import_job=self.root.after(100,self.finish_import);return
        try:
            image,metadata=self.future.result();self.metadata=save_map(self.folder,image,metadata);self.base=image
            self.composite_key=None;self.refresh(force=True)
            if self.viewer is not None:self.viewer.set_image(self.heat_image(),refit=True)
            if self.window is not None:self.note.set(f'Merged {metadata["source_count"]} original image(s) · {image.width} × {image.height} · Saved for next launch')
        except Exception as exc:
            if self.window is not None:self.note.set('Import failed; your previous map was kept.');messagebox.showerror('Map import',str(exc),parent=self.window)
        finally:
            self.future=None
            if self.window is not None:self.import_button.configure(state='normal')

    def window_destroyed(self,event):
        if event.widget==self.window:self.viewer=None;self.window=None

    def close_window(self):
        if self.window is not None:self.window.destroy();self.window=None;self.viewer=None

    def close(self):
        self.closed=True
        for job in (self.resize_job,self.import_job):
            if job is not None:self.root.after_cancel(job)
        self.import_cancel.set()
        if self.pool is not None:self.pool.shutdown(wait=True,cancel_futures=True)
        self.close_window();self.photo=None;self.composite=None
