"""Application artwork and a small, consistent set of navigation line icons."""
from PIL import Image,ImageDraw,ImageTk
from resources import ROOT


def gem_image(master,size=32):
    # The supplied transparent app artwork, never a replacement diamond/emoji.
    with Image.open(ROOT/'LoongLens-AppIcon-HD.png') as source:
        image=source.convert('RGBA')
    image=image.crop(image.getchannel('A').getbbox())
    image.thumbnail((size,size),Image.Resampling.LANCZOS)
    tile=Image.new('RGBA',(size,size));tile.alpha_composite(image,((size-image.width)//2,(size-image.height)//2))
    return ImageTk.PhotoImage(tile,master=master)


def line_image(master,kind,size=24,color='#a4bed9'):
    scale=3;im=Image.new('RGBA',(32*scale,32*scale));draw=ImageDraw.Draw(im)
    def line(points,width=1.8):draw.line([(round(x*scale),round(y*scale)) for x,y in points],fill=color,width=round(width*scale),joint='curve')
    def oval(box):draw.ellipse(tuple(round(v*scale) for v in box),outline=color,width=round(1.8*scale))
    if kind=='map':
        line([(3,7),(11,3),(21,7),(29,3),(29,25),(21,29),(11,25),(3,29),(3,7)])
        line([(11,3),(11,25)]);line([(21,7),(21,29)])
    elif kind=='target':
        oval((6,6,26,26));oval((12,12,20,20))
        for p in ([(16,1),(16,9)],[(16,23),(16,31)],[(1,16),(9,16)],[(23,16),(31,16)]):line(p)
    elif kind=='clock':
        oval((3,3,29,29));line([(16,8),(16,16),(22,20)])
    elif kind=='history':
        draw.arc((5*scale,4*scale,29*scale,28*scale),205,525,fill=color,width=5)
        line([(3,5),(3,13),(11,13)]);line([(17,9),(17,16),(22,19)])
    elif kind=='settings':
        oval((5,5,27,27));oval((12,12,20,20))
        for p in ([(16,1),(16,6)],[(16,26),(16,31)],[(1,16),(6,16)],[(26,16),(31,16)]):line(p)
    elif kind=='pin':
        oval((8,3,24,19));oval((13,8,19,14));line([(9,17),(16,29),(23,17)])
    elif kind=='reset':
        draw.arc((4*scale,4*scale,28*scale,28*scale),45,330,fill=color,width=5)
        line([(22,3),(29,8),(22,11)])
    elif kind=='play':
        draw.polygon([(10*scale,5*scale),(26*scale,16*scale),(10*scale,27*scale)],fill=color)
    elif kind=='stop':
        draw.rounded_rectangle((8*scale,8*scale,24*scale,24*scale),radius=2*scale,fill=color)
    return ImageTk.PhotoImage(im.resize((size,size),Image.Resampling.LANCZOS),master=master)
