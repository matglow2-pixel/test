from dataclasses import replace

import numpy as np
import pytest

from pickup_history import PickupHistory
from pose import Match
from resources import Renderer, ResourceStore, SIGHTING_COLOR
from sighting_history import SightingHistory


def event(identifier='live', **changes):
    return dict(dict(event_id=identifier, seen_at=1000., screen_x=10, screen_y=20, score=.95,
                     test_mode=False, zone='Loong Haven III', game_x=100, game_y=100,
                     capture_status='ready', captured_at=1005., screenshot_path='screenshots/gem.png'), **changes)


def scene(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event()])
    store=ResourceStore()
    store.points['gems']=np.empty((0,2))
    renderer=Renderer(store)
    pose=Match(12.45,250-100.5*12.45,460+100.5*12.45,20,0,[])
    return history,renderer,pose


def test_recent_live_coordinates_only_are_marked(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event(),event('test',test_mode=True,game_x=101),
        event('unknown',game_x=None,game_y=None),event('invalid',game_x=280),
        event('expired',seen_at=-3000),event('future',seen_at=1101)])
    rows=history.active_markers(now=1100)
    assert [row.event_id for row in rows]==['live']
    assert rows[0].label(1100)=='58:35' and rows[0].check_at==4615
    assert len(history.list(include_tests=True))==6
    history.close()


def test_sighting_dot_lasts_one_hour_and_fifteen_seconds_from_original_time(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event()])
    row=history.get(1)
    assert row.label(1000)=='1:00:15' and row.label(1015)=='1:00:00'
    assert row.label(1016)=='59:59'
    assert history.active_markers(now=2800)  # Survives the former 30-minute expiry.
    assert history.active_markers(now=4600)[0].label(4600)=='00:15'
    assert history.active_markers(now=4614.99)[0].label(4614.99)=='00:01'
    assert not history.active_markers(now=4615)
    assert history.get(1).seen_at==1000 and len(history.list())==1
    history.close()


def test_late_coordinates_and_edits_keep_original_deadline(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    pending=event(capture_status='pending',game_x=None,game_y=None,screenshot_path=None)
    history.record([pending])
    assert not history.active_markers(now=1006)
    history.record([event(captured_at=1005)])
    assert history.active_markers(now=1006)[0].label(1006)=='1:00:09'
    original=history.get(1)
    history.edit_location(1,'Autumnal Plain',76,152)
    marker=history.active_markers(now=1006.1)[0]
    assert (marker.marker_x,marker.marker_y)==(76,152)
    assert marker.seen_at==original.seen_at and marker.check_at==4615
    assert marker.captured_at==original.captured_at and marker.screenshot_path==original.screenshot_path
    assert marker.label(1300)=='55:15'
    history.close()


def test_deadline_survives_restart_and_expiry_keeps_history(tmp_path):
    path=tmp_path/'sightings.sqlite3'
    history=SightingHistory(path)
    history.record([event(seen_at=1000.25)])
    history.close()
    history=SightingHistory(path)
    assert history.active_markers(now=1300.25)[0].label(1300.25)=='55:15'
    assert history.active_markers(now=4615.2)[0].label(4615.2)=='00:01'
    assert not history.active_markers(now=4615.25)
    history.edit_location(1,'Loong Haven IX',78,48)
    assert not history.active_markers(now=4616)  # Editing does not restart an expired timer.
    assert len(history.list())==1
    history.close()


def test_same_coordinate_uses_latest_sighting_without_deleting_older_rows(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event('old'),event('new',seen_at=1010),event('other',game_x=120)])
    markers=history.active_markers(now=1100)
    assert {row.event_id for row in markers}=={'new','other'}
    new=next(row for row in markers if row.event_id=='new')
    history.edit_location(new.id,'Loong Haven V',110,100)
    assert {row.event_id for row in history.active_markers(now=1100.1)}=={'old','new','other'}
    assert len(history.list())==3
    history.close()


def test_removed_pending_sighting_is_not_recreated_by_its_screenshot(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event(capture_status='pending',game_x=None,game_y=None)])
    history.remove(1)
    history.record([event(),event(capture_status='pending',game_x=None,game_y=None)])
    assert not history.list() and not history.active_markers(now=1010)
    history.close()


def test_marker_queries_are_cached_but_coordinate_edits_refresh_immediately(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event()])
    selects=[]
    history.connection.set_trace_callback(lambda sql:selects.append(sql) if 'ROW_NUMBER()' in sql else None)
    history.active_markers(now=1100.1)
    history.active_markers(now=1100.9)
    assert len(selects)==1
    history.edit_location(1,'Loong Haven IX',78,48)
    assert history.active_markers(now=1100.95)[0].game_x==78
    assert len(selects)==2
    history.active_markers(now=1101)
    assert len(selects)==3
    history.close()


def test_sighting_marker_projection_and_countdown_cache(tmp_path):
    history,renderer,pose=scene(tmp_path)
    markers=history.active_markers(now=1000.1)
    image,counts,changed=renderer.render((570,1029),pose,{'gems':True},sighting_markers=markers,now=1000.1)
    assert changed and counts['gems']==1 and image.getpixel((250,460))[:3]==SIGHTING_COLOR
    cached,_,changed=renderer.render((570,1029),pose,{'gems':True},sighting_markers=markers,now=1000.9)
    assert cached is image and not changed
    _,_,changed=renderer.render((570,1029),pose,{'gems':True},sighting_markers=markers,now=1001.1)
    assert changed
    history.close()


def test_edited_coordinates_move_existing_dot_and_pan_tracks_it(tmp_path):
    history,renderer,pose=scene(tmp_path)
    original=history.get(1)
    renderer.render((570,1029),pose,{'gems':True},sighting_markers=history.active_markers(now=1100),now=1100)
    history.edit_location(1,'Loong Haven V',102,100)
    markers=history.active_markers(now=1100.1)
    image,counts,changed=renderer.render((570,1029),pose,{'gems':True},sighting_markers=markers,now=1100.1)
    assert changed and counts['gems']==1
    assert image.getpixel((275,460))[:3]==SIGHTING_COLOR
    assert not image.getpixel((250,460))[3]
    moved=replace(pose,tx=pose.tx+75,ty=pose.ty+20)
    image,_,_=renderer.render((570,1029),moved,{'gems':True},sighting_markers=markers,now=1100.1)
    assert image.getpixel((350,480))[:3]==SIGHTING_COLOR
    assert history.get(1).seen_at==original.seen_at
    history.remove(1)
    image,counts,_=renderer.render((570,1029),pose,{'gems':True},sighting_markers=history.active_markers(now=1100.2),now=1100.2)
    assert counts['gems']==0 and not np.asarray(image)[:,:,3].any()
    history.close()


@pytest.mark.parametrize('reason',['expired','layer_off','image_test','no_coordinates'])
def test_no_dot_for_expired_hidden_test_or_unknown_sighting(tmp_path,reason):
    history,renderer,pose=scene(tmp_path)
    marker=history.get(1)
    if reason=='image_test':marker=replace(marker,test_mode=True)
    if reason=='no_coordinates':marker=replace(marker,game_x=None)
    image,counts,_=renderer.render((570,1029),pose,{} if reason=='layer_off' else {'gems':True},
        sighting_markers=[marker],now=4615 if reason=='expired' else 1100)
    assert not np.asarray(image)[:,:,3].any() and counts['gems']==0
    history.close()


def test_manual_and_sighting_timers_with_same_id_do_not_share_cached_pixels(tmp_path):
    history,renderer,pose=scene(tmp_path)
    pickups=PickupHistory(tmp_path/'pickups.sqlite3')
    pickup=pickups.record(100,100,collected_at=1000)
    sighting=history.get(1)
    assert pickup.id==sighting.id
    blue,_,_=renderer.render((570,1029),pose,{'gems':True},pickup_markers=[pickup],now=1100)
    teal,counts,changed=renderer.render((570,1029),pose,{'gems':True},sighting_markers=[sighting],now=1100)
    assert changed and blue.getpixel((250,460))[:3]!=(teal.getpixel((250,460))[:3])
    _,counts,_=renderer.render((570,1029),pose,{'gems':True},pickup_markers=[pickup],sighting_markers=[sighting],now=1100)
    assert counts['gems']==1
    history.close();pickups.close()
