"""Exercise the production daily policy, real patrol selection and cancellable collection flow."""
import contextlib
from dataclasses import replace
from datetime import datetime
import math
import cv2
import pytest
from patrol_live import LiveRunner,LiveSettings
from sniper_counter import SniperQuota,ZONE,game_day_window
from sighting_history import SightingHistory
from test_live_patrol import setup


@pytest.fixture(scope='module',autouse=True)
def bounded_opencv_threads():
    previous=cv2.getNumThreads();cv2.setNumThreads(2)
    try:yield
    finally:cv2.setNumThreads(previous)


def collecting_runner(tmp_path,existing=0,stop_at=None,epoch=None):
    engine,backend,events=setup(positive=True)
    backend.center=(241.,107.)
    views=(replace(engine.views[0],x=241.,y=107.,cells=frozenset({(241,107)}),route_number=1),)
    quota=SniperQuota(tmp_path/'sightings.sqlite3')
    if epoch is None:epoch=datetime(2026,10,21,18,tzinfo=ZONE).timestamp()
    for i in range(existing):quota.mark('patrol:prior-'+str(i),epoch-60)
    times=[];selections=[];original_click=backend.click
    def click(point):
        if backend.open and point!=LiveSettings().map_close:
            selections.append((backend.center[0]+(point[0]-285)/12.45,
                               backend.center[1]-(point[1]-500)/12.45))
        times.append((point,engine.clock(),backend.open));original_click(point)
    backend.click=click
    def emit(event):
        events.append(event)
        if stop_at and stop_at(event):runner.stop()
    runner=LiveRunner(views,lambda cancel:contextlib.nullcontext(backend),emit,
                      clock=engine.clock,quota=quota,wall=lambda:epoch+engine.clock())
    backend.cancel=runner.cancel
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title
    return runner,backend,events,quota,times,selections


def run(runner):
    assert runner.start(LiveSettings(),repeat=True)
    runner.thread.join(15)
    if runner.running:runner.stop();runner.thread.join(3);pytest.fail('Daily collection worker did not finish')


def test_fifth_gem_waits_twenty_seconds_returns_to_exact_home_and_stops(tmp_path):
    runner,backend,events,quota,times,selected=collecting_runner(tmp_path,existing=4)
    run(runner)
    assert quota.count(runner.wall())==5
    gem=next(row for row in times if row[0]==(200,400) and not row[2])
    opener=next(row for row in times if row[0]==LiveSettings().map_open and row[1]>gem[1])
    assert opener[1]-gem[1]>=20
    assert len(selected)==2 and all(math.dist(point,(241,107))<.1 for point in selected)
    assert times[-1][0]==(285.,530.) and times[-1][2] is False
    assert '5/5' in events[-1]['message'] and 'Returned' in events[-1]['message']
    assert not any(e['kind']=='pass_started' for e in events)
    assert sum(e['kind']=='gem_clicked' for e in events)==1
    assert not runner.checked and not runner.navigation
    # Both the UI connection and a new worker see the same durable count.
    history=SightingHistory(quota.path)
    assert history.sniper_seen(runner.wall())==5
    history.close()
    assert SniperQuota(quota.path).count(runner.wall())==5


def test_gem_below_quota_returns_and_restarts_at_first_route_point_without_resetting_totals(tmp_path):
    runner,backend,events,quota,times,selected=collecting_runner(tmp_path,
        stop_at=lambda e:e['kind']=='gem_clicked' and quota.count(runner.wall())==2)
    run(runner)
    assert quota.count(runner.wall())==2 and runner.stats.snapshot()['gems']==2
    assert [e['index'] for e in events if e['kind']=='view']==[0,0]
    assert len([e for e in events if e['kind']=='returned_home'])==1
    assert any(e['kind']=='pass_started' and e.get('reason')=='gem_return' for e in events)
    assert selected==pytest.approx([(241,107)]*3)
    assert runner.stats.snapshot()['elapsed']>=20


def test_f10_during_collection_wait_never_opens_map_or_restarts(tmp_path):
    runner,backend,events,quota,times,_=collecting_runner(tmp_path,
        stop_at=lambda e:e['kind']=='status' and 'waiting 20 seconds' in e['message'])
    run(runner)
    assert runner.cancel.is_set() and quota.count(runner.wall())==1
    assert times[-1][0]==(200,400)
    assert not any(e['kind'] in ('returned_home','pass_started') for e in events)


@pytest.mark.parametrize('existing',[5,6])
def test_already_five_today_does_not_even_open_input_backend(tmp_path,existing):
    runner,backend,events,quota,times,_=collecting_runner(tmp_path,existing=existing)
    runner.backend_factory=lambda cancel:pytest.fail('Daily quota must stop before opening input')
    run(runner)
    assert not times and '5/5' in events[-1]['message']


def test_full_five_find_cycle_returns_after_every_find_and_never_starts_a_sixth(tmp_path):
    runner,backend,events,quota,times,_=collecting_runner(tmp_path)
    # Each collection cycle supplies a new gem at a different scene position.
    from types import SimpleNamespace
    runner.detector.detect=lambda *a,**kw:[SimpleNamespace(
        center=(200+runner.stats.snapshot()['gems']*5,400),score=.95,width=20)]
    run(runner)
    assert quota.count(runner.wall())==5 and runner.stats.snapshot()['gems']==5
    assert sum(e['kind']=='gem_clicked' for e in events)==5
    assert sum(e['kind']=='returned_home' for e in events)==5
    assert sum(e['kind']=='pass_started' for e in events)==4
    assert runner.stats.snapshot()['elapsed']>=100
    assert '5/5' in events[-1]['message']


def test_f10_during_return_camera_selection_sends_no_home_character_click(tmp_path):
    runner,backend,events,quota,times,_=collecting_runner(tmp_path)
    capture=backend.capture
    def stop_at_home_outline():
        frame=capture()
        if len([e for e in events if e['kind']=='gem_clicked'])==1 and backend.open:
            runner.stop()
        return frame
    backend.capture=stop_at_home_outline
    run(runner)
    assert runner.cancel.is_set() and all(row[0]!=(285.,530.) for row in times)
    assert not any(e['kind'] in ('returned_home','pass_started') for e in events)


def test_unconfirmed_return_camera_never_clicks_gameplay_center_or_restarts(tmp_path):
    runner,backend,events,quota,times,_=collecting_runner(tmp_path)
    click=backend.click;returning=[False]
    def ignore_home(point):
        if point==LiveSettings().map_open:returning[0]=True
        if returning[0] and backend.open and point!=LiveSettings().map_close:
            backend.selected_world=None;return
        click(point)
    backend.click=ignore_home
    run(runner)
    assert backend.open and 'Camera selection not confirmed' in events[-1]['message']
    assert all(row[0]!=(285.,530.) for row in times)
    assert not any(e['kind']=='pass_started' for e in events)


def test_old_days_do_not_block_new_game_day_and_ui_replays_do_not_double_count(tmp_path):
    quota=SniperQuota(tmp_path/'sightings.sqlite3')
    after=datetime(2026,10,21,16,tzinfo=ZONE).timestamp()
    for i in range(5):quota.mark('patrol:old-'+str(i),after-1)
    assert quota.count(after-1)==5 and quota.count(after)==0
    quota.mark('patrol:new',after)
    history=SightingHistory(quota.path);history.mark_sniper_seen('patrol:new',after)
    assert quota.count(after)==history.sniper_seen(after)==1
    history.close()


def test_fifth_find_just_before_reset_still_finishes_and_stops_after_twenty_second_wait(tmp_path):
    epoch=datetime(2026,10,21,15,59,55,tzinfo=ZONE).timestamp()
    runner,backend,events,quota,times,_=collecting_runner(tmp_path,existing=4,epoch=epoch)
    run(runner)
    assert quota.count(epoch)==5 and quota.count(runner.wall())==0
    assert '5/5' in events[-1]['message'] and 'Returned' in events[-1]['message']
    assert sum(e['kind']=='returned_home' for e in events)==1
    assert not any(e['kind']=='pass_started' for e in events)
