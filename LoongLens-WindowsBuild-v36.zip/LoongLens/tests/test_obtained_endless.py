"""Daily obtained choices, crash persistence and quota-free continuous scanning."""
from pathlib import Path
import subprocess
import sys
import pytest
from sniper_counter import SniperQuota
from sighting_history import SightingHistory
from test_sniper_counter import event,at
from test_sniper_collection_cycle import collecting_runner,run


def test_old_photo_history_recovers_missing_daily_ledger_and_defaults_to_obtained(tmp_path):
    path=tmp_path/'sightings.sqlite3';history=SightingHistory(path)
    history.record([event('patrol:older',at(20,17)),event('spy:ignored',at(20,17)),event('test:ignored',at(20,17),True)])
    history.connection.execute('DELETE FROM sniper_seen_events');history.connection.commit();history.close()
    restored=SightingHistory(path);quota=SniperQuota(path)
    assert restored.sniper_seen(at(21,1))==quota.count(at(21,1))==1
    rows=quota.entries(now=at(21,1))
    assert len(rows)==1 and rows[0]['event_id']=='patrol:older' and rows[0]['obtained']
    restored.close()


def test_unchecked_choice_survives_replay_photo_updates_and_app_restart(tmp_path):
    path=tmp_path/'sightings.sqlite3';history=SightingHistory(path);quota=SniperQuota(path)
    first=event('patrol:one',at(20,17));history.record([first])
    quota.set_obtained(first['event_id'],False)
    history.mark_sniper_seen(first['event_id'],first['seen_at'])
    history.record([dict(first,capture_status='ready',screenshot_path='original.png')]);history.close()
    history=SightingHistory(path);quota=SniperQuota(path)
    assert history.sniper_seen(at(21,1))==quota.count(at(21,1))==0
    assert len(history.list())==1 and history.list()[0].screenshot_path=='original.png'
    assert not quota.entries(now=at(21,1))[0]['obtained']
    quota.set_obtained(first['event_id'],True)
    assert quota.count(at(21,1))==1
    history.remove(history.list()[0].id);history.close()
    assert SniperQuota(path).count(at(21,1))==1
    assert SniperQuota(path).entries(now=at(21,1))[0]['screenshot_path'] is None


def test_worker_commits_find_before_ui_and_survives_forced_process_exit(tmp_path):
    path=tmp_path/'sightings.sqlite3';stamp=at(20,17)
    code='''import json,os,sys
from sniper_counter import SniperQuota
path,stamp=sys.argv[1],float(sys.argv[2])
event=dict(event_id='patrol:crash',seen_at=stamp,screen_x=100,screen_y=200,score=.95,test_mode=False,
           capture_status='pending',zone='Emerald Corner',game_x=241,game_y=107)
SniperQuota(path).mark(event['event_id'],stamp,event)
os._exit(0)
'''
    subprocess.run([sys.executable,'-c',code,str(path),str(stamp)],check=True,cwd=Path(__file__).resolve().parents[1])
    restored=SightingHistory(path);restored.recover_pending()
    assert restored.sniper_seen(at(21,1))==1
    row=restored.list()[0]
    assert row.zone=='Emerald Corner' and row.capture_status=='interrupted'
    assert SniperQuota(path).entries(now=at(21,1))[0]['obtained']
    restored.close()


def test_photo_cooldown_find_is_editable_even_without_a_screenshot(tmp_path):
    runner,backend,events,quota,_,_=collecting_runner(tmp_path,stop_at=lambda e:e['kind']=='gem_clicked')
    runner.cooldown['last']=0
    run(runner)
    found=next(e for e in events if e['kind']=='found')
    assert found['event'] is None and not any(e['kind']=='capture' for e in events)
    rows=quota.entries(now=runner.wall())
    assert len(rows)==1 and rows[0]['zone'] and rows[0]['score']==.95
    quota.set_obtained(rows[0]['event_id'],False)
    assert quota.count(runner.wall())==0


@pytest.mark.parametrize('existing',[4,5,6])
def test_endless_continues_past_five_and_f10_stays_stopped(tmp_path,existing):
    runner,backend,events,quota,_,_=collecting_runner(tmp_path,existing=existing,
        stop_at=lambda e:e['kind']=='gem_clicked' and runner.stats.snapshot()['gems']==2)
    runner.set_endless(True);run(runner)
    assert quota.count(runner.wall())==existing+2
    assert sum(e['kind']=='gem_clicked' for e in events)==2
    assert sum(e['kind']=='returned_home' for e in events)==1
    assert any(e['kind']=='pass_started' for e in events)
    assert runner.cancel.is_set() and not runner.running


def test_turning_endless_off_restores_goal_after_current_collection(tmp_path):
    runner,backend,events,quota,_,_=collecting_runner(tmp_path,existing=5)
    emit=runner.emit
    def report(e):
        if e['kind']=='gem_clicked':runner.set_endless(False)
        emit(e)
    runner.emit=report;runner.set_endless(True);run(runner)
    assert quota.count(runner.wall())==6
    assert sum(e['kind']=='returned_home' for e in events)==1
    assert not any(e['kind']=='pass_started' for e in events)
    assert '5/5' in events[-1]['message']


def test_unchecking_fifth_during_collection_allows_next_pass(tmp_path):
    runner,backend,events,quota,_,_=collecting_runner(tmp_path,existing=4,
        stop_at=lambda e:e['kind']=='gem_clicked' and runner.stats.snapshot()['gems']==2)
    emit=runner.emit
    def report(e):
        if e['kind']=='found' and runner.stats.snapshot()['gems']==1:quota.set_obtained(e['seen_id'],False)
        emit(e)
    runner.emit=report;run(runner)
    assert any(e['kind']=='pass_started' for e in events)
    assert sum(e['kind']=='gem_clicked' for e in events)==2
    assert quota.count(runner.wall())==5


def test_edits_follow_1600_day_boundaries_without_erasing_old_choices(tmp_path):
    quota=SniperQuota(tmp_path/'sightings.sqlite3')
    quota.mark('patrol:old',at(20,15,59));quota.mark('patrol:today',at(20,16))
    quota.set_obtained('patrol:old',False)
    assert quota.count(at(20,15,59))==0 and quota.count(at(20,16))==1
    assert [e['event_id'] for e in quota.entries(now=at(20,16))]==['patrol:today']
    assert len(quota.entries(today_only=False))==2
    assert quota.count(at(21,16))==0


def test_unknown_entry_cannot_create_an_obtained_count(tmp_path):
    quota=SniperQuota(tmp_path/'sightings.sqlite3')
    with pytest.raises(ValueError):quota.set_obtained('not-a-find',True)
    assert not quota.entries(today_only=False)
