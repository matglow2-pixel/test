from dataclasses import replace
from datetime import datetime
from pathlib import Path
import sqlite3
import hashlib
import pytest
from camera_patrol import Viewpoint
from sighting_history import SightingHistory
from spy_history import SpyHistory,point_key,route_signature


@pytest.fixture
def view():return Viewpoint(100.,100.,'Test zone',frozenset({(100,100)}),12)


@pytest.fixture
def store(tmp_path):
    result=SpyHistory(tmp_path/'sightings.sqlite3')
    yield result
    result.close()


def at(hour,minute=0,second=0,day=18):return datetime(2026,10,day,hour,minute,second).timestamp()


def gem(x=285.,y=514.5,score=.95,seen_at=None):
    result=dict(screen_x=x,screen_y=y,score=score)
    if seen_at is not None:result['seen_at']=result['last_seen']=seen_at
    return result


def test_distinct_encounter_adds_standard_row_with_correct_source_and_same_photo(store,view):
    store.observe(view,1,at(8,31),clear=True)
    fresh=store.observe(view,2,at(8,36),[gem()],clear=True)
    event=fresh[0][0]
    result=dict(event,capture_status='ready',screenshot_path='original.png',captured_at=at(8,36,1))
    store.finish_capture(result)
    row=store.standard.list()[0]
    assert row.source=='Gem Spy' and row.source_label=='Gem Spy · Open screenshot'
    assert row.seen_at==at(8,36) and row.score==.95 and row.screenshot_path=='original.png'
    spy=store.encounters()[0]
    assert spy['last_empty']==at(8,31) and spy['first_seen']==at(8,36) and spy['screenshot_path']==row.screenshot_path


def test_repeated_gem_keeps_original_time_score_photo_and_hour(store,view):
    event=store.observe(view,1,at(8,59),[gem()],True)[0][0]
    store.finish_capture(dict(event,capture_status='ready',screenshot_path='once.png',captured_at=at(8,59)))
    assert not store.observe(view,2,at(9,3),[gem(x=287,score=.99)],True)
    assert not store.observe(view,3,at(10),[gem(x=283)],True)
    assert store.totals()==dict(total=1,active=1)
    row=store.encounters()[0]
    assert row['runs']==3 and row['last_seen']==at(10) and row['score']==.95
    standard=store.standard.list()
    assert len(standard)==1 and standard[0].seen_at==at(8,59) and standard[0].screenshot_path=='once.png'
    hours={datetime.fromtimestamp(r['hour_start']).hour:r['gems'] for r in store.hours()}
    assert hours=={8:1,9:0,10:0}


def test_two_gems_in_same_view_are_not_merged(store,view):
    assert len(store.observe(view,1,at(8),[gem(220),gem(350)],True))==2
    assert not store.observe(view,2,at(8,5),[gem(223),gem(347)],True)
    assert store.totals()['total']==2 and len(store.standard.list())==2


def test_new_gem_can_have_empty_evidence_from_view_containing_another_gem(store,view):
    store.observe(view,1,at(8),[gem(220)],True)
    assert len(store.observe(view,2,at(8,5),[gem(220),gem(350)],True))==1
    newest=store.encounters()[0]
    assert newest['last_empty']==at(8) and newest['first_seen']==at(8,5)


def test_overlapping_views_match_same_world_position(store,view):
    store.observe(view,1,at(8),[gem()],True)
    shifted=replace(view,x=101.,route_number=13)
    assert not store.observe(shifted,2,at(8,5),[gem(285-570/6.7)],True)
    assert store.totals()['total']==1 and store.encounters()[0]['runs']==2


def test_absence_requires_two_separate_runs_and_unknown_never_counts(store,view):
    store.observe(view,1,at(8),[gem()],True)
    store.observe(view,2,at(8,5),clear=True)
    store.observe(view,2,at(8,6),clear=True)
    store.observe(view,3,at(8,10),clear=False,reason='Loading')
    assert store.encounters()[0]['miss_count']==1 and store.totals()['active']==1
    store.observe(view,4,at(8,15),clear=True)
    row=store.encounters()[0]
    assert row['first_missing']==at(8,5) and row['confirmed_missing']==at(8,15)
    assert len(store.observe(view,5,at(8,20),[gem()],True))==1
    assert store.totals()==dict(total=2,active=1)
    assert store.encounters()[0]['last_empty']==at(8,15)


def test_uncovered_or_obscured_target_is_not_declared_absent(store,view):
    store.observe(view,1,at(8),[gem()],True)
    for run in (2,3,4):store.observe(replace(view,x=110),run,at(8,run),clear=True)
    assert store.encounters()[0]['miss_count']==0
    assert store.totals()['active']==1


def test_first_seen_without_a_prior_clear_visit_has_no_invented_spawn_time(store,view):
    store.observe(view,1,at(8),clear=False,reason='Map alignment unknown')
    store.observe(view,2,at(8,5),[gem()],True)
    assert store.encounters()[0]['last_empty'] is None


def test_appearance_window_uses_that_locations_visit_not_whole_pass_end(store,view):
    store.observe(view,1,at(8,31),clear=True)
    store.observe(replace(view,x=150,route_number=50),1,at(8,34),clear=True)
    store.observe(view,2,at(8,36),[gem()],True)
    assert store.encounters()[0]['last_empty']==at(8,31)


def test_duplicate_state_survives_reopening_database(tmp_path,view):
    path=tmp_path/'history.sqlite3';first=SpyHistory(path)
    first.observe(view,1,at(8),[gem()],True);first.close()
    second=SpyHistory(path)
    assert not second.observe(view,2,at(8,5),[gem()],True)
    assert second.totals()['total']==1 and len(second.standard.list())==1
    second.close()


def test_removing_standard_row_during_capture_does_not_recreate_it(store,view):
    event=store.observe(view,1,at(8),[gem()],True)[0][0]
    store.standard.remove(store.standard.list()[0].id)
    store.finish_capture(dict(event,capture_status='ready',screenshot_path='spy-only.png',captured_at=at(8)))
    assert not store.standard.list()
    assert store.encounters()[0]['screenshot_path']=='spy-only.png'


def test_manual_location_edit_survives_spy_capture_completion(store,view):
    event=store.observe(view,1,at(8),[gem()],True)[0][0]
    store.standard.edit_location(store.standard.list()[0].id,'My zone',12,34)
    store.finish_capture(dict(event,capture_status='ready',screenshot_path='once.png',captured_at=at(8)))
    row=store.standard.list()[0]
    assert (row.zone,row.game_x,row.game_y)==('My zone',12,34)
    assert row.source=='Gem Spy'


def test_hour_counts_are_separated_by_date_and_first_confirmation_time(store,view):
    store.observe(view,1,at(8,59,59),[gem(seen_at=at(8,59,58))],True)
    store.observe(view,2,at(9),clear=True);store.observe(view,3,at(9,1),clear=True)
    store.observe(view,4,at(8,0,day=19),[gem()],True)
    assert [(datetime.fromtimestamp(r['hour_start']).day,datetime.fromtimestamp(r['hour_start']).hour,r['gems'])
            for r in store.hours()]==[(19,8,1),(18,9,0),(18,8,1)]


def test_checkpoint_retains_same_route_progress_and_keeps_totals_on_route_change(store,view):
    state=store.checkpoint((view,));state.update(elapsed=123,checked=[point_key(view)],total=1)
    store.save_state('checkpoint',state);store.observe(view,1,at(8),[gem()],True)
    assert store.checkpoint((view,))==state
    changed=store.checkpoint((replace(view,x=101),))
    assert changed['elapsed']==123 and changed['checked']==[] and changed['run']==state['run']+1
    assert store.totals()['total']==1


def test_timing_candidates_need_independent_windows_and_do_not_use_midpoints(store,view):
    run=0
    for hour,empty,seen in ((8,31,36),(9,34,38),(10,35,37)):
        run+=1;store.observe(view,run,at(hour,empty),clear=True)
        run+=1;store.observe(view,run,at(hour,seen),[gem()],True)
        run+=1;store.observe(view,run,at(hour,50),clear=True)
        run+=1;store.observe(view,run,at(hour,55),clear=True)
    result=store.patterns()[0]
    assert result['candidate']==':35–:36 (candidate)' and result['support']=='3/3 windows'
    assert result['appearances']==3 and result['gap_minutes'] is not None


def test_existing_history_rows_are_preserved_when_origin_column_is_added(tmp_path):
    path=tmp_path/'legacy.sqlite3'
    con=sqlite3.connect(path)
    con.execute('CREATE TABLE sightings(id INTEGER PRIMARY KEY,event_id TEXT UNIQUE,seen_at REAL,screen_x REAL,screen_y REAL,score REAL,test_mode INTEGER)')
    con.execute("INSERT INTO sightings VALUES(1,'old',100,1,2,.9,0)");con.commit();con.close()
    store=SpyHistory(path)
    row=store.standard.get(1)
    assert row.event_id=='old' and row.source=='Live game' and row.seen_at==100
    store.close()


def test_recovery_links_already_saved_original_photo_without_new_encounter(store,view,tmp_path):
    event=store.observe(view,1,at(8),[gem()],True)[0][0]
    digest=hashlib.sha256(event['event_id'].encode()).hexdigest()[:24]
    photo=tmp_path/'screenshots'/(datetime.fromtimestamp(at(8)).strftime('%Y%m%d-%H%M%S')+'-'+digest+'.png')
    photo.parent.mkdir();photo.write_bytes(b'original image')
    store.recover_captures(tmp_path)
    row=store.standard.list()[0]
    assert row.capture_status=='ready' and row.screenshot_path==str(photo.resolve())
    assert store.encounters()[0]['screenshot_path']==row.screenshot_path
    assert store.totals()['total']==1


def test_recovery_marks_missing_original_interrupted_without_replacing_it(store,view,tmp_path):
    store.observe(view,1,at(8),[gem()],True)
    store.recover_captures(tmp_path)
    assert store.standard.list()[0].capture_status=='interrupted'
    assert store.encounters()[0]['screenshot_path'] is None
    assert not store.observe(view,2,at(8,5),[gem()],True)
