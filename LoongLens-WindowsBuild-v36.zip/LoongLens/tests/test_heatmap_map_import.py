from pathlib import Path
import json
import cv2
import numpy as np
import pytest
from PIL import Image
from heatmap_map_import import stitch_maps,save_map,load_map,MAP_SETTINGS
from resources import ROOT


@pytest.fixture(scope='module',autouse=True)
def application_thread_budget():
    previous=cv2.getNumThreads();cv2.setNumThreads(2)
    try:yield
    finally:cv2.setNumThreads(previous)


@pytest.fixture(scope='module')
def parts(tmp_path_factory):
    folder=tmp_path_factory.mktemp('map-parts');paths=[]
    with Image.open(ROOT/'loong_haven_default_atlas.png') as original:
        # Known world coverage, with overlap, at the original pixel scale.
        for i,(top,bottom) in enumerate(((0,1550),(1050,2600),(2050,3486))):
            path=folder/f'part-{i}.png';original.crop((0,top,3486,bottom)).save(path);paths.append(path)
    return tuple(paths)


def test_three_overlapping_parts_register_to_world_and_survive_restart(parts,tmp_path):
    image,meta=stitch_maps(parts)
    assert abs(image.width-3486)<8 and image.width==image.height
    assert meta['source_count']==3 and meta['world_size']==280
    info=save_map(tmp_path,image,meta);restored,settings=load_map(tmp_path)
    assert restored.size==image.size and restored.tobytes()==image.tobytes()
    assert settings==info
    # Pixel placement is checked away from image seams, using independently
    # known atlas positions, not the registration transform returned by code.
    with Image.open(ROOT/'loong_haven_default_atlas.png') as original:
        expected=np.asarray(original.convert('RGB'))
    actual=np.asarray(image.resize(original.size,Image.Resampling.NEAREST))
    for x,y in ((1100,300),(1800,1700),(2800,2000),(1100,2900)):
        assert np.abs(actual[y-5:y+5,x-5:x+5].astype(float)-expected[y-5:y+5,x-5:x+5]).mean()<12


def test_partial_or_unrecognised_map_is_rejected_instead_of_replacing_current(parts,tmp_path):
    with pytest.raises(ValueError,match='cover only'):stitch_maps(parts[:1])
    path=tmp_path/'blank.png';Image.new('RGB',(600,600),(13,18,24)).save(path)
    with pytest.raises(ValueError,match='blank.png'):stitch_maps([path])


def test_bad_or_modified_saved_map_falls_back_without_touching_original(tmp_path):
    image=Image.new('RGB',(500,500),(80,110,150));meta=dict(width=500,height=500,world_size=280,source_count=1)
    info=save_map(tmp_path,image,meta);path=tmp_path/info['image'];path.write_bytes(b'broken')
    restored,settings=load_map(tmp_path)
    assert restored.size==(3486,3486) and settings['source_count']==0
    outside=dict(info,image='../outside.png')
    (tmp_path/MAP_SETTINGS).write_text(json.dumps(outside))
    restored,_=load_map(tmp_path);assert restored.size==(3486,3486)
    assert not (tmp_path/'outside.png').exists()


def test_replacement_keeps_last_good_image_and_does_not_modify_recognition_atlas(tmp_path):
    original=(ROOT/'loong_haven_default_atlas.png').read_bytes()
    image=Image.new('RGB',(500,500),(50,80,110));meta=dict(width=500,height=500,world_size=280,source_count=1)
    first=save_map(tmp_path,image,meta);second=save_map(tmp_path,image,meta)
    assert first['image']!=second['image'] and (tmp_path/first['image']).exists()
    assert load_map(tmp_path)[1]==second
    assert (ROOT/'loong_haven_default_atlas.png').read_bytes()==original


def test_cancelled_import_does_not_start_processing_or_write_files(parts,tmp_path):
    import threading
    cancel=threading.Event();cancel.set()
    with pytest.raises(RuntimeError,match='cancelled'):stitch_maps(parts,cancel=cancel)
    assert not list(tmp_path.iterdir())
