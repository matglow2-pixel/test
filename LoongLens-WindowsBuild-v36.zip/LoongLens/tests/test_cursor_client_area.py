"""A BlueStacks resize border is never a valid map drag or click target."""
from types import SimpleNamespace
import threading
import pytest
from patrol_windows import WindowsBackend,NativeInput,PatrolStopped
from patrol_live import LivePatrol
from patrol_route import route_drag_step


def backend():
    value=WindowsBackend.__new__(WindowsBackend)
    value.cancel=threading.Event();value.down=False;value.target=(123,(100,100,570,1029))
    value.input_rect=(108,130,662,1121);value.drag_bounds=(8,30,561,1020)
    value._clip_saved=None;value._clip_owned=None
    state=dict(cursor=(300,400),clip=(-1920,0,3840,2160),events=[])
    def move(x,y):state['cursor']=(x,y);state['events'].append(('move',(x,y)));return True
    value.api=SimpleNamespace(user=SimpleNamespace(SetCursorPos=move),cursor=lambda:state['cursor'],
        client_hit=lambda hwnd,p:108<=p[0]<662 and 130<=p[1]<1121,
        mouse=lambda flag:state['events'].append(('button',flag)),left_down=lambda:True,
        clip_rect=lambda:state['clip'],clip=lambda rect:state.update(clip=rect))
    value.guard=lambda:(_ for _ in ()).throw(PatrolStopped('Stopped')) if value.cancel.is_set() else None
    value.visible_at=lambda *a:True;value.wait=lambda t:value.guard()
    return value,state


@pytest.mark.parametrize('point',[(4,500),(565,500),(285,1028),(285,20)])
def test_border_target_never_moves_or_presses_mouse_and_restores_clip(point):
    value,state=backend();original=state['clip']
    with pytest.raises(RuntimeError,match='border'):value.click(point)
    assert not state['events'] and state['clip']==original and not value.down


def test_hit_test_rejects_a_resize_handle_even_inside_the_client_rectangle():
    value,state=backend();value.api.client_hit=lambda *a:False
    with pytest.raises(RuntimeError,match='resize border'):value.click((200,400))
    assert state['events']==[]


def test_cursor_redirected_by_windows_is_not_clicked():
    value,state=backend()
    value.api.user.SetCursorPos=lambda *p:True  # Windows/another clip redirected it.
    with pytest.raises(RuntimeError,match='did not reach'):value.click((200,400))
    assert not any(event[0]=='button' for event in state['events'])


def test_normal_click_is_delivered_inside_client_and_restores_previous_clip():
    value,state=backend();original=state['clip']
    value.click((200,400))
    assert state['events']==[('move',(300,500)),('button',2),('button',4)]
    assert state['clip']==original and not value.down


def test_f10_during_hold_releases_button_and_original_cursor_clip():
    value,state=backend();original=state['clip']
    with pytest.raises(PatrolStopped):
        with value.hold_drag((285,530)):
            assert state['clip']==value.input_rect
            value.cancel.set();value.release();value.drag_held_to((300,500))
    assert state['clip']==original and not value.down
    assert [row for row in state['events'] if row[0]=='button']==[('button',2),('button',4)]


def test_pointer_boundary_uses_real_native_border_width_not_added_padding():
    native=NativeInput.__new__(NativeInput)
    def client(hwnd,p):p._obj.right=400;p._obj.bottom=700;return True
    def origin(hwnd,p):p._obj.x=100;p._obj.y=50;return True
    native.user=SimpleNamespace(GetClientRect=client,ClientToScreen=origin)
    native.client_hit=lambda hwnd,p:107<=p[0]<493 and 81<=p[1]<744
    assert native.input_rect(123)==(107,81,493,744)


def test_full_window_reference_rounding_never_maps_to_pixel_outside_window():
    value,_=backend()
    assert value.point((569.99,1028.99))==(669,1128)


def test_route_reveals_a_target_on_the_native_border_instead_of_clicking_it():
    value,_=backend()
    assert not LivePatrol.target_visible(value,(5,500))
    assert LivePatrol.target_visible(value,(8,500))
    cursor=(285,530)
    for _ in range(4):
        end=route_drag_step(cursor,(1,0),bounds=value.drag_bounds)
        if end is None:break
        cursor=end
    assert cursor[0]<=561 and cursor[0]>560
