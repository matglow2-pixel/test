"""Late drag/recenter frames must reproject the world target without a pause on stable views."""
from dataclasses import replace
import math
import cv2
import pytest
from patrol_live import MapAlignmentLost
from patrol_windows import PatrolStopped
from resources import ROOT
from test_live_patrol import setup
from test_patrol_pan_tracking import render


def moving_map(hidden=False,continuous=False):
    engine,backend,events=setup()
    backend.center=(180.,186.)
    x=200. if hidden else 180.5
    engine.views=(replace(engine.views[0],x=x,y=186.,cells=frozenset({(int(x),186)}),route_number=13),)
    engine.fixed_route=True
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    capture=backend.capture;active=[False];frames=[0];click_world=[]
    def screenshot():
        if not backend.open:return capture()
        if active[0]:
            frames[0]+=1
            if continuous:backend.center=(backend.center[0]+4,186.)
            elif frames[0]==1:backend.center=(168. if hidden else 184.,186.)
            elif frames[0]==2 and not hidden:backend.center=(188.,186.)
        frame,pose=render(atlas,*backend.center);frame[0,0]=1
        if backend.selected_world is not None:
            from test_camera_selection import outline
            outline(frame,pose.project(*backend.selected_world))
        return frame
    backend.capture=screenshot
    original_click=backend.click
    def click(point):
        if backend.open and point!=engine.settings.map_close:
            click_world.append((backend.center[0]+(point[0]-285)/12.45,
                                backend.center[1]-(point[1]-500)/12.45))
        original_click(point)
    backend.click=click
    def emit(event):
        events.append(event)
        if event['kind']=='status' and event['message'].startswith('Clicking'):active[0]=True
    engine.emit=emit
    return engine,backend,events,click_world


@pytest.mark.parametrize('hidden',[False,True])
def test_late_movement_recalculates_and_reveals_same_world_target_automatically(hidden):
    engine,backend,events,selected=moving_map(hidden)
    engine.run(backend)
    assert engine.checked=={0} and len(selected)==1
    assert math.dist(selected[0],(engine.views[0].x,engine.views[0].y))<.1
    assert any(e['kind']=='status' and 'recalculating' in e['message'] for e in events)
    assert any(row[0]=='drag' for row in backend.inputs)==hidden
    assert sum(e['kind']=='checked' for e in events)==1


def test_stationary_preclick_uses_one_capture_no_wait_or_new_alignment():
    engine,backend,_=setup();engine.fixed_route=True
    frame=backend.capture();pose=engine.locator.locate(frame);before=engine.clock();captures=[]
    original=backend.capture
    backend.capture=lambda:(captures.append(True) or original())
    engine.align=lambda *a,**kw:pytest.fail('Stable pre-click view must not re-align')
    fresh,actual=engine.prepare_camera_click(backend,frame,pose,engine.views[0])
    assert len(captures)==1 and engine.clock()==before and actual is pose


def test_continuously_moving_map_exhausts_bounded_recovery_without_a_stale_click():
    engine,backend,_,_=moving_map(continuous=True)
    with pytest.raises(MapAlignmentLost):engine.run(backend)
    assert not backend.inputs and not engine.checked
    assert engine.clock()<8


def test_f10_during_late_movement_recovery_cancels_without_clicking():
    engine,backend,events,_=moving_map();emit=engine.emit
    def stop(event):
        emit(event)
        if event['kind']=='status' and 'recalculating' in event['message']:engine.cancel.set()
    engine.emit=stop
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert not backend.inputs and not engine.checked
