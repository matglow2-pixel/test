"""Held movement uses measured terrain; ambiguous flow falls back to SIFT."""
import cv2
import numpy as np
import pytest
from resources import ROOT
from vision import track_map_flow,track_map_pan
from test_patrol_pan_tracking import render


@pytest.fixture(scope='module')
def atlas():
    cv2.setNumThreads(2)
    return cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))


@pytest.mark.parametrize('delta',[(-100,0),(80,-120),(240,0),(0,160),(-200,160)])
def test_fast_tracking_or_verified_fallback_matches_real_atlas_translation(atlas,delta):
    before,known=render(atlas,180.5,186.5)
    frame,expected=render(atlas,180.5-delta[0]/12.45,186.5+delta[1]/12.45)
    measured=track_map_pan(before,frame,known,delta,fast=True)
    assert measured is not None
    assert measured.tx==pytest.approx(expected.tx,abs=1.5)
    assert measured.ty==pytest.approx(expected.ty,abs=1.5)


def test_fast_path_can_measure_without_running_sift(atlas,monkeypatch):
    before,known=render(atlas,180.5,186.5);frame,_=render(atlas,180.5+100/12.45,186.5)
    def forbidden(*a,**kw):pytest.fail('This clear held frame should use optical flow')
    monkeypatch.setattr(cv2,'SIFT_create',forbidden)
    assert track_map_pan(before,frame,known,(-100,0),fast=True).source=='tracked map terrain'


def test_blank_or_unmoving_scene_never_authorizes_an_input_prediction(atlas):
    before,known=render(atlas,180.5,186.5)
    assert track_map_flow(before,before,known,(-100,0)) is None
    blank=np.full_like(before,80)
    assert track_map_pan(blank,blank,known,(-100,0),fast=True) is None


def test_white_camera_box_on_flat_background_is_not_stationary_terrain():
    from patrol_live import LivePatrol
    frame=np.full((1029,570,3),1,np.uint8)
    cv2.rectangle(frame,(244,425),(327,576),(255,255,255),2)
    assert not LivePatrol.stationary_map(frame,frame)
