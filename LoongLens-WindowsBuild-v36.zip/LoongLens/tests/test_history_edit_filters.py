from dataclasses import asdict
from datetime import date, datetime, time as day_time, timedelta
import time

import pytest

from sighting_history import SightingHistory


def event(identifier='gem', **changes):
    values = dict(event_id=identifier, seen_at=1791963822.1497502, screen_x=148., screen_y=468.,
                  score=.909, test_mode=False, zone=None, game_x=None, game_y=None,
                  screenshot_path='screenshots/original.png', captured_at=1791963827.65,
                  capture_status='unreadable', capture_note='The label was obscured.')
    return dict(values, **changes)


def test_location_correction_changes_only_location_and_survives_restart(tmp_path):
    path=tmp_path/'sightings.sqlite3'
    history=SightingHistory(path)
    history.record([event(),event('other',zone='Snowy Miles',game_x=180,game_y=213)])
    original=history.get(1)
    other=history.get(2)
    history.edit_location(1,' Loong Haven IX ', '78', '48')
    history.close()
    history=SightingHistory(path)
    corrected=asdict(history.get(1))
    expected=dict(asdict(original),zone='Loong Haven IX',game_x=78,game_y=48,manual_location=1)
    assert corrected==expected
    assert history.get(2)==other
    history.close()


def test_manual_location_survives_late_ocr_while_screenshot_finishes(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    pending=event(capture_status='pending',screenshot_path=None,captured_at=None)
    history.record([pending])
    history.edit_location(1,'Loong Haven IX',78,48)
    completed=dict(pending,capture_status='ready',zone='Wrong OCR',game_x=1,game_y=2,
                   screenshot_path='screenshots/new.png',captured_at=pending['seen_at']+5,capture_note='')
    history.record([completed,pending,completed])
    result=history.get(1)
    assert (result.zone,result.game_x,result.game_y)==('Loong Haven IX',78,48)
    assert result.seen_at==pending['seen_at'] and result.captured_at==completed['captured_at']
    assert result.screenshot_path==completed['screenshot_path'] and result.capture_status=='ready'
    assert len(history.list())==1
    history.close()


@pytest.mark.parametrize('zone,x,y', [('',78,48),('Loong Haven IX',-1,48),
    ('Loong Haven IX',78,280),('Loong Haven IX',78.5,48),('Loong Haven IX','nan',48)])
def test_invalid_edit_leaves_record_unchanged(tmp_path,zone,x,y):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event()])
    original=history.get(1)
    with pytest.raises(ValueError):history.edit_location(1,zone,x,y)
    assert history.get(1)==original
    history.remove(1)
    with pytest.raises(ValueError):history.edit_location(1,'Loong Haven IX',78,48)
    assert not history.list()
    history.close()


@pytest.fixture
def sofia_timezone(monkeypatch):
    if not hasattr(time,'tzset'):
        pytest.skip('This cross-timezone check needs POSIX tzset; UI uses the native PC timezone.')
    try:
        with monkeypatch.context() as scoped:
            scoped.setenv('TZ','Europe/Sofia')
            time.tzset()
            yield
    finally:
        time.tzset()


@pytest.mark.parametrize('day,hours',[(date(2026,10,14),24),(date(2026,3,28),23),(date(2026,10,24),25)])
def test_today_filter_uses_sofia_game_day_and_keeps_full_history(tmp_path,day,hours):
    from sniper_counter import ZONE
    now=datetime.combine(day,day_time(hour=17),ZONE)
    start=datetime.combine(day,day_time(hour=16),ZONE).timestamp()
    end=datetime.combine(day+timedelta(days=1),day_time(hour=16),ZONE).timestamp()
    assert end-start==hours*3600
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event('yesterday',seen_at=start-.001),event('reset',seen_at=start),
                    event('last-moment',seen_at=end-.001),event('tomorrow',seen_at=end),
                    event('test-today',seen_at=start+1,test_mode=True)])
    assert [row.event_id for row in history.list(today_only=True,now=now)]==['last-moment','reset']
    assert history.counts(today_only=True,now=now)=={0:2,1:1}
    assert len(history.list(today_only=True,include_tests=True,now=now))==3
    assert len(history.list())==4 and len(history.list(include_tests=True))==5
    assert history.list(today_only=True,now=now,limit=1)[0].event_id=='last-moment'
    history.close()


def test_after_midnight_today_only_still_includes_previous_afternoon(tmp_path):
    from sniper_counter import ZONE
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    def stamp(day,hour,minute=0):return datetime(2026,10,day,hour,minute,tzinfo=ZONE).timestamp()
    history.record([event('before-reset',seen_at=stamp(20,15,59)),event('afternoon',seen_at=stamp(20,16)),
                    event('after-midnight',seen_at=stamp(21,0,5)),event('next-game-day',seen_at=stamp(21,16))])
    assert [row.event_id for row in history.list(today_only=True,now=datetime(2026,10,21,1,tzinfo=ZONE))]==['after-midnight','afternoon']
    assert [row.event_id for row in history.list(today_only=True,now=datetime(2026,10,21,16,tzinfo=ZONE))]==['next-game-day']
    history.close()
