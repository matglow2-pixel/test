"""Delayed/ignored map taps must never become checks at the character's view."""
import cv2
import numpy as np
import pytest
from patrol_live import camera_selection_visible,LiveSettings
from test_live_patrol import setup


def outline(frame,point,scale=12.45):
    x,y=point
    cv2.rectangle(frame,(round(x-scale*6.7/2),round(y-scale*12.1/2)),
                  (round(x+scale*6.7/2),round(y+scale*12.1/2)),(240,240,240),2)
    return frame


@pytest.mark.parametrize('point',[(285,500),(14,300),(140,38),(14,38),(400,900),(555,150)])
def test_camera_outline_can_confirm_clear_or_clipped_views_without_padding(point):
    frame=np.full((1029,570,3),(125,170,140),np.uint8)
    assert camera_selection_visible(outline(frame,point),point,12.45)


@pytest.mark.parametrize('kind',['ripple','blank','snow','wrong-camera'])
def test_click_ripple_or_bright_ground_cannot_acknowledge_a_camera_selection(kind):
    point=(285,500);frame=np.full((1029,570,3),230 if kind in ('blank','snow') else 100,np.uint8)
    if kind=='ripple':cv2.circle(frame,point,16,(255,255,255),2)
    if kind=='wrong-camera':outline(frame,(150,300))
    assert not camera_selection_visible(frame,point,12.45)


@pytest.mark.parametrize('background,line',[
    ((95,117,135),(180,180,180)),
    ((125,170,140),(160,166,161)),
    ((222,229,232),(180,180,180)),
])
@pytest.mark.parametrize('capture_size',[(570,1029),(380,686),(700,1264)])
def test_translucent_outline_on_ground_snow_and_resized_capture(background,line,capture_size):
    point=(237,188);scale=12.45
    frame=np.full((1029,570,3),background,np.uint8)
    x,y=point
    cv2.rectangle(frame,(round(x-scale*6.7/2),round(y-scale*12.1/2)),
                  (round(x+scale*6.7/2),round(y+scale*12.1/2)),line,1,cv2.LINE_AA)
    frame=cv2.resize(frame,capture_size,interpolation=cv2.INTER_AREA)
    assert camera_selection_visible(frame,point,scale)


@pytest.mark.parametrize('offset',[(12,0),(0,15)])
def test_overlapping_sides_of_a_different_camera_cannot_confirm_the_target(offset):
    point=(285,500);frame=np.full((1029,570,3),100,np.uint8)
    outline(frame,(point[0]+offset[0],point[1]+offset[1]))
    assert not camera_selection_visible(frame,point,12.45)


def test_dim_camera_closes_map_after_one_tap_and_checks_once():
    engine,backend,events=setup();capture=backend.capture
    def screenshot():
        frame=capture()
        if backend.open:
            # Preserve the map classifier sentinel; only dim the rendered outline.
            frame[frame==255]=175
        return frame
    backend.capture=screenshot
    engine.run(backend,auto=False)
    assert engine.checked=={0} and not backend.open
    assert len(backend.inputs)==2
    assert backend.inputs[-1][1]==LiveSettings().map_close
    assert sum(row['kind']=='checked' for row in events)==1
    assert not any('not confirmed' in row.get('message','') for row in events)


def test_ignored_map_click_never_closes_map_inspects_or_marks_checked():
    engine,backend,events=setup();original=backend.click
    def ignore(point):
        if backend.open and point!=LiveSettings().map_close:backend.inputs.append(('click',point,True))
        else:original(point)
    backend.click=ignore
    with pytest.raises(RuntimeError,match='Camera selection not confirmed'):engine.run(backend,auto=False)
    assert not engine.checked and backend.open
    assert len(backend.inputs)==2 and all(row[1]!=LiveSettings().map_close for row in backend.inputs)
    assert not any(row['kind'] in ('checked','found','capture') for row in events)


def test_one_ignored_tap_is_retried_against_fresh_recognition_then_checked_once():
    engine,backend,events=setup();original=backend.click;attempts=[]
    def ignore_first(point):
        if backend.open and point!=LiveSettings().map_close:
            attempts.append(point)
            if len(attempts)==1:backend.inputs.append(('click',point,True));return
        original(point)
    backend.click=ignore_first;engine.run(backend,auto=False)
    assert len(attempts)==2 and engine.checked=={0}
    assert sum(row[1]==LiveSettings().map_close for row in backend.inputs)==1
    assert sum(row['kind']=='checked' for row in events)==1


def test_delayed_automatic_camera_selection_is_allowed_without_premature_back():
    engine,backend,events=setup();original=backend.click;capture=backend.capture;due=[None]
    def select(point):
        original(point)
        if point!=LiveSettings().map_close and backend.open:
            backend.selected_world=None;due[0]=engine.clock()+.7
    def screenshot():
        if due[0] is not None and engine.clock()>=due[0]:backend.open=False
        return capture()
    backend.click=select;backend.capture=screenshot
    engine.run(backend,auto=False)
    assert engine.checked=={0} and len(backend.inputs)==1


def test_stop_while_waiting_for_camera_confirmation_sends_no_back():
    engine,backend,events=setup();capture=backend.capture
    def screenshot():
        frame=capture()
        if backend.inputs:engine.cancel.set()
        return frame
    backend.capture=screenshot
    from patrol_windows import PatrolStopped
    with pytest.raises(PatrolStopped):engine.run(backend,auto=False)
    assert not engine.checked and len(backend.inputs)==1
