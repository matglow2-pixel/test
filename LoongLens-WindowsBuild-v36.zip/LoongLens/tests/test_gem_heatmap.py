import time
import numpy as np
from PIL import Image
from gem_heatmap import HeatmapHistory,HeatmapSnapshot,density_grid,compose_map,heat_layer
from sighting_history import SightingHistory
from sniper_counter import SniperQuota


def event(ident,x=241,y=107,**extra):
    return dict(event_id=ident,seen_at=time.time()-100,screen_x=230,screen_y=420,score=.95,test_mode=False,
                game_x=x,game_y=y,zone='Emerald Corner',**extra)


def test_heatmap_uses_whole_standard_history_all_sources_and_keeps_missed_gems(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([dict(event('patrol:old'),seen_at=1),
                    event('spy:one',origin='Gem Spy'),event('live:other',10,279),
                    dict(event('image:test'),test_mode=True),event('missing',None,None)])
    SniperQuota(history.path).set_obtained('patrol:old',False)
    result=HeatmapHistory(history).snapshot()
    assert result.total==4 and result.mapped==3 and result.missing==1
    assert result.cells==((10,279,1),(241,107,2))
    history.close()


def test_photo_completion_and_replay_do_not_add_density_and_manual_edits_refresh(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3');first=event('patrol:one',capture_status='pending')
    history.record([first]);model=HeatmapHistory(history);a=model.snapshot()
    assert model.snapshot() is a
    history.record([dict(first,capture_status='ready',screenshot_path='first.png'),first])
    b=model.snapshot();assert b.total==1 and b.cells==a.cells
    history.edit_location(history.list()[0].id,'Acme Nexus',10,279)
    assert model.snapshot().cells==((10,279,1),)
    history.close()


def test_spy_worker_writes_invalidate_ui_cache_without_own_connection_changes(tmp_path):
    path=tmp_path/'sightings.sqlite3';history=SightingHistory(path);model=HeatmapHistory(history)
    empty=model.snapshot();other=SightingHistory(path);other.record([event('spy:worker')]);other.close()
    assert history.connection.total_changes==empty.revision[0]
    assert model.snapshot().total==1
    history.remove(history.list()[0].id)
    assert model.snapshot().total==0
    history.close()


def test_unknown_out_of_world_and_non_numeric_locations_are_reported_not_drawn(tmp_path):
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record([event('x',-1,20),event('y',20,280),event('unknown',None,20),event('text','bad',20)])
    result=HeatmapHistory(history).snapshot()
    assert result.total==result.missing==4 and not result.cells
    history.close()


def test_world_north_and_south_are_not_reversed_and_counts_accumulate():
    data=HeatmapSnapshot(((0,279,3),(279,0,1),(100,50,2)),6,0,(0,0))
    grid=density_grid(data)
    assert grid[0,0]==3 and grid[279,279]==1 and grid[229,100]==2
    assert float(grid.sum())==6


def test_empty_or_disabled_heatmap_keeps_original_image_and_full_resolution():
    base=Image.new('RGB',(900,900),(50,80,100));empty=HeatmapSnapshot((),0,0,(0,0))
    assert compose_map(base,empty).tobytes()==base.tobytes()
    point=HeatmapSnapshot(((100,100,1),),1,0,(0,0))
    assert compose_map(base,point,False).tobytes()==base.tobytes()
    result=compose_map(base,point)
    assert result.size==base.size and result.tobytes()!=base.tobytes()
    assert heat_layer(empty,base.size).getbbox() is None
