from datetime import datetime,timedelta
from dataclasses import replace
import pytest
from sniper_counter import ZONE,game_day_window
from sighting_history import SightingHistory


def at(day,hour,minute=0):return datetime(2026,10,day,hour,minute,tzinfo=ZONE).timestamp()


@pytest.mark.parametrize('stamp,start,end',[(at(20,15,59),at(19,16),at(20,16)),
    (at(20,16),at(20,16),at(21,16)),(at(21,0),at(20,16),at(21,16)),(at(21,15,59),at(20,16),at(21,16))])
def test_game_day_uses_1600_sofia_instead_of_midnight(stamp,start,end):
    assert game_day_window(stamp)==(start,end)


@pytest.mark.parametrize('stamp,hours',[(datetime(2026,3,28,17,tzinfo=ZONE).timestamp(),23),
                                      (datetime(2026,10,24,17,tzinfo=ZONE).timestamp(),25)])
def test_game_day_follows_sofia_daylight_saving_changes(stamp,hours):
    a,b=game_day_window(stamp);assert b-a==hours*3600


def event(ident,stamp,test=False):
    return dict(event_id=ident,seen_at=stamp,screen_x=544,screen_y=688,score=.95,test_mode=test,capture_status='pending')


def test_only_new_sniper_sightings_increment_and_photo_updates_do_not(tmp_path):
    store=SightingHistory(tmp_path/'sightings.sqlite3');first=event('patrol:one',at(20,17))
    store.record([first,dict(first,capture_status='ready',screenshot_path='first.png'),
                  event('spy:one',at(20,17)),event('image:test',at(20,17),True)])
    assert store.sniper_seen(at(20,18))==1
    store.record([event('patrol:two',at(20,19))]);assert store.sniper_seen(at(20,20))==2
    store.close()


def test_counter_survives_restarts_and_standard_history_removal(tmp_path):
    path=tmp_path/'sightings.sqlite3';store=SightingHistory(path)
    store.record([event('patrol:one',at(20,17))]);store.remove(store.list()[0].id);store.close()
    restored=SightingHistory(path);assert restored.sniper_seen(at(21,1))==1
    restored.close()


def test_counter_changes_at_1600_and_history_is_retained(tmp_path):
    store=SightingHistory(tmp_path/'sightings.sqlite3')
    store.record([event('patrol:previous',at(20,15,59)),event('patrol:new',at(20,16))])
    assert store.sniper_seen(at(20,15,59))==1
    assert store.sniper_seen(at(20,16))==1
    assert store.sniper_seen(at(21,15,59))==1
    assert store.sniper_seen(at(21,16))==0 and len(store.list())==2
    store.close()


def test_counter_does_not_cap_or_stop_the_sixth_valid_sighting(tmp_path):
    store=SightingHistory(tmp_path/'sightings.sqlite3')
    store.record([event('patrol:'+str(i),at(20,17)+i*30) for i in range(6)])
    assert store.sniper_seen(at(20,18))==6
    store.close()


def test_find_during_photo_cooldown_still_counts_once(tmp_path):
    store=SightingHistory(tmp_path/'sightings.sqlite3')
    store.mark_sniper_seen('patrol:cooldown',at(20,17));store.mark_sniper_seen('patrol:cooldown',at(20,17))
    assert store.sniper_seen(at(20,18))==1 and not store.list()
    store.close()
