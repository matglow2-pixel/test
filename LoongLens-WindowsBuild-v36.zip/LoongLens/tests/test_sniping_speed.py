"""Optimize stable screenshots and wait overshoot without shortening inspection."""
from types import SimpleNamespace
import cv2
import numpy as np
import pytest

from resources import ROOT
from patrol_live import LivePatrol
from patrol_windows import PatrolStopped
from pose import Match
from test_live_patrol import setup


def atlas_frame():
    return cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))[1300:2329,900:1470].copy()


def test_still_map_uses_one_recognition_but_two_observed_frames():
    engine,backend,_=setup();frame=atlas_frame();captures=[];recognitions=[]
    backend.capture=lambda:(captures.append(True) or frame.copy())
    engine.title=SimpleNamespace(score=lambda f:1.)
    pose=Match(12.45,-900.,279*12.45-1300,20,0,[])
    engine.locator=SimpleNamespace(locate=lambda f:(recognitions.append(True) or pose))
    opened=backend.capture()
    _,found=engine.align(backend,initial_frame=opened)
    assert found==pose and len(captures)==2 and len(recognitions)==1
    assert backend.clock.now>=.15


def test_moving_map_is_recognized_again_before_clicks_can_use_it():
    engine,backend,_=setup();before=atlas_frame();after=np.roll(before,30,axis=1)
    frames=iter([before,after,after]);recognitions=[]
    backend.capture=lambda:next(frames).copy()
    engine.title=SimpleNamespace(score=lambda f:1.)
    def locate(frame):
        tx=-870. if np.array_equal(frame,after) else -900.
        recognitions.append(tx);return Match(12.45,tx,2173.55,20,0,[])
    engine.locator=SimpleNamespace(locate=locate)
    _,found=engine.align(backend)
    assert found.tx==-870. and recognitions==[-900.,-870.]
    assert backend.clock.now>=.3


def test_flat_or_changed_terrain_never_takes_stationary_shortcut():
    flat=np.zeros((1029,570,3),np.uint8)
    assert not LivePatrol.stationary_map(flat,flat)
    image=atlas_frame()
    assert not LivePatrol.stationary_map(image,np.roll(image,10,axis=0))
    hud=image.copy();hud[:20]=255
    assert LivePatrol.stationary_map(image,hud)


def test_f10_between_stability_frames_stops_alignment():
    engine,backend,_=setup();frame=atlas_frame()
    backend.capture=lambda:frame.copy()
    engine.title=SimpleNamespace(score=lambda f:1.)
    backend.wait=lambda t:engine.cancel.set()
    with pytest.raises(PatrolStopped):engine.align(backend)
    assert not backend.inputs


def test_inspection_keeps_full_window_without_extra_polling_overshoot():
    engine,backend,_=setup();backend.open=False;scans=[]
    def detect(frame,**kwargs):
        scans.append(backend.clock.now);backend.clock.now+=.06;return []
    engine.detector=SimpleNamespace(detect=detect)
    assert engine.inspect(backend)==(None,None)
    assert len(scans)>=3 and scans[-1]>=1.2
    assert 1.2<=backend.clock.now<=1.27


def test_auto_closed_map_confirms_a_fresh_scene_before_inspection():
    engine,backend,events=setup();trace=[]
    original_capture=backend.capture;original_click=backend.click
    def capture():trace.append(('capture',backend.open));return original_capture()
    def click(point):original_click(point);backend.open=False
    backend.capture=capture;backend.click=click
    engine.detector=SimpleNamespace(detect=lambda *a,**kw:(trace.append(('detect',False)) or []))
    engine.run(backend,auto=False)
    first=next(i for i,t in enumerate(trace) if t[0]=='detect')
    assert trace[:first].count(('capture',False))==4
    timing=next(e for e in events if e['kind']=='view_timing')
    assert timing['inspect_seconds']==pytest.approx(1.2)
    assert timing['total_seconds']==pytest.approx(timing['map_seconds']+timing['inspect_seconds'])
