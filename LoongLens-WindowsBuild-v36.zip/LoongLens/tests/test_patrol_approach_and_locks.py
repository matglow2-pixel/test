import math
import numpy as np
import pytest
from types import SimpleNamespace
from camera_patrol import gem_click,Viewpoint
from patrol_live import LiveSettings,locked_at
from test_live_patrol import setup


@pytest.mark.parametrize('shape,center',[((1029,570,3),(285,531)),((2058,1140,3),(570,1062)),
                                        ((1029,570,3),(80,350)),((1029,570,3),(460,700))])
def test_click_targets_the_gem_centre_at_each_capture_scale(shape,center):
    point=gem_click(center,shape)
    assert point==pytest.approx((center[0]*570/shape[1],center[1]*1029/shape[0]))


def test_found_gem_captures_before_clicking_its_exact_centre_once_then_stops():
    engine,backend,events=setup(positive=True)
    engine.settings=LiveSettings(approach_gem=True)
    message=engine.run(backend)
    assert len(backend.inputs)==3  # Map target, Back, then exactly one gem click.
    assert backend.inputs[-1][2] is False
    assert backend.inputs[-1][1]==pytest.approx((200,400))
    assert 'Clicked the gem once' in message and engine.checked=={0}
    capture=next(e for e in events if e['kind']=='capture')
    found=next(e['event'] for e in events if e['kind']=='found')
    assert capture['captured_at']-found['seen_at']==pytest.approx(0)
    assert 'before clicking the gem' in capture['event']['capture_note']
    assert any(e['kind']=='gem_clicked' for e in events)


def test_f10_after_detection_prevents_gem_click():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    def emit(event):
        events.append(event)
        if event['kind']=='found':engine.cancel.set()
    engine.emit=emit
    from patrol_windows import PatrolStopped
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert len(backend.inputs)==2


def test_single_frame_detection_drop_does_not_veto_an_already_confirmed_gem():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    original=engine.detector.detect;triggered=[]
    def detect(*args,**kw):return [] if triggered else original(*args,**kw)
    engine.detector.detect=detect
    def emit(event):
        events.append(event)
        if event['kind']=='found':triggered.append(True)
    engine.emit=emit
    assert 'Clicked the gem once' in engine.run(backend)
    assert len(backend.inputs)==3 and backend.inputs[-1][1]==(200,400)


def test_locked_shading_does_not_confuse_unlocked_biomes_or_blank_capture():
    for color in [(44,47,46),(54,58,57)]:
        assert locked_at(np.full((1029,570,3),color,np.uint8),(285,500),12.45)
    for color in [(100,132,148),(116,188,156),(220,212,188),(68,92,124),(0,0,0),(1,1,1)]:
        assert not locked_at(np.full((1029,570,3),color,np.uint8),(285,500),12.45)


def test_locked_view_skips_selection_scene_inspection_and_history():
    engine,backend,events=setup();engine.views=(engine.views[0],)
    original=backend.capture
    def capture():
        frame=original()
        if backend.open:frame[400:600,180:390]=(44,47,46)
        return frame
    backend.capture=capture
    def detect(*a,**kw):pytest.fail('Locked area must not be opened or inspected')
    engine.detector.detect=detect
    engine.run(backend)
    assert backend.inputs==[] and engine.checked=={0} and engine.skipped=={0}
    assert not any(e['kind'] in ('found','capture') for e in events)


def test_locked_skip_continues_to_next_unlocked_location():
    engine,backend,events=setup()
    engine.views=(Viewpoint(100.5,100.5,'Locked',frozenset({(100,100)})),
                  Viewpoint(110.5,100.5,'Open',frozenset({(110,100)})))
    original=backend.capture
    def capture():
        frame=original()
        if backend.open:frame[470:535,250:320]=(44,47,46)
        return frame
    backend.capture=capture;engine.run(backend)
    assert engine.checked=={0,1} and engine.skipped=={0}
    assert len(backend.inputs)==2


@pytest.mark.parametrize('point',[(-1,100),(570,500),(100,1029),(float('nan'),500),(float('inf'),500)])
def test_offscreen_or_invalid_gem_does_not_get_an_offset_fallback(point):
    assert gem_click(point,(1029,570,3)) is None


@pytest.mark.parametrize('gx', [0,12,45,80,180,350,460,520,544,560,569])
def test_direct_click_does_not_shift_left_or_right(gx):
    assert gem_click((gx,700),(1029,570,3))==pytest.approx((gx,700))


def test_gem_in_reported_right_edge_photo_is_clickable_at_actual_image_scale():
    assert gem_click((348,444),(664,365,3))==pytest.approx((348*570/365,444*1029/664))


def test_confirmed_right_edge_gem_is_clicked_once_in_live_loop():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    engine.detector.detect=lambda *a,**kw:[SimpleNamespace(center=(544,688),score=.95,width=20)]
    assert 'Clicked the gem once' in engine.run(backend)
    assert backend.inputs[-1][1]==(544,688)
    assert sum(e['kind']=='gem_clicked' for e in events)==1


def test_fresh_detection_centre_is_used_if_gem_moves_a_few_pixels():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    current=[(200,400)]
    engine.detector.detect=lambda *a,**kw:[SimpleNamespace(center=current[0],score=.95,width=20)]
    def emit(event):
        events.append(event)
        if event['kind']=='found':current[0]=(212,406)
    engine.emit=emit;engine.run(backend)
    assert backend.inputs[-1][1]==pytest.approx((212,406))
    assert len(backend.inputs)==3


def test_confirmed_gem_is_clicked_at_current_centre_without_a_hud_veto():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    current=[(485,640)]
    engine.detector.detect=lambda *a,**kw:[SimpleNamespace(center=current[0],score=.95,width=20)]
    def emit(event):
        events.append(event)
        if event['kind']=='found':current[0]=(505,615)
    engine.emit=emit
    assert 'Clicked the gem once' in engine.run(backend)
    assert len(backend.inputs)==3 and backend.inputs[-1][1]==(505,615)
