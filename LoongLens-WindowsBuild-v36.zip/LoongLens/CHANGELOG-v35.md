# v35 — Spy heatmap, saved obtained gems and Endless mode

- Persist the daily count with each obtained choice. Recover older saved
  Sniper sightings if their daily ledger was missing; never reset on app exit,
  route reset or opening a different extracted app folder in the same account.
- Commit each find and its location/score metadata before notifying the UI or
  clicking the gem, including finds within the screenshot cooldown. Capture
  completion and UI replays preserve the original time and obtained choice.
- Click the /5 counter, or History → Daily gems, for the daily list. Obtained
  defaults to checked. Untick missed gems to subtract them and retick to add
  them back. Keep their original history and screenshots, including entries
  whose old screenshot is unavailable. Today only uses the 16:00 Sofia day.
- Add Endless mode directly below Gems found. Its preference survives restart.
  When enabled, scan beyond 5/5 with the existing collection/return sequence.
  Turning it off restores the normal five-obtained goal. Stop/F10 always stops.
- An obtained choice changed during collection is rechecked before stopping.
- Keep v34 smooth movement and dim-outline confirmation, the exact four map
  control boxes, no padding/portal blacklist, cursor confinement, saved routes,
  Gem Spy observation-only histories, and the 1 hour 15 second sighting dots.

Validation: obtained storage/migration/replay/forced-exit checks, normal/endless
runner cases and cancellation, two native Windows app launches on one profile,
real detector/photo pipeline with simulated game input, source/frozen GUI and
native input checks, full route comparison and complete archive hash checks.
No private recordings or user databases are packaged. No live BlueStacks run
is claimed; Obtained defaults true and remains the user's collection judgment.


- Replace the latest-observation panel in Gem Spy with a clickable full map.
  Open an all-date heatmap from the shared sighting history, including missed
  gems and excluding image tests. Unknown locations are reported separately.
- Add wheel/button zoom, drag panning, fit, heat-layer toggle and full-resolution
  PNG export. Render only the visible image crop at high zoom.
- Import original overlapping map screenshots and register them to the existing
  world grid. Preserve native source detail and reject uncertain/partial maps.
  Save imports for relaunch and reuse them in the Sniper route editor. Keep the
  original recognition atlas and live mouse/navigation behavior unchanged.
- Validate all-history counts, cache refresh from worker writes, image-test
  exclusion, world orientation, three-part registration, map persistence and
  cancellation. Native Windows checks exercise the map UI, 800% zoom/panning,
  PNG resolution, asynchronous three-part import and route-editor reuse.
