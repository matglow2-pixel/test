"""Shared preferences and standard history, independent of any monitoring tab."""
import json
import logging
import sqlite3
import threading
import tkinter as tk
from resources import user_dir
from sighting_history import SightingHistory
from sighting_panel import SightingControls


class SightingService:
    def __init__(self,root):
        self.root=root;self.folder=user_dir();self.folder.mkdir(parents=True,exist_ok=True)
        self.path=self.folder/'gemwatch-settings.json'
        try:
            values=json.loads(self.path.read_text('utf-8'))
            if not isinstance(values,dict):values={}
        except (OSError,ValueError):values={}
        self.saved_values=values
        self.mode=tk.StringVar(root,value=values.get('mode') if values.get('mode') in ('Conservative','Balanced','Sensitive') else 'Balanced')
        self.mask_hud=tk.BooleanVar(root,value=bool(values.get('mask_hud',True)))
        self.sound=tk.BooleanVar(root,value=bool(values.get('sound',True)))
        self.sighting_history=SightingHistory(self.folder/'sightings.sqlite3')
        self.sighting_history.recover_pending()
        from spy_history import SpyHistory
        spy=SpyHistory(self.folder/'sightings.sqlite3')
        try:spy.recover_captures(self.folder)
        finally:spy.close()
        self.sighting_controls=SightingControls(root,self.sighting_history)
        self.pending_sightings=[];self.last_sighting=-float('inf');self.last_sound=-float('inf')
        self.owner=None;self.sound_lock=threading.Lock();self.closed=False

    @property
    def threshold(self):return {'Conservative':.84,'Balanced':.77,'Sensitive':.70}[self.mode.get()]

    def acquire(self,owner):
        if self.owner is not None:return False
        self.owner=owner;return True

    def release(self,owner):
        if self.owner==owner:self.owner=None

    def save(self):
        values=dict(self.saved_values,mode=self.mode.get(),mask_hud=self.mask_hud.get(),sound=self.sound.get())
        temporary=self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps(values,indent=2)+'\n','utf-8');temporary.replace(self.path)

    def play_sound(self):
        if not self.sound.get() or not self.sound_lock.acquire(False):return
        def play():
            try:
                import winsound
                for frequency,duration in ((950,200),(1350,300),(950,200)):winsound.Beep(frequency,duration)
            except (RuntimeError,ImportError):logging.exception('Could not play gem alert')
            finally:self.sound_lock.release()
        threading.Thread(target=play,daemon=True,name='LoongLens-alert').start()

    def flush_sightings(self):
        if self.pending_sightings:
            try:
                self.sighting_history.record(self.pending_sightings);self.pending_sightings.clear()
            except (OSError,sqlite3.Error):logging.exception('History save failed; keeping pending events')
        self.sighting_controls.refresh()

    def close(self):
        if self.closed:return
        self.closed=True;self.flush_sightings()
        try:self.save()
        except OSError:logging.exception('Could not save detection preferences at exit')
        finally:self.sighting_history.close()
