"""Build and round-trip verify the complete v36 Windows folder as one 7z."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

import py7zr

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exe',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if sys.platform!='win32':raise SystemExit('Assemble this package after the Windows build and native checks.')
    binary=args.exe.resolve();out=args.output.resolve()
    with binary.open('rb') as stream:
        if stream.read(2)!=b'MZ':raise SystemExit('Expected the newly built Windows EXE.')
    reports=[]
    for mode in ('self-check','gui-check','input-check','spy-ui-check','sniper-ui-check','source-gui-check','source-input-check'):
        report=ROOT/(mode+'.json')
        data=json.loads(report.read_text('utf-8-sig'))
        if data.get('passed') is not True or data.get('version')!=36:
            raise SystemExit(f'{mode} did not pass')
        if mode=='sniper-ui-check':
            for key in ('restart_restored_obtained_choice','restart_restored_endless_preference',
                        'endless_continued_beyond_five','f10_stayed_stopped_in_endless','disabling_endless_restored_quota'):
                if data.get(key) is not True:raise SystemExit(f'Missing native daily/endless validation: {key}')
        if mode=='spy-ui-check':
            for key in ('heatmap_all_history','heatmap_zoom_pan','heatmap_viewport_bounded',
                        'heatmap_three_part_import','heatmap_saved_map_reloaded','route_editor_uses_imported_map'):
                if data.get(key) is not True:raise SystemExit(f'Missing native heatmap validation: {key}')
        reports.append(report)
    tests=ROOT/'tests-result.txt'
    result=re.findall(r'(\d+) passed(?:, (\d+) skipped)?',tests.read_text('utf-8-sig'))
    if not result:raise SystemExit('No successful test count found for this build.')
    passed,skipped=result[-1]
    reports.append(tests)
    comparisons={}
    for version in ('v35','v36'):
        path=ROOT/'artifacts'/f'benchmark-{version}.json'
        data=json.loads(path.read_text())
        if data.get('views_checked')!=76:raise SystemExit('Benchmark did not complete the default route.')
        if len(data.get('per_view',[]))!=76:raise SystemExit('Missing per-view timing comparison.')
        comparisons[version]=data;reports.append(path)
    baseline=comparisons['v35'];latest=comparisons['v36']
    if latest.get('held_strokes',0)<1 or latest.get('held_moves',0)<latest['held_strokes']:
        raise SystemExit('Full-route benchmark did not exercise continuous held panning.')
    if latest['held_strokes']>=30 or latest['held_moves']>latest['held_strokes']*5:
        raise SystemExit('The centre-start route comparison exceeded its movement bounds.')
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='loonglens-v36-full-') as temporary:
        folder=Path(temporary);source_zip=folder/'source.zip'
        subprocess.run([sys.executable,str(ROOT/'tools/build_release.py'),'--output',str(source_zip)],check=True)
        with zipfile.ZipFile(source_zip) as archive:
            archive.extractall(folder)
        app=folder/'LoongLens'
        if (app/'patrol_adb.py').exists():raise SystemExit('Unexpected ADB backend in the v24-based package.')
        shutil.copy2(binary,app/'LoongLens.exe')
        validation=app/'validation';validation.mkdir()
        for report in reports:shutil.copy2(report,validation/report.name)
        info=dict(version=36,baseline=35,mouse_foundation=24,commit=os.environ.get('GITHUB_SHA','local build'),
                  windows_tests=dict(passed=int(passed),skipped=int(skipped or 0)),
                  exe_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                  speed_scope='76-view atlas simulation; not measured live BlueStacks performance')
        (app/'BUILD-INFO.json').write_text(json.dumps(info,indent=2)+'\n','utf-8')
        (app/'START-HERE-v36.txt').write_text(
            'Loong Lens v36 - sidebar dashboard\n\n'
            'New sidebar navigation, controls/status cards, live portrait preview and bottom action bar.\n'
            'Uses the original transparent gem artwork throughout the interface.\n'
            'Loop sniping repeats completed routes. Endless bypasses the daily quota.\n'
            'Gem Spy now shows a clickable full map, opening an all-history heatmap with zoom/pan.\n'
            'Use Import map images to merge your original screenshots at native detail.\n'
            'The imported map also appears in Edit route; live recognition keeps the original atlas.\n'
            'Save PNG exports the full-resolution map. Image tests are excluded; missed gems are included.\n'
            'Click the /5 counter or History > Daily gems to tick/untick Obtained.\n'
            'Obtained defaults to checked; unchecking subtracts it without deleting history/photos.\n'
            'The counter and choices are saved immediately and survive app restarts.\n'
            'Endless mode is below Gems found and continues beyond 5/5 until Stop/F10.\n'
            'The Endless preference is saved. Normal mode stops at five obtained entries.\n'
            'Sniper clicks each confirmed gem, waits 20s, returns to Emerald Corner (241,107), then restarts.\n'
            'The top-right counter and Today only use 16:00 Europe/Sofia game-day reset.\n'
            'Teal sighting dots last 1 hour and 15 seconds from their original spotted time.\n'
            'The counter survives route resets and app restarts. In normal mode at 5/5 it finishes collection/return and stops.\n'
            'F10 interrupts collection waits and return input immediately; it never auto-restarts.\n'
            'Late map movement triggers settling and recalculation instead of an immediate stop.\n'
            'Stable views keep the existing capture check and have no extra fixed wait.\n'
            'Mouse input uses native client hit-testing, temporary confinement and cursor verification.\n'
            'Camera selection must close automatically or show its camera outline before Back.\n'
            'Dim and antialiased camera outlines are recognised using line contrast and geometry.\n'
            'A click ripple or an offset camera rectangle does not confirm this target.\n'
            'An ignored tap retries once and never marks that location checked.\n'
            'Held movement uses lightweight terrain tracking with a SIFT fallback.\n\n'
            'Exit the old app completely. Extract this whole folder and run LoongLens.exe here.\n'
            'This build uses v24 Windows mouse control; keep BlueStacks visible and focused.\n\n'
            'Map panning keeps the button held between movement and screenshot checks.\n'
            'It starts at the map centre and moves fast opposite the target direction,\n'
            'holds the cursor still briefly, releases and verifies the position before clicking.\n'
            'Map input excludes only the four marked control boxes within the game surface.\n'
            'No padding or broad right-hand exclusion strip is added.\n'
            'Known portal coordinates are allowed in both this EXE and the source launcher.\n'
            'Hide portal icons in the game map as you requested.\n'
            'The header shows v36; settings and personal routes remain in LocalAppData.\n'
            'Tabs: Map Tweaker, Gem Sniper, Gem Spy. Gem Watch tab is removed.\n'
            'Gem Spy uses the route and preferences selected in Gem Sniper.\n'
            'It observes repeatedly, never clicks a gem, and continues after a find.\n'
            'Spy history contains encounters, appearance windows, hourly counts and timing candidates.\n'
            'Standard history retains its columns; Spy entries show Gem Spy and link the original photo.\n'
            'A continuing gem creates no extra entry, screenshot or hourly count.\n'
            'Two clear absent runs confirm disappearance; uncertain checks do not count as empty.\n'
            'Capture/alignment retries preserve progress, elapsed time, encounters and histories.\n'
            'A failed point is marked unclear after two attempts and revisited on the next run.\n'
            'Stop/F10 stays stopped. App relaunch restores checkpoints; press Start/Resume to continue.\n'
            'Only one route controller runs at a time.\n'
            'A window-edge re-anchor starts another hold at the centre. No blind reverse recovery.\n\n'
            'Movement stops at the first verified frame with the target available.\n'
            'The measured held frame is the first alignment observation.\n'
            'A fresh post-release frame confirms it after the stationary pause. Changed frames\n'
            'still require recognition and another stable observation before the location click.\n'
            'The Loong Haven title, legend, zoom/portrait box and bottom controls\n'
            'remain excluded from map panning and location selection.\n\n'
            'Open Edit route. Run route chooses the saved route that will be used for sniping.\n'
            'Default is protected. Save as creates variants such as Busy zones.\n'
            'Remove selected works on originals and extras. Use Undo remove or Restore originals.\n'
            'Save & reset checks applies edits. Switching routes resets pass progress and timing.\n'
            'Existing v24 edits are imported as My route; the old route file is retained.\n'
            'Removing points can omit spawn spots; totals are shown in the editor and panel.\n\n'
            'Default loading/inspection waits and gem confirmation are unchanged.\n'
            'Last view / Map-load / Inspect show timing on your PC. Offline Windows comparison\n'
            'and validation reports are included under validation; live game speed is not measured.\n'
            'Do not delete %LOCALAPPDATA%\\LoongLens; settings, screenshots and history stay there.\n',
            'utf-8')
        for image in sorted((ROOT/'artifacts').glob('v36-*.png')):shutil.copy2(image,validation/image.name)
        manifest={p.relative_to(app).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted(app.rglob('*')) if p.is_file()}
        (app/'PACKAGE-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n','utf-8')
        with py7zr.SevenZipFile(out,'w',filters=[{'id':py7zr.FILTER_LZMA2,'preset':6}]) as archive:
            archive.writeall(app,'LoongLens')
        with py7zr.SevenZipFile(out) as archive:archive.extractall(folder/'verified')
        for name,digest in manifest.items():
            if hashlib.sha256((folder/'verified/LoongLens'/name).read_bytes()).hexdigest()!=digest:
                raise RuntimeError(f'Archive verification failed: {name}')
    checksum=hashlib.sha256(out.read_bytes()).hexdigest()
    out.with_suffix('.7z.sha256').write_text(f'{checksum}  {out.name}\n','ascii')
    print(f'Verified complete Windows package: {out.name}, {out.stat().st_size:,} bytes, {len(manifest)+1} files')


if __name__=='__main__':main()
