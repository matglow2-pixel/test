"""Try a larger desktop on the disposable Windows CI runner for UI captures."""
import ctypes
from ctypes import wintypes as w

class Mode(ctypes.Structure):
    _fields_=[('device',w.WCHAR*32),('spec',w.WORD),('driver',w.WORD),('size',w.WORD),('extra',w.WORD),('fields',w.DWORD),
      ('x',w.LONG),('y',w.LONG),('orientation',w.DWORD),('fixed_output',w.DWORD),('color',w.SHORT),('duplex',w.SHORT),
      ('yres',w.SHORT),('tt',w.SHORT),('collate',w.SHORT),('form',w.WCHAR*32),('logpixels',w.WORD),
      ('bits',w.DWORD),('width',w.DWORD),('height',w.DWORD),('flags',w.DWORD),('frequency',w.DWORD),
      ('icm_method',w.DWORD),('icm_intent',w.DWORD),('media',w.DWORD),('dither',w.DWORD),('reserved1',w.DWORD),
      ('reserved2',w.DWORD),('pan_width',w.DWORD),('pan_height',w.DWORD)]

def main():
    user=ctypes.WinDLL('user32');assert ctypes.sizeof(Mode)==220
    user.EnumDisplaySettingsW.argtypes=(w.LPCWSTR,w.DWORD,ctypes.POINTER(Mode));user.EnumDisplaySettingsW.restype=w.BOOL
    user.ChangeDisplaySettingsW.argtypes=(ctypes.POINTER(Mode),w.DWORD);user.ChangeDisplaySettingsW.restype=w.LONG
    mode=Mode(size=ctypes.sizeof(Mode))
    if not user.EnumDisplaySettingsW(None,0xffffffff,ctypes.byref(mode)):
        print('Display mode not available; native window checks still run.');return
    print(f'Initial validation desktop: {mode.width} x {mode.height}')
    mode.width=1920;mode.height=1080;mode.fields=0x180000
    result=user.ChangeDisplaySettingsW(ctypes.byref(mode),0)
    current=Mode(size=ctypes.sizeof(Mode));user.EnumDisplaySettingsW(None,0xffffffff,ctypes.byref(current))
    print(f'Display change result: {result}; current {current.width} x {current.height}')

if __name__=='__main__':main()
