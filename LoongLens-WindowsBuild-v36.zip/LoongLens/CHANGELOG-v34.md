# v34 — recognise dim camera selections

- Fix successful camera selections being rejected because the translucent
  outline is gray rather than bright white. Detect thin local-contrast lines
  and the projected camera rectangle instead of imposing a white-pixel cutoff.
- Require the expected horizontal and vertical geometry where visible so a
  nearby offset rectangle or a click ripple cannot confirm the wrong target.
- Recognised selections close the map and inspect the view. Genuinely ignored
  clicks still retry once and remain unchecked if confirmation fails.
- Process the rectangle neighbourhood; add no fixed pause, input padding,
  portal restrictions or changes to map-control boxes and drag bounds.
- Preserve v33 daily 5/5 collection, 20-second waits, Emerald Corner (241,107)
  return, 16:00 Europe/Sofia reset, 1h 15s sighting dots, routes, assets,
  native cursor protection and Gem Spy histories/observation-only behaviour.

Validation includes dim/antialiased outlines on brown/green/snow backgrounds at
three capture sizes, clipped outlines, offset rectangles, click ripples and
one-tap/one-Back simulated inspection. The full Windows suite, native UI/input,
frozen EXE and archive extraction/hash checks are run before publication.
These checks are not a live BlueStacks game run.
