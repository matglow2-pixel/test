"""Capture a native Windows validation window at its full original size."""
import ctypes
from ctypes import wintypes as w
from PIL import Image


class BitmapHeader(ctypes.Structure):
    _fields_=[('size',w.DWORD),('width',w.LONG),('height',w.LONG),('planes',w.WORD),
              ('bits',w.WORD),('compression',w.DWORD),('image_size',w.DWORD),
              ('xppm',w.LONG),('yppm',w.LONG),('used',w.DWORD),('important',w.DWORD)]


def capture_window(hwnd):
    user=ctypes.WinDLL('user32',use_last_error=True);gdi=ctypes.WinDLL('gdi32',use_last_error=True)
    user.GetWindowRect.argtypes=(w.HWND,ctypes.POINTER(w.RECT));user.GetWindowRect.restype=w.BOOL
    user.GetWindowDC.argtypes=(w.HWND,);user.GetWindowDC.restype=w.HDC
    user.ReleaseDC.argtypes=(w.HWND,w.HDC);user.ReleaseDC.restype=ctypes.c_int
    user.PrintWindow.argtypes=(w.HWND,w.HDC,w.UINT);user.PrintWindow.restype=w.BOOL
    gdi.CreateCompatibleDC.argtypes=(w.HDC,);gdi.CreateCompatibleDC.restype=w.HDC
    gdi.CreateCompatibleBitmap.argtypes=(w.HDC,ctypes.c_int,ctypes.c_int);gdi.CreateCompatibleBitmap.restype=w.HBITMAP
    gdi.SelectObject.argtypes=(w.HDC,w.HGDIOBJ);gdi.SelectObject.restype=w.HGDIOBJ
    gdi.DeleteDC.argtypes=(w.HDC,);gdi.DeleteDC.restype=w.BOOL
    gdi.DeleteObject.argtypes=(w.HGDIOBJ,);gdi.DeleteObject.restype=w.BOOL
    gdi.GetDIBits.argtypes=(w.HDC,w.HBITMAP,w.UINT,w.UINT,ctypes.c_void_p,ctypes.c_void_p,w.UINT)
    gdi.GetDIBits.restype=ctypes.c_int
    rect=w.RECT()
    if not user.GetWindowRect(hwnd,ctypes.byref(rect)):raise ctypes.WinError(ctypes.get_last_error())
    width,height=rect.right-rect.left,rect.bottom-rect.top
    if width<=0 or height<=0:raise ValueError('Window has no visible dimensions')
    dc=user.GetWindowDC(hwnd);memory=None;bitmap=None;previous=None
    try:
        if not dc:raise ctypes.WinError(ctypes.get_last_error())
        memory=gdi.CreateCompatibleDC(dc);bitmap=gdi.CreateCompatibleBitmap(dc,width,height)
        if not memory or not bitmap:raise ctypes.WinError(ctypes.get_last_error())
        previous=gdi.SelectObject(memory,bitmap)
        if not user.PrintWindow(hwnd,memory,2):raise RuntimeError('Native window capture failed')
        gdi.SelectObject(memory,previous);previous=None
        header=BitmapHeader(size=ctypes.sizeof(BitmapHeader),width=width,height=-height,planes=1,bits=32)
        pixels=ctypes.create_string_buffer(width*height*4)
        if gdi.GetDIBits(memory,bitmap,0,height,pixels,ctypes.byref(header),0)!=height:raise RuntimeError('Native bitmap capture failed')
        return Image.frombytes('RGB',(width,height),pixels.raw,'raw','BGRX')
    finally:
        if previous and memory:gdi.SelectObject(memory,previous)
        if bitmap:gdi.DeleteObject(bitmap)
        if memory:gdi.DeleteDC(memory)
        if dc:user.ReleaseDC(hwnd,dc)
