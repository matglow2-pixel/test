"""Persistent Spy visits and distinct encounters; one standard row per encounter."""
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics
import sqlite3
import uuid
from gem_detector import gameplay_mask
from sighting_history import SightingHistory

MATCH_DISTANCE=.35
_MASK=gameplay_mask((1029,570))!=0


def point_key(view):
    return json.dumps([view.route_label,round(view.x,5),round(view.y,5),sorted(view.cells)],separators=(',',':'))


def route_signature(views):
    return hashlib.sha256('\n'.join(point_key(v) for v in views).encode()).hexdigest()


def hour_bucket(stamp):
    local=datetime.fromtimestamp(stamp).astimezone()
    start=local.replace(minute=0,second=0,microsecond=0)
    return start.isoformat(),start.timestamp()


def world_position(view,x,y):
    return view.x+(x-285)*6.7/570,view.y-(y-514.5)*12.1/1029


def covered(camera_x,camera_y,x,y):
    px=round(285+(x-camera_x)*570/6.7)
    py=round(514.5-(y-camera_y)*1029/12.1)
    # An absence requires the complete approximate gem footprint to be visible.
    return (15<=px<555 and 15<=py<1014
            and bool(_MASK[py-14:py+15,px-14:px+15].all()))


class SpyHistory:
    def __init__(self,path):
        self.standard=SightingHistory(path)
        self.connection=self.standard.connection
        self.connection.row_factory=sqlite3.Row
        self.connection.execute('PRAGMA busy_timeout=5000')
        self.connection.executescript('''
            CREATE TABLE IF NOT EXISTS spy_state(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS spy_visits(
                id INTEGER PRIMARY KEY,run INTEGER NOT NULL,point_key TEXT NOT NULL,
                point TEXT NOT NULL,zone TEXT NOT NULL,camera_x REAL NOT NULL,camera_y REAL NOT NULL,
                checked_at REAL NOT NULL,outcome TEXT NOT NULL,clear_absence INTEGER NOT NULL,
                detections TEXT NOT NULL,reason TEXT NOT NULL,hour_key TEXT NOT NULL,hour_start REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS spy_visit_time ON spy_visits(checked_at DESC);
            CREATE INDEX IF NOT EXISTS spy_visit_coverage ON spy_visits(camera_x,camera_y,checked_at);
            CREATE INDEX IF NOT EXISTS spy_visit_hour ON spy_visits(hour_key,hour_start);
            CREATE TABLE IF NOT EXISTS spy_encounters(
                id TEXT PRIMARY KEY,event_id TEXT NOT NULL UNIQUE,point_key TEXT NOT NULL,
                point TEXT NOT NULL,zone TEXT NOT NULL,camera_x REAL NOT NULL,camera_y REAL NOT NULL,
                anchor_x REAL NOT NULL,anchor_y REAL NOT NULL,first_seen REAL NOT NULL,last_seen REAL NOT NULL,
                last_empty REAL,first_missing REAL,confirmed_missing REAL,
                miss_count INTEGER NOT NULL DEFAULT 0,miss_run INTEGER,
                hour_key TEXT NOT NULL,hour_start REAL NOT NULL,score REAL NOT NULL,
                screenshot_path TEXT,capture_status TEXT NOT NULL DEFAULT 'pending');
            CREATE INDEX IF NOT EXISTS spy_active ON spy_encounters(confirmed_missing,anchor_x,anchor_y);
            CREATE INDEX IF NOT EXISTS spy_encounter_hour ON spy_encounters(hour_key,hour_start);
            CREATE TABLE IF NOT EXISTS spy_encounter_runs(
                encounter_id TEXT NOT NULL,run INTEGER NOT NULL,PRIMARY KEY(encounter_id,run));
        ''')
        self.connection.commit()

    def close(self):self.standard.close()

    def recover_captures(self,folder):
        """Recover an already-written first photo, never take a later substitute."""
        for row in self.connection.execute("SELECT * FROM spy_encounters WHERE capture_status IN ('pending','interrupted')").fetchall():
            digest=hashlib.sha256(row['event_id'].encode()).hexdigest()[:24]
            name=datetime.fromtimestamp(row['first_seen']).strftime('%Y%m%d-%H%M%S')+'-'+digest+'.png'
            path=Path(folder)/'screenshots'/name
            available=path.is_file() and path.stat().st_size>0
            event=dict(event_id=row['event_id'],zone=row['zone'],game_x=math.floor(row['camera_x']),game_y=math.floor(row['camera_y']),
                screenshot_path=str(path.resolve()) if available else None,capture_status='ready' if available else 'interrupted',
                captured_at=path.stat().st_mtime if available else None,
                capture_note='Camera view: original Gem Spy screenshot recovered.' if available else 'Camera view: app stopped before the original Spy screenshot was saved.')
            self.finish_capture(event)

    def state(self,key,default=None):
        row=self.connection.execute('SELECT value FROM spy_state WHERE key=?',(key,)).fetchone()
        return json.loads(row[0]) if row else default

    def save_state(self,key,value):
        with self.connection:
            self.connection.execute('INSERT INTO spy_state VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                                    (key,json.dumps(value,separators=(',',':'))))

    def checkpoint(self,views):
        state=self.state('checkpoint',{})
        signature=route_signature(views)
        if state.get('route')!=signature:
            state=dict(state,route=signature,checked=[],run=state.get('run',0)+1)
        state.setdefault('elapsed',0.)
        state.setdefault('checked',[])
        state.setdefault('run',1)
        return state

    def _last_empty(self,x,y,before):
        for row in self.connection.execute('''SELECT camera_x,camera_y,checked_at,detections FROM spy_visits
            WHERE clear_absence=1 AND checked_at<? AND camera_x BETWEEN ? AND ? AND camera_y BETWEEN ? AND ?
            ORDER BY checked_at DESC''',(before,x-3.35,x+3.35,y-6.05,y+6.05)):
            if not covered(row['camera_x'],row['camera_y'],x,y):continue
            if all(math.dist((x,y),p[:2])>MATCH_DISTANCE for p in json.loads(row['detections'])):
                return row['checked_at']
        return None

    def observe(self,view,run,stamp,samples=(),clear=False,reason=''):
        key=point_key(view);bucket,start=hour_bucket(stamp)
        detections=[]
        for sample in samples:
            x,y=world_position(view,sample['screen_x'],sample['screen_y'])
            detections.append((x,y,sample))
        new=[];used=set()
        with self.connection:
            active=list(self.connection.execute('SELECT * FROM spy_encounters WHERE confirmed_missing IS NULL'))
            for x,y,sample in detections:
                candidates=[(math.dist((x,y),(r['anchor_x'],r['anchor_y'])),r) for r in active if r['id'] not in used]
                distance,row=min(candidates,key=lambda p:p[0]) if candidates else (float('inf'),None)
                seen_at=float(sample.get('seen_at',stamp));last_seen=float(sample.get('last_seen',seen_at))
                if row is not None and distance<=MATCH_DISTANCE:
                    ident=row['id'];used.add(ident)
                    self.connection.execute('UPDATE spy_encounters SET last_seen=MAX(last_seen,?),miss_count=0,miss_run=NULL,first_missing=NULL WHERE id=?',(last_seen,ident))
                else:
                    ident=uuid.uuid4().hex;event_id='spy:'+ident;used.add(ident)
                    first_bucket,first_start=hour_bucket(seen_at)
                    last_empty=self._last_empty(x,y,seen_at)
                    self.connection.execute('''INSERT INTO spy_encounters
                        (id,event_id,point_key,point,zone,camera_x,camera_y,anchor_x,anchor_y,first_seen,last_seen,last_empty,hour_key,hour_start,score)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                        (ident,event_id,key,view.route_label,view.near_zone,view.x,view.y,x,y,seen_at,last_seen,last_empty,first_bucket,first_start,sample['score']))
                    note='Camera view: selected area; gem position is approximate. Gem Spy observation only.'
                    event=dict(event_id=event_id,seen_at=seen_at,screen_x=sample['screen_x'],screen_y=sample['screen_y'],
                        score=sample['score'],test_mode=False,origin='Gem Spy',capture_status='pending',capture_note=note,
                        zone=view.near_zone,game_x=math.floor(view.x),game_y=math.floor(view.y),
                        camera_location=dict(zone=view.near_zone,x=math.floor(view.x),y=math.floor(view.y)))
                    # Same transaction: a committed encounter always has its
                    # standard-history row, even if the process stops next.
                    self.connection.execute('''INSERT INTO sightings
                        (event_id,seen_at,screen_x,screen_y,score,test_mode,zone,game_x,game_y,capture_status,capture_note,origin)
                        VALUES(?,?,?,?,?,0,?,?,?,'pending',?,'Gem Spy')''',
                        (event_id,seen_at,sample['screen_x'],sample['screen_y'],sample['score'],view.near_zone,math.floor(view.x),math.floor(view.y),note))
                    new.append((event,sample))
                self.connection.execute('INSERT OR IGNORE INTO spy_encounter_runs VALUES(?,?)',(ident,run))
            if clear:
                for row in active:
                    if row['id'] in used or not covered(view.x,view.y,row['anchor_x'],row['anchor_y']):continue
                    # Overlapping views or a retry in one run cannot supply two
                    # independent absence checks.
                    if row['miss_run']==run:continue
                    count=row['miss_count']+1
                    self.connection.execute('''UPDATE spy_encounters SET miss_count=?,miss_run=?,
                        first_missing=COALESCE(first_missing,?),confirmed_missing=? WHERE id=?''',
                        (count,run,stamp,stamp if count>=2 else None,row['id']))
            outcome='present' if detections else 'empty' if clear else 'unclear'
            self.connection.execute('''INSERT INTO spy_visits
                (run,point_key,point,zone,camera_x,camera_y,checked_at,outcome,clear_absence,detections,reason,hour_key,hour_start)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (run,key,view.route_label,view.near_zone,view.x,view.y,stamp,outcome,int(clear),
                 json.dumps([[x,y] for x,y,_ in detections]),reason,bucket,start))
        return new

    def finish_capture(self,event):
        columns=SightingHistory.CAPTURE_FIELDS
        assignments=','.join(f'{name}=CASE WHEN manual_location THEN {name} ELSE ? END'
                             if name in ('zone','game_x','game_y') else f'{name}=?' for name in columns)
        with self.connection:
            # UPDATE only: removing a standard-history entry during an async
            # capture must not recreate it. The exclusive Spy record remains.
            self.connection.execute(f'UPDATE sightings SET {assignments} WHERE event_id=?',
                                    tuple(event.get(n) for n in columns)+(event['event_id'],))
            self.connection.execute('UPDATE spy_encounters SET screenshot_path=?,capture_status=? WHERE event_id=?',
                                    (event.get('screenshot_path'),event['capture_status'],event['event_id']))

    def totals(self):
        return dict(self.connection.execute('SELECT COUNT(*) total,SUM(confirmed_missing IS NULL) active FROM spy_encounters').fetchone())

    def encounters(self):
        return [dict(row) for row in self.connection.execute('''SELECT e.*,
            (SELECT COUNT(*) FROM spy_encounter_runs r WHERE r.encounter_id=e.id) runs
            FROM spy_encounters e ORDER BY first_seen DESC''')]

    def visits(self,limit=1000):
        return [dict(row) for row in self.connection.execute('SELECT * FROM spy_visits ORDER BY checked_at DESC,id DESC LIMIT ?',(limit,))]

    def hours(self):
        return [dict(row) for row in self.connection.execute('''WITH hours AS (
            SELECT hour_key,hour_start FROM spy_visits UNION SELECT hour_key,hour_start FROM spy_encounters)
            SELECT h.hour_key,h.hour_start,(SELECT COUNT(*) FROM spy_encounters e WHERE e.hour_key=h.hour_key) gems,
            (SELECT COUNT(*) FROM spy_visits v WHERE v.hour_key=h.hour_key) checks
            FROM hours h ORDER BY hour_start DESC''')]

    def patterns(self):
        groups={}
        for row in self.encounters():groups.setdefault(row['point_key'],[]).append(row)
        result=[]
        for rows in groups.values():
            counts=[0]*60;valid=[]
            for row in rows:
                lower=row['last_empty'];upper=row['first_seen']
                if lower is None or not 0<=upper-lower<3600:continue
                a=datetime.fromtimestamp(lower);b=datetime.fromtimestamp(upper)
                minutes=min(59,math.floor((a.second+a.microsecond/1e6+upper-lower)/60))
                bins={(a.minute+i)%60 for i in range(minutes+1)}|{b.minute}
                for minute in bins:counts[minute]+=1
                valid.append(row)
            support=max(counts);best=[i for i,n in enumerate(counts) if n==support and support]
            distinct_hours=len({row['hour_key'] for row in valid})
            if len(valid)<3 or distinct_hours<2:
                candidate='Learning — need 3 windows across 2 hours'
            else:
                spans=[]
                for minute in best:
                    if spans and minute==spans[-1][1]+1:spans[-1][1]=minute
                    else:spans.append([minute,minute])
                candidate=', '.join(f':{a:02d}–:{b:02d}' if a!=b else f':{a:02d}' for a,b in spans)+' (candidate)'
            ordered=sorted(row['first_seen'] for row in rows)
            gaps=[(b-a)/60 for a,b in zip(ordered,ordered[1:])]
            result.append(dict(point=rows[0]['point'],zone=rows[0]['zone'],candidate=candidate,
                               support=f'{support}/{len(valid)} windows',appearances=len(rows),
                               gap_minutes=statistics.median(gaps) if gaps else None))
        return sorted(result,key=lambda r:(r['zone'],r['point']))
