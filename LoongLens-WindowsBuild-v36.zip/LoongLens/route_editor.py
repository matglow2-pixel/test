"""Full-map camera target editor. Editing never sends game input."""
from dataclasses import replace
import math
import tkinter as tk
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
from resources import user_dir
from camera_patrol import PatrolSettings
from patrol_route import camera_warnings,clear_view_bounds,add_camera_view,remove_camera_view,restore_camera_originals
from ui_theme import BG,CARD,TEXT,ACCENT,MUTED


class RouteEditor:
    def __init__(self,parent,base,views,on_save,on_close=lambda:None,*,route_choices=None,active_route='',on_route_change=None,on_save_copy=None):
        self.base=tuple(base);self.views=list(views);self.on_save=on_save;self.on_close=on_close
        self.defaults={v.route_label:v for v in views}
        self.undo_removed=[]
        self.route_choices=route_choices;self.on_route_change=on_route_change;self.on_save_copy=on_save_copy
        self.active_route=active_route
        self.selected=0;self.dragging=False;self.dirty=False;self.scale=.18
        self.window=tk.Toplevel(parent);self.window.title('Loong Lens · Edit camera route')
        width=min(1100,self.window.winfo_screenwidth()-60);height=min(820,self.window.winfo_screenheight()-80)
        self.window.geometry(f'{width}x{height}');self.window.minsize(820,620)
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        from heatmap_map_import import load_map
        self.source,self.map_metadata=load_map(user_dir())
        bar=ttk.Frame(self.window,padding=10);bar.pack(fill='x')
        ttk.Label(bar,text='Drag camera targets · pink dots are the original spawn locations',font=('Segoe UI',11,'bold')).pack(side='left')
        ttk.Button(bar,text='Save & reset checks',style='Primary.TButton',command=self.save).pack(side='right')
        if route_choices is not None:
            profiles=ttk.Frame(self.window,padding=(10,0,10,8));profiles.pack(fill='x')
            ttk.Label(profiles,text='Run route').pack(side='left')
            self.route_choice=tk.StringVar(value=active_route)
            self.route_box=ttk.Combobox(profiles,textvariable=self.route_choice,values=route_choices(),state='readonly',width=32)
            self.route_box.pack(side='left',fill='x',expand=True,padx=10)
            self.route_box.bind('<<ComboboxSelected>>',self.change_route)
            ttk.Button(profiles,text='Save as…',command=self.save_route_copy).pack(side='right')
        body=ttk.Frame(self.window,padding=(10,0,10,10));body.pack(fill='both',expand=True)
        sidebar=ttk.Frame(body,width=270);sidebar.pack(side='right',fill='y',padx=(12,0));sidebar.pack_propagate(False)
        self.total=tk.StringVar();ttk.Label(sidebar,textvariable=self.total).pack(anchor='w')
        listing=ttk.Frame(sidebar);listing.pack(fill='both',expand=True,pady=6)
        self.listbox=tk.Listbox(listing,bg=CARD,fg=TEXT,selectbackground='#35516b',exportselection=False,highlightthickness=0,height=5)
        scroll=ttk.Scrollbar(listing,command=self.listbox.yview);scroll.pack(side='right',fill='y')
        self.listbox.configure(yscrollcommand=scroll.set);self.listbox.pack(fill='both',expand=True)
        self.refresh_list()
        self.listbox.bind('<<ListboxSelect>>',self.select_list)
        fields=ttk.Frame(sidebar);fields.pack(fill='x')
        self.x=tk.StringVar();self.y=tk.StringVar()
        for name,value in (('X',self.x),('Y',self.y)):
            ttk.Label(fields,text=name).pack(side='left');ttk.Entry(fields,textvariable=value,width=7).pack(side='left',padx=(4,8))
        ttk.Button(sidebar,text='Apply coordinates',command=self.apply_fields).pack(fill='x',pady=6)
        ttk.Button(sidebar,text='Add view after selected',command=self.add_view).pack(fill='x',pady=(0,6))
        ttk.Button(sidebar,text='Zoom to selected',command=self.zoom_selected).pack(fill='x')
        reset=ttk.Frame(sidebar);reset.pack(fill='x',pady=6)
        ttk.Button(reset,text='Reset point',command=self.reset_selected,padding=(8,7)).pack(side='left',expand=True,fill='x')
        self.remove_button=ttk.Button(reset,text='Remove selected',command=self.remove_selected,padding=(8,7))
        self.remove_button.pack(side='left',expand=True,fill='x',padx=(6,0))
        restore=ttk.Frame(sidebar);restore.pack(fill='x',pady=(0,6))
        self.undo_button=ttk.Button(restore,text='Undo remove',command=self.undo_remove,padding=(6,7))
        self.undo_button.pack(side='left',expand=True,fill='x')
        self.restore_button=ttk.Button(restore,text='Restore originals',command=self.restore_originals,padding=(6,7))
        self.restore_button.pack(side='left',expand=True,fill='x',padx=(6,0))
        ttk.Button(sidebar,text='Reset route to defaults',command=self.reset_all).pack(fill='x')
        self.info=tk.StringVar();ttk.Label(sidebar,textvariable=self.info,wraplength=258,style='Muted.TLabel').pack(fill='x',pady=10)
        ttk.Label(sidebar,text='Solid box: camera view\nDashed box: suggested clear area\nWheel / + −: zoom · drag empty map: pan\nArrow keys: nudge selected camera\nRemoved targets are skipped in sniping.\nPink spawn dots stay unchanged.',wraplength=258,style='Muted.TLabel').pack(fill='x')
        area=ttk.Frame(body);area.pack(fill='both',expand=True)
        zoom=ttk.Frame(area);zoom.pack(fill='x',pady=(0,5))
        ttk.Button(zoom,text='Whole map',command=self.fit).pack(side='left')
        ttk.Button(zoom,text='+',command=lambda:self.zoom(1.4)).pack(side='left',padx=5)
        ttk.Button(zoom,text='-',command=lambda:self.zoom(1/1.4)).pack(side='left')
        self.canvas=tk.Canvas(area,bg=BG,highlightthickness=0);self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<ButtonPress-1>',self.press);self.canvas.bind('<B1-Motion>',self.motion)
        self.canvas.bind('<ButtonRelease-1>',lambda e:setattr(self,'dragging',False))
        self.canvas.bind('<MouseWheel>',lambda e:self.zoom(1.25 if e.delta>0 else .8,e.x,e.y))
        self.canvas.bind('<Button-4>',lambda e:self.zoom(1.25,e.x,e.y))
        self.canvas.bind('<Button-5>',lambda e:self.zoom(.8,e.x,e.y))
        for key,dx,dy in (('Left',-.25,0),('Right',.25,0),('Up',0,.25),('Down',0,-.25)):
            self.canvas.bind('<'+key+'>',lambda e,a=dx,b=dy:self.nudge(a,b))
        self.window.update_idletasks();self.fit();self.select(0)

    def point(self,x,y):return x*12.45*self.scale,(279-y)*12.45*self.scale
    def world(self,x,y):return x/(12.45*self.scale),279-y/(12.45*self.scale)

    def load_profile(self,name,views):
        self.views=list(views);self.defaults={v.route_label:v for v in views}
        self.selected=0;self.undo_removed=[];self.dirty=False;self.active_route=name
        self.route_box.configure(values=self.route_choices());self.route_choice.set(name)
        self.refresh_list();self.select(0)

    def change_route(self,event=None):
        name=self.route_choice.get()
        if name==self.active_route:return
        if self.dirty and not messagebox.askyesno('Unsaved route edits',f'Switch to {name} and discard unsaved changes?',parent=self.window):
            self.route_choice.set(self.active_route);return
        try:
            views=self.on_route_change(name)
            self.load_profile(name,views)
        except (OSError,ValueError,TypeError) as exc:
            self.route_choice.set(self.active_route)
            messagebox.showerror('Could not change route',str(exc),parent=self.window)

    def save_route_copy(self):
        try:result=self.on_save_copy(tuple(self.views))
        except (OSError,ValueError,TypeError) as exc:
            messagebox.showerror('Could not save route',str(exc),parent=self.window);return
        if result is not None:self.load_profile(*result)

    def draw(self):
        c=self.canvas;c.delete('all')
        size=round(3486*self.scale)
        if getattr(self,'image_size',None)!=size:
            self.photo=ImageTk.PhotoImage(self.source.resize((size,size),Image.Resampling.LANCZOS));self.image_size=size
        c.create_image(0,0,image=self.photo,anchor='nw');c.configure(scrollregion=(0,0,size,size))
        path=[coord for v in self.views for coord in self.point(v.x,v.y)]
        if len(path)>=4:c.create_line(*path,fill=ACCENT,width=2,arrow='last')
        for v in self.base:
            for x,y in v.cells:
                px,py=self.point(x+.5,y+.5);c.create_oval(px-3,py-3,px+3,py+3,fill='#ff79dc',outline='#311b37')
        view=self.views[self.selected]
        for bounds,color,dash in ((view.bounds(PatrolSettings()),'#ffffff',None),(clear_view_bounds(view),'#ffd27b',(5,3))):
            l,b,r,t=bounds;coords=(*self.point(l,t),*self.point(r,b))
            c.create_rectangle(*coords,outline=color,width=2,dash=dash or ())
        for i,v in enumerate(self.views):
            x,y=self.point(v.x,v.y);color='#ffcf76' if i==self.selected else ACCENT
            c.create_oval(x-7,y-7,x+7,y+7,fill=BG,outline=color,width=2)
            c.create_text(x+9,y-10,text=v.route_label,anchor='w',fill=color,font=('Segoe UI',10,'bold'))

    def fit(self):
        self.scale=max(.1,min(self.canvas.winfo_width(),self.canvas.winfo_height())/3486)
        self.draw();self.canvas.xview_moveto(0);self.canvas.yview_moveto(0)

    def zoom(self,factor,x=None,y=None):
        x=self.canvas.winfo_width()/2 if x is None else x;y=self.canvas.winfo_height()/2 if y is None else y
        wx,wy=self.world(self.canvas.canvasx(x),self.canvas.canvasy(y))
        self.scale=min(1.6,max(.1,self.scale*factor));self.draw();px,py=self.point(wx,wy)
        size=round(3486*self.scale)
        self.canvas.xview_moveto((px-x)/size);self.canvas.yview_moveto((py-y)/size)

    def zoom_selected(self):
        self.scale=max(self.scale,.65);self.draw()
        px,py=self.point(self.views[self.selected].x,self.views[self.selected].y);size=round(3486*self.scale)
        self.canvas.xview_moveto((px-self.canvas.winfo_width()/2)/size)
        self.canvas.yview_moveto((py-self.canvas.winfo_height()/2)/size)

    def select(self,index):
        self.selected=index;self.listbox.selection_clear(0,'end');self.listbox.selection_set(index);self.listbox.see(index)
        v=self.views[index];self.x.set(f'{v.x:.2f}');self.y.set(f'{v.y:.2f}')
        warnings=camera_warnings(v)
        self.remove_button.configure(state='normal' if len(self.views)>1 else 'disabled')
        self.undo_button.configure(state='normal' if self.undo_removed else 'disabled')
        originals={view.route_label for view in self.views if not view.route_parent}
        self.restore_button.configure(state='normal' if len(originals)<len(self.base) else 'disabled')
        extra=f'Extra view for #{v.route_parent}\n' if v.route_parent else ''
        self.info.set(f'#{v.route_label} · {v.near_zone}\n{extra}Camera ({v.x:.2f}, {v.y:.2f})\n'+('\n'.join(warnings) if warnings else 'Recorded centres fit the suggested clear area.'))
        self.draw()

    def select_list(self,event=None):
        if self.listbox.curselection():self.select(self.listbox.curselection()[0])

    def press(self,event):
        self.canvas.focus_set();x,y=self.canvas.canvasx(event.x),self.canvas.canvasy(event.y)
        distances=[math.dist((x,y),self.point(v.x,v.y)) for v in self.views]
        nearest=self.selected if distances[self.selected]<=12 else min(range(len(distances)),key=distances.__getitem__)
        if distances[nearest]<=12:self.select(nearest);self.dragging=True
        else:self.dragging=False;self.canvas.scan_mark(event.x,event.y)

    def motion(self,event):
        if not self.dragging:self.canvas.scan_dragto(event.x,event.y,gain=1);return
        x,y=self.world(self.canvas.canvasx(event.x),self.canvas.canvasy(event.y));self.move_to(x,y)

    def move_to(self,x,y):
        self.views[self.selected]=replace(self.views[self.selected],x=round(min(279.99,max(0.,x)),2),y=round(min(279.99,max(0.,y)),2))
        self.dirty=True;self.select(self.selected)

    def nudge(self,x,y):
        v=self.views[self.selected];self.move_to(v.x+x,v.y+y);return 'break'

    def apply_fields(self):
        try:
            x,y=float(self.x.get()),float(self.y.get())
            if not all(math.isfinite(a) and 0<=a<280 for a in (x,y)):raise ValueError()
        except ValueError:messagebox.showerror('Invalid coordinates','Use coordinates from 0 to 279.99.',parent=self.window);return
        self.move_to(x,y)

    def reset_selected(self):
        current=self.views[self.selected]
        self.views[self.selected]=(self.defaults[current.route_label] if current.route_parent else next(v for v in self.base if v.route_label==current.route_label))
        self.dirty=True;self.select(self.selected)

    def refresh_list(self):
        self.listbox.delete(0,'end')
        for v in self.views:self.listbox.insert('end',f'#{v.route_label} · {v.near_zone}')
        covered=set().union(*(v.cells for v in self.views));all_cells=set().union(*(v.cells for v in self.base))
        self.total.set(f'CAMERA TARGETS · {len(self.views)} views\nListed spots: {len(covered)} / {len(all_cells)} · {len(all_cells-covered)} omitted')

    def add_view(self):
        self.views=list(add_camera_view(self.views,self.selected,reserved_labels=[v.route_label for v,*_ in self.undo_removed]));self.selected+=1
        extra=self.views[self.selected];self.defaults[extra.route_label]=extra
        self.dirty=True;self.refresh_list();self.select(self.selected)

    def remove_extra(self):
        if not self.views[self.selected].route_parent:return
        self.remove_selected()

    def remove_selected(self):
        if len(self.views)<=1:return
        i=self.selected
        self.undo_removed.append((self.views[i],self.views[i-1].route_label if i else None,
                                  self.views[i+1].route_label if i+1<len(self.views) else None,i))
        self.views=list(remove_camera_view(self.views,i));self.selected=min(i,len(self.views)-1)
        self.dirty=True;self.refresh_list();self.select(self.selected)

    def undo_remove(self):
        if not self.undo_removed:return
        view,before,after,index=self.undo_removed.pop()
        labels=[v.route_label for v in self.views]
        if after in labels:index=labels.index(after)
        elif before in labels:index=labels.index(before)+1
        else:index=min(index,len(self.views))
        self.views.insert(index,view);self.selected=index
        self.dirty=True;self.refresh_list();self.select(index)

    def restore_originals(self):
        label=self.views[self.selected].route_label
        self.views=list(restore_camera_originals(self.base,self.views));self.undo_removed=[]
        self.selected=next(i for i,v in enumerate(self.views) if v.route_label==label)
        self.dirty=True;self.refresh_list();self.select(self.selected)

    def reset_all(self):
        view=self.views[self.selected];label=view.route_parent or view.route_label
        self.views=list(self.base);self.selected=next(i for i,v in enumerate(self.base) if v.route_label==label)
        self.undo_removed=[]
        self.dirty=True;self.refresh_list();self.select(self.selected)

    def save(self):
        try:result=self.on_save(tuple(self.views))
        except (OSError,ValueError) as exc:messagebox.showerror('Could not save',str(exc),parent=self.window);return
        if result is False:return
        self.dirty=False;self.close()

    def close(self):
        if self.dirty and not messagebox.askyesno('Discard adjustments?','Close without saving your camera adjustments?',parent=self.window):return
        self.source.close();self.window.destroy();self.on_close()
