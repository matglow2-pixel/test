"""Daily Gem Sniper finds and user-correctable obtained flags."""
from datetime import datetime
import os
from pathlib import Path
import sqlite3
import tkinter as tk
from tkinter import ttk,messagebox


class DailyGemsControls:
    def __init__(self,root,quota,on_change):
        self.root=root;self.quota=quota;self.on_change=on_change
        self.window=None;self.tree=None;self.rows={}
        self.scope=tk.StringVar(root,value='today');self.summary=tk.StringVar(root)
        self.obtained=tk.BooleanVar(root,value=True);self.check=None

    def show(self):
        if self.window is not None and self.window.winfo_exists():self.window.lift();return
        window=self.window=tk.Toplevel(self.root);window.title('Daily gems — Gem Sniper')
        window.transient(self.root);window.geometry('980x510');window.minsize(760,380)
        window.bind('<Destroy>',self.destroyed)
        body=ttk.Frame(window,padding=18);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Daily gems',font=('Segoe UI',14,'bold')).pack(anchor='w')
        ttk.Label(body,textvariable=self.summary,style='Muted.TLabel').pack(anchor='w',pady=(5,8))
        filters=ttk.Frame(body);filters.pack(fill='x')
        ttk.Label(filters,text='Untick Obtained if you missed a gem. The sighting and screenshot stay saved.',
                  style='Muted.TLabel').pack(side='left')
        for text,value in (('Today only','today'),('Show all','all')):
            ttk.Radiobutton(filters,text=text,variable=self.scope,value=value,command=self.refresh).pack(side='right',padx=5)
        table=ttk.Frame(body);table.pack(fill='both',expand=True,pady=10)
        self.tree=ttk.Treeview(table,columns=('obtained','time','location','source','score'),show='headings',selectmode='browse')
        for name,label,width in [('obtained','Obtained',80),('time','Spotted',150),('location','Location',260),('source','Source',230),('score','Match score',85)]:
            self.tree.heading(name,text=label);self.tree.column(name,width=width,minwidth=65,anchor='center' if name=='obtained' else 'w')
        scroll=ttk.Scrollbar(table,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        self.tree.bind('<ButtonRelease-1>',self.click);self.tree.bind('<<TreeviewSelect>>',self.select)
        self.tree.bind('<space>',self.toggle_selected)
        actions=ttk.Frame(body);actions.pack(fill='x')
        self.check=ttk.Checkbutton(actions,text='Obtained',variable=self.obtained,command=self.change_selected,state='disabled')
        self.check.pack(side='left')
        ttk.Button(actions,text='Open screenshot',command=self.open_screenshot).pack(side='left',padx=12)
        ttk.Button(actions,text='Close',command=window.destroy).pack(side='right')
        self.refresh()

    def destroyed(self,event):
        if event.widget==self.window:self.window=self.tree=self.check=None;self.rows={}

    def refresh(self):
        if self.tree is None or not self.tree.winfo_exists():return
        entries=self.quota.entries(today_only=self.scope.get()=='today');self.rows={r['event_id']:r for r in entries}
        self.summary.set(f'Game day resets at 16:00 Sofia · Obtained: {self.quota.count()}/5 · '+
                         f"{'Today' if self.scope.get()=='today' else 'All dates'} sightings: {len(entries)}")
        existing=set(self.tree.get_children());wanted=set(self.rows)
        for key in existing-wanted:self.tree.delete(key)
        for index,row in enumerate(entries):
            key=row['event_id'];location=row['zone'] or 'Location unavailable'
            if row['game_x'] is not None and row['game_y'] is not None:location+=f" ({row['game_x']},{row['game_y']})"
            values=('☑' if row['obtained'] else '☐',datetime.fromtimestamp(row['seen_at']).strftime('%d/%m/%y %H:%M'),
                    location,'Gem Sniper · Open screenshot' if row['screenshot_path'] else 'Gem Sniper · No screenshot',
                    '' if row['score'] is None else f"{row['score']:.3f}")
            if key in existing:self.tree.item(key,values=values)
            else:self.tree.insert('',index,iid=key,values=values)
            self.tree.move(key,'',index)
        self.select()

    def selected(self):
        selection=self.tree.selection() if self.tree is not None else ()
        return self.rows.get(selection[0]) if selection else None

    def select(self,event=None):
        row=self.selected()
        if self.check is not None:self.check.configure(state='normal' if row else 'disabled')
        if row:self.obtained.set(row['obtained'])

    def change(self,key,value):
        try:self.quota.set_obtained(key,value)
        except (ValueError,sqlite3.Error) as exc:messagebox.showerror('Could not update obtained gem',str(exc),parent=self.window)
        self.refresh();self.on_change()

    def change_selected(self):
        row=self.selected()
        if row:self.change(row['event_id'],self.obtained.get())

    def toggle_selected(self,event=None):
        row=self.selected()
        if row:self.change(row['event_id'],not row['obtained'])
        return 'break'

    def click(self,event):
        key=self.tree.identify_row(event.y);column=self.tree.identify_column(event.x)
        if key and column=='#1':self.change(key,not self.rows[key]['obtained'])
        elif key and column=='#4':self.tree.selection_set(key);self.open_screenshot()

    def open_screenshot(self):
        row=self.selected()
        if not row:return
        if not row['screenshot_path']:
            messagebox.showinfo('Gem screenshot','No screenshot is available for this entry.',parent=self.window);return
        path=Path(row['screenshot_path']).resolve();folder=(self.quota.path.parent/'screenshots').resolve()
        try:
            if path.suffix.lower()!='.png' or not path.is_relative_to(folder) or not path.is_file():raise OSError('The saved screenshot is unavailable.')
            os.startfile(str(path))
        except OSError as exc:messagebox.showerror('Gem screenshot',str(exc),parent=self.window)
