"""All-date visual sightings, independent of obtained status and daily quotas."""
from dataclasses import dataclass
import math
import cv2
import numpy as np
from PIL import Image

WORLD_SIZE=280


@dataclass(frozen=True)
class HeatmapSnapshot:
    cells: tuple
    total: int
    missing: int
    revision: tuple

    @property
    def mapped(self):return self.total-self.missing


class HeatmapHistory:
    def __init__(self,history):self.history=history;self.cached=None

    def snapshot(self):
        db=self.history.connection
        revision=(db.total_changes,db.execute('PRAGMA data_version').fetchone()[0])
        if self.cached is not None and revision==self.cached.revision:return self.cached
        cells=[];total=missing=0
        # One row per confirmed event; photo enrichments update that same row.
        # Include every date/source and missed gems. Image tests are excluded.
        for x,y,count in db.execute('''SELECT game_x,game_y,COUNT(*) FROM sightings
                WHERE test_mode=0 GROUP BY game_x,game_y'''):
            total+=count
            try:valid=all(math.isfinite(v) and float(v).is_integer() and 0<=v<WORLD_SIZE for v in (x,y))
            except (TypeError,ValueError):valid=False
            if valid:cells.append((int(x),int(y),count))
            else:missing+=count
        self.cached=HeatmapSnapshot(tuple(sorted(cells)),total,missing,revision)
        return self.cached


def density_grid(snapshot):
    grid=np.zeros((WORLD_SIZE,WORLD_SIZE),np.float32)
    for x,y,count in snapshot.cells:grid[WORLD_SIZE-1-y,x]+=count
    return grid


def heat_layer(snapshot,size):
    grid=density_grid(snapshot)
    if not snapshot.mapped:return Image.new('RGBA',size)
    density=cv2.GaussianBlur(grid,(0,0),1.6,borderType=cv2.BORDER_CONSTANT)
    peak=float(density.max())
    value=np.log1p(density*8)/np.log1p(peak*8) if peak else density
    # Transparent tails keep terrain labels readable. The density is relative,
    # not a spawn probability or a correction for observation effort.
    stops=np.array([[70,136,244],[66,215,192],[247,227,92],[251,143,54],[238,68,81]],np.float32)
    position=np.minimum(value*4,4);lo=np.floor(position).astype(int);hi=np.minimum(lo+1,4)
    fraction=(position-lo)[...,None]
    rgb=stops[lo]*(1-fraction)+stops[hi]*fraction
    alpha=np.where(value>.055,np.minimum(.76,value*.95),0)*255
    rgba=np.concatenate((rgb,alpha[...,None]),axis=2).astype(np.uint8)
    return Image.fromarray(rgba).resize(size,Image.Resampling.BILINEAR)


def compose_map(base,snapshot,enabled=True):
    if not enabled or not snapshot.mapped:return base.copy()
    return Image.alpha_composite(base.convert('RGBA'),heat_layer(snapshot,base.size)).convert('RGB')
