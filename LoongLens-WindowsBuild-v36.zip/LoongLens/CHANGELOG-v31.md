# v31 — Gem Spy and persistent observation histories

- Tabs are Map Tweaker, Gem Sniper and Gem Spy. The Gem Watch tab and its
  background watcher are no longer constructed. Detection sensitivity, HUD
  masking and sound preferences migrate from the existing settings file and
  are available in Gem Sniper settings. Existing standard history is retained.
- Spy uses the selected Sniper route and applicable settings, with its own
  Start/Resume, Stop/F10, status, Time spent and unique Gems found counter.
  There are no Spy route selectors, editors or settings dialogs. Only one
  route controller owns mouse delivery at a time.
- Spy checks and repeats the route without gem clicks, approach movement or
  stop-on-find. Multiple confirmed gems in a view can be recorded separately.
- Standard history keeps Spotted, Source and Match score. New Spy rows show
  Gem Spy and link the original screenshot. The exclusive Spy history keeps
  visits, last-empty/first-seen appearance windows, last seen, first missing,
  runs observed and the same photo. Continuing gems add no extra image or row.
- Two clear empty visits in separate runs confirm disappearance; uncertainty
  is not empty. Matching persists across runs/restarts and tolerates small
  within-view shifts. Exact identity across unobserved replacement is unknown.
- Hourly history groups distinct first-confirmed sightings by date/local hour,
  without counting a continuing gem again at the hour boundary. Timing history
  shows candidate minute ranges, supporting windows and observed gaps. These
  are observations and hypotheses, not exact spawn timestamps or a proven timer.
- Capture/alignment errors release input, retry with delay and retain counters,
  progress and histories. After two failures a point is unclear and revisited
  next run. Manual Stop/F10 cancels retries. A new app process restores the
  checkpoint but waits for Start/Resume; no process-crash watchdog is installed.
- State and new standard rows commit together in SQLite. Async image completion
  enriches those rows. Startup recovers an already-written original photo or
  marks it interrupted; a later screenshot is not mislabeled as the original.
- v30 centre-start dragging, four exact control exclusions with no padding,
  stationary release and removal of portal-coordinate restrictions remain.

Exit the old app, extract the full folder and run its new LoongLens.exe. The
header shows v31. Keep %LOCALAPPDATA%\LoongLens to retain settings, routes,
history and Spy tracking. Windows builds and checks include native Tk and input
on the app's own test windows, plus real detector/Spy storage with simulated
camera delivery. They do not run BlueStacks or establish actual spawn schedules.
