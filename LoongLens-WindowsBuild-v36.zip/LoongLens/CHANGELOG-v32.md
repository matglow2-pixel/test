# v32 — client-area input, confirmed camera selection and game-day sightings

- Native Windows input now asks for the real client area and hit-tests pointer
  positions. Resize borders and title bars never receive map clicks or drags.
  A held gesture temporarily confines the cursor to the client area and restores
  the previous confinement after release, cancellation or failure. GetCursorPos
  verifies the actual destination; redirected input stops before a click.
- The four exact map control boxes remain unchanged. Native window chrome is
  excluded using Windows geometry; no arbitrary map padding is added.
- Held motion uses smaller, paced cursor steps and measured optical flow on map
  terrain. Forward/backward and texture checks validate flow; ambiguous frames
  use the existing SIFT path. Release still happens after a stationary pause.
- A map tap is no longer treated as successful merely because it was sent.
  Delayed automatic closure is allowed; otherwise the white camera outline must
  match the selected point before Back. A click ripple is not confirmation.
  One ignored tap is retried against fresh alignment. Failed selection stays
  unchecked and cannot create a false empty visit or advance the Spy history.
- Gem Sniper always clicks a confirmed gem's centre once and stops. Broad right
  edge/HUD-region click vetoes are removed. A one-frame score drop does not
  cancel an already confirmed find. A fresh image can refine its position;
  native focus, resize, obstruction, finite-image bounds and F10 checks remain.
  Gem Spy remains observation-only.
- The top-right Sniper counter shows seen gems / 5. Photo completion/replayed
  events do not double count. Finds during the photo cooldown still count.
  The counter persists across app restarts, route changes and Reset checks.
- The counter and standard history Today only use the same game day: 16:00
  Europe/Sofia through just before the next 16:00. Midnight does not reset it.
  Daylight-saving transitions are included; tzdata is pinned and bundled into
  the Windows EXE. Show all and original history rows remain available.

The Windows build checks native mouse delivery, client-border rejection,
confinement restoration and F10 on its own test window; UI checks cover the
counter, original source history, saved routes and Spy integration. The full
route uses real atlas pixels and simulated input. These are not live BlueStacks
or game-account tests. The user's recording informed the border/click fixes;
private video frames are not distributed in the release.
