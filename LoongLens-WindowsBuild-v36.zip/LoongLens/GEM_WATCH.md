# Gem Watch: visible-screen AFK alerts

Gem Watch looks for the actual multicolored crystal piles shown in the user's `GemsPictures.rar`. It scans visible normal gameplay instead of assuming exact spawn positions. A gem can appear anywhere in the allowed viewing area.

## Sighting dots and 1h 15s timers (v33)

Recent live sightings now appear as **teal dots** on the large Loong Haven map overlay, at the entry's exact **X,Y**. A countdown above each dot ends **1 hour and 15 seconds after its original spotting time**. For example, a sighting spotted at 01:00 ends at 02:00:15; correcting its coordinates at 01:10 moves the dot and leaves 50 minutes and 15 seconds remaining.

On the Map overlay tab, enable **Gems** and **Sighting timers (1h 15s)**. The sighting-timer setting is enabled by default and saved between launches. The map must be open and aligned for dots to be drawn. Pink dots remain the bundled possible spawn locations. Manual pickup reminders keep their separate **Pickup timers** control.

A sighting gains a dot once its coordinates are known, including a manual correction after an unreadable screenshot. A delayed screenshot does not restart the timer. Editing a location moves its dot immediately when the map is next visible; removing a row removes its dot. Existing sightings from the last hour and 15 seconds also work after restarting. Expired dots disappear while their history entries remain. Editing an expired entry does not restart its timer.

Image-test entries and entries without valid coordinates do not create map dots. The Today/Show all history filter does not affect active map dots. If multiple live rows have identical X,Y, the latest spotting time supplies the single timer at that point; all history rows are kept. These are sighting coordinates, not automatic pickup confirmations.

## History editing and date filters (v8)

In **Gem Watch → History**, select an entry and click **Edit location**. Change only **Zone**, **X** and **Y**, then click **Save location**. Coordinates must be whole numbers from 0 to 279. The original spotting date/time, capture time, source, score and screenshot are preserved. Manual corrections also survive a late OCR result and restarting the app.

**Today only** is selected initially and uses your PC's local date. **Show all** displays the stored history across every date, including records beyond the previous 1,000-row display cap. **Include image tests** works with either date filter. The counts follow the selected date range, and an open history window refreshes its date range after midnight. These filters do not delete entries.

The sighting-history **Export history CSV** button has been removed. Existing history is upgraded automatically in `%LOCALAPPDATA%\LoongLens\sightings.sqlite3`. Close the older app before launching this release; your saved screenshots and history remain in the same folder. The 20-second saving cooldown and five-second capture delay are retained.

## Saving cooldown (v7)

After a live gem is confirmed and recorded, automatic history entries and screenshot scheduling are blocked for **20 seconds**. The first entry still captures its screenshot after **five seconds**. Further confirmations during the cooldown are ignored rather than queued for later, including a different gem. A continuously visible pile does not automatically create another entry when the cooldown ends.

The saving cooldown survives scan resets, panning, pause/resume and switching to/from image tests within the running app. Image tests remain separate and neither consume nor reset it. The existing sound behavior is unchanged. The cooldown starts at the accepted spotting time; restarting the whole app starts a new watching session.

## Delayed location and screenshot (v6)

After a live confirmation the alert sounds immediately. You have **five seconds** to move toward the gem; the app then saves a fresh game screenshot and reads the zone and player coordinates under the minimap using local OCR. Recognition runs on another thread while scanning continues. The history row retains the original spotting time and looks like **`Loong Haven III (193,121) 14/10/26 08:08`** under **Spotted**.

Click **Live game · Open screenshot** under **Source** to open that row's saved PNG in your default image viewer. The keyboard Enter key and **Open screenshot** button also work. The files live under `%LOCALAPPDATA%\LoongLens\screenshots` and remain linked after restart. No screenshot is uploaded by the app. OCR models and their Apache-2.0 notices are bundled; ONNX Runtime is installed by the launcher.

Keep the game visible during the wait. If it is covered/minimized, the window changes, you pause, or you switch to a photo before the deadline, the entry remains but the screenshot can be unavailable. Click Source to see why. An unreadable minimap label displays **Location unavailable** rather than guessed coordinates; any saved screenshot is still accessible. Coordinates are your character's location at capture time, not proof of the exact gem tile or pickup.

**Test image** exercises the same local screenshot/OCR/history path immediately, without the live movement delay, and keeps its **Image test** source. Older history entries retain their spotting times; locations can now be corrected manually, while older screenshots cannot be recreated.

## Combined app and sighting history (v5)

Gem Watch is now a tab in the combined **Loong Lens** window. Both launchers open that app; `RUN_GEM_WATCH.bat` selects the watcher tab initially. Changing tabs does not pause watching. Exit stops both tools. Recognized large-map views are skipped until normal gameplay returns.

**History** automatically stores one entry per newly confirmed pile with its local date/time and match score. Continuously visible gems are not logged every scan. New confirmations can be saved while sound is disabled or in its cooldown, subject to the separate 20-second saving cooldown above. Use Today only or Show all to choose the date range. Live sightings appear by default; tick **Include image tests** for clearly labelled picture-test entries.

The log is saved under **`%LOCALAPPDATA%\\LoongLens\\sightings.sqlite3`** and survives restarts. History does not establish the exact spawn time, collection, or the number of unique game resources. A new watching session or an absence of ten seconds can create a new encounter for a pile seen earlier.

## Version 2: direct image testing and wider-window scaling

The first release normalized every BlueStacks capture to portrait width and searched only a narrow size range. A screenshot displayed in Media Manager's wider sidebar layout could shrink below that range. Version 2 preserves more detail in wide windows and selects template sizes using the observed crystal tip. Reproductions of that sidebar layout are included in the regression checks.

**Test image** now loads a screenshot directly from your PC. It runs the actual detector and temporal alert gate repeatedly and requests the normal alert sound when a pile is confirmed. Photo mode is clearly labeled **IMAGE TEST**; it is not a live-game spawn alert. The image test ignores saved live scan rectangles, interface masks and window-ownership checks so another application's photo viewer cannot interfere.

To test without waiting for a spawn:

1. Start `RUN_GEM_WATCH.bat`, click **Test sound**, then **Test image**.
2. Choose an original gem screenshot (PNG/JPG). Expect pink boxes, a message starting **IMAGE TEST: GEM DETECTED**, and the alert tone after roughly 1–2 seconds on a responsive machine.
3. Click **Test image** again and choose `MyLocationNoGems.png`. Expect **IMAGE TEST · no gems detected** and no new alert sound.
4. Click **Watch game** to return to live BlueStacks capture. Your live scan rectangle and interface-mask settings are preserved.

Loading the same positive photo again re-arms its alert. This checks recognition, confirmation, panel messages and sound requests without needing a real spawn; it does not validate native Windows screen capture or live-game detection.

## Start

1. Extract the whole ZIP into a new writable folder. Install 64-bit Python 3.10–3.13 with Tcl/Tk, as described in `README.md`.
2. Double-click **`RUN_GEM_WATCH.bat`**. It opens the combined app on its **Gem Watch** tab, using the same private `.venv` and pinned dependencies.
3. Leave BlueStacks showing your normal AFK gameplay view. The watcher pauses recognition while the large Loong Haven map is recognized, then resumes automatically. Keep the game visible and unminimized.
4. Click **Test sound** and confirm that you can hear it. Then click **Start watching**.
5. Check the live preview. Pink boxes show candidates; a confirmed gem triggers the sound and updates the panel's last-alert message.

The game does not need keyboard focus. It can remain visible on a second monitor while you use a browser or another application. The watcher reads the desktop: covered areas and minimized windows cannot be reliably checked. Candidate centers and corners must belong to the BlueStacks window before they are allowed to trigger alerts. Detection also needs an unobstructed view of the gem itself; terrain, characters or effects can hide it.

The largest visible window titled `BlueStacks App Player` is selected. Multiple simultaneous emulator instances are not individually selectable in this prototype.

## Controls and behavior

- **Start watching / Pause:** enable or pause scanning. Startup is paused so you can test the sound and position windows first.
- **Test sound:** plays the alert tone even if automatic sound alerts are unchecked.
- **Test image / Watch game:** load a screenshot for the clearly labeled offline alert test, then return to live capture. Automatic tones still follow the **Sound alerts** checkbox.
- **Sound alerts:** enable/disable the automatic tone. This release uses sound and a panel message; it does not send phone, email, or push notifications.
- **Mask interface areas:** exclude the default HUD blocks. If that mask covers visible terrain in your layout, turn it off and use **Select scan area** to define the gameplay rectangle you want checked. Unmasked UI can increase false detections.
- **Detection:** Balanced uses the screenshot-tested threshold. Conservative demands a closer match and may miss gems; Sensitive allows looser matches and may produce false alerts. Those alternate thresholds have not been validated on a live session.
- **Select scan area:** start watching, then drag a rectangle over gameplay in the larger captured preview and save it. This is an optional search area, not a list of spawn coordinates. The interface-mask checkbox also applies inside it.
- **Reset area:** search the default allowed gameplay area again.
- **History:** review confirmed sightings with their dates and times. Live entries are shown initially; enable **Include image tests** to review photo tests.

The default mask excludes the header, minimap, right-side event controls, edge strips, and the bottom chat/menu area. Its rectangular exclusions can also cover some terrain around controls. If your HUD layout differs, disable **Mask interface areas**, select the actual visible gameplay area, and inspect the preview.

The target is **two scans per second**, depending on machine speed. A candidate needs **three consecutive sightings spanning at least 0.8 seconds**. A continuously visible gem alerts once; a brief missed detection does not immediately re-arm it. After at least 10 seconds without a matching sighting, it can be treated as a new appearance. There is also a **30-second global alert cooldown**. A new persistent gem seen during that cooldown can alert when it expires.

A gem already visible when watching starts also triggers an alert after confirmation. The watcher detects appearance/presence; it cannot establish the exact spawn time, ownership, who collected it, or a guaranteed one-hour respawn schedule. It does not collect gems or move your character.

Preferences and scan area are saved in **`%LOCALAPPDATA%\LoongLens\gemwatch-settings.json`**. Diagnostic logs are in **`loonglens.log`** in the same directory. Sensitivity mode is saved between launches.

## Screenshot validation

The archive supplied **18 positive screenshots containing 19 visible gem piles**, and **one negative screenshot**, `MyLocationNoGems.png`.

Only three positive screenshots supplied the small appearance templates:

- `IMG_1401.png`
- `IMG_1423.png`
- `IMG_1442.png`

On the 15 remaining positive screenshots, the detector found all 16 annotated piles, with no extra detections. Across all 18 positive screenshots it found all 19 annotated piles. Your negative screenshot produced no detections, both with the full-image reference scan and with the live HUD mask.

The reference screenshots have different cropping/UI layouts, so the positive reference evaluation scans their whole images with HUD masking disabled. Live HUD masking, arbitrary locations, doubled resolution, selected-area exclusions, temporal confirmation, cooldown and occlusion filtering are exercised separately by automated tests. Version 2 also checks smaller pictures inside wide sidebar layouts, direct picture-mode alerts, negative picture tests, live-mode return and rejection of results from a previous input source.

These are **small screenshot-set results, not a guarantee against false alerts or missed spawns**. There is only one no-gem example, and it was used during development. We have not tested a long live gameplay session, motion/animation coverage, Windows capture, native occlusion checks or actual Windows audio playback. The Tk panel was exercised on a Linux virtual display with simulated Windows capture and sound backends.

Full-resolution source screenshots and your no-gem screenshot are **not included in the downloadable release**. Only three tiny crystal-pile crops are distributed as detector assets. No screenshots are sent to an online service during operation.

## Offline checks

```sh
python gem_watch.py --check-image path/to/MyLocationNoGems.png
python gem_watch.py --check-image path/to/cropped-reference.png --no-hud-mask
python -m pytest -q
python tools/validate_gem_examples.py path/to/extracted/GemsPictures
```

The last command needs the original image folder and checks all annotated locations, including missing and extra detections. Results are written to `artifacts/gem-validation.json`. The original images are not part of the release.

## First live check on your PC

Test the sound, verify that your empty AFK view produces no pink boxes or alerts, and check a real gem when one becomes available. If another object triggers an alert, save the offending gameplay screenshot for diagnosis. If a real gem is missed, capture it while clearly visible. Additional no-gem scenes and a short gameplay recording would improve validation of false alerts and animation changes.
