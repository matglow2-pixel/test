"""Cross-platform atlas recognition and incremental motion; no game process access."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
import logging
from pathlib import Path
import threading
import time
import cv2
import numpy as np
from resources import ROOT, REF_W, REF_H
from pose import Match

LOG = logging.getLogger('loonglens')
_pan_features=threading.local()

def map_mask(shape):
    h, w = shape[:2]
    mask = np.zeros((h, w), np.uint8)
    mask[round(.20*h):round(.80*h), round(.09*w):round(.72*w)] = 255
    return mask


def patrol_map_mask(shape):
    """Wider map-only region for sparse islands; exclude title and controls."""
    h,w = shape[:2]
    mask = np.zeros((h,w),np.uint8)
    mask[round(.15*h):round(.875*h),round(.04*w):round(.90*w)] = 255
    mask[:round(.25*h),round(.73*w):] = 0
    mask[round(.62*h):,round(.90*w):] = 0
    return mask


def track_map_flow(before,frame,pose,expected):
    """Low-latency held-drag tracking with forward/backward terrain evidence."""
    from terrain_alignment import RAW
    old=cv2.resize(cv2.cvtColor(before,cv2.COLOR_BGR2GRAY),None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
    new=cv2.resize(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
    mask=patrol_map_mask(before.shape)
    yy,xx=np.indices(mask.shape);wx=np.floor((xx-pose.tx)/pose.scale).astype(int);wy=np.floor((pose.ty-yy)/pose.scale).astype(int)
    inside=(wx>=0)&(wx<280)&(wy>=0)&(wy<280)
    ground=np.zeros_like(inside);ground[inside]=np.isin(RAW[wy[inside],wx[inside]],(0,4,5))
    mask[~ground]=0;mask=cv2.resize(mask,(old.shape[1],old.shape[0]),interpolation=cv2.INTER_NEAREST)
    corners=cv2.goodFeaturesToTrack(old,220,.02,7,mask=mask,blockSize=5)
    if corners is None or len(corners)<16:return None
    criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,24,.02)
    dest,status,error=cv2.calcOpticalFlowPyrLK(old,new,corners,None,winSize=(25,25),maxLevel=4,criteria=criteria)
    if dest is None:return None
    back,status_back,_=cv2.calcOpticalFlowPyrLK(new,old,dest,None,winSize=(25,25),maxLevel=4,criteria=criteria)
    if back is None:return None
    src=corners[:,0,:]*2;dst=dest[:,0,:]*2;shifts=dst-src;expected=np.asarray(expected)
    valid=(status[:,0]>0)&(status_back[:,0]>0)&(error[:,0]<18)&(np.linalg.norm(back[:,0,:]-corners[:,0,:],axis=1)<.65)
    valid &= np.all((shifts*np.sign(expected)>=-5)&(np.abs(shifts)<=np.abs(expected)*3+30),axis=1)
    valid &= (dst[:,0]>=24)&(dst[:,0]<513)&(dst[:,1]>=154)&(dst[:,1]<900)
    if np.linalg.norm(expected)>12:valid &= np.linalg.norm(shifts,axis=1)>3
    if valid.sum()<16:return None
    delta=np.median(shifts[valid],axis=0);valid &= np.linalg.norm(shifts-delta,axis=1)<1.8
    if valid.sum()<16 or np.ptp(src[valid],axis=0).min()<65:return None
    # Separate textured patches must agree after translation. This rejects
    # aperture ambiguities on repeating terrain and unmoving HUD/background.
    agreements=0
    for a,b in zip(src[valid][::max(1,valid.sum()//24)],dst[valid][::max(1,valid.sum()//24)]):
        pa=cv2.getRectSubPix(old,(11,11),tuple(a/2));pb=cv2.getRectSubPix(new,(11,11),tuple(b/2))
        if pa.std()<8 or pb.std()<8:continue
        score=float(cv2.matchTemplate(pa,pb,cv2.TM_CCOEFF_NORMED)[0,0])
        agreements+=score>.88
    if agreements<8:return None
    delta=np.median(shifts[valid],axis=0)
    return Match(pose.scale,pose.tx+float(delta[0]),pose.ty+float(delta[1]),int(valid.sum()),
                 float(np.median(np.linalg.norm(shifts[valid]-delta,axis=1))),[],'tracked map terrain')


def track_map_pan(before, frame, pose, expected, recovery=False,fast=False):
    """Measure a drag from overlapping screenshot features, never from input alone.

    Terrain near an isolated island may not have an absolute atlas match in
    the central crop. Its overlap with the previous known view is sufficient.
    Stationary background and HUD features cannot establish a moving map pose.
    """
    if fast and not recovery:
        found=track_map_flow(before,frame,pose,expected)
        if found is not None:return found
    from terrain_alignment import classify_screen,RAW
    mapped=cv2.dilate(np.isin(RAW,(0,4,5)).astype(np.uint8),np.ones((3,3),np.uint8))
    # Patrol stores immutable reference images. Reuse only their source
    # landmarks; every new screenshot still gets fresh destination features.
    # Writable images are never cached, avoiding stale matches after edits.
    cached=getattr(_pan_features,'before',None)
    signature=(pose.scale,pose.tx,pose.ty)
    reuse=(not before.flags.writeable and cached is not None
           and cached[0] is before and cached[1]==signature)
    features=[cached[2]] if reuse else []
    sift=cv2.SIFT_create(nfeatures=2000,contrastThreshold=.018)
    for source in ((frame,) if reuse else (before,frame)):
        gray=cv2.cvtColor(source,cv2.COLOR_BGR2GRAY)
        base_mask=patrol_map_mask(source.shape)
        low,high,_,_=cv2.minMaxLoc(gray,mask=base_mask)
        if high-low<2:return None  # Flat terrain cannot provide visual landmarks.
        terrain=(classify_screen(source)!=0).astype(np.uint8)*255
        terrain=cv2.dilate(terrain,np.ones((9,9),np.uint8))
        mask=cv2.bitwise_and(terrain,base_mask)
        image=cv2.resize(gray,None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
        small_mask=cv2.resize(mask,(image.shape[1],image.shape[0]),interpolation=cv2.INTER_NEAREST)
        key,desc=sift.detectAndCompute(image,small_mask)
        if desc is None or len(key)<8:return None
        if not features:
            # Anchor matches on the known map footprint, not on the stationary
            # gameplay scenery visible through the map's empty background.
            points=np.float32([k.pt for k in key])*2
            world=np.floor(np.column_stack(((points[:,0]-pose.tx)/pose.scale,
                                            (pose.ty-points[:,1])/pose.scale))).astype(int)
            inside=(world[:,0]>=0)&(world[:,0]<mapped.shape[1])&(world[:,1]>=0)&(world[:,1]<mapped.shape[0])
            keep=np.zeros(len(key),bool)
            keep[inside]=mapped[world[inside,1],world[inside,0]]!=0
            key=[k for k,valid in zip(key,keep) if valid];desc=desc[keep]
            if len(key)<8:return None
        features.append((key,desc))
        if len(features)==1 and not before.flags.writeable:
            _pan_features.before=(before,signature,features[0])
    pairs=cv2.BFMatcher().knnMatch(features[0][1],features[1][1],k=2)
    unique={}
    for pair in pairs:
        if len(pair)!=2 or pair[0].distance>=.7*pair[1].distance:continue
        m=pair[0]
        if m.trainIdx not in unique or m.distance<unique[m.trainIdx].distance:unique[m.trainIdx]=m
    good=list(unique.values())
    if len(good)<8:return None
    src=np.float32([features[0][0][m.queryIdx].pt for m in good])*2
    dst=np.float32([features[1][0][m.trainIdx].pt for m in good])*2
    shifts=dst-src
    # A map can clamp at the border, but cannot move backwards or farther
    # than the drag. Reject unmoving background on an ordinary nonzero drag.
    expected=np.array(expected)
    moving=np.linalg.norm(shifts,axis=1)>3 if np.linalg.norm(expected)>12 else np.ones(len(src),bool)
    # Measure inertia instead of assuming that movement equals mouse distance.
    # Geometry/terrain correspondences still have to agree independently.
    near=np.all((shifts*np.sign(expected)>=-5) & (np.abs(shifts)<=np.abs(expected)*3+30),axis=1)
    if recovery:
        # The net movement after an overshoot and reverse drag is unknown.
        # Accept only a directly measured overlap with the last trusted image.
        near=np.linalg.norm(shifts,axis=1)<=350
        moving=np.ones(len(src),bool)
    valid=moving & near
    if valid.sum()<8:return None
    delta=np.median(shifts[valid],axis=0)
    valid &= np.linalg.norm(shifts-delta,axis=1)<2.5
    if valid.sum()<8 or np.ptp(src[valid],axis=0).min()<25:return None
    delta=np.median(shifts[valid],axis=0)
    error=float(np.median(np.linalg.norm(shifts[valid]-delta,axis=1)))
    return Match(pose.scale,pose.tx+float(delta[0]),pose.ty+float(delta[1]),int(valid.sum()),error,[], 'overlapping map terrain')

class TitleDetector:
    def __init__(self):
        self.template = cv2.imread(str(ROOT / 'loong_title_template.png'), cv2.IMREAD_GRAYSCALE)
        if self.template is None:
            raise FileNotFoundError('Missing map title template.')

    def score(self, frame):
        gray = cv2.cvtColor(frame[31:133, 8:245], cv2.COLOR_BGR2GRAY)
        if any(a < b for a, b in zip(gray.shape, self.template.shape)):
            return 0.
        return float(cv2.minMaxLoc(cv2.matchTemplate(gray, self.template, cv2.TM_CCOEFF_NORMED))[1])

class AtlasIndex:
    """A cached SIFT index replaces repeated whole-atlas template searches.

    The index is warmed in the recognition thread. Precise, constrained geometric
    checks precede accepting a pose; the original matcher remains a fallback.
    """
    RATIO = .5
    FEATURES = 12000

    def __init__(self, cache_dir=None):
        self.ready = False
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.lock = threading.Lock()
        self.points = self.descriptors = self.matcher = None
        self.query = cv2.SIFT_create(nfeatures=1200, contrastThreshold=.025)
        meta = json.loads((ROOT / 'atlas_metadata.json').read_text('utf-8'))
        self.grid_scale = float(meta['scale'])
        self.map_height = 280

    def prepare(self):
        with self.lock:
            if self.ready:
                return
            source = ROOT / 'loong_haven_default_atlas.png'
            stamp = hashlib.sha256(source.read_bytes()).hexdigest()[:20]
            filename = f'sift-{stamp}-{cv2.__version__}-{self.FEATURES}.npz'
            cache = self.cache_dir / filename if self.cache_dir else None
            if cache and cache.exists():
                try:
                    with np.load(cache, allow_pickle=False) as saved:
                        pts = saved['points'].copy()
                        desc = saved['descriptors'].copy()
                    if pts.shape != (len(desc), 2) or desc.shape[1:] != (128,) or len(desc) < 100:
                        raise ValueError('Invalid atlas cache shape')
                    if not np.isfinite(pts).all() or not np.isfinite(desc).all():
                        raise ValueError('Invalid atlas cache values')
                    self.points, self.descriptors = pts, desc.astype(np.float32)
                except (OSError, ValueError, KeyError):
                    LOG.warning('Rebuilding an invalid atlas cache.')
            if self.descriptors is None:
                image = cv2.imread(str(source), cv2.IMREAD_GRAYSCALE)
                if image is None:
                    raise FileNotFoundError('Missing map atlas.')
                image = cv2.resize(image, None, fx=self.RATIO, fy=self.RATIO, interpolation=cv2.INTER_AREA)
                extractor = cv2.SIFT_create(nfeatures=self.FEATURES, contrastThreshold=.025)
                keypoints, desc = extractor.detectAndCompute(image, None)
                if desc is None or len(keypoints) < 100:
                    raise ValueError('The atlas does not contain enough recognizable detail.')
                self.points = np.array([k.pt for k in keypoints], np.float32)
                self.descriptors = desc
                if cache:
                    try:
                        cache.parent.mkdir(parents=True, exist_ok=True)
                        temporary = cache.with_suffix('.tmp.npz')
                        np.savez_compressed(temporary, points=self.points, descriptors=desc)
                        temporary.replace(cache)
                    except OSError:
                        LOG.warning('Atlas cache is not writable; using in-memory index.')
            self.matcher = cv2.FlannBasedMatcher(dict(algorithm=1, trees=4), dict(checks=48))
            self.matcher.add([self.descriptors])
            self.matcher.train()
            self.ready = True

    def locate(self, frame, prior_scale=None, wide=False):
        self.prepare()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Half resolution keeps descriptors and CPU work independent of desktop DPI.
        small = cv2.resize(gray, None, fx=self.RATIO, fy=self.RATIO, interpolation=cv2.INTER_AREA)
        keypoints, descriptors = self.query.detectAndCompute(small, patrol_map_mask(small.shape) if wide else map_mask(small.shape))
        if descriptors is None or len(keypoints) < 10:
            return None
        pairs = self.matcher.knnMatch(descriptors, k=2)
        good = [pair[0] for pair in pairs if len(pair) == 2 and pair[0].distance < .70 * pair[1].distance]
        # Repeated text can yield many matches to the same atlas feature.
        unique = {}
        for m in good:
            if m.trainIdx not in unique or m.distance < unique[m.trainIdx].distance:
                unique[m.trainIdx] = m
        good = list(unique.values())
        if len(good) < 10:
            return None
        src = np.array([keypoints[m.queryIdx].pt for m in good], np.float32)
        dst = self.points[[m.trainIdx for m in good]]
        affine, flags = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                       ransacReprojThreshold=2., maxIters=1600, confidence=.995)
        if affine is None or flags is None:
            return None
        valid = flags.ravel().astype(bool)
        n = int(valid.sum())
        if n < 9 or n / len(good) < .38:
            return None
        a, b, dx = affine[0]; c, d, dy = affine[1]
        scale = float(np.hypot(a, c))
        if not (.38 < scale < 2.8) or abs(b) > .015 * scale or abs(c) > .015 * scale:
            return None
        in_src, in_dst = src[valid], dst[valid]
        span = np.ptp(in_src, axis=0)
        if span[0] < 35 or span[1] < 50:
            return None
        # Fit the exact non-rotated model used by the overlay rather than retaining
        # even a small rotation that would place edge markers incorrectly.
        mean_src, mean_dst = in_src.mean(axis=0), in_dst.mean(axis=0)
        centered = in_src - mean_src
        denominator = float(np.sum(centered ** 2))
        fitted = float(np.sum(centered * (in_dst - mean_dst)) / denominator)
        shift = mean_dst - fitted * mean_src
        residual = np.linalg.norm(in_src * fitted + shift - in_dst, axis=1)
        error = float(np.median(residual))
        if error > 1.6 or np.quantile(residual, .9) > 3.:
            return None
        map_scale = self.grid_scale / fitted
        if not 12.05 <= map_scale <= 12.85:
            return None
        return Match(map_scale,
                     -float(shift[0]) / (fitted * self.RATIO),
                     ((self.map_height - 1) * self.grid_scale - float(shift[1]) / self.RATIO) / fitted,
                     n, error / (fitted * self.RATIO), [], f'features {n} landmarks')

class MotionTracker:
    """Optical flow with forward/backward validation and current-frame masks."""
    def __init__(self):
        self.reset()

    def reset(self):
        self.gray = self.points = None
        self.frames = 0

    def prime(self, frame):
        self.gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        self.points = cv2.goodFeaturesToTrack(self.gray, 130, .018, 9,
                                             mask=map_mask(frame.shape), blockSize=5)
        self.frames = 0

    def update(self, frame, pose):
        if self.gray is None:
            self.prime(frame)
            return pose
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        old = self.gray
        self.gray = gray
        if self.points is None or len(self.points) < 20 or self.frames % 15 == 0:
            self.points = cv2.goodFeaturesToTrack(old, 130, .018, 9,
                                                 mask=map_mask(frame.shape), blockSize=5)
        self.frames += 1
        if self.points is None or len(self.points) < 10:
            return None
        nxt, status, _ = cv2.calcOpticalFlowPyrLK(old, gray, self.points, None,
                                                winSize=(21, 21), maxLevel=3)
        if nxt is None:
            return None
        back, backward, _ = cv2.calcOpticalFlowPyrLK(gray, old, nxt, None,
                                                   winSize=(21, 21), maxLevel=3)
        if back is None:
            return None
        valid = ((status.ravel() == 1) & (backward.ravel() == 1)
                 & (np.linalg.norm(self.points - back, axis=2).ravel() < 1.3))
        src, dst = self.points[valid].reshape(-1, 2), nxt[valid].reshape(-1, 2)
        self.points = dst.reshape(-1, 1, 2) if len(dst) > 12 else None
        if len(src) < 10:
            return None
        affine, flags = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                    ransacReprojThreshold=1.8, maxIters=400)
        if affine is None or flags is None or flags.sum() < 10 or flags.mean() < .6:
            return None
        a, b, dx = affine[0]; c, d, dy = affine[1]
        scale = float(np.hypot(a, c))
        if not (.98 < scale < 1.02) or abs(b) > .005 or abs(c) > .005:
            return None
        # Avoid jitter and needless bitmap uploads when the terrain is still.
        if abs(dx) < .08 and abs(dy) < .08 and abs(scale - 1) < .00008:
            return pose
        if pose is None:
            return None
        if not 12.05 <= pose.scale * scale <= 12.85:
            return None
        return Match(pose.scale * scale, pose.tx * scale + dx, pose.ty * scale + dy,
                     int(flags.sum()), 0., [], 'motion')

@dataclass(frozen=True)
class Ticket:
    generation: int
    frame: np.ndarray
    timestamp: float

class Session:
    """Invalidate slow search results across map closures, resizing, or pause."""
    def __init__(self):
        self.generation = 0
        self.active = False
        self.rect = None

    def update(self, active, rect):
        if active != self.active or rect != self.rect:
            self.generation += 1
        self.active, self.rect = active, rect

    def ticket(self, frame, now):
        return Ticket(self.generation, frame.copy(), now)

    def accepts(self, ticket, now):
        return self.active and ticket.generation == self.generation and now - ticket.timestamp <= 2.5

class Calibrator:
    def __init__(self, cache_dir=None, wide=False):
        self.index = AtlasIndex(cache_dir)
        self.wide = wide

    def locate(self, frame, prior_scale=None):
        match = self.index.locate(frame, prior_scale)
        if match is not None:
            return match
        if self.wide:
            match = self.index.locate(frame, prior_scale, wide=True)
            if match is not None:
                return match
        from map_alignment import find_portals, align_portals
        match = align_portals(find_portals(frame), prior_scale)
        if match is not None:
            return match
        from terrain_alignment import align_terrain
        match = align_terrain(frame, prior_scale)
        if match is not None:
            return match
        # Retain tested default-zoom template fallback without the combinatorial
        # portal-pair search that could monopolize the worker for several seconds.
        from sxs_atlas_tracker import align_atlas
        return align_atlas(frame, prior_scale)

def reconcile(ticket, frame, pose):
    """Move a background result to today's pixels or reject it after a fast pan."""
    if pose is None:
        return None
    interior = (slice(220, 740), slice(55, 410))
    difference = float(np.mean(cv2.absdiff(ticket.frame[interior], frame[interior])))
    if difference < .7:
        return pose
    motion = MotionTracker()
    motion.prime(ticket.frame)
    return motion.update(frame, pose)
