import csv
from types import SimpleNamespace

import numpy as np
import pytest

from gem_detector import AlertGate, Detection
from gem_watch_worker import WatchWorker
from sighting_history import SightingHistory


def hit(x=100):
    return Detection(x, 300, 32, 22, .95)


class Capture:
    def grab(self, _):
        return np.zeros((1029, 570, 4), np.uint8)


def live_worker():
    worker = WatchWorker(lambda: (123, (0, 0, 570, 1029)), lambda *args: True)
    worker.map_title = SimpleNamespace(score=lambda frame: 0)
    worker.configure(paused=False)
    return worker


def step(worker, monkeypatch, now):
    monkeypatch.setattr('gem_watch_worker.time.perf_counter', lambda: now)
    worker.step(Capture(), now)


def test_sightings_are_confirmed_once_and_sound_cooldown_does_not_lose_new_piles(monkeypatch):
    worker = live_worker()
    detections = [hit()]
    worker.detector.detect = lambda *args, **kwargs: detections
    for now in (0, .5):
        step(worker, monkeypatch, now)
        assert not worker.drain_sightings()
    step(worker, monkeypatch, 1)
    first = worker.drain_sightings()
    assert len(first) == 1 and not first[0]['test_mode']
    assert len(worker.drain_alerts()) == 1
    detections.append(hit(350))
    for now in (1.5, 2, 2.5):
        step(worker, monkeypatch, now)
    second = worker.drain_sightings()
    assert len(second) == 1 and second[0]['event_id'] != first[0]['event_id']
    assert second[0]['screen_x'] == 366
    assert not worker.drain_alerts()  # Sound remains in its 30-second cooldown.
    for now in np.arange(3, 40, .5):
        step(worker, monkeypatch, float(now))
    assert not worker.drain_sightings()


def test_flicker_stays_one_encounter_but_long_absence_can_make_a_new_sighting(monkeypatch):
    worker = live_worker()
    detections = [hit()]
    worker.detector.detect = lambda *args, **kwargs: detections
    for now in (0, .5, 1):
        step(worker, monkeypatch, now)
    assert len(worker.drain_sightings()) == 1
    detections.clear()
    step(worker, monkeypatch, 2)
    detections.append(hit())
    for now in (3, 3.5, 4):
        step(worker, monkeypatch, now)
    assert not worker.drain_sightings()
    detections.clear()
    step(worker, monkeypatch, 15)
    detections.append(hit())
    for now in (16, 16.5, 17):
        step(worker, monkeypatch, now)
    assert len(worker.drain_sightings()) == 1


def test_large_map_icons_never_create_sightings_or_alerts(monkeypatch):
    worker = live_worker()
    worker.map_title = SimpleNamespace(score=lambda frame: .9)
    worker.detector.detect = lambda *args, **kwargs: pytest.fail('Map icons must not reach the pile detector')
    for now in (0, .5, 1):
        step(worker, monkeypatch, now)
    assert 'Large map open' in worker.get()['state']
    assert not worker.drain_sightings() and not worker.drain_alerts()


def test_source_change_during_scan_cannot_log_stale_sighting(monkeypatch):
    worker = live_worker()
    def detect(*args, **kwargs):
        worker.test_image(np.zeros((1029, 570, 3), np.uint8))
        return [hit()]
    worker.detector.detect = detect
    step(worker, monkeypatch, 0)
    assert not worker.drain_sightings()


def test_history_survives_restart_and_retried_events_do_not_duplicate(tmp_path):
    path = tmp_path / 'local' / 'sightings.sqlite3'
    history = SightingHistory(path)
    events = [dict(event_id='session:1', seen_at=1000, screen_x=116, screen_y=311, score=.95, test_mode=False),
              dict(event_id='session:2', seen_at=1001, screen_x=116, screen_y=311, score=.95, test_mode=True)]
    history.record(events)
    history.record(events)
    history.close()
    restarted = SightingHistory(path)
    assert restarted.counts() == {0: 1, 1: 1}
    assert len(restarted.list()) == 1
    assert len(restarted.list(include_tests=True)) == 2
    assert restarted.list()[0].source == 'Live game'
    assert restarted.list(include_tests=True)[0].source == 'Image test'
    restarted.remove(restarted.list()[0].id)
    assert not restarted.list() and len(restarted.list(include_tests=True)) == 1
    restarted.close()


def test_export_uses_local_and_utc_dates_and_explicit_screen_coordinates(tmp_path):
    history = SightingHistory(tmp_path / 'history.db')
    history.record([dict(event_id='live', seen_at=1000, screen_x=116, screen_y=311, score=.95, test_mode=False),
                    dict(event_id='test', seen_at=1001, screen_x=116, screen_y=311, score=.95, test_mode=True)])
    path = tmp_path / 'history.csv'
    history.export_csv(path)
    with path.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 1 and rows[0]['source'] == 'Live game'
    assert rows[0]['seen_at_utc'].endswith('+00:00') and rows[0]['screen_x'] == '116.0'
    assert '1970-' in rows[0]['seen_at_utc']
    history.export_csv(path, include_tests=True)
    with path.open(encoding='utf-8-sig', newline='') as f:
        assert len(list(csv.DictReader(f))) == 2
    history.close()
