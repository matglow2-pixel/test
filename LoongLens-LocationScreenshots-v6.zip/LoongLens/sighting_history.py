"""Local history of confirmed visual sightings, separate from manual pickups."""
from dataclasses import dataclass
from datetime import datetime, timezone
import csv
from pathlib import Path
import sqlite3


@dataclass(frozen=True)
class Sighting:
    id: int
    event_id: str
    seen_at: float
    screen_x: float
    screen_y: float
    score: float
    test_mode: bool
    zone: str | None = None
    game_x: int | None = None
    game_y: int | None = None
    screenshot_path: str | None = None
    capture_status: str = 'legacy'
    capture_note: str = ''
    captured_at: float | None = None

    @property
    def local_time(self):
        return datetime.fromtimestamp(self.seen_at).astimezone().strftime('%Y-%m-%d %H:%M:%S')

    @property
    def source(self):
        return 'Image test' if self.test_mode else 'Live game'

    @property
    def spotted(self):
        stamp = datetime.fromtimestamp(self.seen_at).astimezone().strftime('%d/%m/%y %H:%M')
        if self.zone and self.game_x is not None and self.game_y is not None:
            return f'{self.zone} ({self.game_x},{self.game_y}) {stamp}'
        status = 'Location pending' if self.capture_status == 'pending' else 'Location unavailable'
        return f'{status} {stamp}'

    @property
    def source_label(self):
        if self.screenshot_path:
            return self.source + ' · Open screenshot'
        if self.capture_status == 'pending':
            return self.source + ' · Capture pending'
        return self.source + ' · No screenshot'


class SightingHistory:
    FIELDS = 'id,event_id,seen_at,screen_x,screen_y,score,test_mode,zone,game_x,game_y,screenshot_path,capture_status,capture_note,captured_at'
    CAPTURE_FIELDS = ('zone', 'game_x', 'game_y', 'screenshot_path', 'capture_status', 'capture_note', 'captured_at')
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.execute('''CREATE TABLE IF NOT EXISTS sightings (
            id INTEGER PRIMARY KEY, event_id TEXT NOT NULL UNIQUE,
            seen_at REAL NOT NULL, screen_x REAL NOT NULL, screen_y REAL NOT NULL,
            score REAL NOT NULL, test_mode INTEGER NOT NULL)''')
        columns = {row[1] for row in self.connection.execute('PRAGMA table_info(sightings)')}
        for name, definition in [('zone','TEXT'),('game_x','INTEGER'),('game_y','INTEGER'),('screenshot_path','TEXT'),
                                  ('capture_status',"TEXT NOT NULL DEFAULT 'legacy'"),('capture_note',"TEXT NOT NULL DEFAULT ''"),('captured_at','REAL')]:
            if name not in columns:
                self.connection.execute(f'ALTER TABLE sightings ADD COLUMN {name} {definition}')
        self.connection.execute('CREATE INDEX IF NOT EXISTS sighting_time ON sightings(seen_at DESC,id DESC)')
        self.connection.commit()

    def record(self, events):
        # Capture results enrich a row while preserving its original spotting
        # time. A replayed pending event must not erase a finished capture.
        columns = 'event_id,seen_at,screen_x,screen_y,score,test_mode,' + ','.join(self.CAPTURE_FIELDS)
        updates = ','.join(f'{name}=excluded.{name}' for name in self.CAPTURE_FIELDS)
        values = []
        for event in events:
            values.append((event['event_id'],event['seen_at'],event['screen_x'],event['screen_y'],event['score'],bool(event['test_mode']),
                event.get('zone'),event.get('game_x'),event.get('game_y'),event.get('screenshot_path'),
                event.get('capture_status','legacy'),event.get('capture_note',''),event.get('captured_at')))
        with self.connection:
            self.connection.executemany(f'''INSERT INTO sightings ({columns}) VALUES({','.join('?' for _ in range(13))})
                ON CONFLICT(event_id) DO UPDATE SET {updates}
                WHERE sightings.capture_status IN ('pending','legacy') AND excluded.capture_status NOT IN ('pending','legacy')''', values)

    def recover_pending(self):
        with self.connection:
            self.connection.execute("UPDATE sightings SET capture_status='interrupted',capture_note='The app stopped before this capture finished.' WHERE capture_status='pending'")

    def get(self, sighting_id):
        row = self.connection.execute(f'SELECT {self.FIELDS} FROM sightings WHERE id=?',(sighting_id,)).fetchone()
        return Sighting(*row) if row else None

    def list(self, include_tests=False, limit=None):
        query = f'SELECT {self.FIELDS} FROM sightings'
        if not include_tests:
            query += ' WHERE test_mode=0'
        query += ' ORDER BY seen_at DESC,id DESC'
        if limit is not None:
            query += ' LIMIT ?'
        return [Sighting(*row) for row in self.connection.execute(query, () if limit is None else (limit,))]

    def counts(self):
        return dict(self.connection.execute('SELECT test_mode,COUNT(*) FROM sightings GROUP BY test_mode'))

    def pending_count(self):
        return self.connection.execute("SELECT COUNT(*) FROM sightings WHERE capture_status='pending'").fetchone()[0]

    def remove(self, sighting_id):
        with self.connection:
            self.connection.execute('DELETE FROM sightings WHERE id=?', (sighting_id,))

    def export_csv(self, path, include_tests=False):
        with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['id', 'spotted', 'seen_at_local', 'seen_at_utc', 'source', 'match_score', 'screen_x', 'screen_y',
                             'zone','game_x','game_y','screenshot_path','capture_status','capture_note','captured_at_utc'])
            for row in self.list(include_tests=include_tests):
                captured = datetime.fromtimestamp(row.captured_at,timezone.utc).isoformat() if row.captured_at is not None else ''
                writer.writerow([row.id, row.spotted, datetime.fromtimestamp(row.seen_at).astimezone().isoformat(),
                                 datetime.fromtimestamp(row.seen_at, timezone.utc).isoformat(), row.source,
                                 row.score, row.screen_x, row.screen_y, row.zone, row.game_x, row.game_y, row.screenshot_path,
                                 row.capture_status, row.capture_note, captured])

    def close(self):
        self.connection.close()
