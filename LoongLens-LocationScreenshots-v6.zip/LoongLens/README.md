# Loong Lens

A combined **Sword x Staff / Loong Haven** map overlay and visible-screen gem watcher for **Windows 10 (2004+) or Windows 11, BlueStacks, and the normal/default map zoom**.

## Locations and screenshots (v6)

Live gem alerts remain immediate after confirmation. The app waits **five seconds**, then captures a fresh BlueStacks frame and reads the **zone name and player X,Y beneath the minimap**. The original spotting time is preserved. History uses the exact display format:

```text
Spotted
Loong Haven III (193,121) 14/10/26 08:08
```

Click **Live game · Open screenshot** in the **Source** column, or select the row and click **Open screenshot**, to view the PNG for that exact sighting. Captures are taken after at least five seconds; the two-scans-per-second loop normally adds up to about half a second. Text recognition finishes in the background after the frame is frozen, so it cannot substitute a later image. Coordinates describe **your character's position at capture time**, not a measured gem tile. The watcher does not move your character.

Images are saved locally in **`%LOCALAPPDATA%\LoongLens\screenshots`** and linked from the existing `sightings.sqlite3`. History and links survive restarting or extracting a newer version. Text recognition uses bundled PP-OCRv4 models on your CPU; screenshots are not sent to a service. The launcher installs the new ONNX Runtime dependency automatically; first-time setup needs internet. The model licenses and provenance are included in `ocr_models`.

Keep BlueStacks visible for the five-second wait. Pausing, changing to an image test, minimizing, switching emulator instances, or covering the game can cancel or prevent that capture. The sighting is retained with a reason available by clicking Source. **Location unavailable** means the minimap label could not be read reliably; an existing screenshot remains viewable even if text recognition fails. Older v5 rows have their original times but no invented coordinates or retroactive screenshots. Picture tests also save/read their selected image, clearly marked **Image test**, with no movement delay.

CSV export retains the original full local/UTC timestamps and adds the displayed Spotted text, zone, game coordinates, screenshot path, capture status and capture time. `screen_x/screen_y` remain the initially detected gem's screen pixels; `game_x/game_y` are the player's later minimap coordinates. Removing a history row does not delete its saved PNG. Back up both the database and screenshots folder while the app is closed.

## Combined application (v5)

Run **`RUN_LOONG_LENS.bat`** to open one window with **Map overlay** and **Gem Watch** tabs. **`RUN_GEM_WATCH.bat`** opens the same application on the Gem Watch tab. Both functions continue running when you change tabs; **Exit** closes both. The launcher brings an existing v5 app to the foreground instead of opening a second instance.

The map runs at the highest previous target, **45 FPS**, without a rate selector. Actual FPS still depends on your PC. A single **Ingredients** checkbox enables the beans, bamboo, and crab layers together, retaining their different colors. CSV import has been removed; previously saved personal coordinates remain available.

On **Gem Watch**, click **Start watching**. **History** automatically records the local date and time of each newly confirmed gem pile. It records confirmation events even during the 30-second sound cooldown and when sound alerts are disabled. A continuously visible pile produces one entry; a return after at least ten seconds absent, a source/configuration change, or restarting watching can create another encounter. This is a sighting log, not a count of unique game resources or collected gems.

Live sightings and image tests are stored separately by source. The history initially shows live sightings; tick **Include image tests** to review your picture checks. CSV export follows that filter and includes all matching records, even those outside the table's newest 1,000 rows. Exported screen coordinates are **screen pixels**, not game X,Y. The log lives at **`%LOCALAPPDATA%\\LoongLens\\sightings.sqlite3`** and survives restarts. Manual pickup history and map countdowns are preserved separately.

Gem Watch skips recognition while it recognizes the large Loong Haven map, then automatically resumes in normal gameplay. Reference dots on the map are not gameplay piles. This protection uses the existing map-title detector; changed layouts remain a live-test limitation.

The launchers start the app with **pythonw** and close their command window after startup. A brief setup window still appears, and first-time dependency installation can take longer. Errors after detached startup appear in a dialog and are saved to `startup-error.log` in the same local data folder. Close both older applications before using this release. Windows console detachment and native single-instance behavior need verification on your PC.

## Pickup history and large-map timers (v4)

After you pick up a gem, click **Mark collected** in `RUN_LOONG_LENS.bat`:

1. Enter the pickup **X,Y** from the game's minimap.
2. Leave **Check after** at 30 minutes, or choose another whole-minute duration. **Picked up minutes ago** is optional for a delayed entry.
3. Review **Timer marker on the large map**. It defaults to the nearest bundled/personal gem dot if that dot is within ten tiles. You can choose another suggested dot or **At entered coordinates**. The history always keeps the actual coordinates you entered separately from this reference marker.
4. Click **Mark collected** to save. Bring BlueStacks back to the foreground to see the overlay.

With **Gems** and **Show pickup timers on large map** enabled, a blue dot and `MM:SS` label follow the selected position as you pan. At expiry they turn gold and say **Check** for ten minutes, then the countdown marker disappears and normal bundled dots remain. **This is your chosen check reminder, not proof of a respawn**; other players can collect gems first. A later pickup tied to the same dot restarts that dot's timer while retaining earlier events in history.

**Pickup history** lists pickup time in your PC's local timezone, entered X,Y, timer dot X,Y, reminder duration, remaining time, and optional notes. **Export history CSV** saves all records; **Remove selected** corrects an accidental entry. The table shows the newest 1,000 records without deleting older entries. **Pickups today** counts recorded pickup events, not the amount of gem currency rewarded by the game.

History is stored locally in **`%LOCALAPPDATA%\LoongLens\pickups.sqlite3`**, outside the extracted program folder. Closing/reopening the program or extracting a newer release preserves the log and countdown deadlines. Copy this file while the program is closed to back it up. The database and photos are not included in release archives or uploaded by the program.

Gem Watch recognition remains separate: seeing a gem, losing sight of it, or another player's pickup does not add anything to your collection history. No automatic pickup confirmation or game clicking is added.

## Map alignment update (v3)

The map overlay now tries the cached feature atlas, a constrained four-portal constellation, the full 280×280 terrain grid, and finally the original template matcher. This gives it additional ways to recover when the stitched screenshot atlas does not match the current view. Default zoom remains required. Terrain alignment supports the reference atlas's green, brown and snow palettes and is less precise than feature/portal alignment.

The lower map clipping boundary was also moved down to preserve terrain above the current navigation buttons; version 1 treated part of that visible terrain as bottom UI and could omit markers there.

The **Save debug** button saves the last captured map (`map-debug.png`) and alignment details (`map-debug.json`) under `%LOCALAPPDATA%\LoongLens`, then opens that folder. Bring the map window to the foreground for a few seconds before saving. The capture is retained when clicking the control panel takes focus away from BlueStacks. The JSON records capture age, title score, enabled layers, fitted pose, alignment method and display status. Diagnostics stay local; the program does not upload them.

The supplied full-map references and landmark positions are consistent with the bundled map geometry. The current Loot & Waifus website was blocked by the development environment's proxy (HTTP 403), so this release retains the existing 86 gem coordinates; it does not claim to contain a fresh website export. Live alignment on the user's PC is still unverified.

## New: visible-screen Gem Watch

Open the **Gem Watch** tab for AFK gem alerts. It watches normal gameplay and searches for actual gem piles across the allowed visible area rather than relying on fixed spawn coordinates. You can switch back to **Map overlay** in the same window.

Version 2 adds a **Test image** button for checking recognition and alerts from a saved photo, and fixes scale handling for wider emulator/sidebar layouts. See **[GEM_WATCH.md](GEM_WATCH.md)** for startup, sound alerts, scan-area selection, screenshot validation, and live-test limitations.

## Start

1. Install **64-bit Python 3.10–3.13** from python.org. Include **Tcl/Tk** and the Python launcher.
2. Extract this folder to a writable location. Close your previous overlay.
3. Double-click **RUN_LOONG_LENS.bat** to open the combined app. The launcher creates a private `.venv` and installs the pinned dependencies on the first run. Internet access is needed for that installation; ordinary tracking works offline.
4. Open the Loong Haven map in BlueStacks at **default zoom**. Bring BlueStacks to the foreground. Gems are enabled initially; choose other resources in the panel.

The first launch builds an atlas index in the background (about five seconds on the development machine). Later launches reuse that index. The panel can say “Finding map position” while this happens. There is no need to keep the map open while the cache builds.

Markers disappear when the map title disappears, BlueStacks is minimized or loses focus, tracking loses confidence, or you pause. Clicking the control panel therefore temporarily hides markers; click BlueStacks again to continue. **Re-align** requests fresh recognition. The window must be fully visible on screen. The screenshot title/template layout is inherited from the upload; other emulator layouts, changed game UI, or landscape layouts have not been validated.

## Controls

- **Gems:** 86 candidate locations from the uploaded dataset, shown in pink.
- **Ingredients:** beans (3 green areas), bamboo (9 blue areas), and crab (11 approximate orange dots), toggled together.
- **Shade ingredient areas:** toggle the translucent fill independently of borders.
- **Dot size / Opacity:** adjust the overlay; preferences are saved automatically.
- **Pause / Resume / Exit:** stop tracking temporarily, restart it, or close the overlay.
- **Mark collected / Pickup history:** record your pickups manually, review timestamps/coordinates, and export the log.
- **Show pickup timers on large map:** display countdowns for manually recorded pickups when the Gems layer is enabled.

Preferences, the atlas cache, personal coordinates, and diagnostics live under **`%LOCALAPPDATA%\LoongLens`**. The program does not write preferences into the installation folder. To reset settings, close it and remove `settings.json` from that directory. Diagnostics are in `loonglens.log`.

## Previous personal coordinates

The CSV import button has been removed. A personal coordinate file saved by an older version is still loaded from `%LOCALAPPDATA%\\LoongLens\\coordinates.csv`; this update does not overwrite it. The bundled resource dataset is unchanged.

## What changed from the upload

- A precomputed, cached SIFT landmark index replaces repeated whole-atlas image searches. The uploaded template matcher remains a default-zoom fallback.
- Recognition runs on a separate worker with **one in-flight request**. Results are checked against the map session, frame age, and current pixels; a result from a closed map cannot paint onto a reopened map.
- Optical flow follows map motion, with forward/backward checks to reject unreliable movement. Periodic absolute recognition limits drift.
- Default-zoom constraints reject substantially zoomed views instead of assuming the normal scale.
- Vectorized point projection, reusable marker sprites, and an unchanged-frame cache reduce drawing work. The native layered window reuses its bitmap and device contexts.
- The panel has resource colors, saved preferences, grouped ingredient controls, pickup/sighting logs, pause/re-align controls, and measured timing indicators.
- The overlay is click-through and does not take focus. Windows capture exclusion prevents it from tracking its own markers. If exclusion cannot be enabled, the overlay pauses with an explanation.

## Data and limitations

This release reuses the map atlas and location data supplied in `SxSMapOverlay.rar`. It does not invent new gem or ingredient coordinates, infer exact spawns from broad zone hints, or detect whether a resource is currently present. The broad areas may not include every gathering location.

The upload cited these ingredient sources:

- https://www.taptap.cn/moment/702592615505201982
- https://hackmd.io/@Tj-HoTwkRNWfXZ9-XrH_Zg/BkMmylVhZg

Those pages and a search for additional interactive maps were blocked by the development environment's egress policy. No new online location data was imported or independently verified. The gem dataset's exact viewer URL was not provided in the archive.

The overlay reads ordinary desktop screenshots and paints a separate transparent window. It does not inject into the game, read game memory, use ADB, or send game input. Your game's rules still govern overlay use.

### Validation

Offline tests exercise atlas alignment, rejection of other zoom levels, pan tracking, title detection, CSV validation, transparent rendering, stationary-frame caching, and stale-session handling. The real Tk panel was also exercised using a simulated Windows backend on a Linux virtual display.

**The Windows capture, Win32 display/click-through behavior, BlueStacks, and the live game have not been tested in this Linux environment.** This is a source release with a Windows launcher, not a compiled `.exe`. See `VALIDATION.md` for measured results and remaining live checks.

## Development

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS (offline engine checks only): source .venv/bin/activate
python -m pip install -r requirements.txt
python loong_lens.py --self-check
python -m pip install pytest==8.4.2
python -m pytest -q
python tools/benchmark.py
```

`--self-check` works without a game or display. It checks real atlas crops and transparent rendering; it does not simulate a successful live-game run. Benchmark results use synthetic viewports cropped from the supplied atlas, not live screenshots or end-to-end latency on your PC.
