"""History window for confirmed sightings; test images are excluded by default."""
import sqlite3
import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


class SightingControls:
    def __init__(self, root, history):
        self.root = root
        self.history = history
        self.window = None
        self.tree = None
        self.rows = {}
        self.include_tests = tk.BooleanVar(root, value=False)
        self.summary = tk.StringVar(root)
        self.refresh()

    def refresh(self):
        counts = self.history.counts()
        pending = self.history.pending_count()
        suffix = f' · Captures pending: {pending}' if pending else ''
        self.summary.set(f'Live sightings: {counts.get(0, 0)} · Image tests: {counts.get(1, 0)}' + suffix)
        if self.tree is None or not self.tree.winfo_exists():
            return
        rows = self.history.list(include_tests=self.include_tests.get(), limit=1000)
        self.rows = {str(row.id): row for row in rows}
        existing = set(self.tree.get_children())
        wanted = {str(row.id) for row in rows}
        for removed in existing - wanted:
            self.tree.delete(removed)
        for index, row in enumerate(rows):
            values = (row.spotted, row.source_label, f'{row.score:.3f}')
            key = str(row.id)
            if key in existing:
                self.tree.item(key, values=values)
            else:
                self.tree.insert('', index, iid=key, values=values)
            self.tree.move(key, '', index)

    def show(self):
        if self.window is not None and self.window.winfo_exists():
            self.window.lift()
            return
        self.window = window = tk.Toplevel(self.root)
        window.title('Gem sighting history')
        window.transient(self.root)
        window.geometry('880x450')
        window.minsize(660, 330)
        body = ttk.Frame(window, padding=18)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='Gems spotted', font=('Segoe UI', 14, 'bold')).pack(anchor='w')
        ttk.Label(body, textvariable=self.summary, style='Muted.TLabel').pack(anchor='w', pady=(5, 8))
        ttk.Checkbutton(body, text='Include image tests', variable=self.include_tests,
                        command=self.refresh).pack(anchor='w')
        ttk.Label(body, text='Live location/screenshot captured after 5 seconds · Click Source to open its screenshot\nTimes use your PC clock. Coordinates are your position at capture time.',
                  style='Muted.TLabel').pack(anchor='w', pady=(4, 10))
        table = ttk.Frame(body)
        table.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(table, columns=('time', 'source', 'score'), show='headings', selectmode='browse')
        for name, label, width in [('time', 'Spotted', 470), ('source', 'Source', 250),
                                   ('score', 'Match score', 100)]:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=width, minwidth=80)
        scrollbar = ttk.Scrollbar(table, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        self.tree.bind('<ButtonRelease-1>', self.source_click)
        self.tree.bind('<Motion>', self.source_hover)
        self.tree.bind('<Return>', lambda _: self.open_screenshot())
        row = ttk.Frame(body)
        row.pack(side='bottom', fill='x', pady=(12, 0), before=table)
        ttk.Button(row, text='Open screenshot', command=self.open_screenshot).pack(side='left', padx=(0,8))
        ttk.Button(row, text='Export history CSV', command=self.export).pack(side='left')
        ttk.Button(row, text='Remove selected', command=self.remove).pack(side='left', padx=8)
        ttk.Button(row, text='Close', command=window.destroy).pack(side='right')
        self.refresh()

    def source_hover(self, event):
        row = self.rows.get(self.tree.identify_row(event.y))
        link = self.tree.identify_column(event.x) == '#2' and row and row.screenshot_path
        self.tree.configure(cursor='hand2' if link else '')

    def source_click(self, event):
        key = self.tree.identify_row(event.y)
        if key and self.tree.identify_column(event.x) == '#2':
            self.open_screenshot(key)

    def open_screenshot(self, key=None):
        selected = self.tree.selection()
        key = key or (selected[0] if selected else None)
        if key is None:
            return
        row = self.history.get(int(key))
        if row is None:
            return
        if not row.screenshot_path:
            detail = row.capture_note or ('Capture is still pending.' if row.capture_status == 'pending'
                                         else 'No screenshot was saved for this older sighting.')
            messagebox.showinfo('Sighting screenshot', detail, parent=self.window)
            return
        path = Path(row.screenshot_path).resolve()
        folder = (self.history.path.parent/'screenshots').resolve()
        if path.suffix.lower() != '.png' or not path.is_relative_to(folder):
            messagebox.showerror('Sighting screenshot', 'This image is outside the saved screenshots folder.', parent=self.window)
            return
        try:
            if not path.is_file():
                raise OSError(f'The screenshot is missing: {path}')
            os.startfile(str(path))
        except OSError as exc:
            messagebox.showerror('Could not open screenshot', str(exc), parent=self.window)

    def remove(self):
        selected = self.tree.selection()
        if not selected:
            return
        try:
            self.history.remove(int(selected[0]))
            self.refresh()
        except sqlite3.Error as exc:
            messagebox.showerror('Could not remove sighting', str(exc), parent=self.window)

    def export(self):
        path = filedialog.asksaveasfilename(parent=self.window, title='Export sighting history',
                                          initialfile='LoongLens-sightings.csv', defaultextension='.csv',
                                          filetypes=[('CSV', '*.csv')])
        if not path:
            return
        try:
            self.history.export_csv(path, include_tests=self.include_tests.get())
        except (OSError, sqlite3.Error) as exc:
            messagebox.showerror('Could not export sightings', str(exc), parent=self.window)
            return
        messagebox.showinfo('Sightings exported', f'Saved sighting history to:\n{path}', parent=self.window)
