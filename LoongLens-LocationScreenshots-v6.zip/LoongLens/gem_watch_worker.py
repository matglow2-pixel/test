"""Low-rate desktop capture and confirmed alert events; no gameplay input."""
from __future__ import annotations
from collections import deque
from datetime import datetime
import logging
import threading
import time
import uuid
import cv2
import numpy as np
from gem_detector import GemDetector, AlertGate

class WatchWorker:
    def __init__(self, find_window, visible_at, capture=None):
        self.find_window = find_window
        self.visible_at = visible_at
        self.detector = GemDetector()
        self.gate = AlertGate()
        self.lock = threading.Lock()
        self.paused = True
        self.region = None
        self.exclude_hud = True
        self.test_frame = None
        self.generation = 0
        self.reset_requested = False
        self.stop_event = threading.Event()
        self.thread = None
        self.target = None
        self.snapshot = dict(state='Ready — press Start watching', frame=None,
                             detections=[], scan_ms=0., rect=None, test_mode=False)
        self.alerts = deque(maxlen=20)
        self.sightings = deque()
        self.event_session = uuid.uuid4().hex
        self.event_number = 0
        self.map_title = None
        self.capture = capture

    def collect_captures(self):
        if self.capture is not None:
            events = self.capture.poll()
            with self.lock:
                self.sightings.extend(events)

    def capture_due(self, now, frame=None, target=None, reason='BlueStacks was not visible at capture time.', generation=None):
        if self.capture is None:
            return
        with self.lock:
            if self.paused or self.test_frame is not None:
                detail = 'Watching was paused before capture.' if self.paused else 'The source changed to an image test before capture.'
                self.capture.cancel_waiting(detail)
            elif generation is None or generation == self.generation:
                unobscured = False
                if frame is not None and target is not None and any(now >= item.due for item in self.capture.waiting):
                    hwnd, (x,y,w,h) = target
                    # Check a dense grid only when a screenshot is due. Covered
                    # desktop content must not be saved as a game screenshot.
                    columns = max(2, (w+23)//24)
                    rows = max(2, (h+23)//24)
                    unobscured = all(self.visible_at(hwnd,x+px,y+py)
                        for py in np.linspace(10,h-11,rows) for px in np.linspace(10,w-11,columns))
                    reason = 'Another window covered BlueStacks at the five-second capture.'
                self.capture.due(now, frame, target, unobscured, reason)
            self.sightings.extend(self.capture.poll())

    def start(self):
        self.thread = threading.Thread(target=self.run, name='GemWatch-capture', daemon=True)
        self.thread.start()

    def configure(self, paused=None, region=None, threshold=None, reset=False, exclude_hud=None):
        with self.lock:
            self.generation += 1
            if paused is not None:
                if paused != self.paused:
                    self.reset_requested = True
                self.paused = paused
            if reset:
                self.region = region
            if threshold is not None:
                self.detector.threshold = float(threshold)
            if exclude_hud is not None:
                self.exclude_hud = bool(exclude_hud)
                self.reset_requested = True
            self.reset_requested = self.reset_requested or reset

    def test_image(self, frame):
        """Use an explicitly loaded photo through the real confirmation/alert path."""
        with self.lock:
            self.test_frame = frame.copy()
            self.paused = False
            self.reset_requested = True
            self.generation += 1
            self.alerts.clear()
            self.snapshot.update(state='IMAGE TEST — scanning selected picture…', frame=None,
                                 detections=[], rect=None, test_mode=True)

    def watch_game(self):
        with self.lock:
            self.test_frame = None
            self.paused = False
            self.reset_requested = True
            self.generation += 1
            self.alerts.clear()
            self.snapshot.update(state='Returning to live BlueStacks capture…', frame=None,
                                 detections=[], rect=None, test_mode=False)

    def get(self):
        with self.lock:
            return self.snapshot.copy()

    def drain_alerts(self):
        with self.lock:
            alerts = list(self.alerts)
            self.alerts.clear()
            return alerts

    def drain_sightings(self):
        with self.lock:
            events = list(self.sightings)
            self.sightings.clear()
            return events

    def publish(self, **values):
        with self.lock:
            self.snapshot.update(values)

    def run(self):
        import mss
        try:
            with mss.mss() as screen:
                while not self.stop_event.is_set():
                    started = time.perf_counter()
                    try:
                        self.step(screen, started)
                    except Exception as exc:
                        logging.exception('Gem watcher capture failed')
                        self.gate.reset()
                        self.capture_due(time.perf_counter(), reason=f'Screenshot capture failed: {exc}')
                        self.publish(state=f'Capture interrupted: {str(exc)[:100]}', detections=[])
                    # A target of 2 scans/second; expensive frames naturally run slower.
                    self.stop_event.wait(max(.05,.5-(time.perf_counter()-started)))
        except Exception as exc:
            logging.exception('Gem watcher backend failed')
            self.publish(state=f'Screenshot capture unavailable: {str(exc)[:100]}', detections=[])

    def step(self, screen, now):
        self.collect_captures()
        with self.lock:
            paused, region, exclude_hud = self.paused, self.region, self.exclude_hud
            test_frame, generation = self.test_frame, self.generation
            reset = self.reset_requested
            self.reset_requested = False
        if reset:
            self.gate.reset()
        if paused:
            if self.capture is not None:
                self.capture.cancel_waiting('Watching was paused before the five-second capture.')
                self.collect_captures()
            self.publish(state='Paused — Start watching to scan', detections=[])
            return
        if test_frame is not None:
            if self.capture is not None:
                self.capture.cancel_waiting('The source changed to an image test before capture.')
                self.collect_captures()
            self._process(test_frame, None, now, generation, True)
            return
        target = self.find_window()
        if target is None:
            self.capture_due(now)
            self.gate.reset()
            self.target = None
            self.publish(state='Waiting for a visible BlueStacks window', frame=None, detections=[])
            return
        hwnd, rect = target
        x,y,w,h = rect
        if target != self.target:
            self.gate.reset()
            self.target = target
        # Require part of the gameplay area to remain unobscured. Candidate
        # centers/corners are separately checked before they can trigger an alert.
        if not any(self.visible_at(hwnd, x+w*fx, y+h*fy)
                   for fx,fy in [(.25,.4),(.5,.4),(.75,.4),(.25,.65),(.5,.65),(.75,.65)]):
            self.gate.reset()
            self.capture_due(now, reason='BlueStacks was covered at the five-second capture.')
            self.publish(state='BlueStacks is covered — keep the game visible', frame=None, detections=[])
            return
        frame = np.asarray(screen.grab(dict(left=x,top=y,width=w,height=h)))[:,:,:3].copy()
        self.capture_due(time.perf_counter(), frame, target, generation=generation)
        # Large-map icons are reference locations, not gameplay gem piles.
        if self.map_title is None:
            from vision import TitleDetector
            self.map_title = TitleDetector()
        if self.map_title.score(cv2.resize(frame, (570, 1029), interpolation=cv2.INTER_AREA)) >= .64:
            with self.lock:
                if generation == self.generation and not self.paused and not self.reset_requested:
                    self.gate.reset()
                    self.snapshot.update(state='Large map open — watching resumes in gameplay', frame=frame,
                                         detections=[], rect=rect, test_mode=False)
            return
        self._process(frame, target, now, generation, False, region, exclude_hud)

    def _process(self, frame, target, now, generation, test_mode, region=None, exclude_hud=False):
        start = time.perf_counter()
        detections = self.detector.detect(frame, region=region, exclude_hud=exclude_hud)
        scan_ms = (time.perf_counter()-start)*1000
        rect = None
        if not test_mode:
            hwnd, rect = target
            x,y,_,_ = rect
            detections = [d for d in detections if all(self.visible_at(hwnd,x+px,y+py) for px,py in
                          [d.center,(d.x,d.y),(d.x+d.width-1,d.y),(d.x,d.y+d.height-1),
                           (d.x+d.width-1,d.y+d.height-1)])]
        with self.lock:
            # A source change/pause during a scan invalidates all its results.
            if generation != self.generation or self.paused or self.reset_requested:
                return
            confirmed = self.gate.update(detections, time.perf_counter())
            seen_at = time.time()
            for detection in self.gate.new_sightings:
                self.event_number += 1
                event = dict(event_id=f'{self.event_session}:{self.event_number}',
                    seen_at=seen_at, screen_x=detection.center[0], screen_y=detection.center[1],
                    score=detection.score, test_mode=test_mode,
                    capture_status='pending' if self.capture is not None else 'legacy')
                self.sightings.append(event)
                if self.capture is not None:
                    self.capture.schedule(event, target, time.perf_counter(), frame if test_mode else None)
            if confirmed:
                self.alerts.append(dict(time=datetime.fromtimestamp(seen_at).strftime('%Y-%m-%d %H:%M:%S'),
                                        count=len(detections), best=max(d.score for d in detections),
                                        test_mode=test_mode))
            label = 'IMAGE TEST' if test_mode else 'Watching'
            self.snapshot.update(state=f'{label} · {len(detections)} gem candidate(s)' if detections
                                 else f'{label} · no gems detected', frame=frame, rect=rect,
                                 detections=detections, scan_ms=scan_ms, test_mode=test_mode)

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=3.)
        if self.capture is not None:
            events = self.capture.close()
            with self.lock:
                self.sightings.extend(events)
