"""Persistent, manually confirmed pickups and user-chosen check reminders."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, time as day_time, timezone
import csv
import math
from pathlib import Path
import sqlite3
import time

def nearby_markers(x, y, centered_points, limit=6):
    """Return nearby reference dots, converting internal tile centers to game X,Y."""
    if not all(math.isfinite(v) and 0 <= v < 280 for v in (x, y)):
        raise ValueError('Enter pickup coordinates from 0 to 279.')
    points = [(float(px)-.5, float(py)-.5) for px, py in centered_points]
    distances = [(px, py, math.hypot(px-x, py-y)) for px, py in points]
    return sorted(distances, key=lambda point: (point[2], point[0], point[1]))[:limit]

def countdown(seconds):
    if seconds <= 0:
        return 'Check'
    value=math.ceil(seconds)
    return f'{value//60:02d}:{value%60:02d}'

@dataclass(frozen=True)
class Pickup:
    id: int
    map_id: int
    x: float
    y: float
    collected_at: float
    timer_minutes: int
    note: str
    anchor_x: float | None = None
    anchor_y: float | None = None

    @property
    def marker_x(self):
        return self.x if self.anchor_x is None else self.anchor_x

    @property
    def marker_y(self):
        return self.y if self.anchor_y is None else self.anchor_y

    @property
    def check_at(self):
        return self.collected_at+self.timer_minutes*60

    def remaining(self,now):
        return max(0.,self.check_at-now)

    def label(self,now):
        return countdown(self.check_at-now)

    @property
    def local_time(self):
        return datetime.fromtimestamp(self.collected_at).astimezone().strftime('%Y-%m-%d %H:%M:%S')

class PickupHistory:
    FIELDS='id,map_id,x,y,collected_at,timer_minutes,note,anchor_x,anchor_y'
    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.connection=sqlite3.connect(self.path)
        self.connection.execute('''CREATE TABLE IF NOT EXISTS pickups (
            id INTEGER PRIMARY KEY, map_id INTEGER NOT NULL,
            x REAL NOT NULL, y REAL NOT NULL, collected_at REAL NOT NULL,
            timer_minutes INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '',
            anchor_x REAL, anchor_y REAL)''')
        columns={row[1] for row in self.connection.execute('PRAGMA table_info(pickups)')}
        for name in ('anchor_x','anchor_y'):
            if name not in columns:
                self.connection.execute(f'ALTER TABLE pickups ADD COLUMN {name} REAL')
        self.connection.execute('CREATE INDEX IF NOT EXISTS pickup_position ON pickups(map_id,x,y,collected_at DESC,id DESC)')
        self.connection.commit()

    def record(self,x,y,timer_minutes=30,collected_at=None,note='',map_id=14,anchor=None):
        now=time.time()
        try:
            x,y=float(x),float(y)
            collected_at=now if collected_at is None else float(collected_at)
            duration=float(timer_minutes)
        except (ValueError,TypeError):
            raise ValueError('Enter valid coordinates and a reminder duration.') from None
        if not all(math.isfinite(v) and 0<=v<280 for v in (x,y)):
            raise ValueError('Coordinates must be from 0 to 279 (decimals below 280 are supported).')
        if not math.isfinite(duration) or not duration.is_integer() or not 1<=duration<=1440:
            raise ValueError('The reminder must be a whole number from 1 to 1440 minutes.')
        if not math.isfinite(collected_at) or collected_at<0 or collected_at>now+1:
            raise ValueError('The pickup time must be a valid time in the past or now.')
        if map_id!=14:
            raise ValueError('This release records Loong Haven pickups only.')
        if anchor is not None:
            try:
                if len(anchor)!=2:raise ValueError()
                anchor=tuple(float(v) for v in anchor)
                if not all(math.isfinite(v) and 0<=v<280 for v in anchor):raise ValueError()
            except (ValueError,TypeError):
                raise ValueError('Choose a valid timer marker coordinate.') from None
        ax,ay=anchor if anchor is not None else (None,None)
        with self.connection:
            cursor=self.connection.execute('INSERT INTO pickups(map_id,x,y,collected_at,timer_minutes,note,anchor_x,anchor_y) VALUES(?,?,?,?,?,?,?,?)',
                (map_id,x,y,collected_at,int(duration),str(note).strip()[:500],ax,ay))
        return self.get(cursor.lastrowid)

    def get(self,pickup_id):
        row=self.connection.execute(f'SELECT {self.FIELDS} FROM pickups WHERE id=?',(pickup_id,)).fetchone()
        return Pickup(*row) if row else None

    def list(self,limit=None):
        query=f'SELECT {self.FIELDS} FROM pickups ORDER BY collected_at DESC,id DESC'
        rows=self.connection.execute(query if limit is None else query+' LIMIT ?',() if limit is None else (int(limit),))
        return [Pickup(*row) for row in rows]

    def latest_locations(self):
        rows=self.connection.execute(f'''SELECT {self.FIELDS} FROM (
            SELECT *,ROW_NUMBER() OVER (PARTITION BY map_id,COALESCE(anchor_x,x),COALESCE(anchor_y,y) ORDER BY collected_at DESC,id DESC) AS newest
            FROM pickups WHERE map_id=14) WHERE newest=1 ORDER BY collected_at DESC,id DESC''')
        return [Pickup(*row) for row in rows]

    def today_count(self,now=None):
        now=time.time() if now is None else now
        local=datetime.fromtimestamp(now).astimezone()
        start=datetime.combine(local.date(),day_time()).astimezone().timestamp()
        return self.connection.execute('SELECT COUNT(*) FROM pickups WHERE collected_at>=? AND collected_at<=?',(start,now)).fetchone()[0]

    def remove(self,pickup_id):
        with self.connection:
            self.connection.execute('DELETE FROM pickups WHERE id=?',(pickup_id,))

    def export_csv(self,path):
        with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f)
            writer.writerow(['id','map_id','x','y','collected_at_local','collected_at_utc','reminder_minutes','timer_marker_x','timer_marker_y','note'])
            for pickup in self.list():
                stamp=datetime.fromtimestamp(pickup.collected_at,timezone.utc).isoformat()
                local=datetime.fromtimestamp(pickup.collected_at).astimezone().isoformat()
                # Spreadsheet formulas in user notes must remain plain text.
                note=pickup.note
                if note.lstrip().startswith(('=','+','-','@')):
                    note="'"+note
                writer.writerow([pickup.id,pickup.map_id,pickup.x,pickup.y,local,stamp,pickup.timer_minutes,pickup.marker_x,pickup.marker_y,note])

    def close(self):
        self.connection.close()
