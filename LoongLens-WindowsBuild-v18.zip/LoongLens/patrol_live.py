"""Screenshot-guided live patrol loop; input and clock are injectable for tests."""
from __future__ import annotations
from dataclasses import dataclass,replace
import math
import threading
import time
import uuid
import cv2
from gem_detector import GemDetector,AlertGate
from patrol_windows import PatrolStopped

LEGACY_MAP_OPEN = (515.,830.)
MINIMAP_OPEN = (480.,170.)
LIVE_SETTINGS_VERSION = 2


@dataclass(frozen=True)
class LiveSettings:
    map_open: tuple = MINIMAP_OPEN
    map_close: tuple = (64.,980.)
    settle_seconds: float = .8
    inspect_seconds: float = 1.5
    threshold: float = .77
    mask_hud: bool = False
    approach_gem: bool = True

    def __post_init__(self):
        for x,y in (self.map_open,self.map_close):
            if not (math.isfinite(x) and math.isfinite(y) and 0<=x<570 and 0<=y<1029):
                raise ValueError('Choose map buttons inside the BlueStacks screenshot.')
        if not (math.isfinite(self.settle_seconds) and .2<=self.settle_seconds<=10
                and math.isfinite(self.inspect_seconds) and 1.2<=self.inspect_seconds<=10
                and .5<=self.threshold<=.99):raise ValueError('Invalid patrol timing or detector settings.')


def load_live_config(config):
    """Upgrade the v14 wrong default only; keep user calibration/timings intact."""
    values=dict(config['settings'])
    migrated=(config.get('version',1)==1 and tuple(values.get('map_open',MINIMAP_OPEN))==LEGACY_MAP_OPEN)
    if migrated:values['map_open']=MINIMAP_OPEN
    settings=LiveSettings(**values)
    key=config.get('key','F8')
    return settings,key if key in ('F6','F7','F8','F9') else 'F8',migrated


def clickable(point):
    x,y=point
    return 32<=x<=510 and 150<=y<=800 and not (x>=420 and y<=250)


def locked_at(frame,point,scale):
    """Recognise the dark desaturated locked-zone shading at a known spawn.

    Do not infer locks from names, the character level, or the atlas: locks
    belong to this player's current map. Ignore text/icons using a tile patch.
    """
    x,y=map(round,point);radius=max(8,round(scale*1.15))
    h,w=frame.shape[:2]
    if not (radius<=x<w-radius and radius<=y<h-radius):return False
    hsv=cv2.cvtColor(frame[y-radius:y+radius+1,x-radius:x+radius+1],cv2.COLOR_BGR2HSV)
    dark=(hsv[:,:,2]>18)&(hsv[:,:,2]<96)&(hsv[:,:,1]<80)
    return float(dark.mean())>=.68


def accessible_view(view,frame,pose):
    """Exclude locked member spots, preserving the unlocked ones in one view."""
    from camera_patrol import PatrolSettings,playable_ground,camera_click_clear
    unlocked=frozenset(cell for cell in view.cells if not locked_at(frame,pose.project(cell[0]+.5,cell[1]+.5),pose.scale))
    if not unlocked:return None
    if camera_click_clear(view.x,view.y) and not locked_at(frame,pose.project(view.x,view.y),pose.scale):
        return replace(view,cells=unlocked)
    # A group straddling a locked boundary must be centred on its open side.
    import numpy as np
    settings=PatrolSettings();half=np.array([settings.view_width/2-.6,settings.view_height/2-.6])
    points=np.array([(x+.5,y+.5) for x,y in unlocked]);low=(points-half).max(axis=0);high=(points+half).min(axis=0)
    ground=playable_ground();candidates=[]
    for x in np.arange(low[0],high[0]+.001,.25):
        for y in np.arange(low[1],high[1]+.001,.25):
            point=pose.project(x,y)
            if 0<=x<280 and 0<=y<280 and ground[int(y),int(x)] and camera_click_clear(x,y) and clickable(point) and not locked_at(frame,point,pose.scale):
                candidates.append((math.hypot(x-view.x,y-view.y),x,y))
    if not candidates:raise RuntimeError('This view crosses a locked boundary; no open camera target was visible. Patrol stopped.')
    _,x,y=min(candidates)
    return replace(view,x=x,y=y,cells=unlocked)


class MapAlignmentLost(RuntimeError):
    pass


class LivePatrol:
    def __init__(self,views,settings,cancel,emit,checked=None,cooldown=None,
                 detector=None,locator=None,title=None,clock=time.perf_counter,wall=time.time,skipped=None,navigation=None):
        self.views=tuple(views);self.settings=settings;self.cancel=cancel;self.emit=emit
        self.checked=checked if checked is not None else set()
        self.cooldown=cooldown if cooldown is not None else {'last':-float('inf')}
        self.detector=detector or GemDetector(threshold=settings.threshold)
        self.locator=locator;self.title=title;self.clock=clock;self.wall=wall
        self.navigation=navigation if navigation is not None else {}
        self.map_reference=self.navigation.get('reference')
        self.pan_scale=self.navigation.get('pan_scale',1.)
        self.skipped=skipped if skipped is not None else set()

    def send(self,kind,**data):self.emit(dict(kind=kind,**data))
    def check(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')

    @staticmethod
    def normal(frame):return cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)

    def is_map(self,frame):return self.title.score(self.normal(frame))>=.64

    def map_frame(self,backend):
        deadline=self.clock()+6
        while self.clock()<deadline:
            self.check();frame=backend.capture()
            if self.is_map(frame):return frame
            backend.wait(.2)
        raise RuntimeError('The large map did not open. Set Open map to the minimap in Live settings; patrol stopped.')

    def open_map(self,backend):
        frame=backend.capture()
        if self.is_map(frame):return frame
        self.send('status',message='Reopening the large map…')
        backend.click(self.settings.map_open)
        # One opener click only. Do not proceed or click other controls until
        # the actual map title appears; alignment follows on fresh screenshots.
        return self.map_frame(backend)

    def align(self,backend,reference=None,timeout=7.,recovery=False):
        deadline=self.clock()+timeout
        previous=None
        reference=reference or self.map_reference
        while self.clock()<deadline:
            self.check();frame=self.map_frame(backend)
            normal=self.normal(frame)
            pose=None
            if reference is not None:
                from vision import track_map_pan
                before,known,delta=reference
                pose=track_map_pan(before,normal,known,delta,recovery=recovery)
            if pose is not None and reference is not None and math.hypot(*reference[2])>1 and hasattr(self.locator,'index'):
                # Refresh against absolute atlas landmarks when available so
                # many relative pans do not accumulate small registration errors.
                absolute=self.locator.index.locate(normal)
                if absolute is None:absolute=self.locator.index.locate(normal,wide=True)
                if absolute is not None and math.hypot(absolute.tx-pose.tx,absolute.ty-pose.ty)<10:
                    pose=absolute
            if pose is None:pose=self.locator.locate(normal)
            self.check()
            if pose is not None and previous is not None and (
                    abs(pose.scale-previous.scale)<.03 and abs(pose.tx-previous.tx)<3 and abs(pose.ty-previous.ty)<3):
                self.map_reference=(normal,pose,(0.,0.))
                self.navigation['reference']=self.map_reference
                return frame,pose
            previous=pose
            backend.wait(.15)
        raise MapAlignmentLost('Could not align Loong Haven. Use default zoom and keep map terrain visible.')

    def recover_pan(self,backend):
        pending=self.navigation.get('pending')
        if pending is None or self.navigation.get('recovery_exhausted'):
            raise MapAlignmentLost('Could not align the map. Drag it back to recognisable terrain, then resume; checked locations are kept.')
        before,known,delta=pending
        length=math.hypot(*delta)
        if length<1:raise MapAlignmentLost('Could not recover an unmoving map; checked locations are kept.')
        # Only undo our own last pan, in small steps, while the large map is
        # visibly open. Never click a guessed gem position during recovery.
        reverse=tuple(-v/length*min(70.,length) for v in delta)
        for attempt in range(6):
            self.check();self.map_frame(backend)
            self.send('status',message=f'Recovering map alignment — small reverse pan {attempt+1}/6…')
            self.check();backend.drag((285.,500.),(285+reverse[0],500+reverse[1]))
            backend.wait(.25)
            try:
                frame,pose=self.align(backend,(before,known,delta),timeout=1.5,recovery=True)
            except MapAlignmentLost:
                continue
            self.navigation.pop('pending',None);self.navigation.pop('recovery_exhausted',None)
            self.pan_scale=max(.25,self.pan_scale*.5)
            self.navigation['pan_scale']=self.pan_scale
            self.send('status',message='Map recovered. Continuing with smaller pans; progress kept.')
            return frame,pose
        self.navigation['recovery_exhausted']=True
        raise MapAlignmentLost('Map recovery could not find enough terrain. Drag back onto the map and resume; checked locations are kept.')

    def pan(self,backend,frame,pose,delta):
        before=self.normal(frame)
        self.navigation['pending']=(before,pose,delta)
        self.check();backend.drag((285.,500.),(285+delta[0],500+delta[1]))
        backend.wait(.25)
        try:
            current,updated=self.align(backend,(before,pose,delta),timeout=3.)
        except MapAlignmentLost:
            return self.recover_pan(backend)
        actual=math.hypot(updated.tx-pose.tx,updated.ty-pose.ty)
        requested=math.hypot(*delta)
        if actual>requested*1.35:
            self.pan_scale=max(.25,self.pan_scale*requested/actual)
            self.navigation['pan_scale']=self.pan_scale
        self.navigation.pop('pending',None);self.navigation.pop('recovery_exhausted',None)
        return current,updated

    def inspect(self,backend):
        gate=AlertGate(cooldown=0)
        started=self.clock();scans=0
        while self.clock()-started<self.settings.inspect_seconds or scans<3:
            self.check();frame=backend.capture()
            if self.is_map(frame):raise RuntimeError('The map did not close. Set its Back button in Live settings.')
            boxes=self.detector.detect(frame,exclude_hud=self.settings.mask_hud)
            self.check();gate.update(boxes,self.clock());scans+=1
            self.send('frame',frame=frame,detections=boxes)
            if gate.new_sightings:return gate.new_sightings[0],frame
            if self.clock()-started>8:raise RuntimeError('Screenshot detection is too slow to complete this view.')
            backend.wait(.2)
        return None,None

    def run(self,backend,auto=True):
        self.check()
        if self.locator is None:
            from vision import Calibrator,TitleDetector
            from resources import user_dir
            self.send('status',message='Preparing map recognition…')
            self.locator=Calibrator(user_dir(),wide=True);self.title=TitleDetector()
        if hasattr(self.locator,'index') and not self.locator.index.ready:
            self.send('status',message='Preparing map recognition cache…')
            self.locator.index.prepare()
            self.check()
        self.send('status',message='Starting in 2 seconds. F10 stops at any time.')
        backend.wait(2);backend.focus()
        while len(self.checked)<len(self.views):
            self.check();self.open_map(backend)
            pending=self.navigation.get('pending')
            try:
                frame,pose=self.align(backend,pending,timeout=3. if pending else 7.)
                self.navigation.pop('pending',None);self.navigation.pop('recovery_exhausted',None)
            except MapAlignmentLost:
                frame,pose=self.recover_pan(backend)
            remaining=[i for i in range(len(self.views)) if i not in self.checked]
            if not remaining:break
            visible=[i for i in remaining if clickable(pose.project(self.views[i].x,self.views[i].y))]
            center=((285-pose.tx)/pose.scale,(pose.ty-500)/pose.scale)
            index=(visible[0] if visible else min(remaining,key=lambda i:
                math.hypot(self.views[i].x-center[0],self.views[i].y-center[1])))
            view=self.views[index]
            self.send('view',index=index,view=view,checked=len(self.checked))
            stalled=0;previous=None
            for attempt in range(257):
                self.check();point=pose.project(view.x,view.y)
                if clickable(point):break
                if attempt==256:raise RuntimeError('Could not bring this dot into view. Patrol stopped.')
                distance=math.hypot(point[0]-285,point[1]-500)
                stalled=stalled+1 if previous is not None and distance>=previous-3 else 0
                if stalled>=3:raise RuntimeError('Map panning is not moving toward the dot. Patrol stopped.')
                previous=distance
                dx,dy=285-point[0],500-point[1]
                self.send('status',message='Panning to reveal the next gem dot…')
                from terrain_alignment import classify_screen
                known_ground=classify_screen(self.normal(frame))
                sparse=(known_ground[150:850,24:510]!=0).mean()<.35
                limit=(70. if sparse else 120.)*self.pan_scale
                factor=max(1,math.hypot(dx,dy)/limit)
                delta=(dx/factor,dy/factor)
                frame,pose=self.pan(backend,frame,pose,delta)
            available=accessible_view(view,self.normal(frame),pose)
            if available is None:
                self.checked.add(index);self.skipped.add(index)
                self.send('checked',index=index,count=len(self.checked),skipped=len(self.skipped))
                self.send('status',message=f'Skipped locked area: {view.near_zone}')
                if not auto:return 'Locked gem location skipped. Press the advance hotkey for another.'
                continue
            view=available;point=pose.project(view.x,view.y)
            if not clickable(point):raise RuntimeError('The accessible camera target moved outside the clickable map; stopped.')
            # Recognition came from this fresh screenshot; guard input again.
            self.check();self.send('status',message=f'Clicking {view.near_zone} ({math.floor(view.x)},{math.floor(view.y)})')
            if not self.is_map(backend.capture()):raise RuntimeError('The map changed before the dot click. Patrol stopped.')
            backend.click(point);backend.wait(.2)
            if self.is_map(backend.capture()):backend.click(self.settings.map_close)
            deadline=self.clock()+5
            while self.is_map(backend.capture()):
                if self.clock()>deadline:raise RuntimeError('The map did not close. Calibrate its Back button.')
                backend.wait(.2)
            backend.wait(self.settings.settle_seconds)
            self.send('status',message='Inspecting the visible scene…')
            found,frame=self.inspect(backend)
            self.checked.add(index);self.send('checked',index=index,count=len(self.checked))
            if found is not None:
                now=self.clock();event=None
                if now-self.cooldown['last']>=20:
                    self.cooldown['last']=now
                    event=dict(event_id='patrol:'+uuid.uuid4().hex,seen_at=self.wall(),screen_x=found.center[0],
                        screen_y=found.center[1],score=found.score,test_mode=False,capture_status='pending',
                        zone=view.near_zone,game_x=math.floor(view.x),game_y=math.floor(view.y),
                        capture_note='Camera view: selected spawn area, not the gem tile.',
                        camera_location=dict(zone=view.near_zone,x=math.floor(view.x),y=math.floor(view.y)))
                sound=now-self.cooldown.get('sound',-float('inf'))>=30
                if sound:self.cooldown['sound']=now
                self.send('found',event=event,view=view,sound=sound)
                if self.settings.approach_gem:
                    from camera_patrol import approach_click
                    point=approach_click(found.center,frame.shape)
                    if event is not None:
                        event=dict(event,capture_note=event['capture_note']+' Photo saved before the movement click.')
                        self.send('capture',event=event,frame=frame.copy(),captured_at=self.wall())
                    self.check()
                    if point is None:
                        return 'Gem found. No nearby click away from interface controls was available; stopped for manual movement.'
                    # Capture guards cover focus/resize/obstruction, and a fresh
                    # visual check avoids sending a move into a changed scene.
                    fresh=backend.capture()
                    if self.is_map(fresh):return 'Gem found. Map reopened; movement cancelled.'
                    current=self.detector.detect(fresh,exclude_hud=self.settings.mask_hud)
                    if not any(math.dist(box.center,found.center)<max(30,found.width*2) for box in current):
                        return 'Gem found. Scene changed before movement; stopped without clicking.'
                    self.check();backend.click(point)
                    self.send('approached',point=point)
                    return 'Gem found. Clicked beside the gem once; patrol stopped. Collect it manually.'
                if event is not None:
                    try:
                        backend.wait(5);fresh=backend.capture()
                        if self.is_map(fresh):raise RuntimeError('The map was opened before capture.')
                        self.send('capture',event=event,frame=fresh,captured_at=self.wall())
                    except Exception as exc:
                        self.send('sighting',event=dict(event,capture_status='cancelled',
                            capture_note=event['capture_note']+' Screenshot unavailable: '+str(exc)))
                return 'Gem found. Patrol stopped; collect it manually.'
            if not auto:return 'One location checked. Press the advance hotkey for another.'
        return f'Pass complete: {len(self.checked)-len(self.skipped)} camera views checked, {len(self.skipped)} locked views skipped. Reset checks to scan again.'


class PatrolRunStats:
    """Elapsed wall time and confirmed finds until every view is processed."""
    def __init__(self,clock=time.perf_counter):
        self.clock=clock;self.lock=threading.Lock()
        self.elapsed=0.;self.started=None;self.gems=0

    def start(self):
        with self.lock:
            if self.started is None:self.started=self.clock()

    def complete(self):
        with self.lock:
            if self.started is not None:
                self.elapsed+=max(0.,self.clock()-self.started);self.started=None

    def found(self):
        with self.lock:self.gems+=1

    def reset(self):
        with self.lock:self.elapsed=0.;self.started=None;self.gems=0

    def snapshot(self):
        with self.lock:
            elapsed=self.elapsed+(max(0.,self.clock()-self.started) if self.started is not None else 0.)
            return dict(elapsed=elapsed,gems=self.gems)

    def text(self):
        values=self.snapshot();minutes,seconds=divmod(int(values['elapsed']),60)
        return f"Time spent: {minutes}:{seconds:02d}\nGems found: {values['gems']}"


class LiveRunner:
    def __init__(self,views,backend_factory,emit,clock=time.perf_counter):
        self.views=views;self.backend_factory=backend_factory;self.emit=emit
        self.cancel=threading.Event();self.thread=None;self.checked=set();self.skipped=set();self.cooldown={'last':-float('inf')}
        self.detector=None;self.locator=None;self.title=None
        self.stats=PatrolRunStats(clock)
        self.navigation={}
    @property
    def running(self):return self.thread is not None and self.thread.is_alive()
    def stop(self):self.cancel.set()
    def start(self,settings,auto=True):
        if self.running or len(self.checked)>=len(self.views):return False
        self.cancel.clear()
        self.stats.start()
        def report(event):
            if event['kind']=='found':self.stats.found()
            self.emit(event)
        def work():
            message='Stopped.'
            try:
                if self.cancel.is_set():raise PatrolStopped('Stopped.')
                if self.detector is None:self.detector=GemDetector(threshold=settings.threshold)
                self.detector.threshold=settings.threshold
                if self.cancel.is_set():raise PatrolStopped('Stopped.')
                if self.locator is None:
                    from vision import Calibrator,TitleDetector
                    from resources import user_dir
                    self.locator=Calibrator(user_dir(),wide=True);self.title=TitleDetector()
                patrol=LivePatrol(self.views,settings,self.cancel,report,self.checked,self.cooldown,
                    self.detector,self.locator,self.title,clock=self.stats.clock,skipped=self.skipped,navigation=self.navigation)
                patrol.check()
                with self.backend_factory(self.cancel) as backend:message=patrol.run(backend,auto)
            except Exception as exc:message=str(exc)
            finally:
                if len(self.checked)>=len(self.views):self.stats.complete()
                self.emit(dict(kind='finished',message=message,stats=self.stats.snapshot()))
        self.thread=threading.Thread(target=work,daemon=True,name='LoongLens-live-patrol');self.thread.start()
        return True
