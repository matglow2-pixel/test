# Loong Lens

A redesigned **Sword x Staff / Loong Haven** map overlay for **Windows 10 (2004+) or Windows 11, BlueStacks, and the normal/default map zoom**.

## Start

1. Install **64-bit Python 3.10–3.13** from python.org. Include **Tcl/Tk** and the Python launcher.
2. Extract this folder to a writable location. Close your previous overlay.
3. Double-click **RUN_LOONG_LENS.bat**. The launcher creates a private `.venv` and installs the pinned dependencies on the first run. Internet access is needed for that installation; ordinary tracking works offline.
4. Open the Loong Haven map in BlueStacks at **default zoom**. Bring BlueStacks to the foreground. Gems are enabled initially; choose other resources in the panel.

The first launch builds an atlas index in the background (about five seconds on the development machine). Later launches reuse that index. The panel can say “Finding map position” while this happens. There is no need to keep the map open while the cache builds.

Markers disappear when the map title disappears, BlueStacks is minimized or loses focus, tracking loses confidence, or you pause. Clicking the control panel therefore temporarily hides markers; click BlueStacks again to continue. **Re-align** requests fresh recognition. The window must be fully visible on screen. The screenshot title/template layout is inherited from the upload; other emulator layouts, changed game UI, or landscape layouts have not been validated.

## Controls

- **Gems:** 86 candidate locations from the uploaded dataset, shown in pink.
- **Beans / Crisp Beans:** 3 reported ingredient areas, outlined in green.
- **Bamboo Shoots:** 9 reported ingredient areas, outlined in blue.
- **Giant Crab / Crab King:** 11 approximate community coordinates, shown in orange.
- **Shade ingredient areas:** toggle the translucent fill independently of borders.
- **Dot size / Opacity:** adjust the overlay; preferences are saved automatically.
- **Battery saver / Balanced / Smooth:** target capture rates of 15 / 30 / 45 FPS. These are limits, not guaranteed FPS.
- **Import CSV:** replace your personal coordinate list after validation. Bundled data is preserved. Imported coordinates are added as dots.
- **Pause / Resume / Exit:** stop tracking temporarily, restart it, or close the overlay.

Preferences, the atlas cache, personal coordinates, and diagnostics live under **`%LOCALAPPDATA%\LoongLens`**. The program does not write preferences into the installation folder. To reset settings, close it and remove `settings.json` from that directory. Diagnostics are in `loonglens.log`.

## Personal coordinates

Use `gems`, `common`, `rare`, or `epic` in the `tier` column, and coordinates in `[0,280)` (the game's integer grid runs from 0 to 279). Labels are optional. Imports with invalid columns, unknown tiers, NaN/infinite values, or out-of-range coordinates are rejected entirely. Duplicate locations are removed.

```csv
tier,x,y,label
rare,156,121,My verified gathering spot
gems,184,138,My reported gem location
```

The rows above demonstrate the format; they are **not additional verified locations**. A CSV import replaces the previous personal CSV and leaves the bundled coordinates and zones intact. An empty CSV containing just the header clears personal coordinates.

## What changed from the upload

- A precomputed, cached SIFT landmark index replaces repeated whole-atlas image searches. The uploaded template matcher remains a default-zoom fallback.
- Recognition runs on a separate worker with **one in-flight request**. Results are checked against the map session, frame age, and current pixels; a result from a closed map cannot paint onto a reopened map.
- Optical flow follows map motion, with forward/backward checks to reject unreliable movement. Periodic absolute recognition limits drift.
- Default-zoom constraints reject substantially zoomed views instead of assuming the normal scale.
- Vectorized point projection, reusable marker sprites, and an unchanged-frame cache reduce drawing work. The native layered window reuses its bitmap and device contexts.
- The panel has resource colors, saved preferences, personal imports, pause/re-align controls, and measured timing indicators.
- The overlay is click-through and does not take focus. Windows capture exclusion prevents it from tracking its own markers. If exclusion cannot be enabled, the overlay pauses with an explanation.

## Data and limitations

This release reuses the map atlas and location data supplied in `SxSMapOverlay.rar`. It does not invent new gem or ingredient coordinates, infer exact spawns from broad zone hints, or detect whether a resource is currently present. The broad areas may not include every gathering location.

The upload cited these ingredient sources:

- https://www.taptap.cn/moment/702592615505201982
- https://hackmd.io/@Tj-HoTwkRNWfXZ9-XrH_Zg/BkMmylVhZg

Those pages and a search for additional interactive maps were blocked by the development environment's egress policy. No new online location data was imported or independently verified. The gem dataset's exact viewer URL was not provided in the archive.

The overlay reads ordinary desktop screenshots and paints a separate transparent window. It does not inject into the game, read game memory, use ADB, or send game input. Your game's rules still govern overlay use.

### Validation

Offline tests exercise atlas alignment, rejection of other zoom levels, pan tracking, title detection, CSV validation, transparent rendering, stationary-frame caching, and stale-session handling. The real Tk panel was also exercised using a simulated Windows backend on a Linux virtual display.

**The Windows capture, Win32 display/click-through behavior, BlueStacks, and the live game have not been tested in this Linux environment.** This is a source release with a Windows launcher, not a compiled `.exe`. See `VALIDATION.md` for measured results and remaining live checks.

## Development

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS (offline engine checks only): source .venv/bin/activate
python -m pip install -r requirements.txt
python loong_lens.py --self-check
python -m pip install pytest==8.4.2
python -m pytest -q
python tools/benchmark.py
```

`--self-check` works without a game or display. It checks real atlas crops and transparent rendering; it does not simulate a successful live-game run. Benchmark results use synthetic viewports cropped from the supplied atlas, not live screenshots or end-to-end latency on your PC.
