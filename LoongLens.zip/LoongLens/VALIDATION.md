# Validation of this source release

Tests were run in the Linux development environment with Python 3.12, OpenCV 4.12.0, and two OpenCV threads. The live application targets Windows 10 (2004+) / Windows 11 and BlueStacks at default map zoom.

## Results

- **35 automated tests passed.** These exercise default-scale atlas alignment, rejection of nondefault zoom, motion tracking, title detection, cache recovery, CSV validation, rendering, transparent UI exclusion, background request limits, pause/focus handling, and rejection of recognition results from a previous map session.
- **Offline self-check passed:** 3/3 selected atlas viewports aligned, the packaged 86-gem dataset loaded, and transparent rendering completed.
- **Tk panel smoke check passed** on a virtual X display with a simulated Windows overlay backend. Layer toggles, dot size, opacity, pause/resume, preferences, initial layout, and exit were exercised. This does not test Windows native APIs.
- **Release archive CRC checked**, then extracted for the offline self-check and automated suite.

## Measured performance

These are microbenchmarks of **synthetic viewports cropped from the supplied atlas**. They do not establish detection accuracy on live screenshots or end-to-end latency on a user's PC. Each original matcher timing used six repetitions; each indexed matcher timing used twelve repetitions after warm-up.

| Atlas viewport origin | Original search median | Indexed search median | Ratio |
|---|---:|---:|---:|
| 900, 1300 | 304.56 ms | 52.12 ms | 5.84× |
| 1600, 1500 | 384.86 ms | 60.46 ms | 6.37× |
| 2000, 1700 | 308.11 ms | 51.78 ms | 5.95× |

At a 570×1029 render size with all four layers enabled, full rendering had a **0.659 ms median** over 60 repetitions. An unchanged frame returned the cached surface in **0.002 ms median** over 1,000 repetitions. Stationary optical flow had a **2.985 ms median** over 60 repetitions.

The measured index preparation run took 2.38 seconds; an earlier run took about 5 seconds. Later launches reuse an on-disk index. Performance varies with CPU, atlas cache state, map detail, emulator size, and other activity. Windows bitmap upload and screen capture costs were not measured here.

Reproduce the microbenchmarks using `python tools/benchmark.py`; detailed results are written into `artifacts/benchmark.json`.

## Required live checks still outstanding

These require the user's Windows / BlueStacks / game installation, which was unavailable here:

1. Launch with `RUN_LOONG_LENS.bat`, put the map at normal/default zoom, and bring BlueStacks to the foreground. Confirm that transparent markers appear at recognizable locations.
2. Pan across several areas. Confirm that dots and zone borders follow the terrain without persistent offsets.
3. Close/reopen the map, resize/move BlueStacks, switch to another app, and pause/resume. Confirm that markers disappear and reacquire correctly.
4. Confirm that mouse clicks pass through the overlay and that the overlay does not steal keyboard focus.
5. Compare candidate coordinates with the live map. The supplied community data is not a verified list of current spawns.

The game must be visible on the desktop for screenshot capture. Its title and fixed UI layout must match the supplied templates. If alignment is unavailable, restore normal zoom and use **Re-align**; inspect `%LOCALAPPDATA%\LoongLens\loonglens.log` for capture errors.

## Source availability

All location data and reference images were reused from the user's uploaded `SxSMapOverlay.rar`. Requests to the cited TapTap/HackMD guides and an interactive-map web search were blocked with proxy HTTP 403 responses. No additional online coordinates were downloaded or verified.
