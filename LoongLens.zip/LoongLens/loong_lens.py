"""Loong Lens — Windows / BlueStacks resource overlay."""
from __future__ import annotations
import argparse
import json
import logging
import os
from pathlib import Path
import sys
import time

def self_check():
    import cv2
    import numpy as np
    from resources import ResourceStore, Renderer, ROOT
    from vision import AtlasIndex
    from pose import Match
    cv2.setNumThreads(2)
    store = ResourceStore()
    renderer = Renderer(store)
    picture, counts, _ = renderer.render((570, 1029), Match(12.45, -1650, 2250, 0, 0, []),
                                         dict.fromkeys(('gems', 'common', 'rare', 'epic'), True))
    assert picture.mode == 'RGBA' and len(store.points['gems']) == 86
    index = AtlasIndex()
    index.prepare()
    atlas = cv2.imread(str(ROOT / 'loong_haven_default_atlas.png'))
    checked = 0
    for x, y in [(900, 1300), (1600, 1500), (2000, 1700)]:
        frame = atlas[y:y+1029, x:x+570].copy()
        found = index.locate(frame)
        if found is not None:
            assert abs(found.tx + x) < 4 and abs(found.ty - (279 * 12.45 - y)) < 4
            checked += 1
    if not checked:
        raise RuntimeError('Could not align any atlas test viewport.')
    print(f'Self-check passed: {checked}/3 atlas viewports aligned; 86 gems; transparent render OK.')
    print('This offline check does not validate Windows capture, click-through, or the live game.')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-check', action='store_true', help='Check data and atlas recognition without opening a window')
    args = parser.parse_args()
    if args.self_check:
        self_check()
        return
    if sys.platform != 'win32':
        parser.error('The live overlay requires Windows 10/11 and BlueStacks. Use --self-check for offline validation.')
    import cv2
    cv2.setNumThreads(2)
    # Activate DPI awareness before Tk creates any window.
    from win_overlay import PixelAlphaOverlay, find_emulator
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    from resources import ResourceStore, Renderer, COLORS, TIERS, user_dir, load_coordinates
    from tracker import VisualWorker

    folder = user_dir()
    folder.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=folder / 'loonglens.log', level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    settings_path = folder / 'settings.json'
    coordinates_path = folder / 'coordinates.csv'
    settings = {}
    try:
        settings = json.loads(settings_path.read_text('utf-8'))
        if not isinstance(settings, dict):
            settings = {}
    except (OSError, ValueError):
        pass

    class App:
        def __init__(self):
            self.root = tk.Tk()
            self.root.title('Loong Lens')
            self.root.geometry('430x660')
            self.root.minsize(410, 650)
            self.root.configure(bg='#101620')
            self.root.protocol('WM_DELETE_WINDOW', self.close)
            self.closed = False
            self.paused = False
            self.last_rect = None
            self.last_status = 0.
            self.last_upload = 0.
            self.upload_ms = 0.
            self.render_ms = 0.
            self.settings_dirty = False
            self.save_after = None
            self.warning = None
            try:
                self.store = ResourceStore(coordinates_path)
            except ValueError as exc:
                self.store = ResourceStore()
                self.warning = str(exc)
            self.renderer = Renderer(self.store)
            self.overlay = PixelAlphaOverlay()
            self.worker = VisualWorker(find_emulator, folder, fps=30)
            saved_layers = settings.get('layers', {})
            if not isinstance(saved_layers, dict):
                saved_layers = {}
            self.layers = {t: tk.BooleanVar(value=bool(saved_layers.get(t, t == 'gems'))) for t in TIERS}
            self.fill = tk.BooleanVar(value=bool(settings.get('fill', True)))
            self.size = tk.IntVar(value=self.setting_number('size', 5, 3, 9))
            self.opacity = tk.DoubleVar(value=self.setting_number('opacity', .85, .3, 1.))
            self.mode = tk.StringVar(value='Balanced (30 FPS)')
            self.state = tk.StringVar(value='Preparing atlas…')
            self.info = tk.StringVar(value='Bring BlueStacks to the foreground')
            self.count = tk.StringVar(value='Waiting for the Loong Haven map')
            self.metrics = tk.StringVar(value='Recognition runs in the background')
            self.build_ui()
            self.worker.start()
            self.root.after(16, self.tick)
            if self.warning:
                messagebox.showwarning('Personal coordinates ignored', self.warning, parent=self.root)

        def setting_number(self, name, default, low, high):
            try:
                value = float(settings.get(name, default))
                if not low <= value <= high:
                    return default
                return int(value) if name == 'size' else value
            except (ValueError, TypeError):
                return default

        def build_ui(self):
            style = ttk.Style(self.root)
            style.theme_use('clam')
            style.configure('.', background='#101620', foreground='#e4eaf5', font=('Segoe UI', 10))
            style.configure('TFrame', background='#101620')
            style.configure('TLabel', background='#101620')
            style.configure('Muted.TLabel', foreground='#95a5bc')
            style.configure('TButton', background='#253449', borderwidth=0, padding=(12, 8))
            style.map('TButton', background=[('active', '#344b69')])
            style.configure('TCheckbutton', background='#101620', padding=(0, 5))
            style.map('TCheckbutton', background=[('active', '#1b2636')])
            style.configure('TCombobox', fieldbackground='#253449', background='#253449', foreground='#e4eaf5')
            style.map('TCombobox', fieldbackground=[('readonly', '#253449')],
                      foreground=[('readonly', '#e4eaf5')], selectbackground=[('readonly', '#253449')])
            style.configure('Horizontal.TScale', troughcolor='#253449', background='#65a4de')
            for tier, rgb in COLORS.items():
                style.configure(f'{tier}.TLabel', foreground='#%02x%02x%02x' % rgb, font=('Segoe UI', 15, 'bold'))
            body = ttk.Frame(self.root, padding=22)
            body.pack(fill='both', expand=True)
            ttk.Label(body, text='LOONG LENS', font=('Segoe UI', 22, 'bold')).pack(anchor='w')
            ttk.Label(body, text='Loong Haven  /  default zoom', style='Muted.TLabel').pack(anchor='w', pady=(0, 16))
            ttk.Label(body, textvariable=self.state, font=('Segoe UI', 12, 'bold')).pack(anchor='w')
            ttk.Label(body, textvariable=self.info, style='Muted.TLabel', wraplength=380).pack(anchor='w', pady=(4, 12))
            ttk.Separator(body).pack(fill='x', pady=(0, 12))
            descriptions = [('gems', 'Gems', '86 possible locations'),
                            ('common', 'Beans / Crisp Beans', '3 reported areas · green borders'),
                            ('rare', 'Bamboo Shoots', '9 reported areas · blue borders'),
                            ('epic', 'Giant Crab / Crab King', '11 approximate locations')]
            for tier, label, detail in descriptions:
                row = ttk.Frame(body)
                row.pack(fill='x', pady=3)
                ttk.Label(row, text='●', style=f'{tier}.TLabel').pack(side='left', padx=(0, 9))
                text = ttk.Frame(row)
                text.pack(side='left', fill='x', expand=True)
                ttk.Checkbutton(text, text=label, variable=self.layers[tier], command=self.changed).pack(anchor='w')
                ttk.Label(text, text=detail, style='Muted.TLabel', font=('Segoe UI', 9)).pack(anchor='w')
            ttk.Label(body, textvariable=self.count, wraplength=380, style='Muted.TLabel').pack(anchor='w', pady=(10, 9))
            ttk.Separator(body).pack(fill='x', pady=(0, 10))
            row = ttk.Frame(body)
            row.pack(fill='x')
            ttk.Checkbutton(row, text='Shade ingredient areas', variable=self.fill, command=self.changed).pack(side='left')
            ttk.Button(row, text='Import CSV', command=self.import_csv).pack(side='right')
            row = ttk.Frame(body)
            row.pack(fill='x', pady=5)
            ttk.Label(row, text='Dot size').pack(side='left')
            ttk.Scale(row, from_=3, to=9, variable=self.size, command=lambda _: self.changed()).pack(side='left', fill='x', expand=True, padx=(12, 0))
            row = ttk.Frame(body)
            row.pack(fill='x', pady=5)
            ttk.Label(row, text='Opacity').pack(side='left')
            ttk.Scale(row, from_=.3, to=1., variable=self.opacity, command=lambda _: self.changed()).pack(side='left', fill='x', expand=True, padx=(14, 0))
            modes = ttk.Combobox(body, textvariable=self.mode, state='readonly',
                                values=['Battery saver (15 FPS)', 'Balanced (30 FPS)', 'Smooth (45 FPS)'])
            modes.pack(fill='x', pady=(8, 10))
            modes.bind('<<ComboboxSelected>>', self.change_mode)
            row = ttk.Frame(body)
            row.pack(fill='x')
            self.pause_button = ttk.Button(row, text='Pause', command=self.toggle_pause)
            self.pause_button.pack(side='left')
            ttk.Button(row, text='Re-align', command=self.worker.request_scan).pack(side='left', padx=8)
            ttk.Button(row, text='Exit', command=self.close).pack(side='right')
            ttk.Label(body, textvariable=self.metrics, style='Muted.TLabel', font=('Segoe UI', 9), wraplength=380).pack(anchor='w', pady=(12, 4))
            ttk.Label(body, text='Dots are candidate locations, not live spawns.\nBorders show reported gathering areas.',
                      style='Muted.TLabel', font=('Segoe UI', 9)).pack(anchor='w')

        def change_mode(self, _=None):
            self.worker.fps = {'Battery saver (15 FPS)': 15, 'Balanced (30 FPS)': 30, 'Smooth (45 FPS)': 45}[self.mode.get()]

        def changed(self):
            self.renderer.invalidate()
            self.settings_dirty = True
            if self.save_after:
                self.root.after_cancel(self.save_after)
            self.save_after = self.root.after(400, self.save_settings)
            if not any(v.get() for v in self.layers.values()):
                self.overlay.hide()

        def save_settings(self):
            self.save_after = None
            content = {'layers': {k: bool(v.get()) for k, v in self.layers.items()},
                       'size': self.size.get(), 'opacity': self.opacity.get(), 'fill': self.fill.get()}
            try:
                tmp = settings_path.with_suffix('.tmp')
                tmp.write_text(json.dumps(content, indent=2), encoding='utf-8')
                tmp.replace(settings_path)
                self.settings_dirty = False
            except OSError:
                logging.exception('Could not save preferences')

        def toggle_pause(self):
            self.paused = not self.paused
            self.worker.pause(self.paused)
            self.pause_button.configure(text='Resume' if self.paused else 'Pause')
            self.overlay.hide()
            self.last_rect = None

        def import_csv(self):
            # Overlay is hidden whenever the emulator loses focus.
            path = filedialog.askopenfilename(title='Import personal coordinates', filetypes=[('Coordinate CSV', '*.csv')])
            if not path:
                return
            try:
                rows = load_coordinates(path)
                total = sum(len(v) for v in rows.values())
                # Validate before replacing any saved user data; normalized CSV is data only.
                import csv
                temporary = coordinates_path.with_suffix('.tmp')
                with temporary.open('w', encoding='utf-8', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['tier', 'x', 'y', 'label'])
                    for tier, points in rows.items():
                        writer.writerows((tier, p['x'], p['y'], p['label']) for p in points)
                replacement = ResourceStore(temporary)
                temporary.replace(coordinates_path)
                self.store = replacement
                self.renderer = Renderer(self.store)
                self.last_rect = None
                messagebox.showinfo('Coordinates imported', f'{total} personal locations saved. This replaces your previous personal CSV; bundled locations remain.', parent=self.root)
            except (ValueError, OSError) as exc:
                messagebox.showerror('Import failed', str(exc), parent=self.root)

        def tick(self):
            if self.closed:
                return
            try:
                snapshot = self.worker.get()
                enabled = {t: v.get() for t, v in self.layers.items()}
                show = (not self.paused and any(enabled.values()) and snapshot['open']
                        and snapshot['match'] is not None and snapshot['rect'] is not None)
                if not show:
                    self.overlay.hide()
                    self.last_rect = None
                else:
                    rect = snapshot['rect']
                    start = time.perf_counter()
                    image, counts, changed = self.renderer.render(rect[2:], snapshot['match'], enabled,
                                             self.size.get(), self.opacity.get(), self.fill.get())
                    self.render_ms = (time.perf_counter() - start) * 1000
                    if changed or self.last_rect != rect:
                        start = time.perf_counter()
                        if sum(counts.values()):
                            self.overlay.show_image(rect, image)
                        else:
                            self.overlay.hide()
                        self.upload_ms = (time.perf_counter() - start) * 1000
                        self.last_rect = rect
                        if self.overlay.hwnd and not self.overlay.excluded_from_capture:
                            # Avoid tracking our own pixels on unsupported capture configurations.
                            self.overlay.hide()
                            self.paused = True
                            self.worker.pause(True)
                            self.pause_button.configure(text='Resume')
                            messagebox.showerror('Capture exclusion unavailable',
                                'Windows could not exclude the overlay from screenshots. Markers have been paused to avoid self-tracking. Windows 10 version 2004 or newer is required.', parent=self.root)
                        self.count.set('   ·   '.join(f'{t.title()}: {counts[t]}' for t in TIERS if enabled[t]))
                now = time.perf_counter()
                if now - self.last_status > .25:
                    self.last_status = now
                    self.state.set(snapshot['state'])
                    self.info.set(snapshot['info'])
                    self.metrics.set(f"{snapshot['fps']:.0f} capture FPS · alignment {snapshot['scan_ms']:.0f} ms\nDraw {self.render_ms:.1f} ms · upload {self.upload_ms:.1f} ms")
                    if not show:
                        self.count.set('Paused' if self.paused else 'Choose a resource layer' if not any(enabled.values())
                                       else 'Waiting for a visible, aligned map')
            except Exception as exc:
                self.overlay.hide()
                self.last_rect = None
                self.state.set('Overlay hidden — display error')
                self.info.set(str(exc)[:150])
                logging.exception('Display failed')
            self.root.after(16, self.tick)

        def close(self):
            self.closed = True
            self.save_settings()
            self.overlay.hide()
            self.worker.close()
            self.overlay.close()
            self.root.destroy()

    App().root.mainloop()

if __name__ == '__main__':
    main()
