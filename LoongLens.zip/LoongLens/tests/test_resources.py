from pathlib import Path
import numpy as np
import pytest
from resources import load_coordinates, ResourceStore, Renderer, TIERS
from pose import Match

def test_import_deduplicates_and_keeps_labels(tmp_path):
    csv = tmp_path / 'points.csv'
    csv.write_text('tier,x,y,label\nrare,12,24,Bamboo\nrare,12,24,Duplicate\ngems,279,0,Edge\n', encoding='utf-8')
    rows = load_coordinates(csv)
    assert len(rows['rare']) == 1
    assert rows['rare'][0]['label'] == 'Bamboo'
    assert rows['gems'][0]['x'] == 279

@pytest.mark.parametrize('row', ['rare,nan,20', 'rare,1,inf', 'epic,280,1',
                                  'rare,-1,0', 'legendary,1,2', 'rare,no,2'])
def test_bad_import_fails_without_silent_partial_data(tmp_path, row):
    csv = tmp_path / 'points.csv'
    csv.write_text('tier,x,y\ncommon,1,2\n' + row + '\n', encoding='utf-8')
    with pytest.raises(ValueError, match='line 3'):
        load_coordinates(csv)

def test_csv_requires_columns(tmp_path):
    csv = tmp_path / 'points.csv'
    csv.write_text('x,y\n1,2\n')
    with pytest.raises(ValueError, match='columns'):
        load_coordinates(csv)

def test_marker_projected_to_expected_screen_location():
    store = ResourceStore()
    renderer = Renderer(store)
    x, y = store.points['gems'][0]
    pose = Match(12.45, 250 - 12.45*x, 460 + 12.45*y, 20, 0, [])
    image, counts, changed = renderer.render((570, 1029), pose, {'gems': True})
    assert changed and counts['gems'] > 0
    assert image.getpixel((250, 460))[3] > 150
    assert image.getpixel((250, 460))[0] > 200

def test_stationary_frame_reuses_image_but_settings_redraw():
    renderer = Renderer(ResourceStore())
    pose = Match(12.45, -1650, 2250, 10, 0, [])
    image, _, first = renderer.render((570, 1029), pose, {'gems': True})
    cached, _, second = renderer.render((570, 1029), pose, {'gems': True})
    assert first and not second and image is cached
    _, _, updated = renderer.render((570, 1029), pose, {'gems': True}, marker_size=7)
    assert updated and renderer.draws == 2

def test_disabling_all_layers_is_fully_transparent():
    image, counts, _ = Renderer(ResourceStore()).render((570, 1029), Match(12.45, -1650, 2250, 1, 0, []), {})
    assert not np.asarray(image)[:, :, 3].any()
    assert not sum(counts.values())

@pytest.mark.parametrize('size', [(570, 1029), (855, 1544), (380, 686)])
def test_chrome_and_fixed_controls_are_transparent(size):
    renderer = Renderer(ResourceStore())
    image, _, _ = renderer.render(size, Match(12.45, -1650, 2250, 10, 0, []), dict.fromkeys(TIERS, True))
    arr = np.asarray(image)
    rx, ry = size[0]/570, size[1]/1029
    assert not arr[:int(35*ry), :, 3].any()
    assert not arr[int(902*ry):, :, 3].any()
    assert not arr[int(36*ry):int(232*ry), int(422*rx):, 3].any()

def test_area_layers_render_borders_without_gem_dots():
    store = ResourceStore()
    renderer = Renderer(store)
    center = store.ingredients['rare']['areas'][0]['center']
    pose = Match(12.45, 270 - 12.45*center['x'], 460 + 12.45*center['y'], 10, 0, [])
    image, counts, _ = renderer.render((570, 1029), pose, {'rare': True}, fill=False)
    assert counts['rare'] > 0 and counts['gems'] == 0
    alpha = np.asarray(image)[:, :, 3]
    assert alpha.max() > 150
    assert image.getpixel((270, 460))[3] == 0
