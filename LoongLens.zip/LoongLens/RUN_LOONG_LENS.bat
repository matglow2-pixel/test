@echo off
setlocal
cd /d "%~dp0"
title Loong Lens - Sword x Staff
where py >nul 2>nul
if errorlevel 1 (
    set "PYEXE=python"
) else (
    set "PYEXE=py -3"
)
%PYEXE% -c "import sys; assert (3,10) <= sys.version_info[:2] <= (3,13), 'Use Python 3.10-3.13 (64-bit), with Tkinter'"
if errorlevel 1 goto error
if not exist ".venv\Scripts\python.exe" (
    %PYEXE% -m venv .venv
    if errorlevel 1 goto error
)
set "VENV_PY=.venv\Scripts\python.exe"
%VENV_PY% -c "import cv2,numpy,mss,PIL,tkinter; assert cv2.__version__=='4.12.0' and numpy.__version__=='2.2.6' and PIL.__version__=='11.3.0' and mss.__version__=='10.1.0'" >nul 2>nul
if errorlevel 1 (
    echo Preparing a private Python environment. This is needed only once...
    %VENV_PY% -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto error
)
%VENV_PY% -u loong_lens.py
if errorlevel 1 goto error
exit /b 0
:error
echo.
echo Loong Lens could not start. Read the error above.
echo Install 64-bit Python 3.10-3.13 from python.org, including Tcl/Tk.
pause
exit /b 1
