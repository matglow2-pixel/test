"""Build a self-contained Windows source zip without caches or user settings."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['README.md', 'VALIDATION.md', 'RUN_LOONG_LENS.bat', 'requirements.txt',
         'loong_lens.py', 'resources.py', 'vision.py', 'tracker.py', 'pose.py',
         'win_overlay.py', 'sxs_atlas_tracker.py', 'atlas_metadata.json',
         'loong_haven_default_atlas.png', 'loong_title_template.png',
         'loong_haven_map_data.json', 'loong_haven_ingredients.json',
         'ingredient_coordinates.csv', 'pytest.ini']

def main():
    output = ROOT.parent / 'LoongLens.zip'
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            source = ROOT / name
            if source.suffix == '.bat':
                archive.writestr('LoongLens/' + name, source.read_text().replace('\n', '\r\n'))
            else:
                archive.write(source, 'LoongLens/' + name)
        for directory in ['tests', 'tools']:
            for source in sorted((ROOT / directory).glob('*.py')):
                archive.write(source, 'LoongLens/' + str(source.relative_to(ROOT)))
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
    print(f'{output} ({output.stat().st_size:,} bytes)')

if __name__ == '__main__':
    main()
