"""Start Sniper inspection early only after observing a rendered stable scene."""
import cv2
import numpy as np


def ground_gray(frame):
    small=cv2.resize(frame,(285,514),interpolation=cv2.INTER_AREA)
    gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
    # The selected scene, not chat, portrait, minimap or emulator chrome.
    return gray[154:380,40:225]


def rendered(frame):
    gray=ground_gray(frame);average,deviation=cv2.meanStdDev(gray)
    return float(average[0,0])>25 and float(deviation[0,0])>=8


def scene_change(before,after,threshold=.30):
    if before.shape!=after.shape:return True
    a=ground_gray(before);b=ground_gray(after)
    difference=cv2.absdiff(a,b)
    if float(np.mean(difference>35))>threshold:return True
    _,sa=cv2.meanStdDev(a);_,sb=cv2.meanStdDev(b)
    if min(float(sa[0,0]),float(sb[0,0]))<8:return False
    correlation=float(cv2.matchTemplate(a,b,cv2.TM_CCOEFF_NORMED)[0,0])
    return correlation<(.85 if threshold<.1 else .55) and float(difference.mean())>3


def ready_frame(backend,initial,seconds,clock,check,is_map):
    """Two consistent rendered observations replace only the default 0.5s wait.

    Custom loading delays are preserved. Loading/blank/changing scenes keep
    the existing full delay; no input or inspection evidence comes from them.
    """
    started=clock()
    if abs(seconds-.5)>.000001 or not rendered(initial) or is_map(initial):
        backend.wait(seconds);return None
    backend.wait(.08);check();fresh=backend.capture();check()
    if not is_map(fresh) and rendered(fresh) and not scene_change(initial,fresh,threshold=.08):
        return fresh
    remaining=seconds-(clock()-started)
    if remaining>0:backend.wait(remaining)
    return None
