# v42 — Screenshot sweep and cursor recovery

Fast map sweep now captures a ready gameplay view, checks its owned screenshot in
a background worker and continues navigating. Empty views avoid the full 1.2s
inspection dwell. If the saved image contains a gem candidate, the main patrol
releases any map drag, returns to that exact saved camera view and confirms the
gem again on fresh frames before clicking. Old screenshot coordinates are never
clicked after navigation. The original screenshot, spotted time and camera
location stay attached to one history/counter entry after confirmation.

Only one screenshot can be in flight. The last screenshot is resolved before a
pass can finish. An uncertain/loading scene uses normal temporal inspection;
a candidate that disappears on return is not counted or clicked. The unfinished
next route location remains unchecked and is resumed. F10 discards pending work,
releases input and never restarts. Gem Spy retains its observation timing.

Fast map sweep is on by default in Sniper settings. Turning it off restores fixed
loading waits and full multi-frame inspection on every view. The v41 UI handoff
that ignored the saved speed preference is corrected. Custom loading delays are
honored. A quick sweep samples one ready screenshot per view; turn it off for the
longer observation window when gems render late. Positive candidates still need
the normal multi-frame/0.8s confirmation after return. Detector thresholds and
map/route assets are unchanged.

The reported mouse-position stop now has bounded recovery. Before mouse-down,
a transient mismatch gets up to two reposition retries at 15ms intervals; an
exact, eligible target is still required. A mismatch while held releases input
and retries the unfinished route location from fresh map recognition, at most
twice per progress checkpoint. Persistent errors, changed window geometry, lost
focus, obstruction and F10 still stop. Recovery after an already-recorded find
never re-records it. Normal pointer operations have no added wait.

The 20-second collection wait, Emerald Corner return, daily obtained choices,
Endless mode, histories, heatmaps, compact UI and MuMu mouse backend remain.
Keep MuMu visible, uncovered and focused. No ADB is used. Exit the old app,
extract the whole package and run LoongLens.exe; LocalAppData is retained.

Validation includes delayed detection while a map is open or a held pan is in
progress, last-view draining, cancellation, lost candidates, original evidence,
worker errors, pointer drift/retries/limits and real Windows delivered input.
Full-route comparisons with v37 and v41 use simulated input and already-rendered
scenes; they do not measure live MuMu speed or actual game loading behavior.
