import contextlib
from types import SimpleNamespace
import pytest

from patrol_windows import CursorPositionError,PatrolStopped
from patrol_live import LiveRunner,LiveSettings
from test_cursor_client_area import backend
from test_live_patrol import setup


def test_one_redirected_cursor_move_is_retried_before_exactly_one_click():
    value,state=backend();move=value.api.user.SetCursorPos;calls=[];original_clip=state['clip']
    def redirected(x,y):
        calls.append((x,y))
        if len(calls)==1:state['cursor']=(x+4,y);return True
        return move(x,y)
    value.api.user.SetCursorPos=redirected
    value.click((200,400))
    assert len(calls)==2 and [e for e in state['events'] if e[0]=='button']==[('button',2),('button',4)]
    assert state['clip']==original_clip and not value.down


def test_cursor_drift_between_move_and_down_is_rechecked_and_repositioned():
    value,state=backend();cursor=value.api.cursor;reads=[]
    def drift():
        actual=cursor();reads.append(actual)
        return (actual[0]+3,actual[1]) if len(reads)==2 else actual
    value.api.cursor=drift
    value.click((200,400))
    assert len([e for e in state['events'] if e[0]=='move'])==2
    assert [e for e in state['events'] if e[0]=='button']==[('button',2),('button',4)]


def test_persistent_redirect_has_bounded_attempts_and_no_wrong_click():
    value,state=backend();calls=[];original_clip=state['clip']
    value.api.user.SetCursorPos=lambda *point:calls.append(point) or True
    with pytest.raises(CursorPositionError):value.click((200,400))
    assert len(calls)==3 and not any(e[0]=='button' for e in state['events'])
    assert state['clip']==original_clip and not value.down


def test_f10_during_retry_prevents_any_down_and_restores_clip():
    value,state=backend();original_clip=state['clip']
    value.api.user.SetCursorPos=lambda *point:True
    value.wait=lambda seconds:value.cancel.set()
    with pytest.raises(PatrolStopped):value.click((200,400))
    assert not any(e[0]=='button' for e in state['events']) and state['clip']==original_clip


def test_held_cursor_mismatch_releases_without_moving_again_to_chase_it():
    value,state=backend();original_clip=state['clip']
    with pytest.raises(CursorPositionError):
        with value.hold_drag((285,530)):
            value.api.cursor=lambda:(111,150)
            value.drag_held_to((300,500))
    assert [e for e in state['events'] if e[0]=='button']==[('button',2),('button',4)]
    assert not value.down and state['clip']==original_clip


def configured_runner(always=False,positive=False):
    engine,backend,events=setup(positive=positive);attempts=[];click=backend.click
    backend.release=lambda:setattr(backend,'held',False)
    backend.guard=lambda:backend.wait(0)
    def unreliable(point):
        if always or not attempts or positive and not backend.open and point!=LiveSettings().map_open:
            attempts.append(point);raise CursorPositionError((300,500),(301,500))
        return click(point)
    backend.click=unreliable
    runner=LiveRunner(engine.views,lambda cancel:contextlib.nullcontext(backend),events.append,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title;backend.cancel=runner.cancel
    return runner,backend,events,attempts


def test_runner_retries_transient_pointer_failure_and_keeps_route_progress():
    runner,backend,events,attempts=configured_runner()
    assert runner.start(LiveSettings());runner.thread.join(10)
    assert not runner.running and runner.checked=={0,1}
    assert sum(e['kind']=='pointer_retry' for e in events)==1
    assert not any(e['kind']=='found' for e in events)


def test_runner_never_restarts_indefinitely_on_persistent_pointer_mismatch():
    runner,backend,events,attempts=configured_runner(always=True)
    runner.start(LiveSettings());runner.thread.join(10)
    assert not runner.running and not runner.checked and len(attempts)==3
    assert sum(e['kind']=='pointer_retry' for e in events)==2
    assert 'mouse did not reach' in events[-1]['message']


def test_f10_during_pointer_recovery_stays_stopped():
    runner,backend,events,attempts=configured_runner();emit=runner.emit
    def report(event):
        emit(event)
        if event['kind']=='pointer_retry':runner.stop()
    runner.emit=report;runner.start(LiveSettings());runner.thread.join(10)
    assert not runner.running and len(attempts)==1 and not runner.checked
    assert events[-1]['message']=='Stopped.'


def test_cursor_failure_after_found_does_not_create_duplicate_find_or_restart():
    runner,backend,events,attempts=configured_runner(positive=True)
    runner.start(LiveSettings());runner.thread.join(10)
    assert not runner.running and runner.stats.snapshot()['gems']==1
    assert sum(e['kind']=='found' for e in events)==1
    assert sum(e['kind']=='pointer_retry' for e in events)==1  # Only the pre-find failure.
    assert not any(e['kind']=='gem_clicked' for e in events)


def test_window_or_focus_change_during_cursor_retry_is_not_overridden():
    value,state=backend();lost=[False];original_clip=state['clip'];moves=[]
    value.api.user.SetCursorPos=lambda *point:moves.append(point) or True
    value.wait=lambda seconds:lost.__setitem__(0,True)
    def guard():
        if lost[0]:raise RuntimeError('MuMu lost focus; patrol stopped.')
    value.guard=guard
    with pytest.raises(RuntimeError,match='lost focus'):value.click((200,400))
    assert len(moves)==1 and not any(e[0]=='button' for e in state['events']) and state['clip']==original_clip
