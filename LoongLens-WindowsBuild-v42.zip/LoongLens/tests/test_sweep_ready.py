from types import SimpleNamespace
import threading
import cv2
import numpy as np
import pytest

from gem_scene_fixture import GemCameraScene
from sweep_ready import ready_frame,rendered,scene_change
from patrol_live import LiveSettings
from patrol_windows import PatrolStopped
from test_live_patrol import setup,Clock

cv2.setNumThreads(2)


def test_ready_gameplay_starts_after_two_observations_and_reuses_the_fresh_frame():
    scene=GemCameraScene();frame=scene.render();clock=Clock();captures=[]
    backend=SimpleNamespace(wait=lambda t:setattr(clock,'now',clock.now+t),
        capture=lambda:(captures.append(True) or frame.copy()))
    result=ready_frame(backend,frame,.5,clock,lambda:None,lambda f:False)
    assert result is not None and clock.now==pytest.approx(.08) and len(captures)==1


@pytest.mark.parametrize('seconds',[.2,.75,1.,2.])
def test_custom_loading_wait_is_preserved(seconds):
    clock=Clock();frame=GemCameraScene().render()
    backend=SimpleNamespace(wait=lambda t:setattr(clock,'now',clock.now+t),
        capture=lambda:pytest.fail('A custom wait must not take the fast path'))
    assert ready_frame(backend,frame,seconds,clock,lambda:None,lambda f:False) is None
    assert clock.now==pytest.approx(seconds)


def test_blank_or_loading_scene_keeps_the_default_wait():
    clock=Clock();backend=SimpleNamespace(wait=lambda t:setattr(clock,'now',clock.now+t))
    assert ready_frame(backend,np.zeros((1029,570,3),np.uint8),.5,clock,lambda:None,lambda f:False) is None
    assert clock.now==pytest.approx(.5)


def test_changing_scene_is_not_mistaken_for_ready():
    clock=Clock();scene=GemCameraScene();before=scene.render();scene.pan((300,500),(400,600));after=scene.render()
    backend=SimpleNamespace(wait=lambda t:setattr(clock,'now',clock.now+t),capture=lambda:after)
    assert scene_change(before,after)
    assert ready_frame(backend,before,.5,clock,lambda:None,lambda f:False) is None
    assert clock.now==pytest.approx(.5)


def test_late_scene_change_restarts_the_full_empty_inspection_window():
    engine,backend,_=setup();backend.open=False;engine.adaptive_inspection=True
    scene=GemCameraScene();initial=scene.render();scene.pan((300,500),(400,600));changed=scene.render()
    engine.detector=SimpleNamespace(detect=lambda *a,**kw:[])
    backend.capture=lambda:initial if backend.clock.now<.6 else changed
    assert engine.inspect(backend)==(None,None)
    assert 1.8<=backend.clock.now<2.05


def test_f10_during_ready_probe_produces_no_input():
    engine,backend,_=setup();frame=GemCameraScene().render()
    def wait(t):engine.cancel.set();backend.clock.now+=t
    backend.wait=wait
    with pytest.raises(PatrolStopped):ready_frame(backend,frame,.5,engine.clock,engine.check,lambda f:False)
    assert not backend.inputs


def test_fast_sweep_preference_saves_outside_legacy_settings_and_loads_on_restart(tmp_path):
    import json
    from patrol_live_panel import LivePatrolPanel
    from patrol_live import load_live_config
    panel=LivePatrolPanel.__new__(LivePatrolPanel)
    panel.path=tmp_path/'settings.json';panel.settings=LiveSettings(fast_sweep=False,map_close=(65,981))
    panel.key=SimpleNamespace(get=lambda:'F9');panel.endless=SimpleNamespace(get=lambda:True)
    panel.save_config();data=json.loads(panel.path.read_text())
    assert data['fast_map_sweep'] is False and 'fast_sweep' not in data['settings']
    assert data['settings']['map_close']==[65,981] and data['endless_mode'] is True
    loaded,key,_=load_live_config(data)
    assert loaded.fast_sweep is False and key=='F9' and loaded.map_close==[65,981]


def test_fast_sweep_option_saves_loading_time_without_shortening_gem_confirmation():
    from dataclasses import replace
    from test_gem_recenter import live_scene
    elapsed=[];confirmation=[]
    for fast in (False,True):
        engine,backend,events,scene=live_scene((285,515))
        engine.settings=replace(engine.settings,fast_sweep=fast)
        inspect=engine.inspect
        def measured_inspect(backend):
            started=engine.clock();result=inspect(backend)
            confirmation.append(engine.clock()-started)
            return result
        engine.inspect=measured_inspect
        assert 'Clicked the gem once' in engine.run(backend)
        elapsed.append(engine.clock())
        assert scene.collected and not scene.drags
    # The 0.2s confirmation cadence can require one extra observation because
    # of floating-point timestamp boundaries; it must never be shortened.
    assert all(seconds>=.8-1e-8 for seconds in confirmation)
    assert .2<=elapsed[0]-elapsed[1]<=.42+1e-8
