from types import SimpleNamespace
import threading

import cv2
import numpy as np
import pytest

from gem_detector import GemDetector,Detection
from gem_recenter import (SAFE_AREA,DRAG_AREA,GemRecenterError,safe_box,drag_plan,
                          scene_shift,recenter_gem)
from gem_scene_fixture import GemCameraScene
from patrol_live import LiveSettings
from patrol_windows import PatrolStopped
from test_live_patrol import Clock,setup

cv2.setNumThreads(2)


def harness(center=(520,680),gain=1.,freeze=False):
    scene=GemCameraScene(center,gain,freeze);clock=Clock();cancel=threading.Event();events=[]
    state=SimpleNamespace(down=False,captures=0)
    def check():
        if cancel.is_set():raise PatrolStopped('Stopped.')
    def wait(seconds):check();clock.now+=seconds
    def drag(start,end):
        state.down=True
        try:check();scene.pan(start,end);wait(.3)
        finally:state.down=False
    def capture():check();state.captures+=1;return scene.render()
    backend=SimpleNamespace(drag=drag,capture=capture,wait=wait)
    detector=GemDetector()
    def run():
        frame=scene.render();boxes=detector.detect(frame,exclude_hud=False)
        assert len(boxes)==1,boxes
        return recenter_gem(backend,detector,boxes[0],frame,check,clock,lambda f:False,
                            lambda kind,**data:events.append(dict(kind=kind,**data)))
    return scene,backend,detector,state,cancel,events,run


@pytest.mark.parametrize('center',[(520,680),(320,880),(35,520),(285,200),(285,980),(535,970)])
def test_hud_and_edge_gems_are_refound_in_clear_ground(center):
    scene,backend,detector,state,cancel,events,run=harness(center)
    box,frame=run()
    assert safe_box(box,frame.shape) and len(scene.drags)<=3
    assert np.linalg.norm(np.asarray(box.center)-scene.gem_center)<2
    assert not state.down and not scene.hud_clicks
    assert sum(e['kind']=='gem_recentered' for e in events)==1
    assert not any(e['kind'] in ('found','capture','gem_clicked') for e in events)
    for start,end in scene.drags:
        for x,y in (start,end):
            assert DRAG_AREA[0]*570-1e-6<=x<=DRAG_AREA[2]*570+1e-6
            assert DRAG_AREA[1]*1029-1e-6<=y<=DRAG_AREA[3]*1029+1e-6


@pytest.mark.parametrize('gain',[.5,1.5,2.,-1.])
def test_only_measured_camera_gain_and_direction_control_a_retry(gain):
    scene,_,_,_,_,_,run=harness(gain=gain)
    box,frame=run()
    assert safe_box(box,frame.shape) and len(scene.drags)<=3


def test_no_camera_motion_cannot_authorize_a_hud_or_old_pixel_click():
    scene,_,_,state,_,_,run=harness(freeze=True)
    with pytest.raises(GemRecenterError,match='not confirmed'):run()
    assert len(scene.drags)==1 and not scene.clicks and not state.down


def test_missing_gem_after_movement_has_no_old_coordinate_fallback():
    scene,_,_,state,_,_,run=harness();scene.hide_after_pan=True
    with pytest.raises(GemRecenterError):run()
    assert not scene.clicks and not state.down


def test_f10_after_a_drag_does_not_produce_a_gem_click():
    scene,backend,_,state,cancel,_,run=harness();original=backend.drag
    def stop(start,end):original(start,end);cancel.set()
    backend.drag=stop
    with pytest.raises(PatrolStopped):run()
    assert not state.down and not scene.clicks


def test_terrain_estimate_ignores_static_portrait_and_chat():
    scene=GemCameraScene();before=scene.render()
    scene.pan((400,600),(280,500));after=scene.render()
    assert scene_shift(before,after)==pytest.approx((-120,-100),abs=2)
    assert scene_shift(before,before)==pytest.approx((0,0),abs=1)
    assert scene_shift(np.zeros_like(before),np.zeros_like(before)) is None


@pytest.mark.parametrize('center',[(285,515),(200,400),(380,600)])
@pytest.mark.parametrize('scale',[1,2])
def test_clear_ground_stays_safe_at_each_capture_scale(center,scale):
    box=Detection((center[0]-12)*scale,(center[1]-12)*scale,24*scale,24*scale,.95)
    assert safe_box(box,(1029*scale,570*scale,3))


@pytest.mark.parametrize('center',[(50,500),(530,680),(300,900),(300,200)])
def test_unsafe_core_is_kept_as_a_find_but_requires_recentering(center):
    assert not safe_box(Detection(center[0]-12,center[1]-12,24,24,.95))


def live_scene(center=(520,680)):
    engine,backend,events=setup();scene=GemCameraScene(center)
    engine.settings=LiveSettings(approach_gem=True,mask_hud=False)
    engine.detector=GemDetector();original_capture=backend.capture;original_click=backend.click;original_drag=backend.drag
    def capture():return original_capture() if backend.open else scene.render()
    def drag(start,end):
        if backend.open:return original_drag(start,end)
        backend.wait(.3);scene.pan(start,end);backend.inputs.append(('ground_drag',start,end))
    def click(point):
        if not backend.open and point!=engine.settings.map_open:scene.click(point)
        return original_click(point)
    backend.capture=capture;backend.drag=drag;backend.click=click
    return engine,backend,events,scene


def test_live_collection_records_one_original_photo_and_one_find_after_recentering():
    engine,backend,events,scene=live_scene()
    assert 'Clicked the gem once' in engine.run(backend)
    assert len(scene.clicks)==1 and scene.collected and not scene.hud_clicks
    assert all(sum(e['kind']==kind for e in events)==1 for kind in ('found','capture','gem_clicked','gem_recentered'))
    original=next(e['frame'] for e in events if e['kind']=='capture')
    assert np.linalg.norm(np.asarray(engine.detector.detect(original,exclude_hud=False)[0].center)-np.array((520,680)))<2


def test_safe_live_collection_has_no_extra_drag_and_keeps_the_direct_click():
    engine,backend,events,scene=live_scene((285,515))
    assert 'Clicked the gem once' in engine.run(backend)
    assert not scene.drags and len(scene.clicks)==1 and scene.collected
    assert not any(e['kind']=='gem_recentered' for e in events)


def test_recenter_collection_keeps_one_daily_entry_and_twenty_second_return_wait(tmp_path):
    from test_sniper_collection_cycle import collecting_runner
    runner,backend,events,quota,times,_=collecting_runner(tmp_path,stop_at=lambda e:e['kind']=='returned_home')
    scene=GemCameraScene();capture=backend.capture;drag=backend.drag;click=backend.click
    backend.capture=lambda:capture() if backend.open else scene.render()
    def pan(start,end):
        if backend.open:return drag(start,end)
        backend.wait(.3);scene.pan(start,end);backend.inputs.append(('ground_drag',start,end))
    def target(point):
        if not backend.open and point!=LiveSettings().map_open:scene.click(point)
        return click(point)
    backend.drag=pan;backend.click=target;runner.detector=GemDetector()
    assert runner.start(LiveSettings(mask_hud=False),repeat=True)
    runner.thread.join(15)
    if runner.running:runner.stop();runner.thread.join(3)
    assert not runner.running and quota.count(runner.wall())==1 and runner.stats.snapshot()['gems']==1
    assert not scene.hud_clicks and all(sum(e['kind']==kind for e in events)==1 for kind in ('found','capture','gem_clicked','gem_recentered'))
    stamp=next(t for point,t,opened in times if not opened and point!=LiveSettings().map_open)
    opener=next(t for point,t,opened in times if point==LiveSettings().map_open and t>stamp)
    assert opener-stamp>=20
