"""Deterministic delayed workers prove ownership, map return and Stop ordering."""
from dataclasses import replace
from types import SimpleNamespace
import math
import threading
import time
import cv2
import numpy as np
import pytest

from camera_patrol import Spawn
from gem_detector import GemDetector
from gem_scene_fixture import GemCameraScene
from patrol_live import LiveSettings
from patrol_windows import PatrolStopped
from snapshot_sweep import SnapshotQueue,SnapshotCandidate,capture_snapshot
from test_live_patrol import setup

cv2.setNumThreads(2)


def textured_engine(center=(285,515),gem=True,spawns=None):
    engine,backend,events=setup(spawns=spawns)
    engine.settings=LiveSettings(quick_sweep=True)
    scene=GemCameraScene(center);scene.collected=not gem
    original_capture=backend.capture;original_click=backend.click;original_drag=backend.drag
    scene_view=(engine.views[0].x,engine.views[0].y)
    def capture():
        if backend.open:return original_capture()
        frame=scene.render()
        if backend.selected_world is None or math.dist(backend.selected_world,scene_view)>.1:
            saved=scene.collected;scene.collected=True;frame=scene.render();scene.collected=saved
        return frame
    def click(point):
        if not backend.open and point!=engine.settings.map_open:scene.click(point)
        return original_click(point)
    def drag(start,end):
        if backend.open:return original_drag(start,end)
        scene.pan(start,end);backend.wait(.3)
    backend.capture=capture;backend.click=click;backend.drag=drag
    backend.releases=0
    def release():backend.releases+=1;backend.held=False
    backend.release=release;engine.detector=GemDetector()
    return engine,backend,events,scene


def test_empty_views_have_one_worker_screenshot_each_and_no_long_inspection():
    engine,backend,events,scene=textured_engine(gem=False)
    inspect=engine.inspect
    engine.inspect=lambda *a,**kw:pytest.fail('A ready empty view must not use the 1.2s inspection')
    calls=[];detector=engine.detector
    def detect(frame,**kw):calls.append((threading.current_thread().name,frame.flags.writeable));return detector.detect(frame,**kw)
    engine.detector=SimpleNamespace(detect=detect)
    assert 'Pass complete' in engine.run(backend)
    assert engine.checked=={0,1} and len(calls)==2
    assert all(name=='LoongLens-screenshot' and not writeable for name,writeable in calls)
    assert not any(e['kind'] in ('found','capture','gem_clicked') for e in events)
    assert len([row for row in backend.inputs if row[0]=='click'])==5
    assert engine.snapshot_queue is None


def test_positive_screenshot_returns_to_original_view_and_keeps_its_photo_time_and_count():
    engine,backend,events,scene=textured_engine()
    original=engine.detector;ready=threading.Event();map_open=threading.Event()
    capture=backend.capture
    def screen():
        if backend.open and ready.is_set():map_open.set()
        return capture()
    backend.capture=screen
    def detect(frame,**kw):
        if threading.current_thread().name=='LoongLens-screenshot':
            ready.set();assert map_open.wait(3),'Navigation did not overlap screenshot analysis'
        return original.detect(frame,**kw)
    engine.detector=SimpleNamespace(detect=detect)
    assert 'Clicked the gem once' in engine.run(backend)
    assert scene.collected and len(scene.clicks)==1 and not scene.hud_clicks
    assert backend.releases==1
    assert all(sum(e['kind']==kind for e in events)==1 for kind in ('snapshot_return','found','capture','gem_clicked'))
    returned=next(e for e in events if e['kind']=='snapshot_return')
    found=next(e for e in events if e['kind']=='found')
    photo=next(e for e in events if e['kind']=='capture')
    assert found['view']==engine.views[0] and found['seen_at']==returned['spotted_at']==photo['captured_at']
    assert original.detect(photo['frame'],exclude_hud=False)
    assert not backend.open


def test_late_positive_during_held_map_pan_releases_before_returning():
    spawns=(Spawn(100.5,100.5,'Original'),Spawn(155.5,140.5,'Far next view'))
    engine,backend,events,scene=textured_engine(spawns=spawns)
    engine.views=tuple(replace(view,route_number=i+1) for i,view in enumerate(engine.views));engine.fixed_route=True
    started=threading.Event();moved=threading.Event();original=engine.detector
    drag=backend.drag_held_to
    def moving(end):
        drag(end);moved.set()
        # Give the real worker its deterministic completion point during hold.
        assert finished.wait(3)
    finished=threading.Event();backend.drag_held_to=moving
    def detect(frame,**kw):
        if threading.current_thread().name=='LoongLens-screenshot':
            started.set();assert moved.wait(3)
            result=original.detect(frame,**kw);finished.set();return result
        return original.detect(frame,**kw)
    engine.detector=SimpleNamespace(detect=detect)
    emit=engine.emit
    def report(event):
        if event['kind']=='snapshot_return':assert not getattr(backend,'held',False)
        emit(event)
    engine.emit=report
    assert 'Clicked the gem once' in engine.run(backend)
    assert moved.is_set() and scene.collected and len(scene.clicks)==1
    assert 1 not in engine.checked and not getattr(backend,'held',False)


def test_disappearing_candidate_does_not_click_stale_pixels_or_count_a_find():
    engine,backend,events,scene=textured_engine();emit=engine.emit
    def report(event):
        if event['kind']=='snapshot_return':scene.collected=True
        emit(event)
    engine.emit=report
    assert 'Pass complete' in engine.run(backend)
    assert engine.checked=={0,1} and not scene.clicks
    assert not any(e['kind'] in ('found','capture','gem_clicked') for e in events)


def test_snapshot_candidate_near_portrait_is_confirmed_then_centered_before_one_click():
    engine,backend,events,scene=textured_engine((520,680))
    assert 'Clicked the gem once' in engine.run(backend)
    assert scene.collected and len(scene.clicks)==1 and not scene.hud_clicks
    assert sum(e['kind']=='gem_recentered' for e in events)==1


def test_last_view_candidate_is_drained_before_pass_can_complete():
    engine,backend,events,scene=textured_engine();engine.views=engine.views[:1]
    assert 'Clicked the gem once' in engine.run(backend)
    assert scene.collected and sum(e['kind']=='snapshot_return' for e in events)==1


def test_stop_while_worker_is_late_leaves_its_view_unchecked_and_has_no_late_events():
    engine,backend,events,scene=textured_engine();started=threading.Event();finish=threading.Event();detector=engine.detector
    def detect(frame,**kw):
        started.set();finish.wait(3);return detector.detect(frame,**kw)
    engine.detector=SimpleNamespace(detect=detect)
    emit=engine.emit
    def report(event):
        emit(event)
        if event['kind']=='status' and event['message'].startswith('Checking screenshot'):
            assert started.wait(3);engine.cancel.set()
    engine.emit=report
    try:
        with pytest.raises(PatrolStopped):engine.run(backend)
        assert not engine.checked and not scene.clicks and engine.snapshot_queue is None
    finally:finish.set()
    time.sleep(.05)
    assert not any(e['kind'] in ('found','capture','gem_clicked','checked') for e in events)


def test_scan_error_propagates_without_marking_the_view_checked():
    engine,backend,events,scene=textured_engine()
    engine.detector=SimpleNamespace(detect=lambda *a,**kw:(_ for _ in ()).throw(RuntimeError('Failed image scan')))
    with pytest.raises(RuntimeError,match='Failed image scan'):engine.run(backend)
    assert not engine.checked and not scene.clicks


def test_blank_probe_uses_full_temporal_inspection_instead_of_recording_empty():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(quick_sweep=True)
    assert 'Clicked the gem once' in engine.run(backend)
    assert not any(e['kind']=='snapshot_return' for e in events)


@pytest.mark.parametrize('seconds',[.2,.5,.75,1.])
def test_snapshot_readiness_honors_custom_wait_and_rejects_map_frames(seconds):
    engine,backend,events,scene=textured_engine();backend.open=False
    backend.selected_world=(engine.views[0].x,engine.views[0].y)
    frame=backend.capture();started=engine.clock()
    assert capture_snapshot(backend,frame,seconds,engine.check,engine.is_map) is not None
    assert engine.clock()-started==pytest.approx((.25 if seconds==.5 else seconds)+.08)
    backend.open=True
    with pytest.raises(RuntimeError,match='map reopened'):capture_snapshot(backend,frame,seconds,engine.check,engine.is_map)


def test_queue_owns_the_image_and_never_mutates_progress_from_worker():
    cancel=threading.Event();gate=threading.Event();seen=[];complete=[];source=np.full((100,100,3),55,np.uint8)
    def detect(frame,**kw):gate.wait(2);seen.append(int(frame[0,0,0]));return []
    queue=SnapshotQueue(SimpleNamespace(detect=detect),False,cancel,lambda job,seconds:complete.append(job.index))
    queue.submit(3,object(),source,123.,.3);source[:]=200
    gate.set();queue.pending.future.result(timeout=3)
    assert not complete
    queue.poll();queue.close()
    assert seen==[55] and complete==[3]


def test_speed_switch_is_forwarded_to_runner_and_runtime_field_is_not_saved(tmp_path):
    import json
    from patrol_live_panel import LivePatrolPanel
    panel=LivePatrolPanel.__new__(LivePatrolPanel);panel.keys=object();panel.busy=panel.editing=panel.switching=False
    panel.endless=SimpleNamespace(get=lambda:False);panel.loop_mode=SimpleNamespace(get=lambda:True)
    panel.services=SimpleNamespace(sighting_history=SimpleNamespace(sniper_seen=lambda:0),acquire=lambda name:True,
        mode=SimpleNamespace(get=lambda:'Sensitive'),mask_hud=SimpleNamespace(get=lambda:False),last_sighting=-float('inf'),last_sound=-float('inf'))
    panel.on_active=lambda active:None;panel.buttons=lambda:None
    for enabled in (False,True):
        used=[];panel.busy=False;panel.settings=LiveSettings(fast_sweep=enabled)
        panel.runner=SimpleNamespace(cooldown={'last':-float('inf')},set_endless=lambda enabled:None,start=lambda settings,**kw:used.append(settings) or True)
        panel.start()
        assert used[0].fast_sweep is enabled and used[0].quick_sweep is enabled and used[0].threshold==.70
    panel.path=tmp_path/'config.json';panel.key=SimpleNamespace(get=lambda:'F9');panel.settings=LiveSettings(quick_sweep=True)
    panel.save_config();saved=json.loads(panel.path.read_text())
    assert 'quick_sweep' not in saved['settings'] and saved['fast_map_sweep'] is True


def test_all_screenshot_candidates_can_be_reconfirmed_and_source_box_matches_the_real_gem():
    from gem_detector import Detection
    engine,backend,events,scene=textured_engine();detector=engine.detector
    def detect(frame,**kw):
        boxes=detector.detect(frame,**kw)
        return [Detection(180,380,24,24,.99),*boxes] if threading.current_thread().name=='LoongLens-screenshot' else boxes
    engine.detector=SimpleNamespace(detect=detect)
    assert 'Clicked the gem once' in engine.run(backend)
    assert scene.collected and len(scene.clicks)==1
    found=next(e['seen_event'] for e in events if e['kind']=='found')
    assert abs(found['screen_x']-285)<2 and abs(found['screen_y']-515)<2


def test_f10_as_candidate_return_starts_never_sends_a_return_or_gem_click():
    engine,backend,events,scene=textured_engine();engine.views=engine.views[:1];emit=engine.emit;count=[]
    def report(event):
        emit(event)
        if event['kind']=='snapshot_return':count.append(len(backend.inputs));engine.cancel.set()
    engine.emit=report
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert len(backend.inputs)==count[0] and not engine.checked and not scene.clicks
    assert not any(e['kind']=='found' for e in events)
