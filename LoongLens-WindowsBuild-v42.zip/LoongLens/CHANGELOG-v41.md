# v41 — Safe gem collection and faster Gem Sniper sweep

Confirmed gems beside the floating portrait, under chat or near an edge now
trigger a gameplay camera drag in clear central ground. Loong Lens measures
terrain movement, re-detects the same gem and clicks its fresh position only
when the whole gem is clear of the interface. It can correct the camera response
and try up to three drags. If it cannot confirm movement or reacquire the target,
it pauses without tapping the HUD. F10 releases input and stays stopped.
Safe gems retain their existing direct click. Each encounter retains one original
photo and one history/counter entry. Gem Spy remains observation-only.

**Fast map sweep**, enabled by default in Sniper settings, starts inspection after
two rendered, stable gameplay observations instead of always waiting the default
0.5 seconds. Blank or changing scenes keep the loading wait. Custom loading waits
stay fixed. A late scene change restarts the full inspection window and clears
old detection evidence. The existing three-hit/0.8-second confirmation, inspection
duration, 20-second collection wait and Emerald Corner return remain unchanged.
Turn Fast map sweep off to restore fixed loading waits. Spy timing is unchanged.

This update keeps v40's compact UI, MuMuPlayer 6.8.9 Windows mouse input, routes,
map assets, detector, histories, daily Obtained choices and Endless mode. Keep
MuMu visible, uncovered and focused; no ADB is used. Settings/history stay in
LocalAppData. Exit the old app, extract the whole new folder and run LoongLens.exe.

Validation covers translated gameplay fixtures, portrait/chat/edge collection,
camera response and cancellation, native Windows capture/drag/click/hotkeys in a
procedural game window, source/frozen app checks and a full-route comparison.
The comparison uses already-rendered simulated gameplay; live MuMu performance
and actual game camera behavior cannot be measured in the build environment.
