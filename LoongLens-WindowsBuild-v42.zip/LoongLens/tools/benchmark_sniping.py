"""Profile the full fixed route using real atlas pixels and simulated desktop input.

The existing independent route test verifies every selected camera coordinate.
The model clock includes actual processing plus virtual waits, so recognition
time can satisfy observation intervals. This is not live BlueStacks speed.
Use --app-root to compare an extracted older release in a separate process.
"""
from dataclasses import replace
import argparse
from contextlib import contextmanager
import json
import math
from pathlib import Path
import sys
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app-root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=args.app_root.resolve()
    sys.path[:0]=[str(root),str(root/'tests')]
    import cv2
    cv2.setNumThreads(2)
    import vision
    from patrol_live import LivePatrol
    from patrol_route import load_fixed_route
    from resources import ResourceStore
    from test_fixed_route import test_complete_fixed_route_uses_recentered_atlas_screenshots_and_no_transit_camera_clicks
    result=dict(scope='Full 76-view atlas route with already-rendered textured gameplay; simulated input/loading/detector. Not live MuMu speed.',
                captures=0,relative_matches=0,absolute_matches=0,
                held_strokes=0,held_moves=0,pan_reference_pixels=0.,per_view=[])
    # Identical ready-gameplay pixels for both extracted versions. The base
    # route test uses black placeholders; those intentionally keep full waits.
    import numpy as np
    rng=np.random.default_rng(10);gray=rng.integers(20,160,(1029,570),np.uint8)
    ready_game=np.stack((gray//2+40,gray//2+75,gray//2+95),axis=2);ready_game[0,0]=0
    original_run=LivePatrol.run
    original_track=vision.track_map_pan
    def track(*a,**kw):
        result['relative_matches']+=1
        return original_track(*a,**kw)
    vision.track_map_pan=track
    def run(engine,backend,*a,**kw):
        if hasattr(engine.settings,'quick_sweep'):engine.settings=replace(engine.settings,quick_sweep=True)
        capture=backend.capture;locate=engine.locator.locate
        emit=engine.emit;open_map=engine.open_map;inspect=engine.inspect
        state={}
        counters=('captures','relative_matches','absolute_matches','held_strokes','held_moves')
        def open_view(*args,**kwargs):
            state.update(cpu=time.perf_counter(),clock=engine.clock(),inspect=None,
                         counters={key:result[key] for key in counters})
            return open_map(*args,**kwargs)
        def inspect_view(*args,**kwargs):
            state['inspect']=engine.clock()
            return inspect(*args,**kwargs)
        engine.open_map=open_view;engine.inspect=inspect_view
        def report(event):
            if event['kind']=='checked':
                now=time.perf_counter();view=engine.views[event['index']]
                inspection=state['inspect'] if state['inspect'] is not None else engine.clock()
                row=dict(point=view.route_label,zone=view.near_zone,
                         cpu_wall_seconds=round(now-state['cpu'],4),
                         simulated_map_seconds=round(inspection-state['clock'],4),
                         simulated_inspect_seconds=round(engine.clock()-inspection,4))
                for key in counters:
                    row[key]=result[key]-state['counters'][key]
                result['per_view'].append(row)
            emit(event)
        engine.emit=report
        drag=backend.drag
        def legacy_drag(start,end):
            result['pan_reference_pixels']+=math.dist(start,end)
            return drag(start,end)
        backend.drag=legacy_drag
        if hasattr(backend,'hold_drag'):
            hold=backend.hold_drag;move=backend.drag_held_to;cursor=[None]
            @contextmanager
            def held(start):
                with hold(start):
                    result['held_strokes']+=1;cursor[0]=start
                    try:yield
                    finally:cursor[0]=None
            def held_move(end):
                result['held_moves']+=1
                result['pan_reference_pixels']+=math.dist(cursor[0],end)
                value=move(end);cursor[0]=end
                return value
            backend.hold_drag=held;backend.drag_held_to=held_move
        def screenshot():
            result['captures']+=1;frame=capture()
            return ready_game.copy() if not backend.open else frame
        def absolute(frame):result['absolute_matches']+=1;return locate(frame)
        backend.capture=screenshot;engine.locator.locate=absolute
        started=time.perf_counter()
        initial_wait=backend.now
        engine.clock=lambda:backend.now-initial_wait+time.perf_counter()-started
        value=original_run(engine,backend,*a,**kw)
        processing=time.perf_counter()-started
        result.update(cpu_wall_seconds=round(time.perf_counter()-started,3),
                      scripted_wait_seconds=round(backend.now-initial_wait,3),
                      simulated_elapsed_seconds=round(backend.now-initial_wait+processing,3),
                      views_checked=len(engine.checked),
                      drags=sum(event[0]=='drag' for event in backend.inputs))
        result['pan_reference_pixels']=round(result['pan_reference_pixels'],1)
        return value
    LivePatrol.run=run
    route=load_fixed_route(ResourceStore().data)
    test_complete_fixed_route_uses_recentered_atlas_screenshots_and_no_transit_camera_clicks(route)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items() if key!='per_view'},indent=2))


if __name__=='__main__':main()
