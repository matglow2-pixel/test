"""Procedural gameplay fixture used by collection validation, never live input."""
from pathlib import Path
import cv2
import numpy as np
from resources import ROOT


class GemCameraScene:
    def __init__(self,center=(520,680),gain=1.,freeze=False):
        rng=np.random.default_rng(731)
        gray=rng.integers(0,145,(1500,850),np.uint8)
        gray=cv2.resize(gray,(1700,3000),interpolation=cv2.INTER_CUBIC)
        self.world=np.stack((gray//3+55,gray//3+90,gray//3+110),axis=2).astype(np.uint8)
        for _ in range(100):
            x=int(rng.integers(20,1680));y=int(rng.integers(20,2980))
            cv2.circle(self.world,(x,y),int(rng.integers(8,30)),(65,95,110),2)
        self.template=cv2.imread(str(ROOT/'gem_templates/gem_0.png'))
        self.center=np.asarray(center,dtype=float);self.offset=np.zeros(2)
        self.gain=gain;self.freeze=freeze;self.collected=False
        self.hide_after_pan=False;self.extra_after_pan=False
        self.drags=[];self.clicks=[];self.hud_clicks=[]

    @property
    def gem_center(self):return tuple(self.center+self.offset)

    def render(self):
        dx,dy=self.offset
        frame=cv2.warpAffine(self.world,np.float32([[1,0,dx-560],[0,1,dy-990]]),(570,1029))
        if not self.collected and not (self.hide_after_pan and np.linalg.norm(self.offset)>1):
            self.draw_gem(frame,self.gem_center)
            if self.extra_after_pan and np.linalg.norm(self.offset)>1:
                self.draw_gem(frame,(self.gem_center[0]+20,self.gem_center[1]))
        # Static HUD is deliberately unrelated to camera motion. The icon's
        # larger logical hit rectangle extends below the visible circle,
        # matching the reported gem-near-portrait case.
        cv2.rectangle(frame,(3,34),(240,170),(55,65,75),-1)
        cv2.circle(frame,(515,135),70,(80,130,80),-1)
        cv2.circle(frame,(520,625),28,(210,220,220),3)
        cv2.putText(frame,'HOME',(498,629),cv2.FONT_HERSHEY_SIMPLEX,.3,(230,230,230),1)
        panel=frame[820:1000,10:560]
        panel[:]=(panel.astype(np.float32)*.72).astype(np.uint8)
        cv2.putText(frame,'CHAT',(24,865),cv2.FONT_HERSHEY_SIMPLEX,.5,(210,215,215),1)
        frame[:34]=0;frame[:,:5]=0;frame[:,565:]=0
        return frame

    def draw_gem(self,frame,center):
        h,w=self.template.shape[:2];x=round(center[0]-w/2);y=round(center[1]-h/2)
        if 0<=x and 0<=y and x+w<=frame.shape[1] and y+h<=frame.shape[0]:
            frame[y:y+h,x:x+w]=self.template

    def pan(self,start,end):
        self.drags.append((start,end))
        if not self.freeze:self.offset+=(np.asarray(end)-np.asarray(start))*self.gain

    def click(self,point):
        self.clicks.append(point)
        x,y=point
        if x>470 and 540<y<800 or y>=800:
            self.hud_clicks.append(point);return 'HUD'
        if np.linalg.norm(np.asarray(point)-self.gem_center)<22:
            self.collected=True;return 'gem'
        return 'ground'
