"""One owned screenshot in flight; only the patrol thread can move or count."""
from concurrent.futures import Future,TimeoutError
from dataclasses import dataclass
import threading
import time

from patrol_windows import PatrolStopped
from sweep_ready import rendered,scene_change


@dataclass(frozen=True)
class Snapshot:
    index: int
    view: object
    frame: object
    spotted_at: float
    view_seconds: float
    future: object


class SnapshotCandidate(Exception):
    def __init__(self,snapshot,boxes):
        super().__init__('Returning to a gem candidate from a saved screenshot.')
        self.snapshot=snapshot;self.boxes=boxes


def capture_snapshot(backend,selected,seconds,check,is_map):
    """Keep custom loading waits, and require two rendered stable observations.

    This short screen-readiness check replaces the empty-view detection dwell.
    A failed probe returns to the normal temporal inspection on this view.
    """
    backend.wait(.25 if abs(seconds-.5)<1e-6 else seconds);check()
    first=backend.capture();check()
    if is_map(first):raise RuntimeError('The map reopened before the screenshot; this view remains unchecked.')
    backend.wait(.08);check();second=backend.capture();check()
    if is_map(second):raise RuntimeError('The map reopened before the screenshot; this view remains unchecked.')
    if rendered(first) and rendered(second) and not scene_change(first,second,threshold=.08):return second
    if abs(seconds-.5)<1e-6:backend.wait(.17)
    return None


class SnapshotQueue:
    def __init__(self,detector,mask_hud,cancel,complete):
        self.detector=detector;self.mask_hud=mask_hud;self.cancel=cancel
        self.complete=complete;self.pending=None;self.closed=False

    def submit(self,index,view,frame,spotted_at,view_seconds):
        if self.closed or self.pending is not None:raise RuntimeError('A previous screenshot is still being checked.')
        owned=frame.copy();owned.setflags(write=False);future=Future()
        snapshot=Snapshot(index,view,owned,spotted_at,view_seconds,future)
        self.pending=snapshot
        def scan():
            if not future.set_running_or_notify_cancel():return
            started=time.perf_counter()
            try:
                boxes=self.detector.detect(owned,exclude_hud=self.mask_hud)
                future.set_result((tuple(boxes),time.perf_counter()-started))
            except Exception as exc:future.set_exception(exc)
        # No capture, input, history, counters, Tk or callback touches this worker.
        # It owns one image and cannot keep the app alive after Stop/Exit.
        threading.Thread(target=scan,daemon=True,name='LoongLens-screenshot').start()
        return snapshot

    def poll(self,wait=False):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        snapshot=self.pending
        if snapshot is None:return
        while True:
            if self.cancel.is_set():raise PatrolStopped('Stopped.')
            try:boxes,seconds=snapshot.future.result(timeout=.02 if wait else 0.)
            except TimeoutError:
                if snapshot.future.done():
                    # A detector can itself raise TimeoutError. Do not confuse
                    # that completed failure with waiting for the worker.
                    boxes,seconds=snapshot.future.result()
                    break
                if wait:continue
                return
            break
        # Cancellation wins even when it arrives as the worker finishes.
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        self.pending=None
        if boxes:raise SnapshotCandidate(snapshot,boxes)
        self.complete(snapshot,seconds)

    def close(self):
        self.closed=True
        if self.pending is not None:self.pending.future.cancel()
        self.pending=None
