"""Actual Win32 drag/capture/click checks on a procedural gameplay window."""
import ctypes
from ctypes import wintypes
import queue
import threading
import time
import tkinter as tk

import cv2
import numpy as np
from PIL import Image,ImageTk

from camera_patrol import gem_click
from emulator_view import GameView,REFERENCE_GAME
from gem_detector import GemDetector
from gem_recenter import recenter_gem,safe_box
from gem_scene_fixture import GemCameraScene
from patrol_windows import WindowsBackend,GlobalPatrolKeys,PatrolStopped


def check_gem_recentering():
    import win_overlay  # DPI awareness before creating the native window.
    cv2.setNumThreads(2)
    root=tk.Tk();root.overrideredirect(True);root.geometry('560x1033+40+0')
    root.title('Loong Lens gameplay recenter validation');root.configure(bg='#202020')
    tk.Label(root,text='Procedural MuMu gameplay — input validation only',bg='#202020',fg='white').place(x=5,y=8)
    canvas=tk.Canvas(root,highlightthickness=0,borderwidth=0);canvas.place(x=1,y=40,width=558,height=992)
    state=dict(scene=GemCameraScene(),pressed=None,last=None,travel=0.,gem=0,hud=0,walk=0,drags=0,stop_on_move=False)
    results=queue.Queue();completed=[];cancel=threading.Event();thread=[None];native=[None]

    def draw():
        l,t,r,b=REFERENCE_GAME
        image=state['scene'].render()[t:b,l:r]
        picture=Image.fromarray(cv2.cvtColor(image,cv2.COLOR_BGR2RGB)).resize((558,992),Image.Resampling.BILINEAR)
        photo=ImageTk.PhotoImage(picture,master=root)
        if hasattr(canvas,'item'):canvas.itemconfigure(canvas.item,image=photo)
        else:canvas.item=canvas.create_image(0,0,image=photo,anchor='nw')
        canvas.photo=photo

    def reference(event):return native[0].view.reference((event.x_root,event.y_root))
    def down(event):
        if native[0] is None:return
        point=np.asarray(reference(event));state.update(pressed=point,last=point,travel=0.)
    def motion(event):
        if state['pressed'] is None:return
        point=np.asarray(reference(event));delta=point-state['last']
        state['travel']+=float(np.linalg.norm(delta));state['scene'].pan(state['last'],point)
        state['last']=point;draw()
        if state['stop_on_move']:
            state['stop_on_move']=False
            native[0].api.key(0x79);native[0].api.key(0x79,up=True)
    def up(event):
        if state['pressed'] is None:return
        point=reference(event)
        if state['travel']>=5:state['drags']+=1
        else:
            result=state['scene'].click(point)
            state[result if result in ('gem','HUD') else 'walk' if result=='ground' else 'hud']+=1
        state['pressed']=None;state['last']=None;draw()
    # Scene.click returns the literal HUD token; map it to the same counter.
    state['HUD']=0
    canvas.bind('<ButtonPress-1>',down);canvas.bind('<B1-Motion>',motion);canvas.bind('<ButtonRelease-1>',up)
    draw()

    def on_ui(action):
        finished=threading.Event();failure=[]
        def apply():
            try:action()
            except Exception as exc:failure.append(exc)
            finally:finished.set()
        root.after(0,apply)
        if not finished.wait(5):raise RuntimeError('Gameplay validation UI did not respond.')
        if failure:raise failure[0]

    def start():
        user=ctypes.WinDLL('user32');user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];user.GetAncestor.restype=wintypes.HWND
        user.GetWindowRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
        hwnd=int(user.GetAncestor(root.winfo_id(),2));r=wintypes.RECT();assert user.GetWindowRect(hwnd,ctypes.byref(r))
        outer=(r.left,r.top,r.right-r.left,r.bottom-r.top)
        view=GameView(outer,(canvas.winfo_rootx(),canvas.winfo_rooty(),canvas.winfo_width(),canvas.winfo_height()),int(canvas.winfo_id()))
        target=(hwnd,outer)
        def run():
            keys=None
            try:
                detector=GemDetector();events=[]
                def check():
                    if cancel.is_set():raise PatrolStopped('Stopped.')
                def emit(kind,**data):events.append(dict(kind=kind,**data))
                with WindowsBackend(cancel,find=lambda:target,geometry=lambda *a:view) as backend:
                    native[0]=backend;backend.focus();original_clip=backend.api.clip_rect()
                    for center in ((520,680),(320,880),(35,520),(285,220),(285,980)):
                        on_ui(lambda center=center:(state.update(scene=GemCameraScene(center)),draw()))
                        backend.wait(.1);frame=backend.capture();boxes=detector.detect(frame,exclude_hud=False)
                        assert len(boxes)==1,[(b.center,b.score) for b in boxes]
                        box,frame=recenter_gem(backend,detector,boxes[0],frame,check,time.perf_counter,lambda f:False,emit)
                        assert safe_box(box,frame.shape)
                        backend.click(gem_click(box.center,frame.shape));backend.wait(.12)
                        assert state['scene'].collected and not state['HUD'] and not state['walk'],state
                    assert state['gem']==5 and sum(e['kind']=='gem_recentered' for e in events)==5
                    assert backend.api.clip_rect()==original_clip and not backend.api.left_down()
                    # F10 while the actual native camera drag is in progress.
                    on_ui(lambda:(state.update(scene=GemCameraScene(),stop_on_move=True),draw()))
                    backend.wait(.1);keys=GlobalPatrolKeys(lambda:None,lambda:(cancel.set(),backend.release()))
                    frame=backend.capture();box=detector.detect(frame,exclude_hud=False)[0]
                    try:recenter_gem(backend,detector,box,frame,check,time.perf_counter,lambda f:False,emit)
                    except PatrolStopped:pass
                    else:raise AssertionError('F10 did not interrupt native gameplay dragging')
                    assert not backend.down and not backend.api.left_down() and backend.api.clip_rect()==original_clip
                    assert state['gem']==5 and not state['HUD'] and not state['walk']
                results.put(None)
            except Exception:
                import traceback
                results.put(traceback.format_exc())
            finally:
                if keys is not None:keys.close()
        thread[0]=threading.Thread(target=run,daemon=True);thread[0].start()
    def poll():
        try:error=results.get_nowait()
        except queue.Empty:root.after(100,poll);return
        completed.append(error);root.destroy()
    root.after(500,start);root.after(600,poll)
    root.after(90000,lambda:(cancel.set(),completed.append('Gameplay recenter check timed out'),root.destroy()))
    try:root.mainloop()
    finally:
        cancel.set()
        if thread[0] is not None:thread[0].join(3)
    assert completed and completed[0] is None,completed
    return dict(portrait_gem_centered=True,chat_gem_centered=True,edge_gems_centered=True,
        fresh_detection_before_click=True,gem_clicks=5,hud_clicks=0,ground_walks=0,
        native_drag_delivered=True,f10_released=True,
        scope='Actual Windows capture/drag/click/hotkeys with real gem detector on procedural gameplay. No live MuMu/game session.')
