"""Move a confirmed gameplay gem away from chat, portraits and screen edges."""
import math
import cv2
import numpy as np
from gem_detector import Detection


SAFE_AREA=(.16,.30,.78,.75)
DRAG_AREA=(.20,.33,.76,.70)


class GemRecenterError(RuntimeError):
    pass


def normal(frame):
    return cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)


def reference_box(box,shape):
    height,width=shape[:2];x,y=box.center
    bw=float(box.width);bh=float(getattr(box,'height',bw))
    if not all(math.isfinite(v) for v in (x,y,bw,bh)) or min(bw,bh)<=0:
        raise GemRecenterError('The confirmed gem has invalid image coordinates.')
    return Detection((x-bw/2)*570/width,(y-bh/2)*1029/height,
                     bw*570/width,bh*1029/height,float(box.score))


def safe_box(box,shape=(1029,570,3)):
    box=reference_box(box,shape);margin=6.
    left,top,right,bottom=(a*b for a,b in zip(SAFE_AREA,(570,1029,570,1029)))
    return (box.x-margin>=left and box.y-margin>=top and
            box.x+box.width+margin<=right and box.y+box.height+margin<=bottom)


def drag_plan(center,gain=1.):
    if not all(math.isfinite(v) for v in (*center,gain)) or abs(gain)<.2:
        raise GemRecenterError('The gameplay camera response could not be measured.')
    left,top,right,bottom=(a*b for a,b in zip(DRAG_AREA,(570,1029,570,1029)))
    delta=np.array((285.-center[0],514.5-center[1]))/gain
    # Keep overlapping terrain even when this game's camera gain is high.
    delta/=max(1.,abs(delta[0])/min(150.,right-left),abs(delta[1])/min(180.,bottom-top))
    if np.linalg.norm(delta)<4:
        raise GemRecenterError('The gem cannot be placed clear of the interface.')
    middle=np.array(((left+right)/2,(top+bottom)/2))
    return tuple(middle-delta/2),tuple(middle+delta/2)


def ground_mask():
    mask=np.zeros((1029,570),np.uint8)
    mask[round(.30*1029):round(.75*1029),round(.14*570):round(.80*570)]=255
    return mask


def stable_scene(before,after,limit=.035):
    if before.shape!=after.shape:return False
    a=normal(before);b=normal(after);mask=ground_mask()!=0
    difference=cv2.absdiff(a,b).max(axis=2)
    return float(np.mean(difference[mask]>25))<=limit


def scene_shift(before,after,exclude=None):
    """Independent ground features must agree; fixed HUD cannot prove a pan."""
    a=normal(before);b=normal(after)
    masks=[ground_mask(),ground_mask()]
    if exclude is not None:
        x,y,w,h=exclude.x,exclude.y,exclude.width,exclude.height
        masks[0][max(0,int(y-12)):min(1029,int(y+h+12)),max(0,int(x-12)):min(570,int(x+w+12))]=0
    sift=cv2.SIFT_create(nfeatures=1100,contrastThreshold=.025)
    features=[]
    for image,mask in zip((a,b),masks):
        gray=cv2.resize(cv2.cvtColor(image,cv2.COLOR_BGR2GRAY),None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
        small=cv2.resize(mask,(gray.shape[1],gray.shape[0]),interpolation=cv2.INTER_NEAREST)
        keys,descriptors=sift.detectAndCompute(gray,small)
        if descriptors is None or len(keys)<12:return None
        features.append((keys,descriptors))
    pairs=cv2.BFMatcher().knnMatch(features[0][1],features[1][1],k=2)
    good=[m for pair in pairs if len(pair)==2 for m,n in [pair] if m.distance<.67*n.distance]
    unique={m.trainIdx:m for m in sorted(good,key=lambda m:-m.distance)}
    good=list(unique.values())
    if len(good)<12:return None
    source=np.float32([features[0][0][m.queryIdx].pt for m in good])*2
    target=np.float32([features[1][0][m.trainIdx].pt for m in good])*2
    matrix,inliers=cv2.estimateAffinePartial2D(source,target,method=cv2.RANSAC,ransacReprojThreshold=2.5)
    if matrix is None or inliers is None:return None
    scale=math.hypot(matrix[0,0],matrix[1,0])
    if abs(scale-1)>.025 or abs(matrix[1,0])>.025:return None
    shifts=target-source;keep=inliers[:,0].astype(bool)
    if keep.sum()<12:return None
    delta=np.median(shifts[keep],axis=0)
    keep &= np.linalg.norm(shifts-delta,axis=1)<3
    if keep.sum()<12 or np.ptp(source[keep],axis=0).min()<40:return None
    delta=np.median(shifts[keep],axis=0)
    if np.linalg.norm(delta)>800:return None
    return float(delta[0]),float(delta[1])


def nearest_gem(boxes,shape,predicted,width):
    candidates=[]
    for box in boxes:
        candidate=reference_box(box,shape)
        distance=math.dist(candidate.center,predicted)
        if distance<=max(28,width*1.8):candidates.append((distance,box))
    candidates.sort(key=lambda item:item[0])
    if not candidates:return None
    if len(candidates)>1 and candidates[1][0]-candidates[0][0]<max(5,width*.3):return None
    return candidates[0][1]


def recenter_gem(backend,detector,found,frame,check,clock,is_map,emit):
    """At most three measured ground drags, then one fresh safe target.

    No found/history event is emitted here. The original confirmed encounter
    owns its photo and counter entry. After any movement, old pixels are never
    used as a click fallback.
    """
    box=reference_box(found,frame.shape);predicted=np.array(box.center);gain=1.
    for attempt in range(3):
        check();start,end=drag_plan(predicted,gain)
        emit('status',message=f'Moving the gem clear of chat and portrait ({attempt+1}/3)…')
        before=frame;old_predicted=predicted.copy();old_box=box
        backend.drag(start,end);check();backend.wait(.10)
        deadline=clock()+1.4;previous=None;previous_delta=None;candidate=None;measured=None
        while True:
            check();after=backend.capture()
            if is_map(after):raise GemRecenterError('The map opened during gem centering. Gem click cancelled.')
            delta=scene_shift(before,after,old_box)
            boxes=detector.detect(after,exclude_hud=False)
            emit('frame',frame=after,detections=boxes)
            if delta is not None and math.hypot(*delta)>=5:
                measured=np.asarray(delta);predicted=old_predicted+measured
                candidate=nearest_gem(boxes,after.shape,predicted,old_box.width)
                settled=(previous is not None and previous_delta is not None and
                         np.linalg.norm(measured-previous_delta)<=3 and stable_scene(previous,after))
                footprint=Detection(predicted[0]-old_box.width/2,predicted[1]-old_box.height/2,
                                    old_box.width,old_box.height,old_box.score)
                if settled and (candidate is not None or not safe_box(footprint)):
                    frame=after
                    if candidate is not None:box=reference_box(candidate,after.shape);predicted=np.array(box.center)
                    else:box=footprint
                    requested=np.asarray(end)-np.asarray(start)
                    response=float(np.dot(measured,requested)/np.dot(requested,requested))
                    if .2<=abs(response)<=3:gain=response
                    if candidate is not None and safe_box(candidate,after.shape):
                        emit('gem_recentered',drags=attempt+1,point=box.center)
                        return candidate,after
                    break
            if clock()>=deadline:
                raise GemRecenterError('Gem found, but camera movement and a fresh clear target were not confirmed. Stopped without clicking the interface.')
            previous=after;previous_delta=measured.copy() if measured is not None else None;backend.wait(.08)
    raise GemRecenterError('Gem found, but it is still near the interface after three camera drags. Stopped without clicking the interface.')
