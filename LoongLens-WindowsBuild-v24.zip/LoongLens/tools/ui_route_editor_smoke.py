"""Exercise the real editor canvas and persistence, without sending game input."""
import sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from PIL import ImageGrab
from resources import ResourceStore
from patrol_route import load_fixed_route,load_camera_adjustments,save_camera_adjustments
from route_editor import RouteEditor
from ui_theme import apply_theme


def main():
    root=tk.Tk();root.withdraw();apply_theme(root)
    route=load_fixed_route(ResourceStore().data)
    with tempfile.TemporaryDirectory(prefix='route-editor-',dir='/tmp') as directory:
        path=Path(directory)/'camera-route-adjustments.json';saved=[];closed=[]
        def save(views):save_camera_adjustments(route,views,path);saved.append(views)
        editor=RouteEditor(root,route,route,save,lambda:closed.append(True));root.update()
        index=next(i for i,v in enumerate(route) if v.route_label=='12')
        editor.select(index);editor.zoom_selected();root.update()
        x,y=editor.point(route[index].x,route[index].y)
        x-=editor.canvas.canvasx(0);y-=editor.canvas.canvasy(0)
        editor.canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y));root.update()
        editor.canvas.event_generate('<B1-Motion>',x=round(x),y=round(y+20));root.update()
        editor.canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y+20));root.update()
        adjusted=editor.views[index]
        assert adjusted.y<route[index].y-2 and adjusted.cells==route[index].cells
        assert editor.dragging is False
        assert 'outside' in editor.info.get()
        editor.add_view();root.update()
        assert len(editor.views)==77 and editor.views[index+1].route_label=='12+1'
        editor.nudge(.25,-.5);editor.add_view();root.update()
        assert [v.route_label for v in editor.views[index:index+4]]==['12','12+1','12+2','13']
        assert editor.remove_button.instate(['!disabled'])
        editor.remove_extra();assert len(editor.views)==77
        editor.select(index);assert editor.remove_button.instate(['disabled'])
        editor.select(index+1);editor.add_view();root.update()
        extras=tuple(editor.views[index+1:index+3])
        editor.window.geometry('1100x820+0+0');root.update()
        ImageGrab.grab().save('/tmp/loong-route-editor-v22.png')
        editor.save();root.update();assert saved and closed and path.exists()
        loaded=load_camera_adjustments(route,path);assert loaded[index]==adjusted
        assert loaded[index+1:index+3]==extras
        second=RouteEditor(root,route,loaded,save);root.update();second.select(index)
        second.reset_selected();assert second.views[index]==route[index]
        second.reset_all();second.save();root.update()
        assert load_camera_adjustments(route,path)==route
        third=RouteEditor(root,route,route,save);root.update()
        third.nudge(.25,0);third.dirty=False;third.close();root.update()
        assert load_camera_adjustments(route,path)==route
    root.destroy();print('Map editor: drag, extra insertion/removal, save/reload, reset and unsaved changes passed.')


if __name__=='__main__':main()
