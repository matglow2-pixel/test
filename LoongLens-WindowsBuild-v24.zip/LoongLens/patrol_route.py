"""The approved fixed camera order; removed numbers retain their old map IDs."""
import json
import math
import re
from dataclasses import replace
from pathlib import Path
from camera_patrol import Viewpoint, PatrolSettings, camera_click_clear


# User-marked map surface in the 570 x 1029 reference capture, with a small
# inset. The notch avoids the legend; the lower-right cutout avoids zoom.
MAP_CLICK_POLYGON=((10.,98.),(416.,98.),(416.,250.),(548.,250.),
                   (542.,610.),(502.,616.),(502.,918.),(10.,934.))


def map_clickable(point):
    x,y=point
    if not (math.isfinite(x) and math.isfinite(y)):return False
    inside=False
    for (ax,ay),(bx,by) in zip(MAP_CLICK_POLYGON,MAP_CLICK_POLYGON[1:]+MAP_CLICK_POLYGON[:1]):
        cross=(x-ax)*(by-ay)-(y-ay)*(bx-ax)
        if abs(cross)<1e-7 and min(ax,bx)<=x<=max(ax,bx) and min(ay,by)<=y<=max(ay,by):return True
        if (ay>y)!=(by>y) and x<(bx-ax)*(y-ay)/(by-ay)+ax:inside=not inside
    return inside


def clear_view_bounds(view,settings=None):
    """Spawn centres need context above the chat and below the upper HUD.

    World Y increases upwards. These bounds reserve four tiles at the bottom
    and 2.5 at the top of the full 12.1-tile camera rectangle, plus side padding.
    They cover the listed centres, not every possible ten-tile spawn offset.
    """
    left,bottom,right,top=view.bounds(settings or PatrolSettings())
    return left+.6,bottom+4.,right-.6,top-2.5


def load_fixed_route(data):
    route=json.loads((Path(__file__).resolve().parent/'gem_sniping_route.json').read_text('utf-8'))
    known={(int(s['position']['x']),int(s['position']['y'])) for s in data['gems']}
    excluded={tuple(c) for s in route['excluded'] for c in s['spawn_spots']}
    result=[];seen=set();numbers=[];settings=PatrolSettings()
    for s in route['stops']:
        cells=frozenset(tuple(c) for c in s['spawn_spots'])
        x,y=s['x'],s['y'];number=s['number']
        if not cells or not cells<=known or cells & (seen|excluded):
            raise ValueError('Fixed camera route has missing, duplicate or excluded spawns.')
        if not (math.isfinite(x) and math.isfinite(y) and 0<=x<280 and 0<=y<280 and camera_click_clear(x,y)):
            raise ValueError('Fixed camera route has an invalid camera target.')
        view=Viewpoint(x,y,s['zone'],cells,route_number=number,route_part=s.get('part',''))
        left,bottom,right,top=clear_view_bounds(view,settings)
        if not all(left-1e-6<=cx+.5<=right+1e-6 and bottom-1e-6<=cy+.5<=top+1e-6 for cx,cy in cells):
            raise ValueError('A spawn falls outside the clear gameplay area of its fixed view.')
        result.append(view);seen.update(cells);numbers.append(number)
    expected=[n for n in range(1,78) if n not in (26,51,72) for _ in range(2 if n in (40,64) else 1)]
    parts=[v.route_part for v in result]
    expected_parts=[part for n in range(1,78) if n not in (26,51,72) for part in (('a','b') if n in (40,64) else ('',))]
    if numbers!=expected or parts!=expected_parts or seen!=known-excluded:
        raise ValueError('The fixed camera path must preserve its approved order and exclusions.')
    return tuple(result)


def route_pan_delta(point,limit):
    """Pull an offscreen target toward the middle in one bounded held drag.

    Merely exposing its edge can leave too little terrain for registration and
    require several tiny drags. Endpoints stay in the clear central map area.
    """
    x,y=point
    tx,ty=285.,500.
    dx,dy=tx-x,ty-y
    factor=max(1.,math.hypot(dx,dy)/limit)
    return dx/factor,dy/factor


def apply_camera_adjustments(views,document):
    """Preserve original identities/order while inserting optional extra views."""
    if not isinstance(document,dict) or document.get('version') not in (1,2) or not isinstance(document.get('targets'),dict):
        raise ValueError('Camera adjustments have an unsupported format.')
    targets=document['targets'];known={v.route_label for v in views}
    if not targets.keys()<=known:raise ValueError('Camera adjustments refer to an unknown route point.')
    result=[]
    for view in views:
        if view.route_label not in targets:result.append(view);continue
        point=targets[view.route_label]
        validate_camera_position(point)
        result.append(replace(view,x=float(point[0]),y=float(point[1])))
    extras=document.get('extras',[]) if document['version']==2 else []
    if not isinstance(extras,list):raise ValueError('Extra camera views must be a list.')
    originals={v.route_label:v for v in views}
    for extra in extras:
        if not isinstance(extra,dict):raise ValueError('Invalid extra camera view.')
        parent,label,after=(extra.get(key) for key in ('parent','id','after'))
        if not isinstance(parent,str) or parent not in originals or not isinstance(label,str) or not re.fullmatch(re.escape(parent)+r'\+[1-9][0-9]*',label):
            raise ValueError('Extra camera views need a valid original parent and unique ID.')
        indexes={v.route_label:i for i,v in enumerate(result)}
        if label in indexes or not isinstance(after,str) or after not in indexes:
            raise ValueError('Extra camera views have a duplicate ID or missing preceding view.')
        anchor=result[indexes[after]]
        if (anchor.route_parent or anchor.route_label)!=parent:
            raise ValueError('Extra camera views must follow a view from the same original group.')
        point=[extra.get('x'),extra.get('y')];validate_camera_position(point)
        original=originals[parent]
        view=replace(original,x=float(point[0]),y=float(point[1]),route_part=original.route_part+label[len(parent):],route_parent=parent)
        result.insert(indexes[after]+1,view)
    return tuple(result)


def validate_camera_position(point):
    if not isinstance(point,list) or len(point)!=2 or any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not 0<=x<280 for x in point):
        raise ValueError('Camera positions must be finite coordinates from 0 to 279.99.')


def add_camera_view(views,index):
    """Insert a nearby independently movable view directly after selection."""
    selected=views[index];parent=selected.route_parent or selected.route_label
    original=next(v for v in views if not v.route_parent and v.route_label==parent)
    existing={v.route_label for v in views};number=1
    while f'{parent}+{number}' in existing:number+=1
    x,y=selected.x,selected.y
    # Begin one tile away so the added view is easy to select and nearby.
    for dx,dy in ((1,0),(-1,0),(0,-1),(0,1),(0,0)):
        if 0<=x+dx<280 and 0<=y+dy<280 and camera_click_clear(x+dx,y+dy):
            x,y=x+dx,y+dy;break
    extra=replace(original,x=x,y=y,route_part=original.route_part+f'+{number}',route_parent=parent)
    return tuple(views[:index+1])+(extra,)+tuple(views[index+1:])


def load_camera_adjustments(views,path):
    path=Path(path)
    if not path.exists():return tuple(views)
    return apply_camera_adjustments(views,json.loads(path.read_text('utf-8')))


def save_camera_adjustments(base,views,path):
    originals=[v for v in views if not v.route_parent]
    if [(v.route_label,v.cells,v.near_zone) for v in base]!=[(v.route_label,v.cells,v.near_zone) for v in originals]:
        raise ValueError('Editing camera positions must preserve route order and spawn locations.')
    extras=[]
    for i,v in enumerate(views):
        if v.route_parent:
            if i==0:raise ValueError('An extra view must follow its original group.')
            extras.append(dict(id=v.route_label,parent=v.route_parent,after=views[i-1].route_label,x=v.x,y=v.y))
    document={'version':2,'targets':{v.route_label:[v.x,v.y] for original,v in zip(base,originals) if (original.x,original.y)!=(v.x,v.y)},'extras':extras}
    if apply_camera_adjustments(base,document)!=tuple(views):
        raise ValueError('Extra camera views must retain their parent group and original spawn locations.')
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(document,indent=2)+'\n','utf-8');temporary.replace(path)


def camera_warnings(view):
    warnings=[]
    if not camera_click_clear(view.x,view.y):warnings.append('Camera target overlaps a known portal.')
    left,bottom,right,top=clear_view_bounds(view)
    outside=sum(not(left-1e-6<=x+.5<=right+1e-6 and bottom-1e-6<=y+.5<=top+1e-6) for x,y in view.cells)
    if outside:warnings.append(f'{outside} recorded spawn centre(s) are outside the suggested clear area.')
    return warnings
