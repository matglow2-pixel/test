"""Frozen Windows entry point; validation modes exit without opening error dialogs."""
import json
import os
from pathlib import Path
import runpy
import sys
import traceback

import loong_lens
from patrol_input_check import check_native_input


def gui_check():
    import tkinter as tk
    from tkinter import ttk
    checked = []
    failures = []
    original = tk.Tk
    import patrol_live_panel
    original_patrol_init = patrol_live_panel.LivePatrolPanel.__init__
    patrols = []
    def remember_patrol(panel, *args, **kwargs):
        original_patrol_init(panel, *args, **kwargs)
        patrols.append(panel)
    patrol_live_panel.LivePatrolPanel.__init__ = remember_patrol

    def descendants(widget):
        result = []
        for child in widget.winfo_children():
            result.append(child)
            result.extend(descendants(child))
        return result

    class CheckWindow(original):
        def iconbitmap(self, bitmap=None, default=None):
            if bitmap is not None:
                self.checked_icon_file = str(bitmap)
            elif default is not None:
                self.checked_icon_file = str(default)
            return super().iconbitmap(bitmap, default)

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            def failed(kind, value, trace):
                failures.append(''.join(traceback.format_exception(kind, value, trace)))
                self.destroy()
            self.report_callback_exception = failed
            self.after(2000, self.check)
            self.after(30000, self.destroy)

        def check(self):
            assert self.title() == 'Loong Lens'
            # On Windows wm iconbitmap's getter can return an empty string
            # after successfully loading an ICO. Verify the real setter/path
            # and the native window's icon handles instead.
            icon_file = Path(self.checked_icon_file)
            assert icon_file.name == 'LoongLens-Original-Optimized.ico' and icon_file.is_file()
            if os.name == 'nt':
                import ctypes
                from ctypes import wintypes
                user = ctypes.WinDLL('user32', use_last_error=True)
                user.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
                user.GetAncestor.restype = wintypes.HWND
                user.SendMessageW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
                user.SendMessageW.restype = ctypes.c_ssize_t
                wrapper = user.GetAncestor(self.winfo_id(), 2)
                icons = [user.SendMessageW(wrapper, 0x7F, kind, 0) for kind in (0, 1, 2)]
                if not any(icons):
                    user.GetClassLongPtrW.argtypes = (wintypes.HWND, ctypes.c_int)
                    user.GetClassLongPtrW.restype = ctypes.c_size_t
                    icons = [user.GetClassLongPtrW(wrapper, field) for field in (-14, -34)]
                assert any(icons), 'The native window has no configured icon'
            widgets = descendants(self)
            notebook = next(item for item in widgets if isinstance(item, ttk.Notebook))
            assert [notebook.tab(tab, 'text') for tab in notebook.tabs()] == ['Map overlay', 'Gem Watch', 'Gem Sniping']
            assert not any(isinstance(item,ttk.Checkbutton) and item.cget('text')=='Enable live clicking' for item in widgets)
            assert not any('patrol preview' in str(item.cget('text')).lower() for item in widgets if isinstance(item, (ttk.Label, ttk.Checkbutton)))
            buttons = {item.cget('text'): item for item in widgets if isinstance(item, ttk.Button)}
            assert any(isinstance(item, ttk.Checkbutton) and item.cget('text') == 'Sighting timers (30 min)' for item in widgets)
            assert sum(isinstance(item,ttk.Button) and item.cget('text')=='History' for item in widgets)==2
            buttons['History'].invoke()
            history = next(item for item in descendants(self)
                           if isinstance(item, tk.Toplevel) and item.title() == 'Gem sighting history')
            controls = descendants(history)
            assert any(isinstance(item, ttk.Button) and item.cget('text') == 'Edit location' for item in controls)
            assert any(isinstance(item, ttk.Radiobutton) and item.cget('text') == 'Today only' for item in controls)
            history.destroy()
            self.exit_button = buttons['Exit']
            assert len(patrols)==1 and patrols[0].keys is not None
            notebook.select(notebook.tabs()[2])
            panel=patrols[0]
            assert len(panel.base_views)==76 and len(panel.runner.views)>=76
            assert len(set().union(*(view.cells for view in panel.runner.views)))==83
            assert [v.route_number for v in panel.runner.views if not v.route_parent]==[n for n in range(1,78) if n not in (26,51,72) for _ in range(2 if n in (40,64) else 1)]
            assert not panel.snipe.instate(['disabled']) and not panel.repeat.instate(['disabled'])
            assert 'Check one' not in buttons and 'Start loop' not in buttons
            assert 'Snipe' in buttons and 'Loop Sniping' in buttons
            assert panel.stats_text.get()=='Time spent: 0:00\nGems found: 0'
            assert panel.progress.cget('maximum')==len(panel.runner.views)
            # Visit every page at the minimum supported size. Primary controls
            # must remain visible without resizing or scrolling.
            self.geometry('540x820')
            for tab in notebook.tabs():
                notebook.select(tab)
                self.update_idletasks()
                for item in descendants(self.nametowidget(tab)):
                    if isinstance(item, (ttk.Button,ttk.Label,ttk.Checkbutton,ttk.Combobox)) and item.winfo_ismapped():
                        assert item.winfo_height() >= item.winfo_reqheight(), item.cget('text')
                        assert item.winfo_rootx() >= self.winfo_rootx(), item.cget('text')
                        assert item.winfo_rootx()+item.winfo_width() <= self.winfo_rootx()+self.winfo_width(), item.cget('text')
                        assert item.winfo_rooty()+item.winfo_height() <= self.winfo_rooty()+self.winfo_height(), item.cget('text')
            assert 'Edit route' in buttons
            panel.show_route_editor()
            self.update_idletasks()
            assert panel.editor is not None and panel.editing
            editor=panel.editor
            assert len(editor.views)==len(panel.runner.views) and editor.canvas.find_all()
            index=next(i for i,v in enumerate(editor.views) if v.route_label=='12')
            editor.select(index);editor.nudge(0,-.25)
            assert editor.views[index].y==panel.runner.views[index].y-.25
            count=len(editor.views);editor.add_view()
            assert len(editor.views)==count+1 and editor.views[index+1].route_parent=='12'
            assert editor.remove_button.instate(['!disabled'])
            editor.remove_extra();assert len(editor.views)==count
            # Discard the diagnostic edit; never change real user settings.
            editor.dirty=False;editor.close()
            assert not panel.editing and panel.editor is None
            checked.append(True)
            self.exit_button.invoke()

    tk.Tk = CheckWindow
    try:
        loong_lens.main(argv=[], default_tab='watch')
    finally:
        tk.Tk = original
        patrol_live_panel.LivePatrolPanel.__init__ = original_patrol_init
    if not checked or failures:
        raise RuntimeError(f'Native GUI check failed: {failures}')


def main():
    if len(sys.argv) == 3 and sys.argv[1] in ('--self-check-report', '--gui-check-report','--input-check-report'):
        path = Path(sys.argv[2])
        try:
            if sys.argv[1] == '--self-check-report':
                loong_lens.self_check()
            elif sys.argv[1] == '--gui-check-report':
                gui_check()
            else:
                check_native_input()
            result = {'passed': True, 'mode': sys.argv[1]}
            status = 0
        except Exception:
            result = {'passed': False, 'mode': sys.argv[1], 'error': traceback.format_exc()}
            status = 1
        path.write_text(json.dumps(result, indent=2), encoding='utf-8')
        return status
    runpy.run_path(str(Path(__file__).resolve().parent / 'launch_app.pyw'), run_name='__main__')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
