"""Build a self-contained Windows source zip without caches or user settings."""
from pathlib import Path
import argparse
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['README.md', 'VALIDATION.md', 'GEM_WATCH.md', 'RUN_LOONG_LENS.bat', 'RUN_GEM_WATCH.bat', 'requirements.txt',
         'loong_lens.py', 'resources.py', 'vision.py', 'tracker.py', 'pose.py',
         'win_overlay.py', 'sxs_atlas_tracker.py', 'atlas_metadata.json',
         'loong_haven_default_atlas.png', 'loong_title_template.png',
         'loong_haven_map_data.json', 'loong_haven_ingredients.json',
         'ingredient_coordinates.csv', 'pytest.ini', 'gem_detector.py', 'gem_watch.py',
         'gem_watch_worker.py', 'tools/gem_examples.json', 'map_alignment.py',
         'terrain_alignment.py', 'loong_haven_terrain.json', 'pickup_history.py', 'history_panel.py',
         'gem_watch_panel.py', 'sighting_history.py', 'sighting_panel.py', 'launch_app.pyw']

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT.parent/'LoongLens.zip')
    output = parser.parse_args().output
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            source = ROOT / name
            if source.suffix == '.bat':
                archive.writestr('LoongLens/' + name, source.read_text().replace('\n', '\r\n'))
            else:
                archive.write(source, 'LoongLens/' + name)
        for directory in ['tests', 'tools']:
            for source in sorted((ROOT / directory).glob('*.py')):
                archive.write(source, 'LoongLens/' + str(source.relative_to(ROOT)))
        for source in sorted((ROOT/'gem_templates').iterdir()):
            if source.suffix in ('.png','.txt'):
                archive.write(source,'LoongLens/'+str(source.relative_to(ROOT)))
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
    print(f'{output} ({output.stat().st_size:,} bytes)')

if __name__ == '__main__':
    main()
