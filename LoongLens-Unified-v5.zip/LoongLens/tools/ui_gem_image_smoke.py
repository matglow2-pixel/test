"""Real detector/alert/UI picture-mode smoke check on Linux with mock Windows audio.

The live desktop backend is mocked; image loading, detection, confirmation,
panel updates and sound requests use the actual application implementations.
"""
import os
from pathlib import Path
import sys
import types
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from tkinter import ttk,filedialog
import cv2
import numpy as np
from PIL import Image
from mss.linux import MSS
from gem_detector import ROOT
import gem_watch
from smoke_backend import install
from sighting_history import SightingHistory

OUT=ROOT/'artifacts'
OUT.mkdir(exist_ok=True)
os.environ['XDG_CACHE_HOME']=str(OUT/'image-test-ui-settings')
history_path=OUT/'image-test-ui-settings/LoongLens/sightings.sqlite3'
if history_path.exists():history_path.unlink()
positive=Path(os.environ.get('GEM_WATCH_TEST_POSITIVE',OUT/'picture-mode-positive.png'))
negative=Path(os.environ.get('GEM_WATCH_TEST_NEGATIVE',OUT/'picture-mode-negative.png'))
if not os.environ.get('GEM_WATCH_TEST_POSITIVE'):
    frame=np.full((1029,570,3),(95,145,105),np.uint8)
    sprite=cv2.imread(str(ROOT/'gem_templates/gem_0.png'))
    frame[440:440+sprite.shape[0],280:280+sprite.shape[1]]=sprite
    cv2.imwrite(str(positive),frame)
if not os.environ.get('GEM_WATCH_TEST_NEGATIVE'):
    cv2.imwrite(str(negative),np.full((1029,570,3),(95,145,105),np.uint8))

class Capture:
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def grab(self,*args):return cv2.imread(str(positive))

sys.modules['mss']=types.SimpleNamespace(mss=Capture)
install(find_visible=lambda:(123,(0,0,570,1029)))
sounds=[]
sys.modules['winsound']=types.SimpleNamespace(Beep=lambda *args:sounds.append(args),MessageBeep=lambda *args:None,MB_ICONEXCLAMATION=48)
files=iter([str(positive),str(negative)])
filedialog.askopenfilename=lambda **kwargs:next(files)
original=tk.Tk.__init__
errors=[]
finished=[]

def descendants(root):
    result=[]
    for w in root.winfo_children():result.append(w);result.extend(descendants(w))
    return result

def start(self,*args,**kwargs):
    original(self,*args,**kwargs)
    def callback_error(*args):
        errors.append(args);traceback.print_exception(*args)
    self.report_callback_exception=callback_error
    def buttons():return {w.cget('text'):w for w in descendants(self) if isinstance(w,ttk.Button)}
    def label_values():
        return [str(self.getvar(w.cget('textvariable'))) for w in descendants(self)
                if isinstance(w,ttk.Label) and w.cget('textvariable')]
    def load_positive():
        buttons()['Test image'].invoke()
        assert 'Watch game' in buttons()
        self.after(2500,positive_check)
    def positive_check():
        labels=label_values()
        assert any('IMAGE TEST: GEM DETECTED' in text for text in labels),labels
        assert len(sounds)==3,sounds
        buttons()['History'].invoke()
        history=next(w for w in descendants(self) if isinstance(w,tk.Toplevel) and w.title()=='Gem sighting history')
        tree=next(w for w in descendants(history) if isinstance(w,ttk.Treeview))
        assert not tree.get_children(), 'Image tests must be excluded from live history initially'
        next(w for w in descendants(history) if isinstance(w,ttk.Checkbutton) and w.cget('text')=='Include image tests').invoke()
        assert len(tree.get_children())==1
        values=tree.item(tree.get_children()[0],'values')
        assert values[1]=='Image test' and len(values[0])==19
        history.destroy()
        self.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            cap=screen.grab(dict(left=self.winfo_rootx(),top=self.winfo_rooty(),width=self.winfo_width(),height=self.winfo_height()))
            Image.frombytes('RGB',cap.size,cap.rgb).save(OUT/'image-test-panel-preview.png')
        buttons()['Test image'].invoke()
        self.after(2200,negative_check)
    def negative_check():
        labels=label_values()
        assert any('IMAGE TEST · no gems detected' in text for text in labels),labels
        assert not any('IMAGE TEST: GEM DETECTED' in text for text in labels),labels
        assert len(sounds)==3,'Negative photo unexpectedly sounded an alert'
        buttons()['Watch game'].invoke()
        notebook=next(w for w in descendants(self) if isinstance(w,ttk.Notebook))
        notebook.select(notebook.tabs()[0])  # Live watching continues on the Map tab.
        self.after(2500,game_check)
    def game_check():
        labels=label_values()
        assert any('GEM DETECTED at ' in text and 'IMAGE TEST' not in text for text in labels),labels
        database=SightingHistory(history_path)
        assert len(database.list())==1 and len(database.list(include_tests=True))==2
        database.close()
        assert len(sounds)==6, sounds
        self.after(1600,finish)
    def finish():
        assert not errors,errors
        finished.append(True)
        buttons()['Exit'].invoke()
        restarted=SightingHistory(history_path)
        assert len(restarted.list())==1 and len(restarted.list(include_tests=True))==2
        restarted.close()
        print('Unified UI passed: photo detection/confirmation/sound, filtered dated history, negative photo quiet, live detection while Map tab selected, no repeated sightings, restart persistence and shared exit.')
    self.after(300,load_positive)
    self.after(18000,self.destroy)

tk.Tk.__init__=start
sys.platform='win32';sys.argv=['gem_watch.py']
gem_watch.main()
assert finished and not errors,(finished,errors)
