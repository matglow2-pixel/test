"""History window for confirmed sightings; test images are excluded by default."""
import sqlite3
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


class SightingControls:
    def __init__(self, root, history):
        self.root = root
        self.history = history
        self.window = None
        self.tree = None
        self.include_tests = tk.BooleanVar(root, value=False)
        self.summary = tk.StringVar(root)
        self.refresh()

    def refresh(self):
        counts = self.history.counts()
        self.summary.set(f'Live sightings: {counts.get(0, 0)} · Image tests: {counts.get(1, 0)}')
        if self.tree is None or not self.tree.winfo_exists():
            return
        rows = self.history.list(include_tests=self.include_tests.get(), limit=1000)
        existing = set(self.tree.get_children())
        wanted = {str(row.id) for row in rows}
        for removed in existing - wanted:
            self.tree.delete(removed)
        for index, row in enumerate(rows):
            values = (row.local_time, row.source, f'{row.score:.3f}')
            key = str(row.id)
            if key in existing:
                self.tree.item(key, values=values)
            else:
                self.tree.insert('', index, iid=key, values=values)
            self.tree.move(key, '', index)

    def show(self):
        if self.window is not None and self.window.winfo_exists():
            self.window.lift()
            return
        self.window = window = tk.Toplevel(self.root)
        window.title('Gem sighting history')
        window.transient(self.root)
        window.geometry('600x420')
        window.minsize(500, 300)
        body = ttk.Frame(window, padding=18)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='Gems spotted', font=('Segoe UI', 14, 'bold')).pack(anchor='w')
        ttk.Label(body, textvariable=self.summary, style='Muted.TLabel').pack(anchor='w', pady=(5, 8))
        ttk.Checkbutton(body, text='Include image tests', variable=self.include_tests,
                        command=self.refresh).pack(anchor='w')
        ttk.Label(body, text='One row per confirmed pile · newest 1,000 shown\nTimes use your PC clock. Sightings do not confirm collection.',
                  style='Muted.TLabel').pack(anchor='w', pady=(4, 10))
        table = ttk.Frame(body)
        table.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(table, columns=('time', 'source', 'score'), show='headings', selectmode='browse')
        for name, label, width in [('time', 'Spotted (local date/time)', 225), ('source', 'Source', 140),
                                   ('score', 'Match score', 105)]:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=width, minwidth=80)
        scrollbar = ttk.Scrollbar(table, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        row = ttk.Frame(body)
        row.pack(fill='x', pady=(12, 0))
        ttk.Button(row, text='Export history CSV', command=self.export).pack(side='left')
        ttk.Button(row, text='Remove selected', command=self.remove).pack(side='left', padx=8)
        ttk.Button(row, text='Close', command=window.destroy).pack(side='right')
        self.refresh()

    def remove(self):
        selected = self.tree.selection()
        if not selected:
            return
        try:
            self.history.remove(int(selected[0]))
            self.refresh()
        except sqlite3.Error as exc:
            messagebox.showerror('Could not remove sighting', str(exc), parent=self.window)

    def export(self):
        path = filedialog.asksaveasfilename(parent=self.window, title='Export sighting history',
                                          initialfile='LoongLens-sightings.csv', defaultextension='.csv',
                                          filetypes=[('CSV', '*.csv')])
        if not path:
            return
        try:
            self.history.export_csv(path, include_tests=self.include_tests.get())
        except (OSError, sqlite3.Error) as exc:
            messagebox.showerror('Could not export sightings', str(exc), parent=self.window)
            return
        messagebox.showinfo('Sightings exported', f'Saved sighting history to:\n{path}', parent=self.window)
