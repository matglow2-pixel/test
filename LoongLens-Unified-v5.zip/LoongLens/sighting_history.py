"""Local history of confirmed visual sightings, separate from manual pickups."""
from dataclasses import dataclass
from datetime import datetime, timezone
import csv
from pathlib import Path
import sqlite3


@dataclass(frozen=True)
class Sighting:
    id: int
    event_id: str
    seen_at: float
    screen_x: float
    screen_y: float
    score: float
    test_mode: bool

    @property
    def local_time(self):
        return datetime.fromtimestamp(self.seen_at).astimezone().strftime('%Y-%m-%d %H:%M:%S')

    @property
    def source(self):
        return 'Image test' if self.test_mode else 'Live game'


class SightingHistory:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.execute('''CREATE TABLE IF NOT EXISTS sightings (
            id INTEGER PRIMARY KEY, event_id TEXT NOT NULL UNIQUE,
            seen_at REAL NOT NULL, screen_x REAL NOT NULL, screen_y REAL NOT NULL,
            score REAL NOT NULL, test_mode INTEGER NOT NULL)''')
        self.connection.execute('CREATE INDEX IF NOT EXISTS sighting_time ON sightings(seen_at DESC,id DESC)')
        self.connection.commit()

    def record(self, events):
        # A retried write cannot duplicate an already accepted event.
        with self.connection:
            self.connection.executemany('''INSERT OR IGNORE INTO sightings
                (event_id,seen_at,screen_x,screen_y,score,test_mode) VALUES(?,?,?,?,?,?)''',
                [(e['event_id'], e['seen_at'], e['screen_x'], e['screen_y'], e['score'], bool(e['test_mode']))
                 for e in events])

    def list(self, include_tests=False, limit=None):
        query = 'SELECT id,event_id,seen_at,screen_x,screen_y,score,test_mode FROM sightings'
        if not include_tests:
            query += ' WHERE test_mode=0'
        query += ' ORDER BY seen_at DESC,id DESC'
        if limit is not None:
            query += ' LIMIT ?'
        return [Sighting(*row) for row in self.connection.execute(query, () if limit is None else (limit,))]

    def counts(self):
        return dict(self.connection.execute('SELECT test_mode,COUNT(*) FROM sightings GROUP BY test_mode'))

    def remove(self, sighting_id):
        with self.connection:
            self.connection.execute('DELETE FROM sightings WHERE id=?', (sighting_id,))

    def export_csv(self, path, include_tests=False):
        with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['id', 'seen_at_local', 'seen_at_utc', 'source', 'match_score', 'screen_x', 'screen_y'])
            for row in self.list(include_tests=include_tests):
                writer.writerow([row.id, datetime.fromtimestamp(row.seen_at).astimezone().isoformat(),
                                 datetime.fromtimestamp(row.seen_at, timezone.utc).isoformat(), row.source,
                                 row.score, row.screen_x, row.screen_y])

    def close(self):
        self.connection.close()
