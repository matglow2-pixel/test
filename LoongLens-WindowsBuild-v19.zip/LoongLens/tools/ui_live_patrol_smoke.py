"""Real combined UI + detector/history, with map mouse delivery simulated."""
from pathlib import Path
import contextlib
import os
import sys
import tempfile
import types
import time
import cv2
import json

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import tkinter as tk
from tkinter import ttk
from smoke_backend import install
install()
sys.modules['winsound']=types.SimpleNamespace(Beep=lambda *a:None,MessageBeep=lambda *a:None,MB_ICONEXCLAMATION=48)
sys.modules['mss']=types.SimpleNamespace(mss=lambda:contextlib.nullcontext(None))
approach_mode='--approach' in sys.argv
repeat_mode='--repeat' in sys.argv
visits_to_gem=4 if repeat_mode else 3
folder=Path(tempfile.mkdtemp(prefix='live-patrol-ui-',dir=ROOT/'artifacts'));os.environ['XDG_CACHE_HOME']=str(folder)
(folder/'LoongLens').mkdir()
(folder/'LoongLens/patrol-live-settings.json').write_text(json.dumps({'settings':{'map_open':[515,830],
    'map_close':[64,980],'settle_seconds':.8,'inspect_seconds':1.5,'approach_gem':approach_mode},'key':'F9'}))
import loong_lens
import tracker
from pose import Match
live_backends=[];overlay_draws=[]
original_worker=tracker.VisualWorker
class OverlayWorker(original_worker):
    def get(self):
        if not live_backends:return super().get()
        backend=live_backends[-1]
        return dict(open=backend.open and not self.paused,match=Match(12.45,-backend.x,279*12.45-backend.y,20,0,[]),
            rect=(0,0,570,1029),state='Following map',info='UI simulation',fps=45.,scan_ms=0.)
tracker.VisualWorker=OverlayWorker
from smoke_backend import Overlay
class VisibleOverlay(Overlay):
    def show_image(self,*args):
        if panels and panels[0].busy:overlay_draws.append(True)
sys.modules['win_overlay'].PixelAlphaOverlay=VisibleOverlay
import patrol_live_panel
from camera_patrol import build_plan,Spawn
from patrol_windows import PatrolStopped
from gem_detector import load_image

class Keys:
    def __init__(self,advance,stop,key='F8'):self.advance=advance;self.stop=stop
    def close(self):pass


class Backend:
    inputs=[]
    def __init__(self,cancel):
        live_backends.append(self)
        self.cancel=cancel;self.open=True;self.target=(123,(0,0,570,1029));self.visits=0
        self.atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
        self.title=cv2.imread(str(ROOT/'loong_title_template.png'));self.x=900;self.y=1300
        self.photo=load_image(ROOT.parent/'gem-examples/GemsPictures/IMG_1401.png')
        self.empty=load_image(ROOT.parent/'gem-examples/GemsPictures/MyLocationNoGems.png')
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def wait(self,t):
        if self.cancel.wait(t):raise PatrolStopped('Stopped.')
    def focus(self):self.wait(0)
    def capture(self):
        self.wait(0)
        if not self.open:return (self.empty if self.visits<visits_to_gem else self.photo).copy()
        frame=self.atlas[self.y:self.y+1029,self.x:self.x+570].copy()
        h,w=self.title.shape[:2];frame[45:45+h,30:30+w]=self.title
        return frame
    def click(self,p):
        p=tuple(p)
        self.wait(0);self.inputs.append(('click',p))
        if p==(64.,980.):self.open=False;self.visits+=1
        elif not self.open:
            if p==(480.,170.):self.open=True
            else:
                assert approach_mode and self.visits==visits_to_gem
                assert 40<p[0]<520 and 280<p[1]<760
    def drag(self,a,b):
        self.wait(.1);self.inputs.append(('drag',a,b));self.x-=round(b[0]-a[0]);self.y-=round(b[1]-a[1])


patrol_live_panel.WindowsBackend=Backend;patrol_live_panel.GlobalPatrolKeys=Keys
panels=[];real_panel=patrol_live_panel.LivePatrolPanel.__init__
def remember(panel,*args,**kwargs):real_panel(panel,*args,**kwargs);panels.append(panel)
patrol_live_panel.LivePatrolPanel.__init__=remember
real_root=tk.Tk.__init__;errors=[];done=[]
def root_init(root,*args,**kwargs):
    real_root(root,*args,**kwargs)
    def failed(kind,value,trace):
        import traceback
        errors.append(''.join(traceback.format_exception(kind,value,trace)));root.destroy()
    root.report_callback_exception=failed
    def begin():
        panel=panels[0]
        assert panel.keys is not None
        assert tuple(panel.settings.map_open)==(480.,170.) and panel.key.get()=='F9'
        assert len(panel.runner.views)<86
        assert len(set().union(*(v.cells for v in panel.runner.views)))==86
        # Keep this reopening regression within a known atlas viewport. Panning
        # has separate engine tests; three nearby checks isolate UI transitions.
        from camera_patrol import Viewpoint
        panel.runner.views=tuple(Viewpoint(90.5+i*6,123.5,'Loong Haven XI',frozenset({(90+i*6,123)})) for i in range(3))
        notebook=panel.parent.master;notebook.select(panel.parent)
        (panel.repeat if repeat_mode else panel.snipe).invoke()
        assert panel.busy and panel.watch.patrol_busy and panel.watch.paused
        root.after(100,wait_found)
    deadline=time.perf_counter()+35
    def wait_found():
        panel=panels[0]
        if panel.busy:
            assert time.perf_counter()<deadline,panel.status.get()
            root.after(100,wait_found);return
        rows=panel.watch.sighting_history.list()
        assert len(rows)==1,(panel.status.get(),rows)
        row=rows[0]
        if row.capture_status=='pending':
            assert time.perf_counter()<deadline
            root.after(100,wait_found);return
        assert row.capture_status=='ready' and Path(row.screenshot_path).is_file()
        assert row.source=='Live game · Camera view'
        assert (row.game_x,row.game_y)!=(31,186)  # Character label in the supplied photo.
        if approach_mode:
            assert row.captured_at-row.seen_at<1
            assert 'before the movement click' in row.capture_note
        else:assert row.captured_at-row.seen_at>=4.9
        assert sum(x[0]=='click' for x in Backend.inputs)==(3*visits_to_gem-1+int(approach_mode)),Backend.inputs
        assert sum(x[1]==(480.,170.) for x in Backend.inputs)==visits_to_gem-1
        assert not any(x[1]==(515.,830.) for x in Backend.inputs)
        assert panel.runner.stats.snapshot()['gems']==1
        assert panel.stats_text.get().startswith('Time spent: ') and 'Gems found: 1' in panel.stats_text.get()
        assert len(panel.runner.checked)==(1 if repeat_mode else 3)
        if repeat_mode:
            assert panel.runner.passes==1 and 'Passes completed: 1' in panel.pass_text.get()
        assert overlay_draws, "Overlay must remain visible during live patrol"
        panel.history_button.invoke()
        history=panel.watch.sighting_controls.window
        assert history.winfo_exists()
        panel.watch.sighting_controls.show()
        assert panel.watch.sighting_controls.window is history
        history.destroy()
        saved=json.loads(panel.path.read_text())
        assert saved['version']==3 and saved['settings']['map_open']==[480.,170.]
        panel.reset();assert panel.stats_text.get()=='Time spent: 0:00\nGems found: 0'
        before=len(Backend.inputs)
        panel.start(False);panel.keys.stop()
        root.after(500,lambda:cancelled(before))
    def cancelled(before):
        panel=panels[0]
        assert len(Backend.inputs)==before and panel.runner.cancel.is_set()
        if panel.busy or panel.runner.running:
            assert time.perf_counter()<deadline
            root.after(100,lambda:cancelled(before));return
        assert not panel.busy and not panel.runner.running
        assert len(Backend.inputs)==before and panel.runner.cancel.is_set()
        assert not panel.watch.patrol_busy and panel.watch.paused
        done.append(True)
        widgets=[]
        def visit(widget):
            for child in widget.winfo_children():widgets.append(child);visit(child)
        visit(root)
        next(w for w in widgets if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
    root.after(400,begin);root.after(40000,root.destroy)
tk.Tk.__init__=root_init
old=sys.platform;sys.platform='win32'
try:loong_lens.main(['--tab','watch'])
finally:sys.platform=old;tk.Tk.__init__=real_root
assert done and not errors,errors
print(('Movement-enabled' if approach_mode else 'Hold-only')+' live patrol UI passed: overlay remains visible,  real atlas alignment/detector, actual control loop, stop on gem, saved screenshot, camera-area history, cooldown ownership, emergency cancellation and no collection inputs. Mouse delivery was simulated.')
