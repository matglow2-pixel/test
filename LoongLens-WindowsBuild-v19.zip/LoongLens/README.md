# Loong Lens

A Windows 10 (2004+) / Windows 11 companion for Sword x Staff in BlueStacks. Use Loong Haven's default map zoom.

## Start

Close the previous app and run **LoongLens.exe**. Python and separate icon files are not needed. The portable download contains the EXE and this guide; the full package also includes source, assets and development checks.

The EXE keeps the white gem badge in Explorer. Its window and taskbar use the original transparent gem artwork. Settings, history and screenshots remain in `%LOCALAPPDATA%\LoongLens` when upgrading.

## Map overlay

Open the large Loong Haven map with BlueStacks visible. Pink dots mark 86 possible gem locations; Ingredients groups the bean, bamboo and crab layers. Pause, Re-align and appearance controls affect only the overlay.

Recent sightings appear as teal dots with a 30-minute countdown from their original spotting time. Editing coordinates moves the dot without restarting its timer. Expired dots disappear; history stays saved. Manual pickups have their own Mark collected, Pickup history and timer controls.

## Gem Watch

Press **Start watching** for visible-gameplay detection. Confirmed gems trigger an optional sound and a history entry. A fresh screenshot and the character's minimap location are saved five seconds later. History/screenshots have a 20-second cooldown; sounds have a 30-second cooldown.

**History** opens the shared sighting log. Edit location changes only the zone and X,Y, preserving the original date, time and screenshot. Today only / Show all filter the log. Click Source or Open screenshot to view a saved picture. Test image and Test sound help check detection and alerts.

Detection uses full-resolution captures. The small live view displays the latest inspected screenshot and pink candidate boxes; it is a monitor, not the detector's input resolution. Covered or minimized gameplay cannot be inspected.

## Gem Sniping

This replaces the former Live patrol tab. The separate Patrol preview tab and its simulation controls have been removed; screenshot-based engine and UI checks remain in the development tools.

1. Open Loong Haven's map at default zoom and centre the white camera rectangle over your character's white dot before a new pass. Move Loong Lens aside so BlueStacks is uncovered.
2. Live controls are ready at launch. Press **Snipe** or **F8** to check all remaining spots once, or **Loop Sniping** to repeat passes until a gem is found or F10 stops it. Choose another Snipe key in the panel if needed. Opening the app alone sends no game input.
3. The first check selects the nearest original gem spawn to your character, using the white dot inside the camera rectangle. The rectangle centre is the fallback when the dot is unreadable. If neither can be read, the status reports a fallback to the visible map centre. Resume keeps processed views; Reset checks begins a new pass and a new nearest-first selection.
4. Each check selects a grouped camera viewpoint, closes the map and inspects gameplay. It stops on a confirmed gem; otherwise it reopens the map and continues. Nearby spots share a view: 77 camera checks cover the 86 known spots. It does not sweep the full possible spawn radius.
5. **F10** stops immediately, including while the game has focus. Hotkeys are registered while the app is open. Snipe and Loop Sniping are unavailable if registration fails; choose another Snipe key to retry.

Default startup is 0.5 seconds, scene loading is 0.5 seconds, and empty-view inspection is 1.2 seconds. A late gem candidate receives up to one extra second for the unchanged three-sighting / 0.8-second confirmation. Previous paired timing defaults upgrade automatically; custom waits and button calibration are preserved. Increase the loading/check waits in **Sniping settings** if your game renders slowly. Navigation, detection and loading performance still determine actual pass duration.

Dark locked areas are skipped using the current map screenshot. The Loong Haven IV camera selection avoids its portal icon. Controlled pans hold before release to limit inertia, measure actual map movement, shorten subsequent pans after overshoot and attempt bounded reverse recovery if alignment is lost. Unrecognised maps, focus loss, covered windows, resizing or stalled navigation stop input. Checked views remain available for resuming in this app session.

On a confirmed gem, the default action saves its screenshot, clicks once about one tile left/right beside the gem toward the screen centre, then stops. It avoids HUD buttons and never clicks the gem to collect it. Turn movement off in Sniping settings to retain the five-second photo hold instead. A patrol history location identifies the selected camera area, not the character's minimap position or the exact gem tile.

**Time spent: 7:41** keeps running through pauses, gem stops, errors and manual collection. It freezes only when all views are processed, including locked skips. Gems found counts confirmed detections, including those inside the saving cooldown. Loop Sniping shows the last completed pass duration and a pass count, then starts a fresh pass timer and returns to the same first spot. F10 or a gem stops repetition, including a gem found at the final view. History cooldown is preserved across passes. Reset checks clears the totals. History beside Sniping settings opens the same log as Gem Watch and stops mouse actions while the clock continues.

The overlay stays visible during sniping. Normal Gem Watch pauses to avoid duplicate captures and remains paused afterward until resumed manually. Existing history, screenshots and settings are preserved.

## Files and privacy

The app uses ordinary desktop screenshots and Windows mouse input. It does not read game memory, inject DLLs or modify game files. Screenshots are saved locally and are not uploaded by the app.

Personal data is in `%LOCALAPPDATA%\LoongLens`: `settings.json`, `gemwatch-settings.json`, `patrol-live-settings.json`, `pickups.sqlite3`, `sightings.sqlite3` and `screenshots/`. Existing personal coordinates from earlier versions remain supported. Diagnostics use `loonglens.log`; Save debug writes the last map frame and alignment details to this same folder.

Do not delete that folder when updating. Old build archives, user data, caches, development screenshots and obsolete preview code are excluded from the new packages.

## Development

Use Python 3.12 and the pinned `requirements.txt`. Windows source launchers open the same combined app; RUN_GEM_WATCH selects its Gem Watch tab. The one-file EXE is built with PyInstaller 6.16.0 and has no console window.

```
python -m pip install -r requirements.txt pytest==8.4.2
python -m pytest -q
python loong_lens.py --self-check
# Windows build:
python -m pip install pyinstaller==6.16.0
python tools/build_windows_exe.py
```

`--tab map`, `--tab watch` and `--tab live` select a startup page. Tests use simulated desktop input and real atlas/detector fixtures; the Windows workflow additionally checks the frozen app, icons and native input against its own test window. These checks do not measure a live BlueStacks pass. See VALIDATION.md for the current verification scope. OCR model notices and licences are included in `ocr_models`.
