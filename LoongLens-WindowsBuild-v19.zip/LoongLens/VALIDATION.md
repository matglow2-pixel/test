# Verification — Loong Lens v19

The application targets Windows 10 (2004+) / Windows 11 with BlueStacks and Loong Haven's default zoom. Linux checks use Python 3.12, the pinned dependencies and simulated desktop input. They do not operate a live game.

## Automated engine checks

**258 tests pass in the Linux development environment.** Preview-only sequence tests were removed along with that feature; shared camera planning and all live navigation checks remain.

Coverage includes:

- All 86 original spawn spots covered by 77 grouped viewpoints, edge margins, playable camera centres, the Mirage Cauldron / Demonbind groups and the Loong Haven IV portal exclusion.
- First selection from the white character dot inside the camera rectangle, rectangle fallback, rejecting unrelated white UI icons, ranking original spawn positions rather than shifted camera centres, and a nearest-map-centre fallback when markers are unreadable.
- Faster default timing migration while preserving custom waits and modern saved settings, half-second startup with focus/cancellation checks, late candidate confirmation and a bounded extension for false positives.
- Single passes and continuous passes; returning to the same first spot, preserving cooldown across passes, stopping on F10/errors/finds, and stopping on a find at the final view without restarting. Current and last-pass durations, pass counts and gem totals are retained in the UI.
- Controlled pans, endpoint hold before mouse-up, measured overshoot feedback, bounded reverse recovery, stable screenshot alignment, progress retention and cancellation/foreground/resize/obstruction guards.
- Locked-zone skipping, one horizontal tile of approach toward screen centre, HUD avoidance, screenshot-before-movement, no collection clicks, and retained alert-only five-second capture mode.
- History editing without date/time changes, date filters, saving cooldowns, capture/OCR, persistent logs, map timer projection, personal-coordinate validation, image detection and stale-session handling.

## Resource and interface checks

The offline self-check aligns three real atlas viewports, loads bundled CPU OCR, rejects a blank label, verifies transparent rendering and confirms 77 grouped views cover 86 spots.

The actual Tk interface is checked at 540×820, 560×860 and 700×950 with mocked Windows delivery. It must have exactly Map overlay, Gem Watch and Gem Sniping, no preview tab or live-enable checkbox, ready hotkeys without automatic input on startup, visible controls and complete text, shared History, renamed settings and working shutdown.

Screenshot-driven UI checks use the actual atlas alignment, detector, screenshot writer and SQLite history with a simulated game window. The map overlay must continue drawing during sniping. History location edits must move a live map dot while retaining the original countdown anchor.

## Windows release validation

The GitHub workflow runs the application tests on Windows, builds the one-file windowed EXE and validates its embedded white badge against the supplied ICO. The frozen self-check validates bundled atlas/OCR assets. The native GUI check verifies the three tabs, ready controls, history filters/editor, minimum-size layout, native transparent window icon and clean shutdown.

The native input check sends guarded clicks/drags/hotkeys to the application's own test window, tests F10 cancellation and confirms the click-through overlay is excluded from screenshots. It does not send input to BlueStacks. Release reports are included beside the downloads after a successful build.

## Practical limits

Real game rendering time, inertia, character movement/pathfinding, locked shading on another account and total pass duration require BlueStacks testing. Shorter waits can be increased in Sniping settings. Character anchoring is tested with synthetic white-marker fixtures; the user's inline screenshot is a visual reference, not an imported pixel fixture. Unreadable markers use the explicit fallback reported by the app.

History labels describe a selected camera area, not the exact gem tile. The detector still requires three sightings over 0.8 seconds, and repeat passes do not bypass the 20-second saving or 30-second sound cooldowns. The normal Gem Watch delay remains five seconds. Data files are kept outside the app installation, so upgrading does not reset personal history or settings.
