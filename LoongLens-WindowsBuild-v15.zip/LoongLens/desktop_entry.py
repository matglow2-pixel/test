"""Frozen Windows entry point; validation modes exit without opening error dialogs."""
import json
import os
from pathlib import Path
import runpy
import sys
import traceback

import loong_lens
from patrol_input_check import check_native_input


def gui_check():
    import tkinter as tk
    from tkinter import ttk
    checked = []
    failures = []
    original = tk.Tk
    import patrol_panel
    from camera_patrol import PatrolSettings
    original_patrol_init = patrol_panel.PatrolPanel.__init__
    patrols = []
    def remember_patrol(panel, *args, **kwargs):
        original_patrol_init(panel, *args, **kwargs)
        patrols.append(panel)
    patrol_panel.PatrolPanel.__init__ = remember_patrol

    def descendants(widget):
        result = []
        for child in widget.winfo_children():
            result.append(child)
            result.extend(descendants(child))
        return result

    class CheckWindow(original):
        def iconbitmap(self, bitmap=None, default=None):
            if bitmap is not None:
                self.checked_icon_file = str(bitmap)
            elif default is not None:
                self.checked_icon_file = str(default)
            return super().iconbitmap(bitmap, default)

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            def failed(kind, value, trace):
                failures.append(''.join(traceback.format_exception(kind, value, trace)))
                self.destroy()
            self.report_callback_exception = failed
            self.after(2000, self.check)
            self.after(30000, self.destroy)

        def check(self):
            assert self.title() == 'Loong Lens'
            # On Windows wm iconbitmap's getter can return an empty string
            # after successfully loading an ICO. Verify the real setter/path
            # and the native window's icon handles instead.
            icon_file = Path(self.checked_icon_file)
            assert icon_file.name == 'LoongLens-Original-Optimized.ico' and icon_file.is_file()
            if os.name == 'nt':
                import ctypes
                from ctypes import wintypes
                user = ctypes.WinDLL('user32', use_last_error=True)
                user.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
                user.GetAncestor.restype = wintypes.HWND
                user.SendMessageW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
                user.SendMessageW.restype = ctypes.c_ssize_t
                wrapper = user.GetAncestor(self.winfo_id(), 2)
                icons = [user.SendMessageW(wrapper, 0x7F, kind, 0) for kind in (0, 1, 2)]
                if not any(icons):
                    user.GetClassLongPtrW.argtypes = (wintypes.HWND, ctypes.c_int)
                    user.GetClassLongPtrW.restype = ctypes.c_size_t
                    icons = [user.GetClassLongPtrW(wrapper, field) for field in (-14, -34)]
                assert any(icons), 'The native window has no configured icon'
            widgets = descendants(self)
            notebook = next(item for item in widgets if isinstance(item, ttk.Notebook))
            assert len(notebook.tabs()) == 4
            assert notebook.tab(notebook.tabs()[2], 'text') == 'Patrol preview'
            assert notebook.tab(notebook.tabs()[3], 'text') == 'Live patrol'
            live_box=next(item for item in widgets if isinstance(item,ttk.Checkbutton) and item.cget('text')=='Enable live clicking')
            assert not live_box.instate(['selected'])
            assert any(isinstance(item, ttk.Checkbutton) and item.cget('text') == 'Enable patrol preview' for item in widgets)
            buttons = {item.cget('text'): item for item in widgets if isinstance(item, ttk.Button)}
            assert any(isinstance(item, ttk.Checkbutton) and item.cget('text') == 'Sighting timers (30 min)' for item in widgets)
            buttons['History'].invoke()
            history = next(item for item in descendants(self)
                           if isinstance(item, tk.Toplevel) and item.title() == 'Gem sighting history')
            controls = descendants(history)
            assert any(isinstance(item, ttk.Button) and item.cget('text') == 'Edit location' for item in controls)
            assert any(isinstance(item, ttk.Radiobutton) and item.cget('text') == 'Today only' for item in controls)
            history.destroy()
            self.exit_button = buttons['Exit']
            assert len(patrols)==1 and not patrols[0].enabled.get()
            notebook.select(notebook.tabs()[2])
            panel=patrols[0]
            panel.settings=PatrolSettings()
            panel.enabled.set(True)
            panel.toggle()
            self.after(100,self.check_patrol)

        def check_patrol(self):
            panel=patrols[0]
            if panel.plan is None:
                self.after(100,self.check_patrol)
                return
            assert len(panel.plan.spawns)==len(panel.plan.views)==86
            panel.next_view()
            assert panel.running and panel.step.action=='Open map'
            panel.show_detail()
            assert panel.detail.winfo_exists() and panel.atlas is not None
            panel.stop()
            assert not panel.running and panel.after_id is None
            panel.enabled.set(False)
            panel.toggle()
            assert not panel.enabled.get()
            checked.append(True)
            self.exit_button.invoke()

    tk.Tk = CheckWindow
    try:
        loong_lens.main(argv=[], default_tab='watch')
    finally:
        tk.Tk = original
        patrol_panel.PatrolPanel.__init__ = original_patrol_init
    if not checked or failures:
        raise RuntimeError(f'Native GUI check failed: {failures}')


def main():
    if len(sys.argv) == 3 and sys.argv[1] in ('--self-check-report', '--gui-check-report','--input-check-report'):
        path = Path(sys.argv[2])
        try:
            if sys.argv[1] == '--self-check-report':
                loong_lens.self_check()
            elif sys.argv[1] == '--gui-check-report':
                gui_check()
            else:
                check_native_input()
            result = {'passed': True, 'mode': sys.argv[1]}
            status = 0
        except Exception:
            result = {'passed': False, 'mode': sys.argv[1], 'error': traceback.format_exc()}
            status = 1
        path.write_text(json.dumps(result, indent=2), encoding='utf-8')
        return status
    runpy.run_path(str(Path(__file__).resolve().parent / 'launch_app.pyw'), run_name='__main__')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
