import threading
from types import SimpleNamespace
import numpy as np
import pytest
from camera_patrol import Spawn,build_plan
from patrol_live import LivePatrol,LiveSettings,load_live_config
from patrol_windows import PatrolStopped,WindowsBackend
from pose import Match


class Clock:
    now=0.
    def __call__(self):return self.now


class Backend:
    def __init__(self,cancel,clock):
        self.cancel=cancel;self.clock=clock;self.open=True;self.center=(100.,100.)
        self.target=(123,(0,0,570,1029));self.inputs=[];self.break_back=False;self.stuck=False
    def wait(self,t):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        self.clock.now+=t
    def focus(self):self.wait(.25)
    def capture(self):
        self.wait(0)
        frame=np.full((1029,570,3),int(self.open),np.uint8)
        frame[10,10]=int(self.clock.now)%255
        return frame
    def click(self,point):
        self.wait(0);self.inputs.append(('click',point,self.open))
        if not self.open:
            # A real UI target region, independent of the configured default.
            # The former bottom-right menu point must not open this fake map.
            if 390<point[0]<550 and 80<point[1]<245:self.open=True
        elif point==LiveSettings().map_close:
            if not self.break_back:self.open=False
    def drag(self,a,b):
        self.wait(.36);self.inputs.append(('drag',a,b))
        if not self.stuck:self.center=(self.center[0]-(b[0]-a[0])/12.45,self.center[1]+(b[1]-a[1])/12.45)


class Locator:
    def __init__(self,backend):self.backend=backend
    def locate(self,frame):
        x,y=self.backend.center
        return Match(12.45,285-x*12.45,500+y*12.45,20,0,[])


def setup(positive=False,spawns=None):
    cancel=threading.Event();clock=Clock();backend=Backend(cancel,clock);events=[]
    box=SimpleNamespace(center=(200,400),score=.95,width=20)
    detector=SimpleNamespace(detect=lambda frame,**kw:[box] if positive else [])
    views=build_plan(spawns or (Spawn(100.5,100.5,'A'),Spawn(105.5,103.5,'B'))).views
    engine=LivePatrol(views,LiveSettings(),cancel,events.append,detector=detector,
        locator=Locator(backend),title=SimpleNamespace(score=lambda f:float(f[0,0,0])),
        clock=clock,wall=lambda:1000+clock.now)
    return engine,backend,events


def test_real_loop_select_close_inspect_next_no_collect_clicks():
    engine,backend,events=setup();engine.run(backend,auto=True)
    assert engine.checked=={0,1}
    assert not any(x[0]=='drag' for x in backend.inputs)
    assert [x[2] for x in backend.inputs]==[True,True,False,True,True]
    assert not any(e['kind']=='found' for e in events)


def test_default_opener_targets_the_round_minimap_not_bottom_menu():
    assert LiveSettings().map_open==(480.,170.)


def test_reported_bug_wrong_old_opener_fails_after_first_closed_scene():
    engine,backend,events=setup();engine.settings=LiveSettings(map_open=(515.,830.))
    with pytest.raises(RuntimeError,match='large map did not open'):engine.run(backend)
    assert engine.checked=={0}
    assert backend.inputs[-1]==('click',(515.,830.),False)
    assert len([e for e in events if e['kind']=='view'])==1


def test_repeated_empty_scenes_reopen_by_minimap_each_time():
    engine,backend,events=setup(spawns=tuple(Spawn(100.5+i,100.5+i,str(i)) for i in range(4)))
    engine.run(backend)
    assert len(engine.checked)==4
    openers=[point for action,point,was_map in backend.inputs if not was_map]
    assert openers==[(480.,170.)]*3
    assert all(point!=(515.,830.) for action,point,state in backend.inputs)


def test_old_saved_default_is_upgraded_without_losing_other_settings():
    config={'settings':dict(map_open=[515,830],map_close=[62,975],settle_seconds=2,inspect_seconds=3),'key':'F9'}
    settings,key,migrated=load_live_config(config)
    assert migrated and settings.map_open==(480.,170.) and key=='F9'
    assert settings.map_close==[62,975] and settings.settle_seconds==2 and settings.inspect_seconds==3


def test_custom_calibration_is_preserved_and_migration_is_not_repeated():
    custom={'settings':dict(map_open=[475,165])}
    settings,key,migrated=load_live_config(custom)
    assert not migrated and settings.map_open==[475,165]
    modern={'version':2,'settings':dict(map_open=[515,830])}
    assert not load_live_config(modern)[2]  # Explicitly saved v2 calibration is kept.


def test_single_check_leaves_next_location_unchecked():
    engine,backend,events=setup();engine.run(backend,auto=False)
    assert engine.checked=={0}
    assert len(backend.inputs)==2


def test_automatic_map_close_does_not_send_a_back_click_into_gameplay():
    engine,backend,events=setup(positive=True)
    original=backend.click
    def click(point):original(point);backend.open=False
    backend.click=click
    engine.run(backend,auto=False)
    assert len(backend.inputs)==1 and engine.checked=={0}


def test_visible_dots_first_then_nearest_offscreen_and_realign_after_each_drag():
    engine,backend,events=setup(spawns=(Spawn(250.5,250.5,'Far'),Spawn(100.5,100.5,'Visible'),Spawn(150.5,150.5,'Next')))
    engine.run(backend)
    assert [e['index'] for e in events if e['kind']=='view']==[1,2,0]
    for action,a,b in (x for x in backend.inputs if x[0]=='drag'):
        assert 32<b[0]<510 and 233<b[1]<788


def test_confirmed_gem_stops_and_captures_fresh_scene_five_seconds_later():
    engine,backend,events=setup(positive=True);message=engine.run(backend)
    assert engine.checked=={0} and 'Gem found' in message
    found=next(e['event'] for e in events if e['kind']=='found')
    capture=next(e for e in events if e['kind']=='capture')
    assert capture['event']==found
    assert engine.wall()-found['seen_at']==pytest.approx(5)
    assert found['camera_location']==dict(zone='A',x=100,y=100)
    assert found['capture_note'].startswith('Camera view:')
    assert len(backend.inputs)==2  # No map reopening and no collection click.


def test_history_cooldown_does_not_prevent_stop_on_gem():
    engine,backend,events=setup(positive=True);engine.cooldown['last']=0
    engine.run(backend)
    assert next(e for e in events if e['kind']=='found')['event'] is None
    assert not any(e['kind']=='capture' for e in events)


def test_sound_cooldown_does_not_prevent_recording_or_stopping():
    engine,backend,events=setup(positive=True);engine.cooldown['sound']=0
    engine.run(backend)
    found=next(e for e in events if e['kind']=='found')
    assert found['event'] is not None and not found['sound']
    assert engine.checked=={0}


def test_f10_during_found_hold_cancels_screenshot_without_moving_camera():
    engine,backend,events=setup(positive=True)
    def emit(event):
        events.append(event)
        if event['kind']=='found':engine.cancel.set()
    engine.emit=emit;engine.run(backend)
    cancelled=next(e['event'] for e in events if e['kind']=='sighting')
    assert cancelled['capture_status']=='cancelled'
    assert cancelled['capture_note'].startswith('Camera view:')
    assert len(backend.inputs)==2


def test_failed_alignment_never_clicks_a_gem_or_marks_it_checked():
    engine,backend,events=setup();engine.locator=SimpleNamespace(locate=lambda frame:None)
    with pytest.raises(RuntimeError,match='align'):engine.run(backend)
    assert backend.inputs==[] and not engine.checked


def test_unmoving_map_aborts_instead_of_repeating_blind_clicks():
    engine,backend,events=setup(spawns=(Spawn(250,250,'Far'),));backend.stuck=True
    with pytest.raises(RuntimeError,match='not moving'):engine.run(backend)
    assert all(i[0]=='drag' for i in backend.inputs) and not engine.checked


def test_bad_back_button_does_not_classify_an_open_map_as_empty_gameplay():
    engine,backend,events=setup();backend.break_back=True
    with pytest.raises(RuntimeError,match='did not close'):engine.run(backend)
    assert not engine.checked


def test_stop_before_start_sends_no_input():
    engine,backend,events=setup();engine.cancel.set()
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert backend.inputs==[]


@pytest.mark.parametrize('kwargs',[{'map_open':(-1,2)},{'map_close':(570,100)},
    {'settle_seconds':float('nan')},{'inspect_seconds':.5}])
def test_invalid_live_settings_rejected(kwargs):
    with pytest.raises(ValueError):LiveSettings(**kwargs)


def test_native_drag_cancellation_always_releases_mouse():
    backend=WindowsBackend.__new__(WindowsBackend)
    backend.down=False;backend.cancel=threading.Event();sent=[]
    backend.api=SimpleNamespace(mouse=sent.append)
    backend.move=lambda point:None;backend.guard=lambda:None
    def wait(t):raise PatrolStopped('Stopped.')
    backend.wait=wait
    with pytest.raises(PatrolStopped):backend.drag((100,100),(200,200))
    assert sent==[2,4] and not backend.down


def test_patrol_suspension_clears_old_image_test_without_starting_live_capture():
    from collections import deque
    from gem_watch_worker import WatchWorker
    worker=WatchWorker.__new__(WatchWorker)
    worker.lock=threading.Lock();worker.generation=4;worker.test_frame=object()
    worker.paused=False;worker.reset_requested=False;worker.alerts=deque([object()]);worker.snapshot={}
    worker.watch_game(paused=True)
    assert worker.paused and worker.test_frame is None and worker.generation==5
    assert worker.reset_requested and not worker.alerts and not worker.snapshot['test_mode']


@pytest.mark.parametrize('reason',['focus','resize','stop','covered'])
def test_native_input_guards_prevent_any_mouse_move_or_down(reason):
    backend=WindowsBackend.__new__(WindowsBackend);backend.cancel=threading.Event()
    backend.down=False;backend.target=(123,(10,20,570,1029));sent=[]
    def bounds(hwnd,pointer):
        rect=pointer._obj;rect.left=10;rect.top=20;rect.right=580+(1 if reason=='resize' else 0);rect.bottom=1049
        return True
    user=SimpleNamespace(GetWindowRect=bounds,GetForegroundWindow=lambda:999 if reason=='focus' else 123,
        GetAncestor=lambda hwnd,kind:hwnd,SetCursorPos=lambda *p:sent.append(p))
    backend.api=SimpleNamespace(user=user,mouse=sent.append)
    backend.visible_at=lambda *p:reason!='covered'
    if reason=='stop':backend.cancel.set()
    with pytest.raises(RuntimeError):backend.click((200,300))
    assert sent==[]


def test_camera_capture_bypasses_character_ocr_and_survives_history_edit(tmp_path):
    from sighting_capture import SightingCapture
    from sighting_history import SightingHistory
    reader=SimpleNamespace(read=lambda frame:pytest.fail('Player OCR must not run on a camera sighting'))
    store=SightingCapture(tmp_path,reader=reader)
    engine,backend,events=setup(positive=True);engine.run(backend)
    e=next(e for e in events if e['kind']=='capture')
    result=store.save(e['event'],e['frame'],engine.wall())
    assert (result['zone'],result['game_x'],result['game_y'])==('A',100,100)
    assert result['capture_status']=='ready'
    with __import__('PIL.Image',fromlist=['Image']).open(result['screenshot_path']) as image:
        assert image.size==(570,1029)
    db=SightingHistory(tmp_path/'sightings.sqlite3');db.record([e['event'],result])
    row=db.list()[0];assert row.source=='Live game · Camera view'
    db.edit_location(row.id,'Corrected',101,102);corrected=db.get(row.id)
    assert corrected.seen_at==row.seen_at and corrected.screenshot_path==row.screenshot_path
    store.close();db.close()
