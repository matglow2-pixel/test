"""Screenshot-guided live patrol loop; input and clock are injectable for tests."""
from __future__ import annotations
from dataclasses import dataclass
import math
import threading
import time
import uuid
import cv2
from gem_detector import GemDetector,AlertGate
from patrol_windows import PatrolStopped


@dataclass(frozen=True)
class LiveSettings:
    map_open: tuple = (515.,830.)
    map_close: tuple = (64.,980.)
    settle_seconds: float = .8
    inspect_seconds: float = 1.5
    threshold: float = .77
    mask_hud: bool = False

    def __post_init__(self):
        for x,y in (self.map_open,self.map_close):
            if not (math.isfinite(x) and math.isfinite(y) and 0<=x<570 and 0<=y<1029):
                raise ValueError('Choose map buttons inside the BlueStacks screenshot.')
        if not (math.isfinite(self.settle_seconds) and .2<=self.settle_seconds<=10
                and math.isfinite(self.inspect_seconds) and 1.2<=self.inspect_seconds<=10
                and .5<=self.threshold<=.99):raise ValueError('Invalid patrol timing or detector settings.')


def clickable(point):
    x,y=point
    return 32<=x<=510 and 150<=y<=800 and not (x>=420 and y<=250)


class LivePatrol:
    def __init__(self,views,settings,cancel,emit,checked=None,cooldown=None,
                 detector=None,locator=None,title=None,clock=time.perf_counter,wall=time.time):
        self.views=tuple(views);self.settings=settings;self.cancel=cancel;self.emit=emit
        self.checked=checked if checked is not None else set()
        self.cooldown=cooldown if cooldown is not None else {'last':-float('inf')}
        self.detector=detector or GemDetector(threshold=settings.threshold)
        self.locator=locator;self.title=title;self.clock=clock;self.wall=wall

    def send(self,kind,**data):self.emit(dict(kind=kind,**data))
    def check(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')

    @staticmethod
    def normal(frame):return cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)

    def is_map(self,frame):return self.title.score(self.normal(frame))>=.64

    def map_frame(self,backend):
        deadline=self.clock()+6
        while self.clock()<deadline:
            self.check();frame=backend.capture()
            if self.is_map(frame):return frame
            backend.wait(.2)
        raise RuntimeError('The large map did not open. Set the Map button in Live settings.')

    def align(self,backend):
        deadline=self.clock()+7
        previous=None
        while self.clock()<deadline:
            self.check();frame=self.map_frame(backend)
            pose=self.locator.locate(self.normal(frame))
            self.check()
            if pose is not None and previous is not None and (
                    abs(pose.scale-previous.scale)<.03 and abs(pose.tx-previous.tx)<3 and abs(pose.ty-previous.ty)<3):
                return frame,pose
            previous=pose
            backend.wait(.15)
        raise RuntimeError('Could not align Loong Haven. Use default zoom and keep map terrain visible.')

    def inspect(self,backend):
        gate=AlertGate(cooldown=0)
        started=self.clock();scans=0
        while self.clock()-started<self.settings.inspect_seconds or scans<3:
            self.check();frame=backend.capture()
            if self.is_map(frame):raise RuntimeError('The map did not close. Set its Back button in Live settings.')
            boxes=self.detector.detect(frame,exclude_hud=self.settings.mask_hud)
            self.check();gate.update(boxes,self.clock());scans+=1
            self.send('frame',frame=frame,detections=boxes)
            if gate.new_sightings:return gate.new_sightings[0],frame
            if self.clock()-started>8:raise RuntimeError('Screenshot detection is too slow to complete this view.')
            backend.wait(.2)
        return None,None

    def run(self,backend,auto=True):
        self.check()
        if self.locator is None:
            from vision import Calibrator,TitleDetector
            from resources import user_dir
            self.send('status',message='Preparing map recognition…')
            self.locator=Calibrator(user_dir());self.title=TitleDetector()
        self.send('status',message='Starting in 2 seconds. F10 stops at any time.')
        backend.wait(2);backend.focus()
        while len(self.checked)<len(self.views):
            self.check();frame=backend.capture()
            if not self.is_map(frame):backend.click(self.settings.map_open);backend.wait(.4)
            frame,pose=self.align(backend)
            remaining=[i for i in range(len(self.views)) if i not in self.checked]
            if not remaining:break
            visible=[i for i in remaining if clickable(pose.project(self.views[i].x,self.views[i].y))]
            center=((285-pose.tx)/pose.scale,(pose.ty-500)/pose.scale)
            index=(visible[0] if visible else min(remaining,key=lambda i:
                math.hypot(self.views[i].x-center[0],self.views[i].y-center[1])))
            view=self.views[index]
            self.send('view',index=index,view=view,checked=len(self.checked))
            stalled=0;previous=None
            for attempt in range(33):
                self.check();point=pose.project(view.x,view.y)
                if clickable(point):break
                if attempt==32:raise RuntimeError('Could not bring this dot into view. Patrol stopped.')
                distance=math.hypot(point[0]-285,point[1]-500)
                stalled=stalled+1 if previous is not None and distance>=previous-3 else 0
                if stalled>=3:raise RuntimeError('Map panning is not moving toward the dot. Patrol stopped.')
                previous=distance
                dx,dy=285-point[0],500-point[1]
                factor=max(1,abs(dx)/200,abs(dy)/250)
                self.send('status',message='Panning to reveal the next gem dot…')
                backend.drag((285.,500.),(285+dx/factor,500+dy/factor))
                backend.wait(.35);frame,pose=self.align(backend)
            # Recognition came from this fresh screenshot; guard input again.
            self.check();self.send('status',message=f'Clicking {view.near_zone} ({math.floor(view.x)},{math.floor(view.y)})')
            backend.click(point);backend.wait(.2);backend.click(self.settings.map_close)
            deadline=self.clock()+5
            while self.is_map(backend.capture()):
                if self.clock()>deadline:raise RuntimeError('The map did not close. Calibrate its Back button.')
                backend.wait(.2)
            backend.wait(self.settings.settle_seconds)
            self.send('status',message='Inspecting the visible scene…')
            found,frame=self.inspect(backend)
            self.checked.add(index);self.send('checked',index=index,count=len(self.checked))
            if found is not None:
                now=self.clock();event=None
                if now-self.cooldown['last']>=20:
                    self.cooldown['last']=now
                    event=dict(event_id='patrol:'+uuid.uuid4().hex,seen_at=self.wall(),screen_x=found.center[0],
                        screen_y=found.center[1],score=found.score,test_mode=False,capture_status='pending',
                        zone=view.near_zone,game_x=math.floor(view.x),game_y=math.floor(view.y),
                        capture_note='Camera view: selected spawn area, not the gem tile.',
                        camera_location=dict(zone=view.near_zone,x=math.floor(view.x),y=math.floor(view.y)))
                sound=now-self.cooldown.get('sound',-float('inf'))>=30
                if sound:self.cooldown['sound']=now
                self.send('found',event=event,view=view,sound=sound)
                if event is not None:
                    try:
                        backend.wait(5);fresh=backend.capture()
                        if self.is_map(fresh):raise RuntimeError('The map was opened before capture.')
                        self.send('capture',event=event,frame=fresh,captured_at=self.wall())
                    except Exception as exc:
                        self.send('sighting',event=dict(event,capture_status='cancelled',
                            capture_note=event['capture_note']+' Screenshot unavailable: '+str(exc)))
                return 'Gem found. Patrol stopped; collect it manually.'
            if not auto:return 'One location checked. Press the advance hotkey for another.'
        return 'All gem locations checked. Reset checks to scan again.'


class LiveRunner:
    def __init__(self,views,backend_factory,emit):
        self.views=views;self.backend_factory=backend_factory;self.emit=emit
        self.cancel=threading.Event();self.thread=None;self.checked=set();self.cooldown={'last':-float('inf')}
        self.detector=None;self.locator=None;self.title=None
    @property
    def running(self):return self.thread is not None and self.thread.is_alive()
    def stop(self):self.cancel.set()
    def start(self,settings,auto=True):
        if self.running:return False
        self.cancel.clear()
        def work():
            message='Stopped.'
            try:
                if self.cancel.is_set():raise PatrolStopped('Stopped.')
                if self.detector is None:self.detector=GemDetector(threshold=settings.threshold)
                self.detector.threshold=settings.threshold
                if self.cancel.is_set():raise PatrolStopped('Stopped.')
                if self.locator is None:
                    from vision import Calibrator,TitleDetector
                    from resources import user_dir
                    self.locator=Calibrator(user_dir());self.title=TitleDetector()
                patrol=LivePatrol(self.views,settings,self.cancel,self.emit,self.checked,self.cooldown,
                    self.detector,self.locator,self.title)
                patrol.check()
                with self.backend_factory(self.cancel) as backend:message=patrol.run(backend,auto)
            except Exception as exc:message=str(exc)
            finally:self.emit(dict(kind='finished',message=message))
        self.thread=threading.Thread(target=work,daemon=True,name='LoongLens-live-patrol');self.thread.start()
        return True
