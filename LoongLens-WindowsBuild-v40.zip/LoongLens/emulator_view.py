"""MuMu desktop viewport geometry, shared by capture, input and overlay."""
from dataclasses import dataclass
import math
from pathlib import PureWindowsPath
import re

import cv2
import numpy as np
from PIL import Image


REFERENCE_GAME = (5, 34, 565, 1029)
ANDROID_ASPECT = 1080 / 1920


def mumu_device_window(title, executable, width, height):
    """MuMu device tabs can be named Android Device or after the game."""
    name = PureWindowsPath(executable).name.casefold()
    known = name in ('mumunxdevice.exe', 'mumuplayer.exe', 'nemuplayer.exe',
                     'mumunxmain.exe', 'mumuvmheadless.exe')
    if not known:
        return False
    words = re.sub(r'[ _-]+', ' ', title.casefold())
    if words in ('mumuplayer','mumu player') and name in ('mumuplayer.exe','mumunxmain.exe'):return False
    if any(word in words for word in ('multi instance', 'multi player', 'manager',
                                      'installer', '多开', '多開')):
        return False
    # The supplied device window is portrait; the MuMu device manager is wide.
    return width >= 300 and height >= 500 and .43 <= width / height <= .64


@dataclass(frozen=True)
class GameView:
    window: tuple  # root window x,y,width,height, used to detect movement
    content: tuple  # Android pixels x,y,width,height, excludes desktop toolbar
    child: int = 0

    def __post_init__(self):
        x, y, w, h = self.window
        a, b, width, height = self.content
        if not (w > 0 and h > 0 and width > 0 and height > 0 and
                x <= a < a + width <= x + w and y <= b < b + height <= y + h):
            raise ValueError('The Android view must lie inside its MuMu window.')

    def point(self, reference):
        x, y = reference
        left, top, right, bottom = REFERENCE_GAME
        if not (math.isfinite(x) and math.isfinite(y) and left <= x < right and top <= y < bottom):
            raise RuntimeError('Mouse target is outside the MuMu game area, on its toolbar or border.')
        a, b, w, h = self.content
        return (min(a + w - 1, max(a, round(a + (x - left) * w / (right - left)))),
                min(b + h - 1, max(b, round(b + (y - top) * h / (bottom - top)))))

    def reference(self, native):
        a, b, w, h = self.content
        left, top, right, bottom = REFERENCE_GAME
        return left + (native[0] - a) * (right - left) / w, top + (native[1] - b) * (bottom - top) / h

    def normalize(self, image):
        x, y, w, h = self.content
        if image.shape[:2] != (h, w):
            raise ValueError('MuMu capture size changed before normalization.')
        left, top, right, bottom = REFERENCE_GAME
        output = np.zeros((1029, 570, 3), np.uint8)
        output[top:bottom, left:right] = cv2.resize(image[:, :, :3], (right - left, bottom - top), interpolation=cv2.INTER_AREA)
        return output

    def overlay(self, image):
        """Undo normalization for markers; the toolbar never receives dots."""
        return image.crop(REFERENCE_GAME).resize(self.content[2:], Image.Resampling.LANCZOS)


def portrait_view(window, client, children=()):
    """Prefer an actual Android child window; otherwise fit the known 9:16 view.

    The fallback follows the supplied MuMu 6.8.9 layout: a top toolbar, one
    portrait game surface and the native border. Native hit testing supplies
    the client edges; no arbitrary mouse padding is introduced.
    """
    left, top, right, bottom = client
    width, height = right - left, bottom - top
    if width < 250 or height < 450:
        raise RuntimeError('MuMu has no usable portrait game area.')
    candidates = []
    wx, wy, ww, wh = window
    for hwnd, rect in children:
        x, y, w, h = rect
        # A frameless resize band can overlap visible Android pixels. Keep
        # the complete render child for capture/overlay; WindowsBackend clips
        # mouse input to the independently hit-tested eligible client area.
        if (w >= width * .8 and h > 450 and abs(w / h - ANDROID_ASPECT) < .004 and
                wx <= x and wy <= y and x + w <= wx + ww and y + h <= wy + wh):
            candidates.append((hwnd, rect))
    if candidates:
        hwnd, rect = max(candidates, key=lambda item: item[1][2] * item[1][3])
        return GameView(tuple(window), tuple(rect), int(hwnd))
    game_height = round(width / ANDROID_ASPECT)
    toolbar = height - game_height
    if toolbar < 0 or toolbar > max(100, width * .18):
        raise RuntimeError('Use MuMu’s portrait window with its toolbar at the top, as in your screenshots.')
    return GameView(tuple(window), (left, bottom - game_height, width, game_height))
