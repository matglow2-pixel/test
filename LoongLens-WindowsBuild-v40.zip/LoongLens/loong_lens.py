"""Loong Lens — combined Windows / MuMu Map Tweaker, Gem Sniper and Gem Spy."""
from __future__ import annotations
import argparse
import json
import logging
import os
from pathlib import Path
import sys
import time

def self_check():
    import cv2
    import numpy as np
    from resources import ResourceStore, Renderer, ROOT
    from vision import AtlasIndex
    from pose import Match
    cv2.setNumThreads(2)
    store = ResourceStore()
    renderer = Renderer(store)
    picture, counts, _ = renderer.render((570, 1029), Match(12.45, -1650, 2250, 0, 0, []),
                                         dict.fromkeys(('gems', 'common', 'rare', 'epic'), True))
    assert picture.mode == 'RGBA' and len(store.points['gems']) == 86
    index = AtlasIndex()
    index.prepare()
    atlas = cv2.imread(str(ROOT / 'loong_haven_default_atlas.png'))
    checked = 0
    for x, y in [(900, 1300), (1600, 1500), (2000, 1700)]:
        frame = atlas[y:y+1029, x:x+570].copy()
        found = index.locate(frame)
        if found is not None:
            assert abs(found.tx + x) < 4 and abs(found.ty - (279 * 12.45 - y)) < 4
            checked += 1
    if not checked:
        raise RuntimeError('Could not align any atlas test viewport.')
    print(f'Self-check passed: {checked}/3 atlas viewports aligned; 86 gems; transparent render OK.')
    from location_ocr import LocationReader
    assert LocationReader().read(np.zeros((1029,570,3),np.uint8)) is None
    print('Offline minimap OCR loaded; blank-input rejection passed.')
    from camera_patrol import build_plan, load_spawns
    plan = build_plan(load_spawns(store.data))
    assert len(plan.spawns) == 86 and plan.cells
    assert set().union(*(view.cells for view in plan.views)) == plan.cells
    assert len(plan.views) < 86 and len(plan.cells) == 86
    print(f'Offline camera patrol: {len(plan.views)} grouped camera checks cover 86 spots, no live input.')
    from patrol_route import load_fixed_route
    fixed=load_fixed_route(store.data)
    assert len(fixed)==76 and len(set().union(*(v.cells for v in fixed)))==83
    assert [v.route_number for v in fixed]==[i for i in range(1,78) if i not in (26,51,72) for _ in range(2 if i in (40,64) else 1)]
    print('Fixed Gem Sniper path: 76 checks / 83 spots; route IDs 26, 51 and 72 excluded.')
    print('This offline check does not validate Windows capture, click-through, or the live game.')

def main(argv=None, default_tab='map'):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-check', action='store_true', help='Check data and atlas recognition without opening a window')
    parser.add_argument('--tab', choices=('map', 'watch', 'live', 'spy'), default=default_tab, help='Initial tab in the combined application')
    args = parser.parse_args(argv)
    if args.self_check:
        self_check()
        return
    if sys.platform != 'win32':
        parser.error('The live overlay requires Windows 10/11 and MuMu. Use --self-check for offline validation.')
    import cv2
    cv2.setNumThreads(2)
    # Activate DPI awareness before Tk creates any window.
    from win_overlay import PixelAlphaOverlay, find_emulator
    import win_overlay
    import tkinter as tk
    from tkinter import ttk, messagebox
    from resources import ResourceStore, Renderer, COLORS, user_dir
    from tracker import VisualWorker
    from pickup_history import PickupHistory
    from history_panel import PickupControls
    from sighting_service import SightingService
    from spy_panel import SpyPanel
    from patrol_live_panel import LivePatrolPanel

    folder = user_dir()
    folder.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=folder / 'loonglens.log', level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    logging.getLogger('loonglens').info('Loong Lens v40 executable=%s source=%s',sys.executable,Path(__file__).resolve())
    settings_path = folder / 'settings.json'
    coordinates_path = folder / 'coordinates.csv'
    settings = {}
    try:
        settings = json.loads(settings_path.read_text('utf-8'))
        if not isinstance(settings, dict):
            settings = {}
    except (OSError, ValueError):
        pass

    class App:
        def __init__(self):
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LoongLens.Desktop')
            self.root = tk.Tk()
            self.root.title('Loong Lens')
            # The running window uses the optimized transparent art. The EXE
            # keeps its separate white badge for Explorer/desktop display.
            self.root.iconbitmap(str(Path(__file__).resolve().parent / 'LoongLens-Original-Optimized.ico'))
            width=max(960,min(1000,self.root.winfo_screenwidth()-60))
            height=max(720,min(760,self.root.winfo_screenheight()-100))
            left=max(0,(self.root.winfo_screenwidth()-width)//2)
            top=max(0,(self.root.winfo_screenheight()-height-40)//2)
            try:
                target=win_overlay.find_visible_emulator()
                if target is not None:
                    x,y,w,h=target[1]
                    if 0<=x+w+12<=self.root.winfo_screenwidth()-width:left=x+w+12
                    elif 0<=x-width-12<=self.root.winfo_screenwidth()-width:left=x-width-12
            except Exception:pass
            self.root.geometry(f'{width}x{height}+{left}+{top}')
            self.root.minsize(960,720)
            self.root.configure(bg='#0c1622')
            self.root.protocol('WM_DELETE_WINDOW', self.close)
            self.closed = False
            self.paused = False
            self.last_rect = None
            self.last_status = 0.
            self.last_upload = 0.
            self.upload_ms = 0.
            self.render_ms = 0.
            self.settings_dirty = False
            self.save_after = None
            self.warning = None
            try:
                self.store = ResourceStore(coordinates_path)
            except ValueError as exc:
                self.store = ResourceStore()
                self.warning = str(exc)
            self.renderer = Renderer(self.store)
            self.history = PickupHistory(folder / 'pickups.sqlite3')
            self.pickups = PickupControls(self.root, self.history, self.store, self.changed,
                                          default_minutes=int(self.setting_number('reminder_minutes', 30, 1, 1440)))
            self.overlay = PixelAlphaOverlay()
            self.worker = VisualWorker(getattr(win_overlay,'find_game_view',find_emulator), folder, fps=45)
            saved_layers = settings.get('layers', {})
            if not isinstance(saved_layers, dict):
                saved_layers = {}
            self.layers = {
                'gems': tk.BooleanVar(value=bool(saved_layers.get('gems', True))),
                'ingredients': tk.BooleanVar(value=bool(settings.get('ingredients',
                    any(saved_layers.get(t, False) for t in ('common', 'rare', 'epic')))))
            }
            self.fill = tk.BooleanVar(value=bool(settings.get('fill', True)))
            self.show_timers = tk.BooleanVar(value=bool(settings.get('show_timers', True)))
            self.show_sighting_timers = tk.BooleanVar(value=bool(settings.get('show_sighting_timers', True)))
            self.size = tk.IntVar(value=self.setting_number('size', 5, 3, 9))
            self.opacity = tk.DoubleVar(value=self.setting_number('opacity', .85, .3, 1.))
            self.state = tk.StringVar(value='Preparing atlas…')
            self.info = tk.StringVar(value='Bring MuMu to the foreground')
            self.count = tk.StringVar(value='Waiting for the Loong Haven map')
            self.metrics = tk.StringVar(value='Recognition runs in the background')
            self.build_ui()
            self.sightings = SightingService(self.root)
            self.live_patrol = LivePatrolPanel(self.live_tab,self.store.data,self.sightings,self.live_activity)
            self.spy = SpyPanel(self.spy_tab,self.live_patrol,self.sightings,self.live_activity)
            self.notebook.select({'watch': self.spy_tab, 'spy': self.spy_tab, 'map': self.map_tab, 'live': self.live_tab}[args.tab])
            self.worker.start()
            self.root.after(16, self.tick)
            if self.warning:
                messagebox.showwarning('Personal coordinates ignored', self.warning, parent=self.root)

        def setting_number(self, name, default, low, high):
            try:
                value = float(settings.get(name, default))
                if not low <= value <= high:
                    return default
                return int(value) if name == 'size' else value
            except (ValueError, TypeError):
                return default

        def build_ui(self):
            from ui_theme import FONT, apply_theme, heading, card, row
            apply_theme(self.root)
            from dashboard_shell import Sidebar
            shell=ttk.Frame(self.root);shell.pack(fill='both',expand=True)
            # Keep notebook semantics for page controllers, keyboard navigation
            # and diagnostics; its visible navigation lives in the sidebar.
            self.notebook=ttk.Notebook(shell,style='Sidebar.TNotebook')
            self.sidebar=Sidebar(shell,self.notebook,self.close)
            ttk.Separator(shell,orient='vertical').pack(side='left',fill='y')
            self.notebook.pack(side='left',fill='both',expand=True)
            self.map_tab=ttk.Frame(self.notebook);self.live_tab=ttk.Frame(self.notebook);self.spy_tab=ttk.Frame(self.notebook)
            self.notebook.add(self.map_tab,text='Map Tweaker')
            self.notebook.add(self.live_tab,text='Gem Sniper')
            self.notebook.add(self.spy_tab,text='Gem Spy')
            body = ttk.Frame(self.map_tab, padding=(12, 12))
            body.pack(fill='both', expand=True)
            heading(body, 'Map Tweaker', 'Spawn locations, gathering areas and recent gem sightings.')
            columns=ttk.Frame(body);columns.pack(fill='both',expand=True)
            left=ttk.Frame(columns);left.pack(side='left',fill='both',expand=True,padx=(0,10))
            right=ttk.Frame(columns);right.pack(side='left',fill='both',expand=True)
            status = card(left,'Live alignment')
            ttk.Label(status, textvariable=self.state, style='Status.TLabel', wraplength=450).pack(anchor='w')
            ttk.Label(status, textvariable=self.info, style='CardMuted.TLabel', wraplength=450).pack(anchor='w', pady=(5, 0))
            layers = card(left, 'Show on map')
            for tier, label, detail, color in [('gems', 'Gems', '86 possible spawn locations', '#f486dd'),
                    ('ingredients', 'Ingredients', 'Beans, bamboo shoots and crabs', '#a9e887')]:
                line = row(layers)
                ttk.Label(line, text='●', foreground=color, style='Card.TLabel').pack(side='left', padx=(0, 8))
                ttk.Checkbutton(line, text=label, style='Card.TCheckbutton', variable=self.layers[tier], command=self.changed).pack(side='left')
                ttk.Label(line, text=detail, style='CardMuted.TLabel').pack(side='right')
            ttk.Label(layers, textvariable=self.count, style='CardMuted.TLabel', wraplength=450).pack(anchor='w', pady=(5, 0))
            timers = card(right, 'History & timers')
            actions = row(timers)
            ttk.Button(actions, text='Mark collected', command=self.pickups.show_collect).pack(side='left')
            ttk.Button(actions, text='Pickup history', command=self.pickups.show_history).pack(side='left', padx=8)
            line = row(timers)
            ttk.Checkbutton(line, text='Pickup timers', style='Card.TCheckbutton', variable=self.show_timers, command=self.changed).pack(side='left')
            ttk.Checkbutton(line, text='Sighting timers (1h 15s)', style='Card.TCheckbutton', variable=self.show_sighting_timers, command=self.changed).pack(side='right')
            ttk.Label(timers, textvariable=self.pickups.summary, style='CardMuted.TLabel').pack(anchor='w')
            appearance = card(right, 'Appearance')
            ttk.Checkbutton(appearance, text='Shade ingredient areas', style='Card.TCheckbutton', variable=self.fill, command=self.changed).pack(anchor='w')
            for label, variable, low, high in [('Dot size', self.size, 3, 9), ('Opacity', self.opacity, .3, 1.)]:
                line = row(appearance)
                ttk.Label(line, text=label, style='Card.TLabel', width=9).pack(side='left')
                ttk.Scale(line, from_=low, to=high, variable=variable, command=lambda _: self.changed()).pack(side='left', fill='x', expand=True, pady=4)
            actions = ttk.Frame(body)
            actions.pack(fill='x', pady=(0, 10))
            self.pause_button = ttk.Button(actions, text='Pause', style='Primary.TButton', command=self.toggle_pause)
            self.pause_button.pack(side='left')
            ttk.Button(actions, text='Re-align', command=self.worker.request_scan).pack(side='left', padx=6)
            ttk.Button(actions, text='Save debug', command=self.save_debug).pack(side='left')
            def wrap_map(event):
                for panel in (status,layers,timers,appearance):
                    for widget in panel.winfo_children():
                        if isinstance(widget,ttk.Label):widget.configure(wraplength=max(150,panel.winfo_width()-36))
            body.bind('<Configure>',wrap_map)
            ttk.Label(body, text='Dots are candidate locations; teal = recent sightings.\nOpen Loong Haven at default zoom to show the overlay.', style='Muted.TLabel', font=(FONT, 9)).pack(anchor='w')

        def enabled_layers(self):
            return {'gems': self.layers['gems'].get(),
                    **dict.fromkeys(('common', 'rare', 'epic'), self.layers['ingredients'].get())}

        def save_debug(self):
            diagnostic=self.worker.get_diagnostics()
            if diagnostic is None:
                messagebox.showinfo('Map diagnostics','Open the map and bring MuMu to the foreground for a few seconds first.',parent=self.root)
                return
            frame, details=diagnostic
            details['capture_age_seconds']=round(time.perf_counter()-details.pop('age_reference'),2)
            details['layers']=self.enabled_layers()
            details['panel_state']=self.state.get()
            details['panel_info']=self.info.get()
            details['overlay_created']=bool(self.overlay.hwnd)
            details['overlay_capture_excluded']=self.overlay.excluded_from_capture
            details['version']='Gem Spy v40; persistent observations and recovery'
            try:
                success,encoded=cv2.imencode('.png',frame)
                if not success:raise OSError('Could not encode the captured map.')
                encoded.tofile(str(folder/'map-debug.png'))
                (folder/'map-debug.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
            except OSError as exc:
                messagebox.showerror('Could not save diagnostics',str(exc),parent=self.root)
                return
            messagebox.showinfo('Map diagnostics saved',f'Saved map-debug.png and map-debug.json in:\n{folder}\n\nThese are the last captured map and alignment details; the JSON records their age.',parent=self.root)
            os.startfile(str(folder))

        def changed(self):
            self.renderer.invalidate()
            self.settings_dirty = True
            if self.save_after:
                self.root.after_cancel(self.save_after)
            self.save_after = self.root.after(400, self.save_settings)
            if not any(v.get() for v in self.layers.values()):
                self.overlay.hide()

        def save_settings(self):
            self.save_after = None
            content = {'layers': self.enabled_layers(), 'ingredients': self.layers['ingredients'].get(),
                       'size': self.size.get(), 'opacity': self.opacity.get(), 'fill': self.fill.get(),
                       'show_timers': self.show_timers.get(), 'show_sighting_timers': self.show_sighting_timers.get(),
                       'reminder_minutes': self.pickups.default_minutes}
            try:
                tmp = settings_path.with_suffix('.tmp')
                tmp.write_text(json.dumps(content, indent=2), encoding='utf-8')
                tmp.replace(settings_path)
                self.settings_dirty = False
            except OSError:
                logging.exception('Could not save preferences')

        def toggle_pause(self):
            self.paused = not self.paused
            self.worker.pause(self.paused)
            self.pause_button.configure(text='Resume' if self.paused else 'Pause')
            self.overlay.hide()
            self.last_rect = None

        def live_activity(self,active):
            # Live scouting leaves the click-through map overlay running.
            self.worker.pause(self.paused)
            self.last_rect=None

        def tick(self):
            if self.closed:
                return
            try:
                self.pickups.refresh()
                snapshot = self.worker.get()
                enabled = self.enabled_layers()
                show = (not self.paused and any(enabled.values()) and snapshot['open']
                        and snapshot['match'] is not None and snapshot['rect'] is not None)
                if not show:
                    self.overlay.hide()
                    self.last_rect = None
                else:
                    rect = snapshot['rect']
                    start = time.perf_counter()
                    geometry=snapshot.get('geometry')
                    image, counts, changed = self.renderer.render((570,1029) if geometry is not None else rect[2:], snapshot['match'], enabled,
                                             self.size.get(), self.opacity.get(), self.fill.get(),
                                             pickup_markers=self.pickups.markers if self.show_timers.get() else (),
                                             sighting_markers=self.sightings.sighting_history.active_markers()
                                                 if self.show_sighting_timers.get() and enabled['gems'] else ())
                    if geometry is not None and (changed or self.last_rect!=rect):image=geometry.overlay(image)
                    self.render_ms = (time.perf_counter() - start) * 1000
                    if changed or self.last_rect != rect:
                        start = time.perf_counter()
                        if sum(counts.values()):
                            self.overlay.show_image(rect, image)
                        else:
                            self.overlay.hide()
                        self.upload_ms = (time.perf_counter() - start) * 1000
                        self.last_rect = rect
                        if self.overlay.hwnd and not self.overlay.excluded_from_capture:
                            # Avoid tracking our own pixels on unsupported capture configurations.
                            self.overlay.hide()
                            self.paused = True
                            self.worker.pause(True)
                            self.pause_button.configure(text='Resume')
                            messagebox.showerror('Capture exclusion unavailable',
                                'Windows could not exclude the overlay from screenshots. Markers have been paused to avoid self-tracking. Windows 10 version 2004 or newer is required.', parent=self.root)
                        shown = [f"Gems: {counts['gems']}"] if enabled['gems'] else []
                        if enabled['common']:
                            shown.append(f"Ingredients: {sum(counts[t] for t in ('common', 'rare', 'epic'))}")
                        self.count.set('   ·   '.join(shown))
                now = time.perf_counter()
                if now - self.last_status > .25:
                    self.last_status = now
                    self.state.set(snapshot['state'])
                    self.info.set(snapshot['info'])
                    self.metrics.set(f"{snapshot['fps']:.0f} capture FPS · alignment {snapshot['scan_ms']:.0f} ms\nDraw {self.render_ms:.1f} ms · upload {self.upload_ms:.1f} ms")
                    if not show:
                        self.count.set('Paused' if self.paused else 'Choose a resource layer' if not any(enabled.values())
                                       else 'Waiting for a visible, aligned map')
            except Exception as exc:
                self.overlay.hide()
                self.last_rect = None
                self.state.set('Overlay hidden — display error')
                self.info.set(str(exc)[:150])
                logging.exception('Display failed')
            self.root.after(16, self.tick)

        def close(self):
            if self.closed:
                return
            self.closed = True
            self.spy.close()
            self.live_patrol.close()
            self.sightings.close()
            self.save_settings()
            self.overlay.hide()
            self.worker.close()
            self.overlay.close()
            self.history.close()
            self.root.destroy()

    App().root.mainloop()

if __name__ == '__main__':
    main()
