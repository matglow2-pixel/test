"""Real Windows mouse input, scoped to the selected foreground MuMu window."""
from __future__ import annotations
import ctypes
from contextlib import contextmanager
from ctypes import wintypes
import threading
import time
import math
import numpy as np


class PatrolStopped(RuntimeError):
    pass


class NativeInput:
    def __init__(self):
        self.user=ctypes.WinDLL('user32',use_last_error=True)
        ULONG_PTR=ctypes.c_size_t
        class Mouse(ctypes.Structure):
            _fields_=[('dx',wintypes.LONG),('dy',wintypes.LONG),('mouseData',wintypes.DWORD),
                      ('dwFlags',wintypes.DWORD),('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
        class Keyboard(ctypes.Structure):
            _fields_=[('wVk',wintypes.WORD),('wScan',wintypes.WORD),('dwFlags',wintypes.DWORD),
                      ('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
        class Hardware(ctypes.Structure):
            _fields_=[('uMsg',wintypes.DWORD),('wParamL',wintypes.WORD),('wParamH',wintypes.WORD)]
        class Payload(ctypes.Union):
            _fields_=[('mi',Mouse),('ki',Keyboard),('hi',Hardware)]
        class Input(ctypes.Structure):
            _anonymous_=('data',)
            _fields_=[('type',wintypes.DWORD),('data',Payload)]
        self.Input=Input
        self.user.SendInput.argtypes=[wintypes.UINT,ctypes.POINTER(Input),ctypes.c_int]
        self.user.SendInput.restype=wintypes.UINT
        self.user.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int]
        self.user.SetCursorPos.restype=wintypes.BOOL
        self.user.GetForegroundWindow.restype=wintypes.HWND
        self.user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT]
        self.user.GetAncestor.restype=wintypes.HWND
        self.user.SetForegroundWindow.argtypes=[wintypes.HWND]
        self.user.SetForegroundWindow.restype=wintypes.BOOL
        self.user.GetWindowRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
        self.user.GetWindowRect.restype=wintypes.BOOL
        self.user.GetAsyncKeyState.argtypes=[ctypes.c_int]
        self.user.GetAsyncKeyState.restype=wintypes.SHORT
        self.user.GetCursorPos.argtypes=[ctypes.POINTER(wintypes.POINT)]
        self.user.GetCursorPos.restype=wintypes.BOOL
        self.user.GetClientRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
        self.user.GetClientRect.restype=wintypes.BOOL
        self.user.ClientToScreen.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.POINT)]
        self.user.ClientToScreen.restype=wintypes.BOOL
        self.user.SendMessageTimeoutW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM,
                                              wintypes.UINT,wintypes.UINT,ctypes.POINTER(ctypes.c_size_t)]
        self.user.SendMessageTimeoutW.restype=wintypes.LPARAM
        self.user.ClipCursor.argtypes=[ctypes.POINTER(wintypes.RECT)]
        self.user.ClipCursor.restype=wintypes.BOOL
        self.user.GetClipCursor.argtypes=[ctypes.POINTER(wintypes.RECT)]
        self.user.GetClipCursor.restype=wintypes.BOOL

    def cursor(self):
        point=wintypes.POINT()
        if not self.user.GetCursorPos(ctypes.byref(point)):raise OSError('Could not read the Windows cursor.')
        return point.x,point.y

    def client_hit(self,hwnd,point):
        x,y=point;result=ctypes.c_size_t()
        location=(x&0xffff)|((y&0xffff)<<16)
        if not self.user.SendMessageTimeoutW(hwnd,0x84,0,location,0x2,100,ctypes.byref(result)):
            raise RuntimeError('MuMu did not answer its window-border check.')
        return result.value==1  # HTCLIENT; resize borders/caption are not map input.

    def input_rect(self,hwnd):
        rect=wintypes.RECT();origin=wintypes.POINT()
        if not self.user.GetClientRect(hwnd,ctypes.byref(rect)) or not self.user.ClientToScreen(hwnd,ctypes.byref(origin)):
            raise RuntimeError('Could not read the MuMu client area.')
        left,top,right,bottom=origin.x,origin.y,origin.x+rect.right,origin.y+rect.bottom
        cx,cy=(left+right)//2,(top+bottom)//2
        # Some frameless emulator windows include resize pixels in their client
        # rectangle. Ask Windows about those exact pixels; add no fixed margin.
        while left<cx and not self.client_hit(hwnd,(left,cy)):left+=1
        while right>cx and not self.client_hit(hwnd,(right-1,cy)):right-=1
        while top<cy and not self.client_hit(hwnd,(cx,top)):top+=1
        while bottom>cy and not self.client_hit(hwnd,(cx,bottom-1)):bottom-=1
        if left>=cx or right<=cx or top>=cy or bottom<=cy:
            raise RuntimeError('MuMu has no usable client input area.')
        return left,top,right,bottom

    def clip(self,rect):
        native=wintypes.RECT(*rect)
        if not self.user.ClipCursor(ctypes.byref(native)):raise OSError('Could not confine the mouse to MuMu.')

    def clip_rect(self):
        rect=wintypes.RECT()
        if not self.user.GetClipCursor(ctypes.byref(rect)):raise OSError('Could not read cursor confinement.')
        return rect.left,rect.top,rect.right,rect.bottom

    def mouse(self,flags):
        event=self.Input();event.type=0;event.mi.dwFlags=flags
        if self.user.SendInput(1,ctypes.byref(event),ctypes.sizeof(event))!=1:
            raise OSError('Windows refused mouse input. Run Loong Lens and MuMu at the same privilege level.')

    def left_down(self):
        return bool(self.user.GetAsyncKeyState(0x01)&0x8000)

    def key(self,vk,up=False):
        event=self.Input();event.type=1;event.ki.wVk=vk;event.ki.dwFlags=2 if up else 0
        if self.user.SendInput(1,ctypes.byref(event),ctypes.sizeof(event))!=1:
            raise OSError('Windows refused the keyboard input test.')


class WindowsBackend:
    def __init__(self,cancel,find=None,geometry=None):
        import win_overlay as overlay
        self.find=find or overlay.find_visible_emulator
        self.visible_at=overlay.window_visible_at
        self.geometry_provider=geometry or (getattr(overlay,'game_geometry',None) if find is None else None)
        self.view=None
        self.cancel=cancel;self.api=NativeInput();self.target=None;self.screen=None
        self.down=False
        self.input_rect=None;self._clip_saved=None;self._clip_owned=None

    def __enter__(self):
        import mss
        self.screen=mss.mss();return self

    def __exit__(self,*args):
        self.release()
        if self.screen is not None:self.screen.close()

    def wait(self,seconds):
        if self.cancel.wait(seconds):raise PatrolStopped('Stopped.')

    def focus(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        self.target=self.find()
        if self.target is None:raise RuntimeError('MuMu was not found. Keep its window visible.')
        hwnd,_=self.target
        self.api.user.SetForegroundWindow(hwnd)
        self.wait(.25)
        self.guard()
        self.input_rect=self.api.input_rect(hwnd)
        self.view=self.geometry_provider(*self.target) if self.geometry_provider is not None else None
        if self.view is not None:
            x,y,w,h=self.view.content;a,b,c,d=self.input_rect
            self.input_rect=(max(a,x),max(b,y),min(c,x+w),min(d,y+h))
            left,top,right,bottom=self.input_rect
            self.drag_bounds=(*self.view.reference((left,top)),*self.view.reference((right-1,bottom-1)))
        else:
            x,y,w,h=self.target[1];left,top,right,bottom=self.input_rect
            self.drag_bounds=((left-x)*570/w,(top-y)*1029/h,
                              (right-1-x)*570/w,(bottom-1-y)*1029/h)

    def guard(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        hwnd,rect=self.target
        current=wintypes.RECT()
        if not self.api.user.GetWindowRect(hwnd,ctypes.byref(current)):
            raise RuntimeError('MuMu was closed.')
        bounds=(current.left,current.top,current.right-current.left,current.bottom-current.top)
        if bounds!=tuple(rect):raise RuntimeError('MuMu moved or resized. Start the check again.')
        view=getattr(self,'view',None)
        if view is not None and view.child:
            child=wintypes.RECT()
            if not self.api.user.GetWindowRect(view.child,ctypes.byref(child)) or (child.left,child.top,child.right-child.left,child.bottom-child.top)!=view.content:
                raise RuntimeError('MuMu game area changed. Start the check again.')
        active=self.api.user.GetAncestor(self.api.user.GetForegroundWindow(),2)
        if active!=hwnd:raise RuntimeError('MuMu lost focus; patrol stopped.')

    def point(self,reference):
        rx,ry=reference
        if not (math.isfinite(rx) and math.isfinite(ry) and 0<=rx<570 and 0<=ry<1029):
            raise ValueError('Input point is outside the MuMu screenshot.')
        view=getattr(self,'view',None)
        if view is not None:return view.point(reference)
        x,y,w,h=self.target[1]
        return min(x+w-1,round(x+rx*w/570)),min(y+h-1,round(y+ry*h/1029))

    def client_point(self,point):
        rect=getattr(self,'input_rect',None)
        if rect is not None and not (rect[0]<=point[0]<rect[2] and rect[1]<=point[1]<rect[3]):
            raise RuntimeError('Mouse target is on the MuMu window border, not its map surface.')
        if not self.api.client_hit(self.target[0],point):
            raise RuntimeError('Mouse target is a MuMu resize border or title bar.')

    def verify_cursor(self,expected):
        actual=self.api.cursor()
        if actual!=expected:raise RuntimeError('The mouse did not reach the intended map point. Input stopped.')
        self.client_point(actual)

    def confine(self):
        rect=getattr(self,'input_rect',None)
        if rect is None:return
        self._clip_saved=self.api.clip_rect();self.api.clip(rect);self._clip_owned=rect

    def move(self,reference):
        self.guard();point=self.point(reference)
        self.client_point(point)
        if not self.visible_at(self.target[0],*point):raise RuntimeError('Another window covers the click point.')
        if not self.api.user.SetCursorPos(*point):raise OSError('Windows could not move the mouse.')
        self.guard();self.verify_cursor(point)

    def release(self):
        try:
            if self.down:
                try:self.api.mouse(0x0004)
                finally:self.down=False
        finally:
            owned=getattr(self,'_clip_owned',None)
            if owned is not None:
                try:
                    if self.api.clip_rect()==owned:self.api.clip(self._clip_saved)
                finally:self._clip_owned=None;self._clip_saved=None

    def click(self,reference):
        try:
            self.confine();self.move(reference)
            self.guard();self.verify_cursor(self.point(reference))
            self.down=True;self.api.mouse(0x0002);self.wait(.08)
        finally:self.release()

    def drag(self,start,end):
        try:
            self.confine();self.move(start)
            self.guard();self.down=True;self.api.mouse(0x0002)
            steps=max(4,min(18,math.ceil(math.dist(start,end)/24)))
            for i in range(1,steps+1):
                self.wait(.02)
                self.move((start[0]+(end[0]-start[0])*i/steps,start[1]+(end[1]-start[1])*i/steps))
            # Release from a stationary endpoint, rather than a moving swipe.
            # This prevents the game's fling/inertia from carrying the map on.
            self.wait(.18)
        finally:self.release()

    @contextmanager
    def hold_drag(self,start):
        """Keep one guarded mouse hold across moves and screenshot checks."""
        from patrol_route import route_point_visible
        if not route_point_visible(start):raise ValueError('Drag start overlaps map controls.')
        if self.down:raise RuntimeError('A mouse button is already held.')
        try:
            self.confine();self.move(start)
            self.guard();self.down=True;self.api.mouse(0x0002)
            self._drag_position=tuple(start)
            self.wait(.025)  # Let the emulator receive down before fast motion.
            self.require_hold()
            yield
            # Do not move the cursor during this pause or after releasing.
            self.wait(.18)
            self.guard()
        finally:
            self.release();self._drag_position=None

    def require_hold(self):
        if not self.down or not self.api.left_down():
            raise RuntimeError('The mouse hold was released. Patrol stopped before moving the cursor.')
        if getattr(self,'input_rect',None) is not None:
            self.verify_cursor(self.point(self._drag_position))

    def drag_held_to(self,end):
        from patrol_route import route_point_visible
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        if not self.down or getattr(self,'_drag_position',None) is None:
            raise RuntimeError('Start a held drag before moving it.')
        start=self._drag_position
        steps=max(1,math.ceil(math.dist(start,end)/24))
        points=[(start[0]+(end[0]-start[0])*i/steps,start[1]+(end[1]-start[1])*i/steps)
                for i in range(1,steps+1)]
        if not all(route_point_visible(point) for point in points):
            raise ValueError('Held movement overlaps map controls.')
        for point in points:
            self.wait(.008)
            self.require_hold()
            self.move(point);self._drag_position=point

    def capture(self):
        self.guard()
        hwnd,rect=self.target
        view=getattr(self,'view',None);x,y,w,h=view.content if view is not None else rect
        # No other desktop window may contribute pixels to detection/history.
        if not all(self.visible_at(hwnd,x+px,y+py)
                   for py in np.linspace(10,h-11,max(2,(h+47)//48))
                   for px in np.linspace(10,w-11,max(2,(w+47)//48))):
            raise RuntimeError('MuMu is covered. Move Loong Lens and other windows aside.')
        frame=np.asarray(self.screen.grab(dict(left=x,top=y,width=w,height=h)))[:,:,:3].copy()
        return view.normalize(frame) if view is not None else frame

    @staticmethod
    def peek():
        """A calibration screenshot; no focus changes or inputs."""
        import mss
        from win_overlay import find_visible_emulator,game_geometry,window_visible_at
        target=find_visible_emulator()
        if target is None:raise RuntimeError('Keep MuMu visible first.')
        view=game_geometry(*target);x,y,w,h=view.content
        if not all(window_visible_at(target[0],x+px,y+py) for py in np.linspace(10,h-11,6) for px in np.linspace(10,w-11,4)):
            raise RuntimeError('MuMu is covered. Move other windows aside before picking a map button.')
        with mss.mss() as screen:
            frame=np.asarray(screen.grab(dict(left=x,top=y,width=w,height=h)))[:,:,:3].copy()
        return view.normalize(frame)


class GlobalPatrolKeys:
    """Register only while live controls are enabled; stop callback is immediate."""
    def __init__(self,advance,stop,key='F8'):
        self.advance=advance;self.stop=stop;self.key=key
        self.ready=threading.Event();self.thread_id=None;self.error=None
        self.thread=threading.Thread(target=self._run,daemon=True,name='LoongLens-hotkeys')
        self.thread.start()
        if not self.ready.wait(3):raise RuntimeError('Could not start the global hotkeys.')
        if self.error:raise RuntimeError(self.error)

    def _run(self):
        user=ctypes.WinDLL('user32',use_last_error=True)
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.thread_id=kernel.GetCurrentThreadId()
        # Create the message queue before another thread can request shutdown.
        msg=wintypes.MSG();user.PeekMessageW(ctypes.byref(msg),None,0,0,0)
        registered=[]
        try:
            for ident,vk in ((1,0x79),(2,0x70+int(self.key[1:])-1)):
                if not user.RegisterHotKey(None,ident,0x4000,vk):
                    raise RuntimeError(f'{"F10" if ident==1 else self.key} is already in use. Choose another advance key or close the conflicting app.')
                registered.append(ident)
            self.ready.set()
            while user.GetMessageW(ctypes.byref(msg),None,0,0)>0:
                if msg.message==0x0312:
                    (self.stop if msg.wParam==1 else self.advance)()
        except Exception as exc:self.error=str(exc)
        finally:
            self.ready.set()
            for ident in registered:user.UnregisterHotKey(None,ident)

    def close(self):
        if self.thread_id:
            ctypes.WinDLL('user32',use_last_error=True).PostThreadMessageW(self.thread_id,0x0012,0,0)
        self.thread.join(timeout=2)
