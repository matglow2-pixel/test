"""Windows screenshot-only, click-through per-pixel-alpha display backend."""
import ctypes
import sys
from pathlib import PureWindowsPath
from emulator_view import mumu_device_window,portrait_view
from ctypes import wintypes
import numpy as np

if sys.platform != 'win32':
    raise RuntimeError('The live overlay requires Windows. Use --self-check on other systems.')

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try: ctypes.windll.user32.SetProcessDPIAware()
    except Exception: pass

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
kernel32 = ctypes.windll.kernel32

# Full pointer-sized signatures prevent truncated HWND / GDI handles on 64-bit Windows.
user32.EnumWindows.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
user32.EnumWindows.restype = wintypes.BOOL
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextLengthW.restype = ctypes.c_int
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowTextW.restype = ctypes.c_int
user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.c_void_p]
user32.GetWindowRect.restype = wintypes.BOOL
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.IsWindowVisible.restype = wintypes.BOOL
user32.IsIconic.argtypes = [wintypes.HWND]
user32.IsIconic.restype = wintypes.BOOL
user32.CreateWindowExW.argtypes = [wintypes.DWORD,wintypes.LPCWSTR,wintypes.LPCWSTR,wintypes.DWORD,
    ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,wintypes.HWND,wintypes.HMENU,wintypes.HINSTANCE,ctypes.c_void_p]
user32.CreateWindowExW.restype = wintypes.HWND
user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
user32.SetWindowPos.argtypes=[wintypes.HWND,wintypes.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,wintypes.UINT]
user32.SetWindowPos.restype=wintypes.BOOL
user32.UpdateLayeredWindow.argtypes=[wintypes.HWND,wintypes.HDC,ctypes.c_void_p,ctypes.c_void_p,
    wintypes.HDC,ctypes.c_void_p,wintypes.COLORREF,ctypes.c_void_p,wintypes.DWORD]
user32.UpdateLayeredWindow.restype=wintypes.BOOL
user32.GetDC.argtypes=[wintypes.HWND]
user32.GetDC.restype=wintypes.HDC
user32.ReleaseDC.argtypes=[wintypes.HWND,wintypes.HDC]
user32.ReleaseDC.restype=ctypes.c_int
user32.DestroyWindow.argtypes=[wintypes.HWND]
gdi32.CreateCompatibleDC.argtypes=[wintypes.HDC]
gdi32.CreateCompatibleDC.restype=wintypes.HDC
gdi32.CreateDIBSection.argtypes=[wintypes.HDC,ctypes.c_void_p,wintypes.UINT,
    ctypes.POINTER(ctypes.c_void_p),wintypes.HANDLE,wintypes.DWORD]
gdi32.CreateDIBSection.restype=wintypes.HBITMAP
gdi32.SelectObject.argtypes=[wintypes.HDC,wintypes.HGDIOBJ]
gdi32.SelectObject.restype=wintypes.HGDIOBJ
gdi32.DeleteObject.argtypes=[wintypes.HGDIOBJ]
gdi32.DeleteDC.argtypes=[wintypes.HDC]
kernel32.GetModuleHandleW.argtypes=[wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype=wintypes.HMODULE

class RECT(ctypes.Structure):
    _fields_=[('left',ctypes.c_long),('top',ctypes.c_long),('right',ctypes.c_long),('bottom',ctypes.c_long)]
class POINT(ctypes.Structure):
    _fields_=[('x',ctypes.c_long),('y',ctypes.c_long)]
class SIZE(ctypes.Structure):
    _fields_=[('cx',ctypes.c_long),('cy',ctypes.c_long)]
class BLENDFUNCTION(ctypes.Structure):
    _fields_=[('BlendOp',ctypes.c_ubyte),('BlendFlags',ctypes.c_ubyte),('SourceConstantAlpha',ctypes.c_ubyte),('AlphaFormat',ctypes.c_ubyte)]
class BITMAPINFOHEADER(ctypes.Structure):
    _fields_=[('biSize',wintypes.DWORD),('biWidth',ctypes.c_long),('biHeight',ctypes.c_long),
              ('biPlanes',wintypes.WORD),('biBitCount',wintypes.WORD),('biCompression',wintypes.DWORD),
              ('biSizeImage',wintypes.DWORD),('biXPelsPerMeter',ctypes.c_long),('biYPelsPerMeter',ctypes.c_long),
              ('biClrUsed',wintypes.DWORD),('biClrImportant',wintypes.DWORD)]
class BITMAPINFO(ctypes.Structure):
    _fields_=[('bmiHeader',BITMAPINFOHEADER),('bmiColors',wintypes.DWORD*3)]

user32.GetForegroundWindow.restype=wintypes.HWND
user32.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT]
user32.GetAncestor.restype=wintypes.HWND
user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowThreadProcessId.restype=wintypes.DWORD
user32.EnumChildWindows.argtypes=[wintypes.HWND,ctypes.c_void_p,wintypes.LPARAM]
user32.EnumChildWindows.restype=wintypes.BOOL
kernel32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel32.OpenProcess.restype=wintypes.HANDLE
kernel32.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
kernel32.QueryFullProcessImageNameW.restype=wintypes.BOOL
kernel32.CloseHandle.argtypes=[wintypes.HANDLE]
_process_names={}
_game_views={}

def process_name(hwnd):
    pid=wintypes.DWORD();user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
    key=(int(hwnd),pid.value)
    if key in _process_names:return _process_names[key]
    handle=kernel32.OpenProcess(0x1000,False,pid.value)
    if not handle:return ''
    try:
        size=wintypes.DWORD(32768);name=ctypes.create_unicode_buffer(size.value)
        result=PureWindowsPath(name.value).name if kernel32.QueryFullProcessImageNameW(handle,0,name,ctypes.byref(size)) else ''
    finally:kernel32.CloseHandle(handle)
    # A window/PID change invalidates the identity; never cache full paths.
    if len(_process_names)>128:_process_names.clear()
    _process_names[key]=result
    return result

EMULATOR_WINDOWS=[]
@ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
def _enum_window(hwnd,_):
    if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
        return True
    n=user32.GetWindowTextLengthW(hwnd)
    if n < 0: return True
    title=ctypes.create_unicode_buffer(n+1)
    user32.GetWindowTextW(hwnd,title,n+1)
    bounds=RECT()
    if user32.GetWindowRect(hwnd,ctypes.byref(bounds)):
        width,height=bounds.right-bounds.left,bounds.bottom-bounds.top
        if mumu_device_window(title.value,process_name(hwnd),width,height):
            EMULATOR_WINDOWS.append((int(hwnd),(bounds.left,bounds.top,width,height)))
    return True

def find_emulator():
    EMULATOR_WINDOWS.clear()
    user32.EnumWindows(_enum_window,0)
    foreground=user32.GetAncestor(user32.GetForegroundWindow(),2)
    active=[entry for entry in EMULATOR_WINDOWS if entry[0]==foreground]
    return max(active,key=lambda e:e[1][2]*e[1][3])[1] if active else None

def find_visible_emulator():
    """Watcher mode: MuMu may stay visible on a second monitor without focus."""
    EMULATOR_WINDOWS.clear()
    user32.EnumWindows(_enum_window,0)
    active=user32.GetAncestor(user32.GetForegroundWindow(),2)
    preferred=[entry for entry in EMULATOR_WINDOWS if entry[0]==active]
    return max(preferred or EMULATOR_WINDOWS,key=lambda e:e[1][2]*e[1][3]) if EMULATOR_WINDOWS else None

def game_geometry(hwnd,window):
    from patrol_windows import NativeInput
    cached=_game_views.get(hwnd)
    if cached is not None and cached.window==tuple(window):
        if not cached.child:return cached
        bounds=RECT()
        if user32.GetWindowRect(cached.child,ctypes.byref(bounds)) and (bounds.left,bounds.top,bounds.right-bounds.left,bounds.bottom-bounds.top)==cached.content:return cached
    client=NativeInput().input_rect(hwnd)
    children=[]
    @ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    def child(handle,_):
        if user32.IsWindowVisible(handle):
            bounds=RECT()
            if user32.GetWindowRect(handle,ctypes.byref(bounds)):
                children.append((int(handle),(bounds.left,bounds.top,bounds.right-bounds.left,bounds.bottom-bounds.top)))
        return True
    user32.EnumChildWindows(hwnd,child,0)
    view=portrait_view(window,client,children)
    if len(_game_views)>32:_game_views.clear()
    _game_views[hwnd]=view
    return view


def find_game_view():
    target=find_visible_emulator()
    if target is None:return None
    active=user32.GetAncestor(user32.GetForegroundWindow(),2)
    if active!=target[0]:return None
    try:return game_geometry(*target)
    except RuntimeError:return None


def window_visible_at(hwnd, x, y):
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    pointed = user32.WindowFromPoint(POINT(round(x), round(y)))
    return user32.GetAncestor(pointed, 2) == hwnd


class PixelAlphaOverlay:
    """Native premultiplied RGBA layered window: cannot have an opaque canvas background."""
    def __init__(self):
        self.hwnd=None
        self.location=None
        self.excluded_from_capture=False
        self._dc=None
        self._screen_dc=None
        self._bitmap=None
        self._previous=None
        self._bits=None
        self._bitmap_size=None

    def _create(self):
        if self.hwnd: return
        WS_POPUP=0x80000000
        WS_EX_LAYERED=0x80000
        WS_EX_TRANSPARENT=0x20
        WS_EX_TOOLWINDOW=0x80
        WS_EX_NOACTIVATE=0x08000000
        WS_EX_TOPMOST=0x8
        self.hwnd=user32.CreateWindowExW(
            WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE|WS_EX_TOPMOST,
            'STATIC','SXS Resource Markers',WS_POPUP,0,0,1,1,None,None,kernel32.GetModuleHandleW(None),None)
        if not self.hwnd:
            raise OSError('Windows could not create the transparent marker layer')
        # On supported Windows versions, exclude our own markers from screenshot tracking.
        try:
            affinity=user32.SetWindowDisplayAffinity
            affinity.argtypes=[wintypes.HWND,wintypes.DWORD]
            affinity.restype=wintypes.BOOL
            self.excluded_from_capture=bool(affinity(self.hwnd,0x11))
        except Exception:
            pass

    def hide(self):
        if self.hwnd: user32.ShowWindow(self.hwnd,0)

    def _free_bitmap(self):
        if self._dc:
            if self._previous:gdi32.SelectObject(self._dc,self._previous)
            if self._bitmap:gdi32.DeleteObject(self._bitmap)
            gdi32.DeleteDC(self._dc)
        if self._screen_dc:user32.ReleaseDC(None,self._screen_dc)
        self._dc=self._screen_dc=self._bitmap=self._previous=self._bits=None
        self._bitmap_size=None

    def close(self):
        self._free_bitmap()
        if self.hwnd:
            user32.DestroyWindow(self.hwnd)
            self.hwnd=None

    def _ensure_bitmap(self,w,h):
        if self._bitmap_size==(w,h):return
        self._free_bitmap()
        screen_dc=user32.GetDC(None)
        memdc=gdi32.CreateCompatibleDC(screen_dc)
        bmi=BITMAPINFO()
        bmi.bmiHeader.biSize=ctypes.sizeof(BITMAPINFOHEADER)
        bmi.bmiHeader.biWidth=w
        bmi.bmiHeader.biHeight=-h
        bmi.bmiHeader.biPlanes=1
        bmi.bmiHeader.biBitCount=32
        bmi.bmiHeader.biCompression=0
        bits=ctypes.c_void_p()
        bmp=gdi32.CreateDIBSection(screen_dc,ctypes.byref(bmi),0,ctypes.byref(bits),None,0)
        if not screen_dc or not memdc or not bmp or not bits.value:
            if bmp:gdi32.DeleteObject(bmp)
            if memdc:gdi32.DeleteDC(memdc)
            if screen_dc:user32.ReleaseDC(None,screen_dc)
            raise OSError('Could not initialize alpha display surface')
        original=gdi32.SelectObject(memdc,bmp)
        self._screen_dc=screen_dc
        self._dc=memdc
        self._bitmap=bmp
        self._previous=original
        self._bits=bits.value
        self._bitmap_size=(w,h)

    def show_image(self,rect,img):
        self._create()
        x,y,w,h=rect
        if img.size!=(w,h):
            raise ValueError('Overlay size does not match MuMu window')
        # UpdateLayeredWindow requires premultiplied BGRA, not opaque chroma-key pixels.
        rgba=np.asarray(img,dtype=np.uint8)
        alpha=rgba[:,:,3:4].astype(np.uint16)
        pre=(rgba[:,:,:3].astype(np.uint16)*alpha//255).astype(np.uint8)
        bgra=np.empty((h,w,4),np.uint8)
        bgra[:,:,0]=pre[:,:,2]; bgra[:,:,1]=pre[:,:,1]; bgra[:,:,2]=pre[:,:,0]
        bgra[:,:,3]=rgba[:,:,3]
        mem=bgra.tobytes()
        # Reuse the same DC and bitmap on every frame; no GDI churn while panning.
        self._ensure_bitmap(w,h)
        ctypes.memmove(self._bits,mem,len(mem))
        position=POINT(x,y)
        size=SIZE(w,h)
        origin=POINT(0,0)
        blend=BLENDFUNCTION(0,0,255,1)
        if not user32.UpdateLayeredWindow(self.hwnd,self._screen_dc,
                     ctypes.byref(position),ctypes.byref(size),
                     self._dc,ctypes.byref(origin),0,ctypes.byref(blend),2):
            raise OSError('Windows refused the transparent alpha render')
        # NEVER show the window until Windows has successfully drawn transparent pixels.
        user32.SetWindowPos(self.hwnd,ctypes.c_void_p(-1),x,y,w,h,0x0010|0x0040)
        user32.ShowWindow(self.hwnd,8)  # SW_SHOWNA: don't steal keyboard focus
        self.location=rect



