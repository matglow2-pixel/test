"""Native Windows checks on a disposable MuMu-shaped Tk device window."""
import ctypes
from ctypes import wintypes
from pathlib import Path
import queue
import threading
import time
import tkinter as tk

import cv2
import numpy as np
from PIL import Image, ImageTk

from emulator_view import REFERENCE_GAME
from patrol_windows import WindowsBackend, GlobalPatrolKeys, PatrolStopped
from resources import ROOT


def map_fixture():
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    tx=285-130*12.45;ty=530+160*12.45
    frame=cv2.warpAffine(atlas,np.float32([[1,0,tx],[0,1,ty-279*12.45]]),(570,1029))
    controls=cv2.imread(str(ROOT/'tests/fixtures/map-controls.png'))
    for l,t,r,b in ((12,938,124,1026),(520,620,557,927),(138,940,555,1016)):
        frame[t:b,l:r]=controls[t:b,l:r]
    title=cv2.imread(str(ROOT/'loong_title_template.png'));h,w=title.shape[:2]
    frame[55:55+h,20:20+w]=title
    return frame


def check_mumu_input():
    import win_overlay
    cv2.setNumThreads(2)
    root=tk.Tk();root.title('Android Device');root.overrideredirect(True)
    root.geometry('560x1033+40+0');root.configure(bg='#222222')
    toolbar=tk.Frame(root,bg='#242424');toolbar.place(x=0,y=0,width=560,height=40)
    tk.Label(toolbar,text='Android Device',bg='#242424',fg='white').pack(side='left',padx=8)
    toolbar_clicks=[]
    tk.Button(toolbar,text='Keyboard',command=lambda:toolbar_clicks.append(True)).pack(side='right')
    canvas=tk.Canvas(root,bg='#152a32',highlightthickness=0,borderwidth=0)
    canvas.place(x=1,y=40,width=558,height=992)
    expected=map_fixture();l,t,r,b=REFERENCE_GAME
    source=cv2.cvtColor(expected[t:b,l:r],cv2.COLOR_BGR2RGB)
    photo=ImageTk.PhotoImage(Image.fromarray(source).resize((558,992),Image.Resampling.BILINEAR),master=root)
    canvas.create_image(0,0,image=photo,anchor='nw');canvas.photo=photo
    manager=tk.Toplevel(root);manager.title('MuMuPlayer');manager.geometry('860x580+800+60')
    tk.Label(manager,text='Disposable MuMu device manager — must not be selected').pack()
    decoy=tk.Toplevel(root);decoy.title('MuMuPlayer documentation');decoy.geometry('400x650+1100+160')
    counts={'down':0,'up':0,'motion':0};positions=[];result=queue.Queue();completed=[]
    canvas.bind('<ButtonPress-1>',lambda e:(counts.update(down=counts['down']+1),positions.append((e.x_root,e.y_root))))
    canvas.bind('<ButtonRelease-1>',lambda e:counts.update(up=counts['up']+1))
    canvas.bind('<B1-Motion>',lambda e:counts.update(motion=counts['motion']+1))
    saved_name=win_overlay.process_name
    user=ctypes.WinDLL('user32',use_last_error=True)
    user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];user.GetAncestor.restype=wintypes.HWND
    ids={};thread=[None]

    def start():
        for name,window in (('device',root),('manager',manager),('decoy',decoy)):
            ids[name]=int(user.GetAncestor(window.winfo_id(),2))
        def executable(hwnd):
            return ('MuMuNxDevice.exe' if hwnd==ids['device'] else
                    'MuMuPlayer.exe' if hwnd==ids['manager'] else
                    'chrome.exe' if hwnd==ids['decoy'] else saved_name(hwnd))
        win_overlay.process_name=executable
        def run():
            cancel=threading.Event();keys=None
            try:
                with WindowsBackend(cancel) as backend:
                    backend.focus()
                    assert backend.target[0]==ids['device'],'Manager or browser was selected'
                    assert backend.view is not None
                    x,y,w,h=backend.view.content
                    assert (x,y,w,h)==(41,40,558,992),backend.view
                    assert win_overlay.find_game_view()==backend.view
                    original_clip=backend.api.clip_rect();before=backend.api.cursor()
                    try:backend.click((285,20))
                    except RuntimeError as exc:assert 'border' in str(exc)
                    else:raise AssertionError('Toolbar accepted a gameplay click')
                    assert backend.api.cursor()==before and backend.api.clip_rect()==original_clip
                    frame=backend.capture()
                    assert frame.shape==(1029,570,3) and not frame[:34].any()
                    from vision import TitleDetector,Calibrator
                    assert TitleDetector().score(frame)>=.64
                    pose=Calibrator().locate(frame)
                    assert pose is not None and abs(pose.scale-12.45)<.15
                    assert np.linalg.norm(np.asarray(pose.project(130,160))-np.array((285,530)))<4
                    backend.click((285,530));backend.wait(.1)
                    # Independent native coordinates from the supplied body
                    # dimensions, not from the conversion under test.
                    assert positions and positions[-1]==(320,535),positions
                    with backend.hold_drag((285,530)):
                        backend.drag_held_to((380,450));backend.capture()
                        assert backend.api.left_down() and backend.api.clip_rect()==(41,40,599,1032)
                    assert not backend.down and backend.api.clip_rect()==original_clip
                    keys=GlobalPatrolKeys(lambda:None,lambda:(cancel.set(),backend.release()))
                    try:
                        with backend.hold_drag((285,530)):
                            backend.drag_held_to((300,500))
                            backend.api.key(0x79);backend.api.key(0x79,up=True)
                            if not cancel.wait(2):raise AssertionError('F10 did not cancel the MuMu hold')
                            backend.wait(.01)
                    except PatrolStopped:pass
                    else:raise AssertionError('F10 did not stop input')
                    assert not backend.down and not backend.api.left_down()
                    assert backend.api.clip_rect()==original_clip
                assert not toolbar_clicks
                result.put(None)
            except Exception:
                import traceback
                result.put(traceback.format_exc())
            finally:
                if keys is not None:keys.close()
        thread[0]=threading.Thread(target=run,daemon=True);thread[0].start()

    def finish():
        try:error=result.get_nowait()
        except queue.Empty:root.after(100,finish);return
        completed.append(error);root.destroy()
    root.after(500,start);root.after(600,finish)
    root.after(90000,lambda:(completed.append('MuMu input check timed out'),root.destroy()))
    try:root.mainloop()
    finally:
        win_overlay.process_name=saved_name
        win_overlay._game_views.clear()
        if thread[0] is not None:thread[0].join(3)
    assert completed and completed[0] is None,completed
    assert counts['down']>=3 and counts['up']>=3 and counts['motion']>0,counts
    return dict(device_window_selected=True,manager_and_browser_ignored=True,
        toolbar_excluded=True,capture_input_overlay_geometry=True,map_alignment_verified=True,
        native_game_click_delivered=True,held_drag_delivered=True,f10_released=True,
        scope='Actual Win32 mouse/capture/hotkeys on a simulated MuMu 6.8.9-shaped window. No live MuMu game session.')
