from types import SimpleNamespace
import threading

import cv2
import numpy as np
import pytest
from PIL import Image, ImageDraw

from emulator_view import GameView, REFERENCE_GAME, mumu_device_window, portrait_view
from patrol_windows import WindowsBackend

cv2.setNumThreads(2)


@pytest.mark.parametrize('title,name', [('Android Device','MuMuNxDevice.exe'),
    ('Sword x Staff','MuMuNxDevice.exe'),('',r'C:\Program Files\MuMu\MuMuNxDevice.exe'),
    ('MuMuPlayer','MuMuNxDevice.exe'),('MuMu Player 12','MuMuPlayer.exe'),
    ('MuMu','NemuPlayer.exe')])
def test_actual_device_identity_does_not_require_a_mumu_tab_title(title,name):
    assert mumu_device_window(title,name,560,1033)


@pytest.mark.parametrize('title,name,w,h', [('MuMuPlayer','MuMuPlayer.exe',860,580),
    ('MuMuPlayer','MuMuPlayer.exe',540,1000),('MuMuPlayer','Chrome.exe',560,1033),
    ('MuMuPlayer','notepad.exe',560,1033),('MuMu Multi-Instance Manager','MuMuNxDevice.exe',560,1033),
    ('Android Device','MuMuMultiPlayer.exe',560,1033),('Android Device','MuMuNxDevice.exe',1033,560)])
def test_manager_non_emulator_and_landscape_windows_are_not_mouse_targets(title,name,w,h):
    assert not mumu_device_window(title,name,w,h)


@pytest.mark.parametrize('offset', [(21,0),(110,0),(-900,100)])
def test_user_560_by_1033_window_excludes_40_pixel_toolbar(offset):
    x,y=offset
    view=portrait_view((x,y,560,1033),(x+1,y+1,x+559,y+1032))
    assert view.content==(x+1,y+40,558,992)
    assert view.point((285,531.5))==(x+280,y+536)
    assert view.point((64,980))[1]>y+970


def test_real_android_child_overrides_inferred_toolbar_geometry():
    outer=(100,50,560,1033);client=(100,50,660,1083)
    child=(101,90,558,992)
    view=portrait_view(outer,client,[(23,(100,50,560,40)),(24,child)])
    assert view.child==24 and view.content==child


def test_resize_hit_band_does_not_crop_the_rendered_android_surface():
    outer=(20,0,560,1033)
    eligible_client=(28,8,572,1025)
    actual_game=(21,40,558,992)
    view=portrait_view(outer,eligible_client,[(42,actual_game)])
    assert view.child==42 and view.content==actual_game
    # Source geometry is unchanged; the backend intersects mouse clipping
    # separately, preserving the original scene scale and camera positions.
    assert view.point((285,530))==(300,535)


@pytest.mark.parametrize('size', [(279,496),(558,992),(837,1488)])
def test_resize_and_dpi_use_one_capture_input_overlay_transform(size):
    w,h=size
    view=GameView((100,10,w+2,h+42),(101,50,w,h))
    for p in ((30,100),(285,530),(500,700),(64,980)):
        native=view.point(p);returned=view.reference(native)
        assert np.max(np.abs(np.asarray(p)-returned))<=1.9
    native=np.zeros((h,w,3),np.uint8);native[:]=(33,110,180)
    normalized=view.normalize(native)
    l,t,r,b=REFERENCE_GAME
    assert normalized.shape==(1029,570,3) and np.all(normalized[t:b,l:r]==[33,110,180])
    assert not normalized[:t].any()
    rgba=Image.new('RGBA',(570,1029));ImageDraw.Draw(rgba).ellipse((280,525,290,535),fill=(255,0,0,255))
    overlay=view.overlay(rgba);assert overlay.size==size
    ax,ay=view.point((285,530));assert overlay.getpixel((ax-101,ay-50))[3]>200


@pytest.mark.parametrize('point',[(0,500),(4,500),(565,500),(285,20),(285,1029)])
def test_toolbar_border_and_outside_pixels_cannot_be_translated_into_clicks(point):
    view=GameView((21,0,560,1033),(22,40,558,992))
    with pytest.raises(RuntimeError,match='toolbar or border'):view.point(point)


def test_capture_uses_only_game_pixels_and_point_uses_identical_mapping():
    value=WindowsBackend.__new__(WindowsBackend)
    value.view=GameView((110,0,560,1033),(111,40,558,992))
    value.target=(123,value.view.window);value.guard=lambda:None;value.visible_at=lambda *a:True
    grabs=[]
    def grab(rect):
        grabs.append(rect);frame=np.zeros((rect['height'],rect['width'],4),np.uint8)
        frame[:,:,:3]=(30,90,150);return frame
    value.screen=SimpleNamespace(grab=grab)
    frame=value.capture()
    assert grabs==[dict(left=111,top=40,width=558,height=992)]
    assert np.all(frame[34:1029,5:565]==[30,90,150])
    assert value.point((285,531.5))==(390,536)


def test_crop_mismatch_and_invalid_portrait_geometry_are_rejected():
    view=GameView((0,0,560,1033),(1,40,558,992))
    with pytest.raises(ValueError):view.normalize(np.zeros((1033,560,3),np.uint8))
    with pytest.raises(RuntimeError):portrait_view((0,0,860,580),(0,0,860,580))
    with pytest.raises(ValueError):GameView((0,0,560,1033),(1,40,600,992))
