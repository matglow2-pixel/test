"""Shared desktop styling and small layout helpers; no application state."""
import os
from tkinter import ttk

FONT = 'Segoe UI' if os.name == 'nt' else 'Helvetica'

BG = '#0c1622'
CARD = '#111f2e'
TEXT = '#f1f5fb'
MUTED = '#a4bed9'
ACCENT = '#56e5df'
BORDER = '#263d53'


def apply_theme(root):
    style = ttk.Style(root)
    style.theme_use('clam')
    style.configure('.', background=BG, foreground=TEXT, font=(FONT, 9))
    style.configure('TFrame', background=BG)
    style.configure('TLabel', background=BG)
    style.configure('Muted.TLabel', foreground=MUTED)
    style.configure('Title.TLabel', font=(FONT, 22, 'bold'))
    style.configure('Heading.TLabel', font=(FONT, 14, 'bold'))
    style.configure('Brand.TLabel', font=(FONT, 12, 'bold'))
    style.configure('Card.TFrame', background=CARD)
    style.configure('Panel.TFrame', background=CARD, borderwidth=1, relief='solid', bordercolor=BORDER)
    style.configure('Card.TLabel', background=CARD)
    style.configure('CardMuted.TLabel', background=CARD, foreground=MUTED, font=(FONT, 9))
    style.configure('CardTitle.TLabel', background=CARD, foreground=TEXT, font=(FONT, 10, 'bold'))
    style.configure('Metric.TLabel', background=CARD, foreground=TEXT, font=(FONT, 14, 'bold'))
    style.configure('Quota.TLabel', background=CARD, foreground=ACCENT, font=(FONT, 22, 'bold'))
    style.configure('Status.TLabel', background=CARD, font=(FONT, 10, 'bold'))
    style.configure('Alert.TLabel', background=CARD, foreground='#f486dd')
    style.configure('Stats.TLabel', background=CARD, font=(FONT, 10, 'bold'))
    style.configure('TButton', background='#28394d', foreground=TEXT, borderwidth=0, padding=(9, 6))
    style.map('TButton', background=[('disabled', '#202b39'), ('pressed', '#354d66'), ('active', '#354d66')],
              foreground=[('disabled', '#718195')])
    style.configure('Primary.TButton', background=ACCENT, foreground='#102c29', font=(FONT, 10, 'bold'))
    style.map('Primary.TButton', background=[('disabled', '#263d3e'), ('active', '#94ebdb')],
              foreground=[('disabled', '#7a9596'), ('active', '#102c29')])
    style.configure('Stop.TButton', background='#523143', foreground='#ffdce7')
    style.map('Stop.TButton', background=[('active', '#704157')])
    for prefix, bg in (('', BG), ('Card.', CARD)):
        style.configure(prefix+'TCheckbutton', background=bg, padding=(0, 4))
        style.map(prefix+'TCheckbutton', background=[('active', bg)], foreground=[('disabled', '#718195')])
    style.configure('TEntry', fieldbackground='#233348', foreground=TEXT, insertcolor=TEXT, padding=5, bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
    style.configure('TCombobox', fieldbackground='#233348', background='#28394d', foreground=TEXT, padding=4, bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER, arrowcolor=MUTED)
    style.map('TCombobox', fieldbackground=[('readonly', '#233348')], foreground=[('readonly', TEXT)],
              selectbackground=[('readonly', '#233348')], selectforeground=[('readonly', TEXT)])
    root.option_add('*TCombobox*Listbox.background', '#233348')
    root.option_add('*TCombobox*Listbox.foreground', TEXT)
    style.configure('Treeview', background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=30, borderwidth=0)
    style.configure('Treeview.Heading', background='#28394d', foreground=TEXT, padding=(8, 7), relief='flat')
    style.map('Treeview', background=[('selected', '#35516b')], foreground=[('selected', '#ffffff')])
    style.configure('Horizontal.TScale', troughcolor='#28394d', background=ACCENT, borderwidth=0)
    style.configure('TNotebook', background=BG, borderwidth=0, tabmargins=(14, 0, 14, 0))
    style.configure('TNotebook.Tab', background=BG, foreground=MUTED, padding=(17, 12), borderwidth=0)
    style.map('TNotebook.Tab', background=[('selected', '#26384b')], foreground=[('selected', TEXT)])
    style.configure('Horizontal.TProgressbar', background=ACCENT, troughcolor='#28394d', borderwidth=0, lightcolor=ACCENT, darkcolor=ACCENT)
    style.configure('TSeparator', background='#2a394b')
    style.configure('Sidebar.TFrame', background='#0b1723')
    style.configure('Sidebar.TLabel', background='#0b1723', foreground=MUTED)
    style.configure('Logo.TLabel', background='#0b1723', foreground=TEXT, font=(FONT, 12, 'bold'))
    style.configure('Nav.TButton', background='#0b1723', foreground=MUTED, anchor='w', padding=(10,11), borderwidth=0, font=(FONT,9))
    style.map('Nav.TButton', background=[('active','#142b3d')], foreground=[('active',TEXT)])
    style.configure('Selected.Nav.TButton', background='#123044', foreground=TEXT, font=(FONT,9,'bold'))
    style.map('Selected.Nav.TButton', background=[('active','#173b50')])
    from PIL import Image,ImageDraw,ImageTk
    switches=[]
    for enabled in (False,True):
        switch=Image.new('RGBA',(144,84));pen=ImageDraw.Draw(switch)
        pen.rounded_rectangle((2,2,141,81),radius=40,fill=ACCENT if enabled else '#283c4e',outline='#68839c',width=3)
        x=100 if enabled else 43
        pen.ellipse((x-32,10,x+32,74),fill='#0b3440' if enabled else '#edf4fb')
        switches.append(ImageTk.PhotoImage(switch.resize((48,28),Image.Resampling.LANCZOS),master=root))
    root._loop_switch_images=switches
    style.element_create('LoopSwitch.indicator','image',switches[0],('selected',switches[1]))
    style.layout('Switch.TCheckbutton', [('Checkbutton.padding',{'sticky':'nswe','children':[
        ('LoopSwitch.indicator',{'side':'left','sticky':'w'}),
        ('Checkbutton.focus',{'side':'left','sticky':'w','children':[('Checkbutton.label',{'sticky':'w'})]})]})])
    style.configure('Switch.TCheckbutton',background=CARD,foreground=TEXT,padding=(0,3),font=(FONT,10,'bold'))
    style.map('Switch.TCheckbutton',background=[('active',CARD)],foreground=[('disabled','#718195')])
    # Only the main notebook hides its tab strip. History notebooks retain tabs.
    style.layout('Sidebar.TNotebook.Tab', [])
    style.configure('Sidebar.TNotebook', background=BG, borderwidth=0, tabmargins=0, bordercolor=BG, lightcolor=BG, darkcolor=BG)
    return style


def heading(parent, title, description):
    ttk.Label(parent, text=title, style='Title.TLabel').pack(anchor='w')
    ttk.Label(parent, text=description, style='Muted.TLabel', wraplength=470).pack(anchor='w', pady=(3, 10))


def card(parent, title=None):
    frame = ttk.Frame(parent, style='Panel.TFrame', padding=10)
    frame.pack(fill='x', pady=(0, 8))
    if title:
        ttk.Label(frame, text=title, style='CardTitle.TLabel').pack(anchor='w', pady=(0, 7))
    return frame


def row(parent):
    frame = ttk.Frame(parent, style='Card.TFrame')
    frame.pack(fill='x')
    return frame
