# v40 — MuMu mouse control and compact Loong Lens UI

This build returns to the v37 codebase and removes the v38/v39 ADB capture/input
changes. It uses desktop screenshots and guarded Windows mouse control for
MuMuPlayer 6.8.9, Android 15, portrait 1080×1920 at 480 DPI, as supplied.

MuMu's running game tab can be named Android Device or after the game. Window
selection uses its process identity and portrait dimensions rather than requiring
a BlueStacks title. The device manager, browser/document windows and unsupported
landscape layouts are excluded. Native child-window bounds identify the Android
viewport; when unavailable, its 9:16 portrait area is fitted below the top toolbar
using native client edges. One transform drives capture, clicks, held drags and
Map Tweaker markers. Toolbar/resize pixels receive no gameplay clicks or dots.
A window move, resize, changed render child, loss of focus, cover or F10 releases
mouse input and stops the current operation. No ADB executable or Android helper
is included or called.

Loong Lens defaults to 1000×760 rather than 1440×940, with a 960×720 minimum.
Sidebar, text, card spacing, buttons and preview are compact. Start, Stop/F10,
Reset, the daily counter, Obtained, Endless and settings stay accessible. The
main window opens beside a visible MuMu window when the desktop has room.

Exit the older Loong Lens completely, extract the whole folder and run the new
LoongLens.exe (header v40). Start the MuMu Android device and launch the game;
keep the portrait window with its toolbar at the top, visible/uncovered/focused.
Use the game's default map zoom. Configure map-button positions in Sniper
Settings if your saved calibration differs. The settings picker shows the same
normalized game image used for route recognition and input.

Existing routes, all histories/screenshots, game-day counter/reset, Obtained
choices, Endless, 20-second collection/return, F10, route exclusions, four map
control boxes and heatmap stay on the v37 behavior. No changes to world data,
recognition atlas or detector assets. Existing LocalAppData data is retained.

Validation includes all prior tests, pure geometry/window-identity regressions,
source/frozen layout checks at 960×720, 1000×760 and 1120×800, plus actual Windows
capture/mouse/hotkeys on a disposable MuMu-shaped window. The independent test
uses the supplied 560×1033 frame, 40-pixel toolbar and 558×992 game surface, verifies
atlas alignment and actual delivered click coordinates, held motion and F10.
It does not run a live MuMu/Android game or establish real route speed. A full
76-view atlas comparison with v37 and archive SHA256 verification are included.


# v37 map-screen regression checks

Tests use real Back/zoom/world-tab control pixels extracted from the previously supplied recording, with the rest of the picture removed. No player name, chat or account information is included. The fixtures contain ordinary map controls only. Regressions cover weak title/background changes, gameplay's identical Back arrow, a covered zoom +, filter overlays, no extra minimap input on an open map, exactly one opener from gameplay, both Back behaviors, ignored Back, cancellation during filter recovery and refusing to count an unclosed map as inspected.

The full Windows suite runs these regressions alongside all prior checks. Source and frozen native GUI/input, Spy import/zoom, Sniper app-restart persistence, Obtained, Endless and F10 checks remain required. Full route timing is compared with v36. Gameplay delivery is simulated; live BlueStacks results are not claimed.

# v36 dashboard validation

Native Windows and frozen EXE checks cover all three sidebar pages at 1000×820, 1200×860 and 1440×940. They verify navigation selection, complete widget bounds, daily-count access, Endless placement, the loop checkbox, right-side preview proportions and bottom action placement. Actual window captures are included in validation.

The complete v35 Spy and Sniper checks are retained: real detector/storage, asynchronous three-image map import and reload, route-editor map reuse, app restart on the same profile, Obtained edits, beyond-five scanning and F10. The full pytest suite, native Windows input, embedded icon and source resources must pass before packaging. The full 76-view route is compared with v35; live game input is simulated in diagnostics.

# Verification — Loong Lens v35

The app targets Windows 10 (2004+) / Windows 11 and BlueStacks at default map
zoom. Local algorithm checks use pinned Python dependencies. The release
workflow runs the full tests, native GUI and input checks, and EXE build on
Windows. These checks do not run the live game.

## Route identity and coverage

The bundled route retains 76 checks and 83 spawn spots, in the approved order.
Original IDs 26, 51 and 72 are absent; #50 Loong Haven XIV is followed by #52
Reed Marsh. Groups #40 and #64 retain a/b views. Route edits, removed points,
extras and saved profiles retain their identities and persistence format.
The normal overlay retains the original 86 spawn locations.

The full-atlas simulation renders real atlas pixels and uses real overlapping
image registration. Every selected camera coordinate is checked against an
independent viewport transform. It requires exactly one camera selection per
saved view and no intermediate camera selections. Another check repeats two
complete passes with navigation carried between them, verifying 152 selections.
Initial/global poses are supplied by the simulated backend, so this does not
prove absolute recognition at every live viewpoint.

## Centre-start drag policy

Every new fixed-route hold begins at (285,530) in the 570x1029 reference. The
direction is centre minus the target's measured screen position. The stroke
keeps that direction, uses fast held movement, and checks screenshots at most
every 240 reference pixels. The cursor path ends at the first control or
viewport edge. If more movement is required, release occurs at rest before
another hold starts at the centre. The first verified visible target ends
movement; a fresh settled position and pre-click screenshot are still required.

The four unchanged blocked rectangles are title (28,54)-(191,98), legend
(422,58)-(554,231), zoom/portrait (490,641)-(569,923), and bottom controls
(3,929)-(551,1028). Game content bounds exclude window chrome and the outer
frame. No padding is added. Tests check blocked edges, immediately adjacent
available pixels, formerly blocked terrain and direct selection without drags.
Ray tests cover 24 directions, checking intermediate pixels and that each
stroke reaches its first exact exclusion/viewport boundary.

Transition regressions simulate #50 XIV to #52 Reed Marsh and the last
Celestship view #65 to #66 Mount Jade. They require one centre-start stroke,
correct up-left movement, no reverse recovery and the correct destination.
They do not establish the state of the user's custom 81-view route.

## Input and alignment failures

Native held movement has one down event, no release between screenshot checks,
a stationary 0.18-second endpoint hold and guaranteed release on exit. Windows
GetAsyncKeyState is checked before moving during a hold; a lost button stops
input. Tests cover a missing initial hold and release partway through motion.
The native Windows check uses actual delivered events on its own Tk window,
including F10 during a held movement. This is not a BlueStacks input test.

Fixed-route recovery recognises fresh frames in place and never sends guessed
reverse sweeps. A regression forces recognition failure after a 20-pixel
request and requires no recovery input, instead of the old 120-pixel reverse
sequence. A successful in-place recognition check retains the measured pose.
Legacy automatic-planner recovery tests remain separate.

Other checks cover stable-frame observation age, elapsed recognition time,
changed screenshots after release, fresh pre-click movement, map closure,
stalled motion, focus, coverage, moved/resized windows and F10 release.
Flat or unrecognisable terrain cannot authorize a guessed camera click.

## Portal restriction removal

Application code no longer has a coordinate blacklist, portal click validator,
planner portal filtering, runtime portal stop or portal warning in Edit route.
Tests select targets at (67.5,211), (70,211) and (184,138) directly without
substitution and retain saved framing at those coordinates. The default route
and spawn database are unchanged. Portal image recognition remains an optional
alignment aid, independently of whether the user hides portal icons.

## Existing behavior and packaging

Existing tests cover saved-route selection, Default protection, point removal,
undo/restore, extras, restart persistence and shared history. Detector tests
retain the three-hit/0.8-second confirmation, bounded late-candidate extension,
screenshot/history cooldown, one direct fresh gem click and optional photo hold.
Timer tests cover cumulative loop time, three recent passes and explicit reset.
The lock detector still classifies active targets from screenshot shading;
removed targets are absent from that loop and never selected for inspection.

The Windows workflow builds a new windowed one-file EXE, verifies all embedded
icon images, and checks frozen assets, the v35 GUI label and actual native input.
Fresh reports identify version 35. The complete folder includes the EXE,
source, assets, OCR models, launchers, tools, tests and validation reports.
Packaging extracts the completed 7z and verifies every payload file by SHA256.

The v34/v35 timings come from sequential runs on the same Windows machine with
simulated input/loading/detection and real atlas processing. Processing time,
modeled waits, per-view timings and movement counts are reported separately.
They are not measured live BlueStacks times. Live animation, loading, gesture
handling, map clamping, account locks and total run speed need game validation.


## v31 Gem Spy

The Windows workflow runs the full application suite and native Tk integration
with the real gem detector, persistent SQLite history and screenshot writer.
The camera backend is simulated; no live BlueStacks or game account is used.
The Spy integration exercises shared route and sensitivity settings, two passes
with continuing gems, one original photo per encounter, unique hourly totals,
retry without rescanning completed points, input ownership and F10 during retry.
The frozen GUI check verifies all three tab labels and the shared settings path.

Store and runner regressions cover history schema migration without losing old
rows, Gem Spy source and photo links, multiple gems, overlapping camera views,
restart persistence, date/hour boundaries, per-location appearance windows,
two separate clear absence checks and uncertain/loading frames. Capture recovery
links an already-written original photo or marks it interrupted. Timing patterns
require at least three bounded observations across two hours and expose supporting
windows; they do not claim exact spawn times or establish a game schedule.

The standard Sniper route is compared against v30 on the same Windows runner.
The v30 drag/exclusion and portal-removal regressions remain in the full suite.
Build reports identify this version and are included in the verified full archive.


## v32 regressions and native Windows checks

Camera confirmation tests cover delayed closure, ignored taps, one retry, click
ripples, bright terrain, partly clipped outlines and cancellation before Back.
Native tests reject real non-client window borders, verify the delivered cursor
position and require cursor confinement to be restored after gestures and F10.
The original four map exclusions and no-padding boundary tests remain.

Fast held tracking is tested against independent atlas translations, blank and
stationary backgrounds, and a SIFT-free clear match. Ambiguous motion falls back
to SIFT. These checks prove measured displacement, not live emulator latency.

Confirmed gems are clicked across the image without a HUD/region veto, including
the reported lower-right case and a one-frame detection drop. Counter tests cover
idempotent photo updates, restarts, history deletion, cooldown sightings, 16:00
Sofia boundaries, midnight and 23/25-hour daylight-saving game days. Today only
uses those same bounds while preserving Show all.

The native source and frozen GUI checks verify the new header counter at the
minimum supported size. Spy UI checks ensure Spy never increments the Sniper
counter. Pinned timezone data is bundled into the EXE. No private recording or
user screenshots are included in the source archive.


## v33 map recovery and daily collection

Late pre-click movement is rendered with actual atlas terrain. Checks cover
settling, target reprojection, a target becoming hidden after recentering, F10
during recovery and continuously moving/unrecognisable frames. Stable views
use exactly one pre-click capture and no added wait or alignment call.

The production daily policy uses the same SQLite seen ledger through separate
worker connections. Checks cover pre-existing counts, fifth collection, all
five collection/return cycles without a sixth, the exact (241,107) map target,
20-second cancellable waits (including a fifth find just before 16:00),
restart at the first route point, F10 while
collecting/returning, and a failed return camera blocking gameplay clicks.
Counter replays, app reconnection, day boundaries and history filters remain
covered by the existing counter suite. No inventory/collection result is read.

Windows additionally runs tools/ui_sniper_smoke.py against the actual Tk UI,
real GemDetector and SQLite/photo pipeline with simulated game screenshots and
virtual waits. It verifies the 5/5 header, original screenshot, return target,
collection wait, stop at quota and Reset checks preserving the daily count.
The existing Spy integration, native client-border/confinement/F10, route
editor/profile, frozen GUI/resource/input and archive hash checks are retained.
The full-route v34/v35 comparison uses the same atlas fixture and excludes gem
collection; it is a simulated timing comparison, not a live BlueStacks result.

Sighting-map timer checks cover the new 3,615-second lifetime, hour-aware
labels, visibility after the former 30-minute cutoff, the final 15 seconds,
exact/fractional expiry, restarts, original timestamps and edited coordinates.


## v34 camera-outline regressions

Camera checks exercise dim and antialiased outlines over brown ground, green
ground and bright snow at three capture sizes, plus the existing clipped-edge
cases. Nearby offset rectangles with overlapping horizontal or vertical sides,
click ripples and bright flat ground remain rejected. A simulated selected
camera with a dim outline sends one target tap and one Back, checks the view
once and never enters the unconfirmed retry path. Genuine ignored clicks,
delayed automatic closing and F10 remain covered.

Native Windows runs the full suite and the same UI, input, frozen EXE and full
archive checks. The v33/v34 full-route benchmark uses the same atlas simulation.
It does not measure this player's game client, the latest inline screenshot,
or a live BlueStacks run. Private videos are not included in the archive.


## v35 durable obtained flags and Endless mode

Storage checks cover recovery from photo history with a missing older ledger,
checked-by-default finds, uncheck/recheck across independent connections and
restart, idempotent UI/photo replays, deleted photos/history, entries within
the photo cooldown, and 16:00 day boundaries. A child process commits a find
and exits immediately with os._exit, without running UI or shutdown callbacks;
a new process connection still reads the find, metadata and count.

Production-runner checks cover Endless starts at 4/5, 5/5 and 6/5, continuing
after collection/home return, F10 staying stopped, turning Endless off to
restore normal quota, and unchecking a fifth find during collection. Existing
fifth-find-across-reset, exact return, no sixth find in normal mode, map and
cursor protections remain covered. The repeat-loop fixture uses the same two
OpenCV threads as the application and a 15-second bounded join, with cleanup
on timeout, to avoid failing valid virtual-clock loops on a busy test host.

Windows Sniper integration launches the actual Tk app twice on the same
isolated profile. It toggles Obtained off/on/off, retains the original photo,
reopens the app to restore 4/5 and Endless enabled, checks Obtained again,
then scans beyond 5/5 until F10. Turning Endless off restores the start guard.
Native source/frozen GUI checks verify the checkbox position under Gems found
and the daily-history UI. Packaging requires the new native report fields.
The full Windows suite, native input, source/frozen resources and complete 7z
round-trip checks are required. This is not a live BlueStacks game test.


## v35 Spy heatmap and visual-map imports

Heatmap tests exercise all dates/sources, not-obtained gems, repeated capture
updates, independent worker commits, manual location edits, deleted records,
invalid/missing locations, north/south world orientation and empty/disabled
layers. PNG composition retains the original map dimensions.

Three overlapping crops of the bundled atlas are registered back to independent
known atlas positions and merged at native pixel density. Checks cover full
coverage, refusal of partial/blank/uncertain maps, checksum/path validation,
restart persistence, import cancellation and the original recognition atlas
remaining byte-for-byte unchanged. These are map-processing fixtures, not the
user's latest inline screenshots, whose original files are not mounted here.

The native Spy UI check opens the map from its thumbnail, zooms with buttons
and wheel, pans at 800%, verifies viewport-sized rendering, toggles the layer,
exports a full-resolution PNG, imports three real image files asynchronously,
reopens the saved map and displays it in the route editor without changing
world coordinates. Source and frozen GUI checks also open the map. Packaging
requires these new native report fields. Live game recognition keeps the
original reference; no claim is made that the new visual map improves live
tracking or that it has been tested with a live BlueStacks game session.
