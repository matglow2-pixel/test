"""Gem Watch — visible-gameplay alerts for Windows / MuMu."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-image', type=Path, help='Scan a saved gameplay screenshot without starting the Windows watcher')
    parser.add_argument('--no-hud-mask', action='store_true', help='For cropped reference images only; scan their entire area')
    args = parser.parse_args()
    import cv2
    from gem_detector import GemDetector, load_image
    cv2.setNumThreads(2)
    if args.check_image:
        try:
            image = load_image(args.check_image)
        except ValueError as exc:
            parser.error(str(exc))
        from dataclasses import asdict
        print(json.dumps([asdict(d) for d in GemDetector().detect(image, exclude_hud=not args.no_hud_mask)], indent=2))
        return
    if sys.platform != 'win32':
        parser.error('The live watcher requires Windows. --check-image works on other systems.')
    from loong_lens import main as combined_main
    combined_main(argv=[], default_tab='watch')

if __name__ == '__main__':
    main()
