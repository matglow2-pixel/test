# v40 — MuMu mouse control and compact Loong Lens UI

This build returns to the v37 codebase and removes the v38/v39 ADB capture/input
changes. It uses desktop screenshots and guarded Windows mouse control for
MuMuPlayer 6.8.9, Android 15, portrait 1080×1920 at 480 DPI, as supplied.

MuMu's running game tab can be named Android Device or after the game. Window
selection uses its process identity and portrait dimensions rather than requiring
a BlueStacks title. The device manager, browser/document windows and unsupported
landscape layouts are excluded. Native child-window bounds identify the Android
viewport; when unavailable, its 9:16 portrait area is fitted below the top toolbar
using native client edges. One transform drives capture, clicks, held drags and
Map Tweaker markers. Toolbar/resize pixels receive no gameplay clicks or dots.
A window move, resize, changed render child, loss of focus, cover or F10 releases
mouse input and stops the current operation. No ADB executable or Android helper
is included or called.

Loong Lens defaults to 1000×760 rather than 1440×940, with a 960×720 minimum.
Sidebar, text, card spacing, buttons and preview are compact. Start, Stop/F10,
Reset, the daily counter, Obtained, Endless and settings stay accessible. The
main window opens beside a visible MuMu window when the desktop has room.

Exit the older Loong Lens completely, extract the whole folder and run the new
LoongLens.exe (header v40). Start the MuMu Android device and launch the game;
keep the portrait window with its toolbar at the top, visible/uncovered/focused.
Use the game's default map zoom. Configure map-button positions in Sniper
Settings if your saved calibration differs. The settings picker shows the same
normalized game image used for route recognition and input.

Existing routes, all histories/screenshots, game-day counter/reset, Obtained
choices, Endless, 20-second collection/return, F10, route exclusions, four map
control boxes and heatmap stay on the v37 behavior. No changes to world data,
recognition atlas or detector assets. Existing LocalAppData data is retained.

Validation includes all prior tests, pure geometry/window-identity regressions,
source/frozen layout checks at 960×720, 1000×760 and 1120×800, plus actual Windows
capture/mouse/hotkeys on a disposable MuMu-shaped window. The independent test
uses the supplied 560×1033 frame, 40-pixel toolbar and 558×992 game surface, verifies
atlas alignment and actual delivered click coordinates, held motion and F10.
It does not run a live MuMu/Android game or establish real route speed. A full
76-view atlas comparison with v37 and archive SHA256 verification are included.

