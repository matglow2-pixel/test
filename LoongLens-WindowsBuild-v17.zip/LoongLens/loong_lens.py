"""Loong Lens — combined Windows / BlueStacks map overlay and Gem Watch."""
from __future__ import annotations
import argparse
import json
import logging
import os
from pathlib import Path
import sys
import time

def self_check():
    import cv2
    import numpy as np
    from resources import ResourceStore, Renderer, ROOT
    from vision import AtlasIndex
    from pose import Match
    cv2.setNumThreads(2)
    store = ResourceStore()
    renderer = Renderer(store)
    picture, counts, _ = renderer.render((570, 1029), Match(12.45, -1650, 2250, 0, 0, []),
                                         dict.fromkeys(('gems', 'common', 'rare', 'epic'), True))
    assert picture.mode == 'RGBA' and len(store.points['gems']) == 86
    index = AtlasIndex()
    index.prepare()
    atlas = cv2.imread(str(ROOT / 'loong_haven_default_atlas.png'))
    checked = 0
    for x, y in [(900, 1300), (1600, 1500), (2000, 1700)]:
        frame = atlas[y:y+1029, x:x+570].copy()
        found = index.locate(frame)
        if found is not None:
            assert abs(found.tx + x) < 4 and abs(found.ty - (279 * 12.45 - y)) < 4
            checked += 1
    if not checked:
        raise RuntimeError('Could not align any atlas test viewport.')
    print(f'Self-check passed: {checked}/3 atlas viewports aligned; 86 gems; transparent render OK.')
    from location_ocr import LocationReader
    assert LocationReader().read(np.zeros((1029,570,3),np.uint8)) is None
    print('Offline minimap OCR loaded; blank-input rejection passed.')
    from camera_patrol import build_plan, load_spawns
    plan = build_plan(load_spawns(store.data))
    assert len(plan.spawns) == 86 and plan.cells
    assert set().union(*(view.cells for view in plan.views)) == plan.cells
    assert len(plan.views) < 86 and len(plan.cells) == 86
    print(f'Offline camera patrol: {len(plan.views)} grouped camera checks cover 86 spots, no live input.')
    print('This offline check does not validate Windows capture, click-through, or the live game.')

def main(argv=None, default_tab='map'):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-check', action='store_true', help='Check data and atlas recognition without opening a window')
    parser.add_argument('--tab', choices=('map', 'watch', 'patrol'), default=default_tab, help='Initial tab in the combined application')
    args = parser.parse_args(argv)
    if args.self_check:
        self_check()
        return
    if sys.platform != 'win32':
        parser.error('The live overlay requires Windows 10/11 and BlueStacks. Use --self-check for offline validation.')
    import cv2
    cv2.setNumThreads(2)
    # Activate DPI awareness before Tk creates any window.
    from win_overlay import PixelAlphaOverlay, find_emulator
    import tkinter as tk
    from tkinter import ttk, messagebox
    from resources import ResourceStore, Renderer, COLORS, user_dir
    from tracker import VisualWorker
    from pickup_history import PickupHistory
    from history_panel import PickupControls
    from gem_watch_panel import WatchPanel
    from patrol_panel import PatrolPanel
    from patrol_live_panel import LivePatrolPanel

    folder = user_dir()
    folder.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=folder / 'loonglens.log', level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    settings_path = folder / 'settings.json'
    coordinates_path = folder / 'coordinates.csv'
    settings = {}
    try:
        settings = json.loads(settings_path.read_text('utf-8'))
        if not isinstance(settings, dict):
            settings = {}
    except (OSError, ValueError):
        pass

    class App:
        def __init__(self):
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LoongLens.Desktop')
            self.root = tk.Tk()
            self.root.title('Loong Lens')
            # The running window uses the optimized transparent art. The EXE
            # keeps its separate white badge for Explorer/desktop display.
            self.root.iconbitmap(str(Path(__file__).resolve().parent / 'LoongLens-Original-Optimized.ico'))
            self.root.geometry('500x820')
            self.root.minsize(490, 780)
            self.root.configure(bg='#101620')
            self.root.protocol('WM_DELETE_WINDOW', self.close)
            self.closed = False
            self.paused = False
            self.patrol_active = False
            self.last_rect = None
            self.last_status = 0.
            self.last_upload = 0.
            self.upload_ms = 0.
            self.render_ms = 0.
            self.settings_dirty = False
            self.save_after = None
            self.warning = None
            try:
                self.store = ResourceStore(coordinates_path)
            except ValueError as exc:
                self.store = ResourceStore()
                self.warning = str(exc)
            self.renderer = Renderer(self.store)
            self.history = PickupHistory(folder / 'pickups.sqlite3')
            self.pickups = PickupControls(self.root, self.history, self.store, self.changed,
                                          default_minutes=int(self.setting_number('reminder_minutes', 30, 1, 1440)))
            self.overlay = PixelAlphaOverlay()
            self.worker = VisualWorker(find_emulator, folder, fps=45)
            saved_layers = settings.get('layers', {})
            if not isinstance(saved_layers, dict):
                saved_layers = {}
            self.layers = {
                'gems': tk.BooleanVar(value=bool(saved_layers.get('gems', True))),
                'ingredients': tk.BooleanVar(value=bool(settings.get('ingredients',
                    any(saved_layers.get(t, False) for t in ('common', 'rare', 'epic')))))
            }
            self.fill = tk.BooleanVar(value=bool(settings.get('fill', True)))
            self.show_timers = tk.BooleanVar(value=bool(settings.get('show_timers', True)))
            self.show_sighting_timers = tk.BooleanVar(value=bool(settings.get('show_sighting_timers', True)))
            self.size = tk.IntVar(value=self.setting_number('size', 5, 3, 9))
            self.opacity = tk.DoubleVar(value=self.setting_number('opacity', .85, .3, 1.))
            self.state = tk.StringVar(value='Preparing atlas…')
            self.info = tk.StringVar(value='Bring BlueStacks to the foreground')
            self.count = tk.StringVar(value='Waiting for the Loong Haven map')
            self.metrics = tk.StringVar(value='Recognition runs in the background')
            self.build_ui()
            self.watch = WatchPanel(self.watch_tab, self.close)
            self.patrol = PatrolPanel(self.patrol_tab, self.store.data)
            self.live_patrol = LivePatrolPanel(self.live_tab,self.store.data,self.watch,self.live_activity)
            self.notebook.select({'watch': self.watch_tab, 'map': self.map_tab, 'patrol': self.patrol_tab}[args.tab])
            self.worker.start()
            self.root.after(16, self.tick)
            if self.warning:
                messagebox.showwarning('Personal coordinates ignored', self.warning, parent=self.root)

        def setting_number(self, name, default, low, high):
            try:
                value = float(settings.get(name, default))
                if not low <= value <= high:
                    return default
                return int(value) if name == 'size' else value
            except (ValueError, TypeError):
                return default

        def build_ui(self):
            style = ttk.Style(self.root)
            style.theme_use('clam')
            style.configure('.', background='#101620', foreground='#e4eaf5', font=('Segoe UI', 10))
            style.configure('TFrame', background='#101620')
            style.configure('TLabel', background='#101620')
            style.configure('Muted.TLabel', foreground='#95a5bc')
            style.configure('TButton', background='#253449', borderwidth=0, padding=(12, 8))
            style.map('TButton', background=[('active', '#344b69')])
            style.configure('TCheckbutton', background='#101620', padding=(0, 5))
            style.map('TCheckbutton', background=[('active', '#1b2636')])
            style.configure('TCombobox', fieldbackground='#253449', background='#253449', foreground='#e4eaf5')
            style.configure('TEntry', fieldbackground='#253449', foreground='#e4eaf5', insertcolor='#e4eaf5')
            style.configure('Treeview', background='#192536', fieldbackground='#192536', foreground='#e4eaf5', rowheight=26)
            style.configure('Treeview.Heading', background='#253449', foreground='#e4eaf5')
            style.map('Treeview', background=[('selected', '#344b69')], foreground=[('selected', '#ffffff')])
            style.map('TCombobox', fieldbackground=[('readonly', '#253449')],
                      foreground=[('readonly', '#e4eaf5')], selectbackground=[('readonly', '#253449')])
            style.configure('Horizontal.TScale', troughcolor='#253449', background='#65a4de')
            style.configure('TNotebook', background='#101620', borderwidth=0)
            style.configure('TNotebook.Tab', background='#253449', foreground='#e4eaf5', padding=(12, 9))
            style.map('TNotebook.Tab', background=[('selected', '#344b69')])
            for tier, rgb in COLORS.items():
                style.configure(f'{tier}.TLabel', foreground='#%02x%02x%02x' % rgb, font=('Segoe UI', 15, 'bold'))
            self.notebook = ttk.Notebook(self.root)
            self.notebook.pack(fill='both', expand=True)
            self.map_tab = ttk.Frame(self.notebook)
            self.watch_tab = ttk.Frame(self.notebook)
            self.patrol_tab = ttk.Frame(self.notebook)
            self.live_tab = ttk.Frame(self.notebook)
            self.notebook.add(self.map_tab, text='Map overlay')
            self.notebook.add(self.watch_tab, text='Gem Watch')
            self.notebook.add(self.patrol_tab, text='Patrol preview')
            self.notebook.add(self.live_tab,text='Live patrol')
            body = ttk.Frame(self.map_tab, padding=22)
            body.pack(fill='both', expand=True)
            ttk.Label(body, text='LOONG LENS', font=('Segoe UI', 22, 'bold')).pack(anchor='w')
            ttk.Label(body, text='Loong Haven  /  default zoom', style='Muted.TLabel').pack(anchor='w', pady=(0, 16))
            ttk.Label(body, textvariable=self.state, font=('Segoe UI', 12, 'bold')).pack(anchor='w')
            ttk.Label(body, textvariable=self.info, style='Muted.TLabel', wraplength=380).pack(anchor='w', pady=(4, 12))
            ttk.Separator(body).pack(fill='x', pady=(0, 12))
            descriptions = [('gems', 'Gems', '86 possible locations'),
                            ('ingredients', 'Ingredients', 'Beans · Bamboo · Crab\nGreen / blue borders · orange crab dots')]
            for tier, label, detail in descriptions:
                row = ttk.Frame(body)
                row.pack(fill='x', pady=3)
                ttk.Label(row, text='●', style=f'{"common" if tier == "ingredients" else tier}.TLabel').pack(side='left', padx=(0, 9))
                text = ttk.Frame(row)
                text.pack(side='left', fill='x', expand=True)
                ttk.Checkbutton(text, text=label, variable=self.layers[tier], command=self.changed).pack(anchor='w')
                ttk.Label(text, text=detail, style='Muted.TLabel', font=('Segoe UI', 9)).pack(anchor='w')
            ttk.Label(body, textvariable=self.count, wraplength=380, style='Muted.TLabel').pack(anchor='w', pady=(10, 9))
            row = ttk.Frame(body)
            row.pack(fill='x')
            ttk.Button(row, text='Mark collected', command=self.pickups.show_collect).pack(side='left')
            ttk.Button(row, text='Pickup history', command=self.pickups.show_history).pack(side='left', padx=8)
            row = ttk.Frame(body)
            row.pack(fill='x')
            ttk.Checkbutton(row, text='Pickup timers', variable=self.show_timers,
                            command=self.changed).pack(side='left')
            ttk.Checkbutton(row, text='Sighting timers (30 min)', variable=self.show_sighting_timers,
                            command=self.changed).pack(side='left', padx=(12,0))
            ttk.Label(body, textvariable=self.pickups.summary, style='Muted.TLabel').pack(anchor='w', pady=(0, 8))
            ttk.Separator(body).pack(fill='x', pady=(0, 10))
            row = ttk.Frame(body)
            row.pack(fill='x')
            ttk.Checkbutton(row, text='Shade ingredient areas', variable=self.fill, command=self.changed).pack(side='left')
            row = ttk.Frame(body)
            row.pack(fill='x', pady=5)
            ttk.Label(row, text='Dot size').pack(side='left')
            ttk.Scale(row, from_=3, to=9, variable=self.size, command=lambda _: self.changed()).pack(side='left', fill='x', expand=True, padx=(12, 0))
            row = ttk.Frame(body)
            row.pack(fill='x', pady=5)
            ttk.Label(row, text='Opacity').pack(side='left')
            ttk.Scale(row, from_=.3, to=1., variable=self.opacity, command=lambda _: self.changed()).pack(side='left', fill='x', expand=True, padx=(14, 0))
            row = ttk.Frame(body)
            row.pack(fill='x', pady=(12, 0))
            self.pause_button = ttk.Button(row, text='Pause', command=self.toggle_pause)
            self.pause_button.pack(side='left')
            ttk.Button(row, text='Re-align', command=self.worker.request_scan).pack(side='left', padx=8)
            ttk.Button(row, text='Save debug', command=self.save_debug).pack(side='left')
            ttk.Button(row, text='Exit', command=self.close).pack(side='right')
            ttk.Label(body, textvariable=self.metrics, style='Muted.TLabel', font=('Segoe UI', 9), wraplength=380).pack(anchor='w', pady=(12, 4))
            ttk.Label(body, text='Dots are candidate locations; teal = recent sightings.\nBorders show reported gathering areas.',
                      style='Muted.TLabel', font=('Segoe UI', 9)).pack(anchor='w')

        def enabled_layers(self):
            return {'gems': self.layers['gems'].get(),
                    **dict.fromkeys(('common', 'rare', 'epic'), self.layers['ingredients'].get())}

        def save_debug(self):
            diagnostic=self.worker.get_diagnostics()
            if diagnostic is None:
                messagebox.showinfo('Map diagnostics','Open the map and bring BlueStacks to the foreground for a few seconds first.',parent=self.root)
                return
            frame, details=diagnostic
            details['capture_age_seconds']=round(time.perf_counter()-details.pop('age_reference'),2)
            details['layers']=self.enabled_layers()
            details['panel_state']=self.state.get()
            details['panel_info']=self.info.get()
            details['overlay_created']=bool(self.overlay.hwnd)
            details['overlay_capture_excluded']=self.overlay.excluded_from_capture
            details['version']='Portal avoidance and pass totals v17'
            try:
                success,encoded=cv2.imencode('.png',frame)
                if not success:raise OSError('Could not encode the captured map.')
                encoded.tofile(str(folder/'map-debug.png'))
                (folder/'map-debug.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
            except OSError as exc:
                messagebox.showerror('Could not save diagnostics',str(exc),parent=self.root)
                return
            messagebox.showinfo('Map diagnostics saved',f'Saved map-debug.png and map-debug.json in:\n{folder}\n\nThese are the last captured map and alignment details; the JSON records their age.',parent=self.root)
            os.startfile(str(folder))

        def changed(self):
            self.renderer.invalidate()
            self.settings_dirty = True
            if self.save_after:
                self.root.after_cancel(self.save_after)
            self.save_after = self.root.after(400, self.save_settings)
            if not any(v.get() for v in self.layers.values()):
                self.overlay.hide()

        def save_settings(self):
            self.save_after = None
            content = {'layers': self.enabled_layers(), 'ingredients': self.layers['ingredients'].get(),
                       'size': self.size.get(), 'opacity': self.opacity.get(), 'fill': self.fill.get(),
                       'show_timers': self.show_timers.get(), 'show_sighting_timers': self.show_sighting_timers.get(),
                       'reminder_minutes': self.pickups.default_minutes}
            try:
                tmp = settings_path.with_suffix('.tmp')
                tmp.write_text(json.dumps(content, indent=2), encoding='utf-8')
                tmp.replace(settings_path)
                self.settings_dirty = False
            except OSError:
                logging.exception('Could not save preferences')

        def toggle_pause(self):
            self.paused = not self.paused
            self.worker.pause(self.paused)
            self.pause_button.configure(text='Resume' if self.paused else 'Pause')
            self.overlay.hide()
            self.last_rect = None

        def live_activity(self,active):
            self.patrol_active=active
            if active:
                self.patrol.stop(silent=True)
                if self.patrol.detail is not None and self.patrol.detail.winfo_exists():self.patrol.detail.destroy()
            self.worker.pause(self.paused)
            self.last_rect=None

        def tick(self):
            if self.closed:
                return
            try:
                self.pickups.refresh()
                snapshot = self.worker.get()
                enabled = self.enabled_layers()
                show = (not self.paused and any(enabled.values()) and snapshot['open']
                        and snapshot['match'] is not None and snapshot['rect'] is not None)
                if not show:
                    self.overlay.hide()
                    self.last_rect = None
                else:
                    rect = snapshot['rect']
                    start = time.perf_counter()
                    image, counts, changed = self.renderer.render(rect[2:], snapshot['match'], enabled,
                                             self.size.get(), self.opacity.get(), self.fill.get(),
                                             pickup_markers=self.pickups.markers if self.show_timers.get() else (),
                                             sighting_markers=self.watch.sighting_history.active_markers()
                                                 if self.show_sighting_timers.get() and enabled['gems'] else ())
                    self.render_ms = (time.perf_counter() - start) * 1000
                    if changed or self.last_rect != rect:
                        start = time.perf_counter()
                        if sum(counts.values()):
                            self.overlay.show_image(rect, image)
                        else:
                            self.overlay.hide()
                        self.upload_ms = (time.perf_counter() - start) * 1000
                        self.last_rect = rect
                        if self.overlay.hwnd and not self.overlay.excluded_from_capture:
                            # Avoid tracking our own pixels on unsupported capture configurations.
                            self.overlay.hide()
                            self.paused = True
                            self.worker.pause(True)
                            self.pause_button.configure(text='Resume')
                            messagebox.showerror('Capture exclusion unavailable',
                                'Windows could not exclude the overlay from screenshots. Markers have been paused to avoid self-tracking. Windows 10 version 2004 or newer is required.', parent=self.root)
                        shown = [f"Gems: {counts['gems']}"] if enabled['gems'] else []
                        if enabled['common']:
                            shown.append(f"Ingredients: {sum(counts[t] for t in ('common', 'rare', 'epic'))}")
                        self.count.set('   ·   '.join(shown))
                now = time.perf_counter()
                if now - self.last_status > .25:
                    self.last_status = now
                    self.state.set(snapshot['state'])
                    self.info.set(snapshot['info'])
                    self.metrics.set(f"{snapshot['fps']:.0f} capture FPS · alignment {snapshot['scan_ms']:.0f} ms\nDraw {self.render_ms:.1f} ms · upload {self.upload_ms:.1f} ms")
                    if not show:
                        self.count.set('Paused' if self.paused else 'Choose a resource layer' if not any(enabled.values())
                                       else 'Waiting for a visible, aligned map')
            except Exception as exc:
                self.overlay.hide()
                self.last_rect = None
                self.state.set('Overlay hidden — display error')
                self.info.set(str(exc)[:150])
                logging.exception('Display failed')
            self.root.after(16, self.tick)

        def close(self):
            if self.closed:
                return
            self.closed = True
            self.live_patrol.close()
            self.patrol.close()
            self.watch.close()
            self.save_settings()
            self.overlay.hide()
            self.worker.close()
            self.overlay.close()
            self.history.close()
            self.root.destroy()

    App().root.mainloop()

if __name__ == '__main__':
    main()
