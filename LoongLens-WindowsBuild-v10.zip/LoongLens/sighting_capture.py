"""Schedule fresh screenshots after sightings without blocking gem scans or Tk."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
import hashlib
import logging
from pathlib import Path
import time

import cv2

from location_ocr import LocationReader


@dataclass
class WaitingCapture:
    event: dict
    hwnd: int
    due: float


class SightingCapture:
    def __init__(self, folder, reader=None, delay=5):
        self.folder = Path(folder) / 'screenshots'
        self.reader = reader or LocationReader()
        self.delay = delay
        self.waiting = []
        self.futures = []
        self.ready = []
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='LoongLens-location')

    def schedule(self, event, target, now, test_frame=None):
        if event['test_mode']:
            self.submit(event, test_frame)
        else:
            self.waiting.append(WaitingCapture(event.copy(), target[0], now+self.delay))

    def submit(self, event, frame):
        captured_at = time.time()
        # Freeze the deadline frame now; OCR can finish later on its own thread.
        self.futures.append((self.pool.submit(self.save, event.copy(), frame.copy(), captured_at), event.copy()))

    def unavailable(self, event, reason, status='unavailable'):
        return dict(event, capture_status=status, capture_note=reason)

    def cancel_waiting(self, reason):
        for item in self.waiting:
            self.ready.append(self.unavailable(item.event, reason, 'cancelled'))
        self.waiting.clear()

    def due(self, now, frame=None, target=None, unobscured=False, reason='BlueStacks was not visible at capture time.'):
        future = []
        for item in self.waiting:
            if now < item.due:
                future.append(item)
            elif frame is None or target is None or target[0] != item.hwnd or not unobscured:
                detail = 'A different BlueStacks window was selected at capture time.' if target is not None and target[0] != item.hwnd else reason
                self.ready.append(self.unavailable(item.event, detail))
            else:
                self.submit(item.event, frame)
        self.waiting = future

    def save(self, event, frame, captured_at):
        result = dict(event, captured_at=captured_at, capture_status='ready', capture_note='',
                      zone=None, game_x=None, game_y=None, screenshot_path=None)
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256(event['event_id'].encode()).hexdigest()[:24]
            name = datetime.fromtimestamp(event['seen_at']).strftime('%Y%m%d-%H%M%S') + '-' + digest + '.png'
            path = self.folder / name
            success, encoded = cv2.imencode('.png', frame)
            if not success:
                raise OSError('Could not encode the screenshot.')
            temporary = path.with_suffix('.tmp')
            encoded.tofile(str(temporary))
            temporary.replace(path)
            result['screenshot_path'] = str(path.resolve())
        except (OSError, cv2.error) as exc:
            result.update(capture_status='save_error', capture_note=f'Could not save screenshot: {exc}')
            logging.exception('Could not save sighting screenshot')
        try:
            location = self.reader.read(frame)
            if location is not None:
                result.update(zone=location.zone, game_x=location.x, game_y=location.y)
            elif result['capture_status'] == 'ready':
                result.update(capture_status='unreadable', capture_note='The minimap label could not be read reliably.')
        except Exception as exc:
            if result['capture_status'] == 'ready':
                result.update(capture_status='ocr_error', capture_note=f'Could not read the minimap label: {exc}')
            logging.exception('Could not read sighting location')
        return result

    def poll(self):
        remaining = []
        for future, event in self.futures:
            if not future.done():
                remaining.append((future, event))
            else:
                try:
                    self.ready.append(future.result())
                except Exception as exc:
                    self.ready.append(self.unavailable(event, f'Capture interrupted: {exc}', 'interrupted'))
        self.futures = remaining
        events, self.ready = self.ready, []
        return events

    def close(self):
        self.cancel_waiting('The app was closed before the five-second capture.')
        # Frames already captured should finish saving even if the window is
        # closed. Waiting deadlines were cancelled above, so this never waits
        # out a five-second timer.
        self.pool.shutdown(wait=True)
        return self.poll()
