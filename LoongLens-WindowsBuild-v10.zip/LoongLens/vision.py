"""Cross-platform atlas recognition and incremental motion; no game process access."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
import logging
from pathlib import Path
import threading
import time
import cv2
import numpy as np
from resources import ROOT, REF_W, REF_H
from pose import Match

LOG = logging.getLogger('loonglens')

def map_mask(shape):
    h, w = shape[:2]
    mask = np.zeros((h, w), np.uint8)
    mask[round(.20*h):round(.80*h), round(.09*w):round(.72*w)] = 255
    return mask

class TitleDetector:
    def __init__(self):
        self.template = cv2.imread(str(ROOT / 'loong_title_template.png'), cv2.IMREAD_GRAYSCALE)
        if self.template is None:
            raise FileNotFoundError('Missing map title template.')

    def score(self, frame):
        gray = cv2.cvtColor(frame[31:133, 8:245], cv2.COLOR_BGR2GRAY)
        if any(a < b for a, b in zip(gray.shape, self.template.shape)):
            return 0.
        return float(cv2.minMaxLoc(cv2.matchTemplate(gray, self.template, cv2.TM_CCOEFF_NORMED))[1])

class AtlasIndex:
    """A cached SIFT index replaces repeated whole-atlas template searches.

    The index is warmed in the recognition thread. Precise, constrained geometric
    checks precede accepting a pose; the original matcher remains a fallback.
    """
    RATIO = .5
    FEATURES = 12000

    def __init__(self, cache_dir=None):
        self.ready = False
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.lock = threading.Lock()
        self.points = self.descriptors = self.matcher = None
        self.query = cv2.SIFT_create(nfeatures=1200, contrastThreshold=.025)
        meta = json.loads((ROOT / 'atlas_metadata.json').read_text('utf-8'))
        self.grid_scale = float(meta['scale'])
        self.map_height = 280

    def prepare(self):
        with self.lock:
            if self.ready:
                return
            source = ROOT / 'loong_haven_default_atlas.png'
            stamp = hashlib.sha256(source.read_bytes()).hexdigest()[:20]
            filename = f'sift-{stamp}-{cv2.__version__}-{self.FEATURES}.npz'
            cache = self.cache_dir / filename if self.cache_dir else None
            if cache and cache.exists():
                try:
                    with np.load(cache, allow_pickle=False) as saved:
                        pts = saved['points'].copy()
                        desc = saved['descriptors'].copy()
                    if pts.shape != (len(desc), 2) or desc.shape[1:] != (128,) or len(desc) < 100:
                        raise ValueError('Invalid atlas cache shape')
                    if not np.isfinite(pts).all() or not np.isfinite(desc).all():
                        raise ValueError('Invalid atlas cache values')
                    self.points, self.descriptors = pts, desc.astype(np.float32)
                except (OSError, ValueError, KeyError):
                    LOG.warning('Rebuilding an invalid atlas cache.')
            if self.descriptors is None:
                image = cv2.imread(str(source), cv2.IMREAD_GRAYSCALE)
                if image is None:
                    raise FileNotFoundError('Missing map atlas.')
                image = cv2.resize(image, None, fx=self.RATIO, fy=self.RATIO, interpolation=cv2.INTER_AREA)
                extractor = cv2.SIFT_create(nfeatures=self.FEATURES, contrastThreshold=.025)
                keypoints, desc = extractor.detectAndCompute(image, None)
                if desc is None or len(keypoints) < 100:
                    raise ValueError('The atlas does not contain enough recognizable detail.')
                self.points = np.array([k.pt for k in keypoints], np.float32)
                self.descriptors = desc
                if cache:
                    try:
                        cache.parent.mkdir(parents=True, exist_ok=True)
                        temporary = cache.with_suffix('.tmp.npz')
                        np.savez_compressed(temporary, points=self.points, descriptors=desc)
                        temporary.replace(cache)
                    except OSError:
                        LOG.warning('Atlas cache is not writable; using in-memory index.')
            self.matcher = cv2.FlannBasedMatcher(dict(algorithm=1, trees=4), dict(checks=48))
            self.matcher.add([self.descriptors])
            self.matcher.train()
            self.ready = True

    def locate(self, frame, prior_scale=None):
        self.prepare()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Half resolution keeps descriptors and CPU work independent of desktop DPI.
        small = cv2.resize(gray, None, fx=self.RATIO, fy=self.RATIO, interpolation=cv2.INTER_AREA)
        keypoints, descriptors = self.query.detectAndCompute(small, map_mask(small.shape))
        if descriptors is None or len(keypoints) < 10:
            return None
        pairs = self.matcher.knnMatch(descriptors, k=2)
        good = [pair[0] for pair in pairs if len(pair) == 2 and pair[0].distance < .70 * pair[1].distance]
        # Repeated text can yield many matches to the same atlas feature.
        unique = {}
        for m in good:
            if m.trainIdx not in unique or m.distance < unique[m.trainIdx].distance:
                unique[m.trainIdx] = m
        good = list(unique.values())
        if len(good) < 10:
            return None
        src = np.array([keypoints[m.queryIdx].pt for m in good], np.float32)
        dst = self.points[[m.trainIdx for m in good]]
        affine, flags = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                       ransacReprojThreshold=2., maxIters=1600, confidence=.995)
        if affine is None or flags is None:
            return None
        valid = flags.ravel().astype(bool)
        n = int(valid.sum())
        if n < 9 or n / len(good) < .38:
            return None
        a, b, dx = affine[0]; c, d, dy = affine[1]
        scale = float(np.hypot(a, c))
        if not (.38 < scale < 2.8) or abs(b) > .015 * scale or abs(c) > .015 * scale:
            return None
        in_src, in_dst = src[valid], dst[valid]
        span = np.ptp(in_src, axis=0)
        if span[0] < 35 or span[1] < 50:
            return None
        # Fit the exact non-rotated model used by the overlay rather than retaining
        # even a small rotation that would place edge markers incorrectly.
        mean_src, mean_dst = in_src.mean(axis=0), in_dst.mean(axis=0)
        centered = in_src - mean_src
        denominator = float(np.sum(centered ** 2))
        fitted = float(np.sum(centered * (in_dst - mean_dst)) / denominator)
        shift = mean_dst - fitted * mean_src
        residual = np.linalg.norm(in_src * fitted + shift - in_dst, axis=1)
        error = float(np.median(residual))
        if error > 1.6 or np.quantile(residual, .9) > 3.:
            return None
        map_scale = self.grid_scale / fitted
        if not 12.05 <= map_scale <= 12.85:
            return None
        return Match(map_scale,
                     -float(shift[0]) / (fitted * self.RATIO),
                     ((self.map_height - 1) * self.grid_scale - float(shift[1]) / self.RATIO) / fitted,
                     n, error / (fitted * self.RATIO), [], f'features {n} landmarks')

class MotionTracker:
    """Optical flow with forward/backward validation and current-frame masks."""
    def __init__(self):
        self.reset()

    def reset(self):
        self.gray = self.points = None
        self.frames = 0

    def prime(self, frame):
        self.gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        self.points = cv2.goodFeaturesToTrack(self.gray, 130, .018, 9,
                                             mask=map_mask(frame.shape), blockSize=5)
        self.frames = 0

    def update(self, frame, pose):
        if self.gray is None:
            self.prime(frame)
            return pose
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        old = self.gray
        self.gray = gray
        if self.points is None or len(self.points) < 20 or self.frames % 15 == 0:
            self.points = cv2.goodFeaturesToTrack(old, 130, .018, 9,
                                                 mask=map_mask(frame.shape), blockSize=5)
        self.frames += 1
        if self.points is None or len(self.points) < 10:
            return None
        nxt, status, _ = cv2.calcOpticalFlowPyrLK(old, gray, self.points, None,
                                                winSize=(21, 21), maxLevel=3)
        if nxt is None:
            return None
        back, backward, _ = cv2.calcOpticalFlowPyrLK(gray, old, nxt, None,
                                                   winSize=(21, 21), maxLevel=3)
        if back is None:
            return None
        valid = ((status.ravel() == 1) & (backward.ravel() == 1)
                 & (np.linalg.norm(self.points - back, axis=2).ravel() < 1.3))
        src, dst = self.points[valid].reshape(-1, 2), nxt[valid].reshape(-1, 2)
        self.points = dst.reshape(-1, 1, 2) if len(dst) > 12 else None
        if len(src) < 10:
            return None
        affine, flags = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                    ransacReprojThreshold=1.8, maxIters=400)
        if affine is None or flags is None or flags.sum() < 10 or flags.mean() < .6:
            return None
        a, b, dx = affine[0]; c, d, dy = affine[1]
        scale = float(np.hypot(a, c))
        if not (.98 < scale < 1.02) or abs(b) > .005 or abs(c) > .005:
            return None
        # Avoid jitter and needless bitmap uploads when the terrain is still.
        if abs(dx) < .08 and abs(dy) < .08 and abs(scale - 1) < .00008:
            return pose
        if pose is None:
            return None
        if not 12.05 <= pose.scale * scale <= 12.85:
            return None
        return Match(pose.scale * scale, pose.tx * scale + dx, pose.ty * scale + dy,
                     int(flags.sum()), 0., [], 'motion')

@dataclass(frozen=True)
class Ticket:
    generation: int
    frame: np.ndarray
    timestamp: float

class Session:
    """Invalidate slow search results across map closures, resizing, or pause."""
    def __init__(self):
        self.generation = 0
        self.active = False
        self.rect = None

    def update(self, active, rect):
        if active != self.active or rect != self.rect:
            self.generation += 1
        self.active, self.rect = active, rect

    def ticket(self, frame, now):
        return Ticket(self.generation, frame.copy(), now)

    def accepts(self, ticket, now):
        return self.active and ticket.generation == self.generation and now - ticket.timestamp <= 2.5

class Calibrator:
    def __init__(self, cache_dir=None):
        self.index = AtlasIndex(cache_dir)

    def locate(self, frame, prior_scale=None):
        match = self.index.locate(frame, prior_scale)
        if match is not None:
            return match
        from map_alignment import find_portals, align_portals
        match = align_portals(find_portals(frame), prior_scale)
        if match is not None:
            return match
        from terrain_alignment import align_terrain
        match = align_terrain(frame, prior_scale)
        if match is not None:
            return match
        # Retain tested default-zoom template fallback without the combinatorial
        # portal-pair search that could monopolize the worker for several seconds.
        from sxs_atlas_tracker import align_atlas
        return align_atlas(frame, prior_scale)

def reconcile(ticket, frame, pose):
    """Move a background result to today's pixels or reject it after a fast pan."""
    if pose is None:
        return None
    interior = (slice(220, 740), slice(55, 410))
    difference = float(np.mean(cv2.absdiff(ticket.frame[interior], frame[interior])))
    if difference < .7:
        return pose
    motion = MotionTracker()
    motion.prime(ticket.frame)
    return motion.update(frame, pose)
