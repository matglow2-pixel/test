"""One camera check per gem location; offline simulation, no desktop input APIs."""
from __future__ import annotations
from dataclasses import dataclass
import math

MAP_SIZE = 280


@dataclass(frozen=True)
class Spawn:
    x: float
    y: float
    zone: str


@dataclass(frozen=True)
class PatrolSettings:
    # About 83 x 151 map pixels in the supplied white rectangle / 12.45.
    view_width: float = 6.7
    view_height: float = 12.1
    inspect_seconds: float = 1.2

    def __post_init__(self):
        values = (self.view_width, self.view_height, self.inspect_seconds)
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Use finite numbers for the preview settings.')
        if not (2 <= self.view_width <= 40 and 2 <= self.view_height <= 60):
            raise ValueError('View width must be 2–40 tiles; height must be 2–60.')
        if not 1 <= self.inspect_seconds <= 30:
            raise ValueError('Inspection time must be 1–30 seconds.')


@dataclass(frozen=True)
class Viewpoint:
    x: float
    y: float
    near_zone: str
    cells: frozenset[tuple[int, int]]

    def bounds(self, settings):
        w, h = settings.view_width/2, settings.view_height/2
        return self.x-w, self.y-h, self.x+w, self.y+h


@dataclass(frozen=True)
class PatrolPlan:
    spawns: tuple[Spawn, ...]
    settings: PatrolSettings
    views: tuple[Viewpoint, ...]
    cells: frozenset[tuple[int, int]]

    @property
    def inspection_seconds(self):
        # Loading, map opening and dragging add time and are deliberately excluded.
        return len(self.views) * self.settings.inspect_seconds


def load_spawns(data):
    return tuple(Spawn(float(row['position']['x'])+.5,
                       float(row['position']['y'])+.5,
                       row.get('regionName', 'Loong Haven')) for row in data['gems'])


def build_plan(spawns, settings=None):
    settings = settings or PatrolSettings()
    spawns = tuple(spawns)
    if len(spawns)>2000:
        raise ValueError('The preview supports up to 2,000 gem locations.')
    views = []
    for spawn in spawns:
        if not (math.isfinite(spawn.x) and math.isfinite(spawn.y)
                and 0 <= spawn.x < MAP_SIZE and 0 <= spawn.y < MAP_SIZE):
            raise ValueError('Spawn coordinates must be inside the Loong Haven map.')
        views.append(Viewpoint(spawn.x,spawn.y,spawn.zone,
                               frozenset({(math.floor(spawn.x),math.floor(spawn.y))})))
    # Keep the supplied location order: one check per entry, with no route search.
    cells = frozenset(cell for view in views for cell in view.cells)
    return PatrolPlan(spawns, settings, tuple(views), cells)


@dataclass(frozen=True)
class MapStep:
    action: str
    center: tuple[float, float]
    start: tuple[float, float] | None = None
    end: tuple[float, float] | None = None


def simulate_map_steps(center, target, scale=12.45):
    """Plan reference-client drags and a click; never dispatch real inputs.

    Map drags start in clear central terrain and stay away from the legend,
    zoom bar and bottom navigation. Actual dragging and camera edge clamping
    still need live calibration in a later version.
    """
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('Map scale must be positive.')
    if not all(math.isfinite(v) and 0 <= v <= MAP_SIZE for v in (*center, *target)):
        raise ValueError('Map centers must be finite coordinates inside the map.')
    x, y = center
    click = ((target[0]-x)*scale+285, -(target[1]-y)*scale+500)
    # Reuse the current map viewport when the next dot is already clickable.
    # Clicking a remote camera target does not recenter the large map itself.
    clickable = (32 <= click[0] <= 510 and 150 <= click[1] <= 800
                 and not (click[0] >= 420 and click[1] <= 250))
    dx, dy = ((0.,0.) if clickable else ((x-target[0])*scale, (target[1]-y)*scale))
    count = max(1, math.ceil(max(abs(dx)/200, abs(dy)/250)))
    steps = [MapStep('Open map', (x,y))]
    if abs(dx)+abs(dy) > 1e-7:
        sx, sy = dx/count, dy/count
        for _ in range(count):
            x -= sx/scale
            y += sy/scale
            steps.append(MapStep('Pan map', (x,y), (285.,500.), (285.+sx,500.+sy)))
    click = ((target[0]-x)*scale+285, -(target[1]-y)*scale+500)
    steps.extend([MapStep('Select view', (x,y), click, click),
                  MapStep('Close map', (x,y)), MapStep('Inspect scene', (x,y))])
    return tuple(steps)
