"""Exercise the actual preview loop with a deterministic timer scheduler."""
from camera_patrol import Spawn, build_plan
from patrol_panel import PatrolPanel


class Value:
    def __init__(self,value):self.value=value
    def get(self):return self.value
    def set(self,value):self.value=value


class Clock:
    def __init__(self):self.pending={};self.serial=0;self.delays=[]
    def after(self,delay,callback):
        self.serial+=1;self.pending[self.serial]=callback;self.delays.append(delay)
        return self.serial
    def after_cancel(self,key):self.pending.pop(key,None)
    def tick(self):
        key=min(self.pending);callback=self.pending.pop(key);callback()


def preview():
    panel=PatrolPanel.__new__(PatrolPanel)
    panel.root=Clock();panel.enabled=Value(True);panel.status=Value('');panel.location=Value('')
    panel.plan=build_plan((Spawn(100.5,100.5,'A'),Spawn(105.5,100.5,'B')))
    panel.settings=panel.plan.settings;panel.index=-1;panel.map_center=(100.5,100.5)
    panel.closed=False;panel.running=False;panel.auto=False;panel.after_id=None
    panel.scene_boxes=();panel.observed=[]
    panel.draw=lambda:panel.observed.append((panel.index,panel.step.action))
    return panel


def test_empty_scenes_close_check_and_advance_without_five_second_holds():
    panel=preview();panel.play()
    while panel.root.pending:panel.root.tick()
    assert panel.observed==[(index,action) for index in (0,1)
                            for action in ('Open map','Select view','Close map','Inspect scene')]
    assert panel.root.delays.count(1200)==2 and 5000 not in panel.root.delays
    assert not panel.running and not panel.auto


def test_positive_scene_stops_at_that_location_and_holds_five_seconds():
    panel=preview();panel.scene_boxes=(object(),);panel.play()
    while panel.root.pending:panel.root.tick()
    assert panel.index==0
    assert [action for _,action in panel.observed]==['Open map','Select view','Close map','Inspect scene']
    assert panel.root.delays[-1]==5000
    assert not panel.auto and not panel.running


def test_stop_cancels_the_next_click_and_inspection_callbacks():
    panel=preview();panel.play();panel.stop()
    assert not panel.root.pending and not panel.running and not panel.auto
    assert panel.observed==[(0,'Open map')]
