import json
from pathlib import Path
import pytest
from camera_patrol import Spawn, PatrolSettings, build_plan, load_spawns, simulate_map_steps


@pytest.fixture(scope='module')
def spawns():
    data=json.loads((Path(__file__).parents[1]/'loong_haven_map_data.json').read_text())
    return load_spawns(data)


def test_exactly_86_locations_in_supplied_order_no_route_or_sweep(spawns):
    plan=build_plan(spawns)
    assert len(plan.views)==len(spawns)==86
    assert [(v.x,v.y,v.near_zone) for v in plan.views]==[(s.x,s.y,s.zone) for s in spawns]
    assert plan.inspection_seconds==pytest.approx(103.2)


def test_footprint_dimensions_do_not_change_the_checks(spawns):
    small=build_plan(spawns,PatrolSettings(view_width=2,view_height=2))
    large=build_plan(spawns,PatrolSettings(view_width=40,view_height=60))
    assert small.views==large.views


def test_empty_and_duplicate_locations_are_not_silently_merged():
    assert build_plan(()).views==()
    point=Spawn(10.5,20.5,'A')
    assert len(build_plan((point,point)).views)==2


@pytest.mark.parametrize('values',[{'view_width':float('nan')},{'view_height':float('inf')},
                                 {'inspect_seconds':0},{'view_width':1},{'view_height':61}])
def test_invalid_settings(values):
    with pytest.raises(ValueError):PatrolSettings(**values)


@pytest.mark.parametrize('x,y',[(float('nan'),10),(10,280),(-1,10)])
def test_invalid_spawn_coordinates(x,y):
    with pytest.raises(ValueError):build_plan((Spawn(x,y,'invalid'),))


def test_reuse_map_viewport_for_nearby_dots():
    center=(100.,100.)
    target=(105.,102.)
    steps=simulate_map_steps(center,target)
    assert [s.action for s in steps]==['Open map','Select view','Close map','Inspect scene']
    assert all(s.center==center for s in steps)
    assert steps[1].end==pytest.approx((347.25,475.1))
    assert all(s.action!='Pan map' for s in simulate_map_steps(steps[-1].center,(107.,103.)))


def test_offscreen_location_requires_bounded_panning():
    start,target=(260.,5.),(10.,270.)
    steps=simulate_map_steps(start,target)
    previous=start
    drags=[s for s in steps if s.action=='Pan map']
    assert len(drags)>1
    for step in drags:
        a,b=step.start,step.end
        dx,dy=b[0]-a[0],b[1]-a[1]
        assert step.center==pytest.approx((previous[0]-dx/12.45,previous[1]+dy/12.45))
        previous=step.center
    assert previous==pytest.approx(target)
    assert steps[-3].end==pytest.approx((285.,500.))


@pytest.mark.parametrize('target',[(0.,0.),(280.,0.),(0.,280.),(280.,280.)])
def test_drag_endpoints_avoid_legend_and_zoom_bar(target):
    for step in simulate_map_steps((140.,140.),target):
        if step.action=='Pan map':
            x,y=step.end
            assert 14<x<519 and 233<y<788


def test_dot_behind_legend_requires_pan_even_inside_map_window():
    steps=simulate_map_steps((100.,100.),(112.,122.))
    assert any(s.action=='Pan map' for s in steps)
