import io
import json
import os
from pathlib import Path
import shlex
import struct
import subprocess
import threading

import cv2
import numpy as np
import pytest

from adb_screen import ScreenChannel, SCREEN_SCRIPT, UnsupportedRawFrame, decode_raw
from patrol_adb import BackgroundInputError
from test_adb_background import android, state


@pytest.mark.parametrize('header', [12, 16])
@pytest.mark.parametrize('fmt,channels', [(1, 4), (2, 4), (3, 3), (5, 4)])
def test_android_raw_headers_and_pixel_order(header, fmt, channels):
    pixels = np.zeros((100, 100, channels), np.uint8)
    pixels[:, :, :3] = [31, 107, 219] if fmt != 5 else [219, 107, 31]
    payload = struct.pack('<III', 100, 100, fmt) + (b'\0' * (header - 12)) + pixels.tobytes()
    result = decode_raw(payload)
    assert result.shape == (100, 100, 3)
    assert np.all(result == [219, 107, 31])


def test_android_rgb565_is_decoded_without_row_padding():
    pixels = np.full((100, 100), 0xf800, dtype='<u2')
    result = decode_raw(struct.pack('<IIII', 100, 100, 4, 0) + pixels.tobytes())
    assert np.all(result == [0, 0, 248])


@pytest.mark.parametrize('payload', [b'', b'bad image', struct.pack('<III', 100, 100, 99),
    struct.pack('<III', 99999, 99999, 1), struct.pack('<III', 100, 100, 1) + b'\0' * 40001],
    ids=['empty','short-header','unknown-format','invalid-dimensions','extra-pixel-byte'])
def test_unsupported_raw_layout_is_never_guessed(payload):
    with pytest.raises(UnsupportedRawFrame): decode_raw(payload)


def test_sustained_capture_reuses_screen_and_app_query_process(android):
    backend, folder, _ = android
    backend.focus(); screen = backend.screen
    before = len([x for x in map(json.loads, (folder/'calls.jsonl').read_text().splitlines()) if x[0] == 'command'])
    images = []
    for offset in (4, 12, 24):
        state(folder, dx=offset); backend.app_check_at=0
        images.append(backend.capture())
    after = len([x for x in map(json.loads, (folder/'calls.jsonl').read_text().splitlines()) if x[0] == 'command'])
    assert backend.screen is screen and before == after
    assert all(not np.array_equal(a, b) for a, b in zip(images, images[1:]))


@pytest.mark.parametrize('slow,expected', [('P', 'R'), ('R', 'P')])
def test_capture_transport_is_measured_instead_of_assuming_raw_is_faster(android, slow, expected):
    backend, folder, _ = android
    state(folder, screen_delays={slow: .15})
    backend.focus()
    assert backend.capture_mode == expected
    assert backend.capture_profile['persistent'] and backend.capture_profile['measured_on_device']


def test_unsupported_android_raw_capture_uses_persistent_png(android):
    backend, folder, _ = android
    state(folder, raw_unsupported=True)
    backend.focus(); backend.capture()
    assert backend.capture_mode == 'P' and backend.capture_profile['raw_ms'] is None


@pytest.mark.skipif(os.name == 'nt', reason='POSIX shell semantics; Windows subprocess protocol is checked natively')
def test_real_remote_shell_script_framing_quoting_and_cleanup(tmp_path):
    # Run the actual quoted remote shell script, substituting only the Android
    # temporary directory and Android command executables on this Linux host.
    binaries = tmp_path/'bin'; binaries.mkdir()
    raw = b'\0\n\xffLLSCREEN1 3 R 1\n' * 30
    source = tmp_path/'pixels'; source.write_bytes(raw)
    (binaries/'screencap').write_text('#!/bin/sh\nfor arg in "$@"; do target="$arg"; done\ncp '+shlex.quote(str(source))+' "$target"\n')
    (binaries/'dumpsys').write_text("#!/bin/sh\nprintf 'mResumedActivity: ActivityRecord{3 u0 com.example.loong/.Game t1}'\n")
    for path in binaries.iterdir(): path.chmod(0o755)
    script = SCREEN_SCRIPT.replace('/data/local/tmp/', str(tmp_path)+'/')
    environment = dict(PATH=str(binaries)+':/usr/bin:/bin')
    process = subprocess.Popen(['sh', '-c', 'sh -c '+shlex.quote(script)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0, env=environment)
    channel = ScreenChannel(process, threading.Event())
    try:
        assert channel.request('P') == raw
        source.write_bytes(b'\x89PNG\nchanged\0')
        assert channel.request('R') == source.read_bytes()
        assert b'com.example.loong' in channel.request('A')
        saved = next(tmp_path.glob('loonglens-screen-*'))
        assert saved.stat().st_mode & 0o077 == 0
    finally: channel.close()
    assert not list(tmp_path.glob('loonglens-screen-*'))


@pytest.mark.parametrize('response', [b'garbage\n', b'LLSCREEN1 1 R 999999999\n',
    b'LLSCREEN1 1 P 10\nshort'])
def test_broken_binary_stream_fails_without_returning_an_image(response):
    class Process:
        stdin = io.BytesIO()
        stdout = io.BytesIO(b'LLSCREEN1 0 READY 0\n' + response)
        stderr = io.BytesIO()
        def poll(self): return None
        def wait(self, timeout=None): return 0
    channel=ScreenChannel(Process(),threading.Event())
    try:
        with pytest.raises(BackgroundInputError): channel.request('P',timeout=.2)
    finally: channel.close()


def capture_requests(folder):
    return [value[1][1] for value in map(json.loads,(folder/'calls.jsonl').read_text().splitlines())
            if value[0]=='screen' and value[1][1] in ('P','R')]


def test_slow_gameplay_png_switches_to_raw_without_discarding_detection_frames(android):
    backend,folder,_=android
    state(folder,screen_delays={'R':.15});backend.focus();assert backend.capture_mode=='P'
    before=len(capture_requests(folder));state(folder,screen_delays={'P':.4,'R':0.})
    first=backend.capture();second=backend.capture()
    assert backend.capture_mode=='R' and first.shape==second.shape==(1029,570,3)
    assert capture_requests(folder)[before:]==['P','R']


def test_an_unsuccessful_raw_probe_restores_png_without_repeated_slow_probes(android):
    backend,folder,_=android
    state(folder,screen_delays={'R':.15});backend.focus();assert backend.capture_mode=='P'
    before=len(capture_requests(folder));state(folder,screen_delays={'P':.4,'R':.6})
    backend.capture();backend.capture();backend.capture()
    assert backend.capture_mode=='P' and capture_requests(folder)[before:]==['P','R','P']
