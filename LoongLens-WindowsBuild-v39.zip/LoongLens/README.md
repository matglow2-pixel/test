# v39 — faster ADB screenshots

v38 started a host ADB command and compressed/transferred a full PNG for every
screenshot. That overhead was repeated many times per camera view. v39 keeps one
request-driven Android screen connection open, including foreground-app queries.
Each screenshot is taken after its request; queued/stale frames are never used.

At connection startup it warms up and measures PNG and uncompressed screenshots
on the selected emulator, including transfer and decoding, then uses the faster
format. If gameplay PNG becomes slower than the startup map, a fresh raw
probe is returned to the detector and retained only if faster; no probe image
is discarded. Android raw RGB/RGBA/RGBX/BGRA/RGB565 images and both header layouts are
handled explicitly. Unsupported raw layouts select persistent PNG. Whole-image
black-screen checking now uses exact OpenCV statistics without allocating a large
floating-point array on every capture.

The route, map validation, loading/inspection waits, three-hit confirmation,
20-second collection wait, return point and histories stay the same. Sniper and
Spy keep Windows mouse/focus free. No new dependency, APK or root is required.
ADB errors never fall back to Windows mouse input. Minimized operation still
requires BlueStacks to keep rendering and the game to stay active inside Android.

Exit the old app, extract the full package and run LoongLens.exe (header v39).
Keep Android Debug Bridge enabled at the existing 127.0.0.1:5555 address. In
Sniper Settings, Test connection / preview with the large map open; the result
now includes measured capture milliseconds. Test map pan with BlueStacks
minimized, then Save. Existing device/alignment, routes and history are retained.

Windows checks compare the actual v38/v39 capture code with an independent
simulated Android subprocess, modeled command/encoding costs and real transfer/
decoding. They require fresh frames and zero new host processes per v39 capture.
Native source/frozen GUI checks also verify this reuse and unchanged Windows
cursor/focus. Linux runs the actual quoted Android shell script against command
stubs, including binary framing, file permissions and cleanup. These checks are
not a measured live BlueStacks speed claim; compare your actual route timings.


# v38 — BlueStacks ADB background mode

ADB is now the default input mode for Gem Sniper and Gem Spy. Android screenshots
and a persistent Android touch session replace desktop screenshots/mouse input.
The Windows mouse and foreground window stay untouched. Mouse mode is still an
explicit option in Settings and never serves as an automatic fallback.

1. Enable Android Debug Bridge in BlueStacks Settings → Advanced. Keep the
   selected device at `127.0.0.1:5555` unless your BlueStacks reports another port.
2. Open the large Loong Haven map. In Gem Sniper → Settings, use **Test connection /
   preview** while BlueStacks is visible. This can align Android pixels with your
   existing routes using a read-only window capture.
3. Minimize BlueStacks and use **Test map pan (minimized)**. It moves the camera
   slightly and restores it. It never clicks a gem or walks your character.
4. Save, then start Sniper or Spy. Keep the game active inside Android.

BlueStacks must remain running and continue rendering while minimized. The pan
test diagnoses paused rendering; a failed test does not claim background support.
Resolution changes, black/corrupt screenshots, known app switches and transport
failures stop ADB input while preserving progress. F10 cancels active commands,
releases the Android finger and stays stopped. A helper watchdog releases a held
touch after loss of heartbeat. Unknown Android focus metadata is accepted when
the large game map is visually confirmed; a null focus is not treated as failure.

The full package includes the EXE, all source/assets and the small compiled touch
helper. Existing BlueStacks HD-Adb.exe is reused; no APK, root, Java or Android SDK
installation is needed on your PC. `android_touch/` contains the Java source,
build manifest and reproducible build instructions. Existing histories, Obtained
choices, routes, counters, Endless, collection/return and heatmaps are retained.

Windows validation uses an independent simulated Android subprocess and real Tk
windows. It verifies screenshots, held gestures, map pan/restore, cancellation,
saved settings and unchanged Windows cursor/foreground. The actual Java helper
is also executed against Android API stubs and rebuilt from pinned tools. These
checks do not prove live BlueStacks permissions or minimized rendering: run the
included pan test on your PC.


# Loong Lens v37

Fixes the map/filter stop reported in v36. The map-open check uses independent Back/zoom/world-tab controls when the old title image does not match its background. An open map is not tapped again at the gameplay minimap position. Transitional frames are rechecked without a fixed per-location wait. An already-open filter is dismissed once through the calibrated Back control; the resulting state is observed before another input. Failed recovery preserves progress and Stop/F10 stays stopped.

The v36 sidebar UI, transparent gem artwork, routes, obtained counter, Endless mode, histories and Spy heatmap are retained. Full Windows source + EXE package; extract the complete folder and launch LoongLens.exe.

> v36 adds the sidebar dashboard, portrait live preview, separate controls/status cards and bottom action bar. All gem artwork comes from the existing transparent Loong Lens icon. Click Daily gems to edit Obtained; Endless mode remains beneath Gems found. Loop sniping starts enabled and controls repetition of completed routes. See CHANGELOG-v36.md.

# Loong Lens

**v36 adds the Gem Spy map/heatmap, saves the daily obtained count and adds Endless mode.** Click the `/5`
counter or **History → Daily gems** to open the daily ledger. Every Gem Sniper
find starts with **Obtained** checked. Untick missed gems to subtract them;
retick to add them back. Sightings and screenshots stay saved. The daily count
and each choice survive closing, relaunching and extracting another app folder
under the same Windows account. Older stored Sniper history repairs a missing
ledger on startup. The game day still resets at **16:00 Europe/Sofia**.

**Endless mode**, directly below **Gems found**, lets Sniper run beyond 5/5.
Its preference is saved. With it off, Sniper stops at five obtained entries.
The normal click, 20-second wait, return to Emerald Corner (241,107) and restart
sequence stays the same. **Stop/F10 works in both modes**. Opening daily history
stops Sniper, just like opening the existing history window. The session's
Gems found/Time spent remain separate from the persistent daily `/5` counter.

Gem Spy stays observation-only with its own histories and duplicate handling;
its sightings do not count as obtained Sniper gems. The existing sighting
history keeps its Spotted/Source/Match score columns and screenshot links.
See [CHANGELOG-v35.md](CHANGELOG-v35.md).

**Edit route → Run route** switches saved routes. Default stays protected;
**Save as…** creates variants such as Busy zones, with their own removed points
and camera adjustments. Existing saved edits are imported as My route.

A Windows 10 (2004+) / Windows 11 companion for Sword x Staff in BlueStacks. Use Loong Haven's default map zoom.

## Start

Exit the previous app completely and run **LoongLens.exe** from this folder. The header must show **v39**. Python and separate icon files are not needed. The portable download contains the EXE and this guide; the full package also includes source, assets and development checks.

The EXE bundles its own code. To run edited Python files, use RUN_LOONG_LENS.bat; editing adjacent source does not alter the EXE. The launcher activates an existing instance, so exit that instance before changing launchers.

The EXE keeps the white gem badge in Explorer. Its window and taskbar use the original transparent gem artwork. Settings, history and screenshots remain in `%LOCALAPPDATA%\LoongLens` when upgrading.

## Map Tweaker

Open the large Loong Haven map with BlueStacks visible. Pink dots mark 86 possible gem locations; Ingredients groups the bean, bamboo and crab layers. Pause, Re-align and appearance controls affect only the overlay.

Recent sightings appear as teal dots with a **1 hour 15 seconds (1:00:15)** countdown from their original spotting time. Editing coordinates moves the dot without restarting its timer. Expired dots disappear; history stays saved. Manual pickups have their own Mark collected, Pickup history and timer controls.

## Gem Spy

Select the route and detection preferences in **Gem Sniper**, then open **Gem Spy**
and press **Start / Resume**. Spy has no route selector, route editor or settings
dialog of its own. Only one camera controller runs at a time. Spy continuously
repeats that route, saves new sightings and continues without clicking gems or
moving the character toward them. Stop or F10 always cancels automatic recovery.

**Time spent** accumulates active Spy time, including automatic recovery waits,
across runs and resumed sessions. **Gems found** counts distinct Spy encounters,
not repeat detections. Both counters and route progress survive closing the app.
A relaunch restores the checkpoint and waits for Start / Resume. Changing the
selected route starts a new route run while retaining totals and histories.

The existing standard history retains **Spotted, Source and Match score**.
Spy entries show **Gem Spy**, with a clickable link to the original screenshot.
A continuing gem adds no extra standard row or screenshot. Another distinct gem
in the same camera view can still create its own record.

**Spy history** is exclusive to this tab. It contains location/camera area,
last clear empty check, first and last sighting, appearance window, first
missing check, distinct runs seen and the original screenshot link. The check
log retains each visit as present, empty or unclear; only its latest 1,000 rows
are displayed, while the database retains all visits. Camera coordinates and
within-view gem positions are approximate, not verified gem tile coordinates.

Two successful empty observations in separate runs confirm an absence. Retries
or overlapping views in one run cannot provide both confirmations. Loading,
blank/changing scenes, unconfirmed candidates, locked views and capture failures
are unclear, not empty. Persistent matching uses approximate positions with a
small tolerance, including overlapping camera views. A visually identical gem
collected and replaced between visits cannot be distinguished reliably.

**Hourly history** groups new encounters by local date and the hour of their
first confirmed sighting. A gem remaining into later hours is not counted again.
UTC offsets distinguish repeated clock hours at daylight-saving changes. Counts
are observed new encounters, not inferred actual spawn-hour totals.

**Timing patterns** compares appearance windows by camera area and minutes of
the hour, with supporting-window counts and median observed gaps. It needs at
least three usable windows across two hours before showing candidate minute
ranges. Windows remain observation bounds; they are not midpoint guesses or
proof of a spawn schedule. Unknown first appearances and windows lasting an
hour or more cannot identify a minute of the hour. Other players and missed
appearances can affect the observed gaps.

Capture/alignment failures release the button, retain state and retry with a
short increasing delay. After two failed attempts, the point is recorded as
unclear and the next selected-route point is attempted using fresh recognition.
It is revisited on the next run. No blind reverse drags or guessed location
clicks are used. Storage/setup errors are reported rather than silently losing
data. This handles worker errors, not a hung or terminated Windows process.
Original screenshots already written before a crash are recovered on startup;
a later image is never substituted as the original first-sighting photo.

## Gem Sniper

This replaces the former Live patrol tab. The separate Patrol preview tab and its simulation controls have been removed; screenshot-based engine and UI checks remain in the development tools.

1. Open Loong Haven's map at default zoom. The fixed route always begins at **Emerald Corner (#1)**, so start there to minimise setup movement. Keep BlueStacks uncovered and move Loong Lens aside.
2. Press **Snipe**, **Loop Sniping** or **F8** to run until the game-day counter reaches 5/5 or **F10** stops it. Finds trigger the collection and return sequence, then the selected route starts again. Live controls are ready at launch; opening the app alone sends no input. Choose another Snipe key if a hotkey is already in use.
3. The saved path keeps the original diagram's order and numbers, with **#26 Forsaken Lotus Pond, #51 Jadetoad Isle and #72 Frosted Plain removed**. They are never inspected or included in completion totals. The default route has **76 camera checks / 83 spawn spots**. The original IDs keep their gaps. Wide vertical groups #40 and #64 are split into a/b checks so a spawn near the rectangle edge is not counted as clearly inspected.
4. Each check selects the next fixed camera destination, closes the map and inspects gameplay. Reopening normally recentres on the selected camera. The next destination is clicked directly when visible. The clickable surface is the game content except the four marked title, legend, zoom/portrait and bottom-control boxes; there is no added padding or broad right strip. Visible targets anywhere inside that surface are selected directly. If it is outside that surface, a held-button drag reveals it; the earlier B/R intermediate camera selections are not used. The fixed order is not replaced by nearest-dot selection.
5. Every click targets the saved map coordinate using fresh screenshot alignment. The actual mouse pixels and corrective drag length depend on the current map position, recentering, edge clamping and emulator size. Late map movement triggers bounded settling and fresh recognition; unrecognisable alignment stops input. Resuming keeps the first unfinished check; Reset checks returns to #1. Each completed loop returns to the same start and order.

The default-route documentation includes **GemSniping-Fixed-Route.png**, a zoomable SVG and a CSV listing all 76 checks. The data used by the app is **gem_sniping_route.json**. Pink spawn locations on the normal map overlay remain the original 86-location dataset; these exclusions apply to Gem Sniper. Existing history entries are kept.

**Edit route** opens the full Loong Haven map and stops sniping input. Select a numbered camera target to see its white camera rectangle and dashed suggested clear area, then drag it or enter X/Y. Pink dots remain the original spawn locations. Use the wheel or +/− to zoom, drag empty map to pan, and use Zoom to selected for fine changes; arrow keys nudge by 0.25 tile. Reset point restores a selected original point to its default position; for an extra it restores the position at which you opened or added it. Reset route to defaults removes extras and restores the bundled camera positions. **Add view after selected** inserts a separate camera target one tile beside the chosen point and selects it for adjustment. It runs immediately after that point, including when you add after another extra. Extra labels such as #12+1 keep the original map numbers intact. Drag the extra to cover the ground you want; **Remove selected** deletes an original point or an extra view from your personal route. Undo remove restores a removal before closing the editor; Restore originals brings back omitted originals at defaults while retaining surviving edits and extras. At least one view must remain. Removing an original leaves its extra views in place; remove those separately if you want to skip them too. Added views do not add spawn coordinates or change the excluded locations. **Save & reset checks** stores your camera positions and extra views locally, clears pass progress/timing and uses those positions on future launches and repeated passes. Closing without saving keeps the current route. Remaining route points keep their original order and labels; omitted targets are skipped. The editor shows omitted spawn totals, while the original spawn database stays unchanged. Extras keep their saved order within their original groups. Existing v21 camera adjustments load automatically. Warnings identify recorded centres outside the suggested clear area; manual adjustments can intentionally show ground beside the listed dots. Known portal coordinates are allowed; hide portal icons using the game map filter. One camera view cannot guarantee coverage of every possible 10-tile spawn offset.

Default startup is 0.5 seconds, scene loading is 0.5 seconds, and empty-view inspection is 1.2 seconds. A late gem candidate receives up to one extra second for the unchanged three-sighting / 0.8-second confirmation. Custom waits and map-button calibration are preserved. Increase the loading/check waits in **Sniper settings** if the game renders slowly.

Fixed-route map panning starts at reference pixel (285,530), near the map centre. The stroke direction is centre minus the next target's measured screen position: a lower-right target means an upper-left drag. The button stays held across fast movement and screenshot checks, with checks at most every 240 reference pixels. The stroke continues along the same direction until the target is available or the cursor reaches one of the four marked controls or the viewport edge. No additional padding is used. If another stroke is needed, the cursor settles, releases and returns to the centre before pressing again. Movement stops on the first verified screenshot with the target available; it does not keep pulling a visible target toward the centre. The cursor stays still for 0.18 seconds before release, then fresh settled alignment and a pre-click screenshot confirm the selection. Windows button state is checked before held movement; a lost hold stops delivery. Alignment recovery tries fresh recognition in place and stops if unsuccessful, without blind reverse sweeps. Focus, coverage, resize and F10 guards remain.

Other dark locked groups are still skipped from the current screenshot without changing the order of remaining targets. The bundled Crowcry camera position is retained, while personal camera targets can use former portal coordinates. Demonbind Tower is shifted lower and horizontally centred to show more ground above the chat. After a confirmed find, Sniper clicks the gem and begins the collection/return sequence below.

On a confirmed gem, Sniper saves the original screenshot and clicks its detected centre once, including gems near screen edges. A one-frame score drop cannot veto an already confirmed gem. It then waits **20 seconds** for collection, opens the map, selects **Emerald Corner (241,107)**, confirms the camera selection, closes the map and clicks the gameplay centre to return the character. The next pass starts at the first point of your selected route with fresh map recognition. After the fifth find it completes collection and return, then stops. The counter records confirmed sightings; it does not read the game's inventory or collection result.

Both **Snipe** and **Loop Sniping**, and the selected hotkey, start this daily loop. They continue through empty passes and findings until **5/5**, Stop or **F10**. Starting while already at 5/5 sends no input. The count resets at **16:00 Europe/Sofia**; the app waits for a manual start after reaching the goal. Screenshot saving keeps its independent 20-second cooldown. F10 cancels the collection wait and return sequence immediately. An unconfirmed return camera sends no gameplay-centre click and does not restart.

**Time spent: 7:41** is cumulative during a Loop Sniping session. It does not reset on each pass, on a find, on F10, or when resuming; the wall clock continues through pauses until you explicitly reset checks. **Last 3 runs** shows the three most recent completed pass durations separately, newest first, such as #4 7:41 · #3 7:36 · #2 7:31. An incomplete pass does not replace a completed time. Gems found also stays cumulative. **Reset checks** clears total time, finds, pass history and progress; saving edits with **Save & reset checks** does the same. The daily loop retains completed-pass times and total elapsed time through collection and return. History beside Sniper settings opens the shared log and stops mouse actions while the incomplete-pass clock continues. These runtime totals are not saved across closing the application.

The overlay stays visible during camera checks. Gem Sniper and Gem Spy share history and detection preferences, and keep exclusive ownership of mouse control. Existing history, screenshots and both icons are preserved.

## Files and privacy

The app uses ordinary desktop screenshots and Windows mouse input. It does not read game memory, inject DLLs or modify game files. Screenshots are saved locally and are not uploaded by the app.

Personal data is in `%LOCALAPPDATA%\LoongLens`: `settings.json`, `gemwatch-settings.json`, `patrol-live-settings.json`, `camera-route-adjustments.json`, `pickups.sqlite3`, `sightings.sqlite3` and `screenshots/`. Spy tables in sightings.sqlite3 store visits, encounters and checkpoints separately from the standard sightings table. Existing personal coordinates from earlier versions remain supported. Diagnostics use `loonglens.log`; Save debug writes the last map frame and alignment details to this same folder.

Do not delete that folder when updating. Old build archives, user data, caches, development screenshots and obsolete preview code are excluded from the new packages.

## Development

Use Python 3.12 and the pinned `requirements.txt`. Windows source launchers open the same combined app; RUN_GEM_SPY selects Gem Spy. The legacy RUN_GEM_WATCH launcher redirects to Gem Spy. The one-file EXE is built with PyInstaller 6.16.0 and has no console window.

```
python -m pip install -r requirements.txt pytest==8.4.2
python -m pytest -q
python loong_lens.py --self-check
# Windows build:
python -m pip install pyinstaller==6.16.0
python tools/build_windows_exe.py
```

`--tab map`, `--tab live` and `--tab spy` select a startup page. Tests use simulated desktop input and real atlas/detector fixtures; the Windows workflow additionally checks the frozen app, icons and native input against its own test window. These checks do not measure a live BlueStacks pass. See VALIDATION.md for the current verification scope. OCR model notices and licences are included in `ocr_models`.


## Input and game-day behaviour

Gem Sniper always clicks a confirmed gem once, including gems near screen
edges, then collects and returns as described above. There is no HUD or region veto after confirmation. Gem Spy never
clicks gems. Native focus, visibility, actual client boundaries and F10 checks
still apply. Map taps must close automatically or show the correct camera
outline before Back; an ignored tap retries once and stays unchecked on failure.

The top-right seen counter and **Today only** use **16:00 Europe/Sofia** as the
game-day boundary, including daylight-saving changes. Midnight, Reset checks,
route changes and restarting the app do not reset the current game-day counter.
Screenshot updates do not create extra counts; a sighting during the screenshot
cooldown still counts. At 5/5 Sniper completes its collection and return and stops. Gem Spy remains unlimited and observation-only.

Window borders use native client geometry and hit-testing. No extra map padding
or portal-coordinate restrictions are introduced. Keep the emulator visible and
focused. Cursor confinement is temporary during a click/drag and is restored
on completion, failure or F10.


## v33 map-settling recovery

The existing pre-click screenshot is reused. A stable view has no extra fixed
pause or screenshot. A late recenter or residual map movement triggers fresh
alignment and projection of the same saved world coordinate. If it moved off
the usable map surface, the held drag reveals it again. Recovery is bounded;
unrecognisable or continuously moving terrain remains unchecked. The original
four control boxes and exact no-padding boundaries remain unchanged.


## v34 camera confirmation

The camera outline is translucent, so it need not be bright white. Selection
confirmation now recognises thin lines by their local contrast and rectangular
geometry, including dim or darker outlines over light terrain and antialiased
captures. A confirmed selection closes the map and proceeds to inspection.
A click ripple, plain bright ground or a rectangle offset from the selected
point cannot acknowledge that target. Genuine ignored clicks still get one
retry against fresh recognition and remain unchecked if unsuccessful.

This correction adds no fixed wait and changes no input boundaries, control
boxes or padding. Daily collection/return, Gem Spy, routes and history remain.


## Gem Spy map and heatmap

The lower Spy panel is now a clickable whole-map overview. Click it to open
**Gem sightings heatmap**. It uses all dates and sources in the shared Gem
Sniper sighting history, including missed/not-obtained gems. Image tests are
excluded. Screenshot updates and continuing Spy encounters retain their
original event, so they do not add duplicate heatmap counts. Entries without
valid coordinates are counted separately. Saved locations can be camera-view
coordinates, so the map describes recorded areas rather than exact gem tiles.

Use the mouse wheel or +/− to zoom, drag to pan, and **Fit map** or double-click
to see the whole map. **Heatmap** toggles the layer; **Save PNG…** exports the
full-resolution image. Large zooms render only the visible crop, keeping
memory bounded while retaining original detail.

For a cleaner map, select **Import map images…** and choose your three original
PNG/JPG screenshots together. One complete map or up to six overlapping parts
are supported. The app aligns them to world coordinates, merges them at the
finest supplied pixel density, and checks whole-map coverage. Uncertain or
partial imports leave the previous map in place. It saves the chosen map in
LocalAppData and reuses it after restart, including in **Gem Sniper → Edit
route**. Existing routes and spawn positions stay unchanged.

The bundled 3486 × 3486 atlas is the initial visual map. Live Map Tweaker and
Gem Sniper recognition retain that original atlas: this build changes the
visual map, not the calibration/tracking reference. Cleaner labels alone do
not establish better recognition against live game frames. Original screenshots
and imported maps stay on your PC; they are not uploaded by this feature.
