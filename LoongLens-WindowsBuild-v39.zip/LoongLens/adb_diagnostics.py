"""Native GUI/subprocess validation against a disposable simulated Android."""
from dataclasses import replace
import ctypes
from ctypes import wintypes
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import traceback
import tkinter as tk
from tkinter import ttk
from adb_fixture import prepare_fixture
from adb_setup_panel import probe_android
from patrol_adb import AdbBackend
from patrol_windows import PatrolStopped
from resources import ROOT


def run_check():
    if os.name!='nt':raise RuntimeError('Run this native ADB UI check on Windows.')
    import loong_lens,patrol_live_panel
    python=os.environ.get('LOONGLENS_DIAGNOSTIC_PYTHON') or (sys.executable if not getattr(sys,'frozen',False) else None)
    if not python or not Path(python).is_file():raise RuntimeError('Set LOONGLENS_DIAGNOSTIC_PYTHON for the simulated-device diagnostic.')
    temporary=tempfile.TemporaryDirectory(prefix='loonglens-adb-check-');folder=Path(temporary.name);device=folder/'device'
    prepare_fixture(device,ROOT)
    launches=[]
    old_local=os.environ.get('LOCALAPPDATA');os.environ['LOCALAPPDATA']=str(folder)
    original_tk=tk.Tk;original_init=patrol_live_panel.LivePatrolPanel.__init__;panels=[];errors=[];completed=[]
    user=ctypes.WinDLL('user32');user.GetForegroundWindow.restype=wintypes.HWND
    user.GetCursorPos.argtypes=(ctypes.POINTER(wintypes.POINT),)
    def cursor():
        point=wintypes.POINT();assert user.GetCursorPos(ctypes.byref(point));return point.x,point.y
    def factory(command,**kwargs):
        assert not kwargs.get('shell');launches.append(command)
        return subprocess.Popen([python,str(ROOT/'adb_fixture.py'),str(device),*command[1:]],**kwargs)
    def adb(cancel,settings):return AdbBackend(cancel,settings,factory)
    def unavailable():raise RuntimeError('No visible emulator window in this diagnostic')
    def remember(panel,*a,**kw):
        original_init(panel,*a,**kw);panels.append(panel)
        panel.input_settings=replace(panel.input_settings,adb_path=str(ROOT/'adb_fixture.py'))
        panel.adb_factory=adb;panel.reference_capture=unavailable
    patrol_live_panel.LivePatrolPanel.__init__=remember
    def descendants(widget):return [w for child in widget.winfo_children() for w in (child,*descendants(child))]

    class Window(original_tk):
        def exit_app(self):
            button=next((w for w in descendants(self) if isinstance(w,ttk.Button) and w.cget('text')=='Exit'),None)
            if button is None:self.destroy()
            else:button.invoke()
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            def failed(kind,value,trace):
                error=''.join(traceback.format_exception(kind,value,trace));errors.append(error);print(error,flush=True);self.exit_app()
            self.report_callback_exception=failed;self.after(1700,self.begin);self.after(90000,self.deadline)
        def deadline(self):errors.append('ADB diagnostic timed out');self.exit_app()
        def begin(self):
            panel=panels[-1]
            assert panel.input_settings.mode=='ADB'
            panel.show_settings();dialog=panel.settings_dialog
            assert dialog.mode.get()=='ADB'
            dialog.test_button.invoke();self.after(100,self.connected)
        def connected(self):
            panel=panels[-1];dialog=panel.settings_dialog
            if dialog.future is not None:self.after(100,self.connected);return
            assert not dialog.error.get(),dialog.error.get()
            assert dialog.frame is not None and dialog.candidate.package=='com.example.loong'
            # Cancel preserves profile; a new dialog and explicit Save applies it.
            dialog.close();assert not panel.input_settings.package
            panel.show_settings();dialog=panel.settings_dialog;dialog.test_button.invoke();self.after(100,self.saved)
        def saved(self):
            panel=panels[-1];dialog=panel.settings_dialog
            if dialog.future is not None:self.after(100,self.saved);return
            assert not dialog.error.get(),dialog.error.get()
            dialog.save();assert panel.input_settings.package=='com.example.loong'
            stored=json.loads(panel.path.read_text());assert stored['input']['mode']=='ADB' and stored['input']['package']=='com.example.loong'
            # Only the explicit settings preview created windows. Backend work
            # below must preserve the Windows cursor and foreground window.
            self.update();before=cursor();foreground=user.GetForegroundWindow()
            settings,frame,info=probe_android(adb,panel.input_settings,threading.Event(),pan=True)
            assert info['pan_verified'] and cursor()==before and user.GetForegroundWindow()==foreground
            # Exercise F10's cancellation path during an outstanding screenshot.
            cancel=threading.Event()
            with adb(cancel,settings) as backend:
                backend.focus()
                assert backend.capture_profile['persistent'] and backend.capture_profile['raw_ms'] is not None
                before_launches=len(launches);screen=backend.screen
                backend.capture();backend.capture()
                assert len(launches)==before_launches and backend.screen is screen
                timer=threading.Timer(.25,cancel.set)
                try:
                    with backend.hold_drag((285.,530.)):
                        (device/'block-capture').touch();timer.start()
                        backend.capture()
                except PatrolStopped:pass
                else:raise AssertionError('Blocked capture ignored cancellation')
                finally:timer.cancel();(device/'block-capture').unlink(missing_ok=True)
            assert not json.loads((device/'state.json').read_text())['down'] and cursor()==before
            assert user.GetForegroundWindow()==foreground
            completed.append(True);self.exit_app()

    tk.Tk=Window
    try:
        loong_lens.main([],default_tab='live')
        assert completed and not errors,errors
        # A new complete Tk/App construction loads the actual saved input data.
        class Restored(Window):
            def begin(self):
                panel=panels[-1]
                assert panel.input_settings.mode=='ADB' and panel.input_settings.package=='com.example.loong'
                assert panel.runtime_settings().map_open==tuple(panel.adb_map['map_open']) or panel.runtime_settings().map_open==panel.adb_map['map_open']
                self.exit_app()
        tk.Tk=Restored;loong_lens.main([],default_tab='live')
        assert len(panels)==2 and not errors,errors
    finally:
        tk.Tk=original_tk;patrol_live_panel.LivePatrolPanel.__init__=original_init
        logging.shutdown()
        if old_local is None:os.environ.pop('LOCALAPPDATA',None)
        else:os.environ['LOCALAPPDATA']=old_local
        temporary.cleanup()
    return dict(persistent_screen=True,capture_benchmark_completed=True,capture_no_new_adb_process=True,android_screenshots=True,persistent_hold=True,map_pan_and_return=True,
        windows_cursor_unchanged=True,windows_foreground_unchanged=True,
        cancel_kept_settings=True,adb_profile_reloaded=True,cancellation_released_android=True,
        scope='Native Windows GUI and subprocess transport; simulated Android device. Real minimized BlueStacks must pass the in-app pan test.')
