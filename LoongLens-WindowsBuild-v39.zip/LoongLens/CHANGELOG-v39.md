# v39 — faster ADB screenshots

v38 started a host ADB command and compressed/transferred a full PNG for every
screenshot. That overhead was repeated many times per camera view. v39 keeps one
request-driven Android screen connection open, including foreground-app queries.
Each screenshot is taken after its request; queued/stale frames are never used.

At connection startup it warms up and measures PNG and uncompressed screenshots
on the selected emulator, including transfer and decoding, then uses the faster
format. If gameplay PNG becomes slower than the startup map, a fresh raw
probe is returned to the detector and retained only if faster; no probe image
is discarded. Android raw RGB/RGBA/RGBX/BGRA/RGB565 images and both header layouts are
handled explicitly. Unsupported raw layouts select persistent PNG. Whole-image
black-screen checking now uses exact OpenCV statistics without allocating a large
floating-point array on every capture.

The route, map validation, loading/inspection waits, three-hit confirmation,
20-second collection wait, return point and histories stay the same. Sniper and
Spy keep Windows mouse/focus free. No new dependency, APK or root is required.
ADB errors never fall back to Windows mouse input. Minimized operation still
requires BlueStacks to keep rendering and the game to stay active inside Android.

Exit the old app, extract the full package and run LoongLens.exe (header v39).
Keep Android Debug Bridge enabled at the existing 127.0.0.1:5555 address. In
Sniper Settings, Test connection / preview with the large map open; the result
now includes measured capture milliseconds. Test map pan with BlueStacks
minimized, then Save. Existing device/alignment, routes and history are retained.

Windows checks compare the actual v38/v39 capture code with an independent
simulated Android subprocess, modeled command/encoding costs and real transfer/
decoding. They require fresh frames and zero new host processes per v39 capture.
Native source/frozen GUI checks also verify this reuse and unchanged Windows
cursor/focus. Linux runs the actual quoted Android shell script against command
stubs, including binary framing, file permissions and cleanup. These checks are
not a measured live BlueStacks speed claim; compare your actual route timings.

