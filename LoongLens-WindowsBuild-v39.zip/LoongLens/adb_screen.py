"""A request-driven Android screen connection; no desktop capture or input."""
import queue
import struct
import subprocess
import threading
import time

import cv2
import numpy as np

from patrol_adb import BackgroundInputError
from patrol_windows import PatrolStopped


# Each response is captured AFTER its request. There is no queued video/stale
# frame to mistake for the result of a camera click or a held map movement.
# The Android shell owns one temporary file, removed on EOF/exit. No APK/root.
SCREEN_SCRIPT = r'''LL_SCREEN_V39=1
umask 077
frame=/data/local/tmp/loonglens-screen-$$
trap 'rm -f "$frame"' EXIT HUP INT TERM
printf 'LLSCREEN1 0 READY 0\n'
while read -r request mode; do
    ok=0
    case "$mode" in
        P) screencap -p "$frame" 2>/dev/null && ok=1 ;;
        R) screencap "$frame" 2>/dev/null && ok=1 ;;
        A) dumpsys activity activities > "$frame" 2>/dev/null && ok=1 ;;
        W) dumpsys window > "$frame" 2>/dev/null && ok=1 ;;
        Q) break ;;
        *) break ;;
    esac
    if [ "$ok" = 1 ]; then
        size=$(wc -c < "$frame")
        printf 'LLSCREEN1 %s %s %s\n' "$request" "$mode" "$size"
        cat "$frame" || break
    else
        printf 'LLSCREEN1 %s E 0\n' "$request"
    fi
done
'''


class ScreenCommandError(BackgroundInputError):
    pass


class UnsupportedRawFrame(ValueError):
    pass


def decode_raw(payload):
    """Android raw screencap: dimensions/format, optional dataspace, pixels."""
    if len(payload) < 12:
        raise UnsupportedRawFrame('Incomplete Android raw image header')
    width, height, fmt = struct.unpack_from('<III', payload)
    if not (100 <= width <= 4320 and 100 <= height <= 7680):
        raise UnsupportedRawFrame('Unsupported Android raw image dimensions')
    channels = {1: 4, 2: 4, 3: 3, 4: 2, 5: 4}.get(fmt)
    if channels is None:
        raise UnsupportedRawFrame('Unsupported Android raw pixel format')
    offset = len(payload) - width * height * channels
    if offset not in (12, 16):
        raise UnsupportedRawFrame('Unsupported Android raw image layout')
    pixels = np.frombuffer(payload, np.uint8, offset=offset).reshape(height, width, channels)
    conversion = {1: cv2.COLOR_RGBA2BGR, 2: cv2.COLOR_RGBA2BGR,
                  3: cv2.COLOR_RGB2BGR, 4: cv2.COLOR_BGR5652BGR,
                  5: cv2.COLOR_BGRA2BGR}[fmt]
    return cv2.cvtColor(pixels, conversion)


class ScreenChannel:
    def __init__(self, process, cancel):
        self.process = process
        self.cancel = cancel
        self.events = queue.Queue()
        self.operation = threading.Lock()
        self.closed = threading.Event()
        self.failure = None
        self.next_id = 1
        self.diagnostics = []
        self.reader = threading.Thread(target=self.read, daemon=True, name='ADB-screen-reader')
        self.error_reader = threading.Thread(target=self.read_errors, daemon=True, name='ADB-screen-errors')
        self.reader.start()
        self.error_reader.start()
        kind, data = self.receive(0, 8.)
        if kind != 'READY' or data:
            raise BackgroundInputError('Android screen connection did not start.')

    def exact(self, length):
        data = bytearray(length)
        view = memoryview(data)
        offset = 0
        while offset < length:
            count = self.process.stdout.readinto(view[offset:])
            if not count:
                raise EOFError('Android screen connection ended during a frame.')
            offset += count
        return data

    def read(self):
        try:
            while True:
                header = self.process.stdout.readline(256)
                if not header:
                    raise EOFError('Android screen connection ended.')
                fields = header.decode('ascii').strip().split()
                if len(fields) != 4 or fields[0] != 'LLSCREEN1':
                    raise ValueError('Invalid Android screen response header.')
                identifier, kind, length = int(fields[1]), fields[2], int(fields[3])
                if identifier < 0 or kind not in ('READY', 'P', 'R', 'A', 'W', 'E') or not 0 <= length <= 64 * 1024 * 1024:
                    raise ValueError('Invalid Android screen response size/type.')
                self.events.put((identifier, kind, self.exact(length)))
        except Exception as exc:
            if not self.closed.is_set():
                self.failure = str(exc)

    def read_errors(self):
        for line in iter(self.process.stderr.readline, b''):
            self.diagnostics = (self.diagnostics + [line.decode('utf-8', 'replace').strip()])[-5:]

    def receive(self, identifier, timeout):
        deadline = time.monotonic() + timeout
        while True:
            if self.cancel.is_set():
                raise PatrolStopped('Stopped.')
            try:
                received, kind, data = self.events.get(timeout=.05)
            except queue.Empty:
                if self.failure or self.process.poll() is not None:
                    raise BackgroundInputError('Android screen connection failed: ' + (self.failure or ' '.join(self.diagnostics)[-250:]))
                if time.monotonic() >= deadline:
                    raise BackgroundInputError('Android screenshot timed out. Check BlueStacks rendering.')
                continue
            if received != identifier:
                raise BackgroundInputError('Android screen responses arrived out of order.')
            return kind, data

    def request(self, mode, timeout=8.):
        if mode not in ('P', 'R', 'A', 'W'):
            raise ValueError('Invalid Android screen request')
        with self.operation:
            if self.cancel.is_set():
                raise PatrolStopped('Stopped.')
            if self.closed.is_set() or self.failure:
                raise BackgroundInputError('Android screen connection is closed.')
            identifier = self.next_id
            self.next_id += 1
            try:
                self.process.stdin.write(f'{identifier} {mode}\n'.encode('ascii'))
                self.process.stdin.flush()
            except (OSError, ValueError) as exc:
                raise BackgroundInputError('Android screen request failed.') from exc
            kind, data = self.receive(identifier, timeout)
            if kind == 'E':
                raise ScreenCommandError('Android could not complete the screen request.')
            if kind != mode:
                raise BackgroundInputError('Unexpected Android screen response type.')
            return data

    def close(self):
        if self.closed.is_set():
            return
        self.closed.set()
        try:
            self.process.stdin.close()  # EOF removes the Android temporary file.
        except (OSError, ValueError):
            pass
        try:
            self.process.wait(timeout=1.)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=2.)
        self.reader.join(1.)
        self.error_reader.join(1.)
