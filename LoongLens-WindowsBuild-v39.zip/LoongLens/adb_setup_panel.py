"""Input setup, Android preview and an explicit background map-pan check."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict,replace
import threading
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import cv2
from PIL import Image,ImageTk
from patrol_adb import InputSettings,align_android_display
from patrol_live import LiveSettings
from patrol_windows import WindowsBackend
from resources import user_dir


def probe_android(factory,settings,cancel,pan=False,reference_capture=None):
    with factory(cancel,settings) as backend:
        backend.connect();raw=backend.capture_raw();aligned=False
        if not pan and reference_capture is not None:
            try:
                reference=reference_capture();rect=align_android_display(raw,reference)
                settings=replace(settings,content_rect=rect);backend.settings=settings
                l,t,r,b=rect;backend.drag_bounds=(l,t,r-1e-6,b-1e-6);aligned=True
            except Exception:
                if cancel.is_set():backend.check()
        frame=backend.render(raw);info=backend.verify_game(frame);backend.last_frame=frame
        if pan:
            from vision import TitleDetector,Calibrator,track_map_pan
            if TitleDetector().score(frame)<.64:raise RuntimeError('Open the large map before testing a map pan. No gameplay touch was sent.')
            pose=Calibrator(user_dir()/'adb-alignment',wide=True).locate(frame)
            if pose is None:raise RuntimeError('Use the default map zoom and show recognisable map terrain before the pan test.')
            before=frame.copy();start=(285.,530.);end=(285.,490.)
            with backend.hold_drag(start):backend.drag_held_to(end);backend.wait(.12)
            backend.wait(.10);after=backend.capture()
            if TitleDetector().score(after)<.64:raise RuntimeError('The map changed during the pan test. Stop and open the large map again.')
            moved=track_map_pan(before,after,pose,(0.,-40.))
            if moved is None or abs(moved.ty-pose.ty)<8:
                raise RuntimeError('No map movement was confirmed. Move away from the map edge and retry. If BlueStacks is minimized, it may have paused rendering.')
            dx,dy=moved.tx-pose.tx,moved.ty-pose.ty
            restore=(start[0]-dx,start[1]-dy)
            if abs(dx)>80 or abs(dy)>80:raise RuntimeError('Unexpected map movement; test stopped before another touch.')
            with backend.hold_drag(start):backend.drag_held_to(restore);backend.wait(.12)
            backend.wait(.10);restored=backend.capture()
            returned=track_map_pan(after,restored,moved,(-dx,-dy))
            if returned is None or abs(returned.tx-pose.tx)>5 or abs(returned.ty-pose.ty)>5:
                raise RuntimeError('Touches reached Android, but the map did not return to its starting view. Inspect the map before starting.')
            frame=restored;info['pan_verified']=True
        info['auto_aligned']=aligned
        return replace(settings,package=info.get('package','')),frame,info


class InputDialog:
    def __init__(self,panel):
        self.panel=panel;self.root=panel.root;self.closed=False;self.future=None;self.job=None
        self.cancel=threading.Event();self.pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ADB-setup')
        self.candidate=panel.input_settings;self.photo=None;self.frame=None
        win=self.window=tk.Toplevel(self.root);win.title('Gem Sniper settings');win.transient(self.root)
        win.protocol('WM_DELETE_WINDOW',self.close)
        body=ttk.Frame(win,padding=18);body.pack(fill='both',expand=True)
        self.mode=tk.StringVar(win,value=self.candidate.mode);self.path=tk.StringVar(win,value=self.candidate.adb_path)
        self.serial=tk.StringVar(win,value=self.candidate.serial);self.note=tk.StringVar(win,value='ADB uses Android screenshots and touches. Your Windows mouse stays free.')
        ttk.Label(body,text='Input and map controls',style='Heading.TLabel').grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,10))
        ttk.Label(body,text='Input mode').grid(row=1,column=0,sticky='w')
        ttk.Combobox(body,textvariable=self.mode,values=('ADB','Mouse'),state='readonly',width=18).grid(row=1,column=1,sticky='w',padx=8)
        ttk.Label(body,text='BlueStacks ADB address').grid(row=2,column=0,sticky='w',pady=5)
        ttk.Entry(body,textvariable=self.serial,width=26).grid(row=2,column=1,sticky='we',padx=8)
        ttk.Label(body,text='ADB executable (blank = auto)').grid(row=3,column=0,sticky='w')
        ttk.Entry(body,textvariable=self.path,width=30).grid(row=3,column=1,sticky='we',padx=8)
        ttk.Button(body,text='Browse…',command=self.browse).grid(row=3,column=2)
        line=ttk.Frame(body);line.grid(row=4,column=0,columnspan=3,sticky='we',pady=10)
        self.test_button=ttk.Button(line,text='Test connection / preview',command=self.test);self.test_button.pack(side='left')
        self.pan_button=ttk.Button(line,text='Test map pan (minimized)',command=lambda:self.test(True));self.pan_button.pack(side='left',padx=8)
        ttk.Label(body,text='Open Loong Haven’s large map for the first test. Connection testing can align to visible BlueStacks.\nFor the pan test, minimize BlueStacks first. It pans the map a little and restores the view; it does not walk your character.',
            style='Muted.TLabel',wraplength=640).grid(row=5,column=0,columnspan=3,sticky='w',pady=(0,8))
        ttk.Label(body,textvariable=self.note,wraplength=640,style='Muted.TLabel').grid(row=6,column=0,columnspan=3,sticky='we')
        ttk.Separator(body).grid(row=7,column=0,columnspan=3,sticky='we',pady=12)
        self.fields={}
        for row,name,label in ((8,'map_open','Open map (minimap)'),(9,'map_close','Map Back button')):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=4)
            field=ttk.Entry(body,width=17);field.grid(row=row,column=1,padx=8,sticky='w');self.fields[name]=field
            ttk.Button(body,text='Pick on screenshot',command=lambda f=field:self.pick(f)).grid(row=row,column=2)
        for row,name,label in ((10,'settle_seconds','Scene loading wait (seconds)'),(11,'inspect_seconds','Empty-view check (seconds)')):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=5)
            field=ttk.Entry(body,width=17);field.insert(0,str(getattr(panel.settings,name)));field.grid(row=row,column=1,padx=8,sticky='w');self.fields[name]=field
        self.detection=tk.StringVar(win,value=panel.services.mode.get());self.mask=tk.BooleanVar(win,value=panel.services.mask_hud.get());self.sound=tk.BooleanVar(win,value=panel.services.sound.get())
        ttk.Label(body,text='Detection sensitivity').grid(row=12,column=0,sticky='w',pady=5)
        ttk.Combobox(body,textvariable=self.detection,values=('Conservative','Balanced','Sensitive'),state='readonly',width=17).grid(row=12,column=1,sticky='w',padx=8)
        ttk.Checkbutton(body,text='Mask interface areas',variable=self.mask).grid(row=13,column=0,sticky='w')
        ttk.Checkbutton(body,text='Sound alerts',variable=self.sound).grid(row=13,column=1,sticky='w',padx=8)
        ttk.Label(body,text='Gem Spy shares this input mode, route and detection settings. F10 stops both.\nKeep the game active inside Android. Minimized operation requires BlueStacks to keep rendering.',style='Muted.TLabel',wraplength=640).grid(row=14,column=0,columnspan=3,sticky='w',pady=8)
        self.error=tk.StringVar(win);ttk.Label(body,textvariable=self.error,wraplength=640).grid(row=15,column=0,columnspan=3,sticky='w')
        ttk.Button(body,text='Save settings',command=self.save).grid(row=16,column=0,sticky='w',pady=8)
        ttk.Button(body,text='Cancel',command=self.close).grid(row=16,column=2,sticky='e')
        self.mode.trace_add('write',lambda *_:self.fill_buttons());self.fill_buttons()

    def fill_buttons(self):
        settings=self.panel.adb_map if self.mode.get()=='ADB' else dict(map_open=self.panel.settings.map_open,map_close=self.panel.settings.map_close)
        for name in ('map_open','map_close'):
            self.fields[name].delete(0,'end');self.fields[name].insert(0,','.join(str(v) for v in settings[name]))

    def input(self):return replace(self.candidate,mode=self.mode.get(),adb_path=self.path.get().strip(),serial=self.serial.get().strip())

    def browse(self):
        path=filedialog.askopenfilename(parent=self.window,title='Choose BlueStacks HD-Adb.exe',filetypes=[('ADB executable','*.exe'),('All files','*.*')])
        if path:self.path.set(path)

    def test(self,pan=False):
        if self.future is not None:return
        try:settings=self.input()
        except (ValueError,TypeError) as exc:self.error.set(str(exc));return
        if settings.mode!='ADB':self.error.set('Choose ADB input to test Android background operation.');return
        self.error.set('');self.cancel.clear();self.note.set('Testing Android connection… Your Windows mouse is not used.')
        self.test_button.state(['disabled']);self.pan_button.state(['disabled'])
        reference=None if pan else self.panel.reference_capture
        self.future=self.pool.submit(probe_android,self.panel.adb_factory,settings,self.cancel,pan,reference)
        self.job=self.root.after(80,self.finish)

    def finish(self):
        self.job=None
        if self.closed:return
        if not self.future.done():self.job=self.root.after(80,self.finish);return
        try:
            self.candidate,self.frame,info=self.future.result()
            self.note.set(('Map pan and return verified. ' if info.get('pan_verified') else 'Connected. ')+f'Android {info["width"]} × {info["height"]}. '+
                ('Screen alignment matched BlueStacks. ' if info['auto_aligned'] else '')+('Game app: '+info['package'] if info['package'] else 'Game map verified; Android did not report an app name.')+
                (' Capture: '+str(min(v for v in (info['capture_profile']['png_ms'],info['capture_profile']['raw_ms']) if v is not None))+' ms/frame.' if info.get('capture_profile') else ''))
            self.preview(self.frame)
        except Exception as exc:self.error.set(str(exc));self.note.set('Test stopped. No Windows mouse input was sent.')
        finally:self.future=None;self.test_button.state(['!disabled']);self.pan_button.state(['!disabled'])

    def preview(self,frame,field=None):
        win=tk.Toplevel(self.window);win.title('Android screenshot — click a map button' if field is not None else 'Android screenshot — background capture')
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));image.thumbnail((420,720))
        photo=ImageTk.PhotoImage(image,master=win);canvas=tk.Canvas(win,width=image.width,height=image.height,highlightthickness=0)
        canvas.pack();canvas.create_image(0,0,image=photo,anchor='nw');canvas.photo=photo
        if field is not None:
            def selected(event):
                field.delete(0,'end');field.insert(0,f'{event.x*570/image.width:.1f},{event.y*1029/image.height:.1f}');win.destroy()
            canvas.bind('<Button-1>',selected)

    def pick(self,field):
        if self.mode.get()=='ADB':
            if self.frame is None:self.error.set('Run Test connection / preview first, then pick the button in that Android screenshot.');return
            self.preview(self.frame,field)
        else:
            try:self.preview(self.panel.reference_capture(),field)
            except Exception as exc:self.error.set(str(exc))

    def save(self):
        if self.future is not None:self.error.set('Wait for the connection test to finish or press F10 to cancel it.');return
        try:
            settings=self.input();points={name:tuple(float(v.strip()) for v in self.fields[name].get().split(',')) for name in ('map_open','map_close')}
            live=replace(self.panel.settings,**points,settle_seconds=float(self.fields['settle_seconds'].get()),inspect_seconds=float(self.fields['inspect_seconds'].get()))
        except (TypeError,ValueError) as exc:self.error.set(str(exc));return
        if settings.mode=='ADB':self.panel.adb_map=points;self.panel.settings=replace(self.panel.settings,settle_seconds=live.settle_seconds,inspect_seconds=live.inspect_seconds)
        else:self.panel.settings=live
        self.panel.input_settings=settings
        self.panel.services.mode.set(self.detection.get());self.panel.services.mask_hud.set(self.mask.get());self.panel.services.sound.set(self.sound.get())
        self.panel.services.save();self.panel.save_config();self.panel.update_input_label();self.close()

    def cancel_test(self):self.cancel.set()

    def close(self,wait=False):
        if self.closed:return
        self.cancel.set()
        if self.job is not None:self.root.after_cancel(self.job);self.job=None
        if not wait and self.future is not None and not self.future.done():
            self.note.set('Stopping the test and releasing Android touch…')
            self.job=self.root.after(80,self.close);return
        self.closed=True
        self.pool.shutdown(wait=wait,cancel_futures=True);self.window.destroy()
        self.panel.settings_dialog=None;self.panel.buttons()
