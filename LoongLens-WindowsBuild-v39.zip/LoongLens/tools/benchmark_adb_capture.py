"""Compare v38/v39 subprocess overhead against a disposable Android model."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=ROOT/'adb-capture-benchmark.json')
    args=parser.parse_args()
    import cv2
    cv2.setNumThreads(2)
    from adb_fixture import prepare_fixture
    from patrol_adb import AdbBackend,InputSettings
    spec=importlib.util.spec_from_file_location('adb_v38_baseline',args.baseline_root/'patrol_adb.py')
    baseline=importlib.util.module_from_spec(spec);sys.modules[spec.name]=baseline;spec.loader.exec_module(baseline)
    results={}
    for label,kind in (('v38',baseline.AdbBackend),('v39',AdbBackend)):
        with tempfile.TemporaryDirectory(prefix='loonglens-capture-bench-') as tmp:
            folder=Path(tmp);prepare_fixture(folder,ROOT)
            path=folder/'state.json';state=json.loads(path.read_text())
            state['screen_delays']={'P':.06,'R':.003};path.write_text(json.dumps(state))
            launches=[]
            def factory(command,**kwargs):
                # Explicit, identical model cost for every host process launch.
                time.sleep(.025);launches.append(command[1:])
                return subprocess.Popen([sys.executable,str(ROOT/'adb_fixture.py'),str(folder),*command[1:]],**kwargs)
            with kind(threading.Event(),InputSettings(adb_path=str(ROOT/'adb_fixture.py')),factory) as backend:
                backend.focus();initial=len(launches);durations=[];hashes=[]
                # Isolate capture. Foreground querying is checked separately by
                # native tests and also reuses the persistent v39 connection.
                backend.app_check_at=time.monotonic()+60
                for n in range(12):
                    state=json.loads(path.read_text());state['dx']=n*4.;path.write_text(json.dumps(state))
                    started=time.perf_counter();frame=backend.capture();durations.append(time.perf_counter()-started)
                    hashes.append(hashlib.sha256(frame.tobytes()).hexdigest())
                assert len(set(hashes))==12,'A screenshot was reused after a new capture request'
                results[label]=dict(captures=12,seconds=round(sum(durations),4),
                    per_capture_ms=[round(t*1000,2) for t in durations],
                    new_host_processes=len(launches)-initial,fresh_frames_verified=True,
                    profile=getattr(backend,'capture_profile',None))
    assert results['v38']['new_host_processes']==12
    assert results['v39']['new_host_processes']==0
    report=dict(passed=True,version=39,results=results,
        scope='Real subprocess transfer/decoding with modeled 25ms host launch and 60ms PNG/3ms raw costs. Simulated Android; not live BlueStacks speed.')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n','utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
