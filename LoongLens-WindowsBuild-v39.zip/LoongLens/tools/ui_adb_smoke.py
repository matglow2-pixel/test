from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adb_diagnostics import run_check

if __name__=='__main__':
    result=run_check();result.update(passed=True,version=39)
    (ROOT/'adb-check.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
    print('Native ADB UI/transport:',result)
