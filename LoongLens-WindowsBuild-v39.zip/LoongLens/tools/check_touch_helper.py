"""Run the actual Java touch protocol against independent Android API stubs."""
import json
from pathlib import Path
import subprocess
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
STUBS={
'android/os/Build.java':'''package android.os; public class Build { public static class VERSION { public static int SDK_INT=30; } }''',
'android/os/SystemClock.java':'''package android.os; public class SystemClock { public static long uptimeMillis(){return System.nanoTime()/1000000L;} }''',
'android/view/InputEvent.java':'''package android.view; public class InputEvent {}''',
'android/view/InputDevice.java':'''package android.view; public class InputDevice { public static final int SOURCE_TOUCHSCREEN=4098; }''',
'android/view/MotionEvent.java':'''package android.view;
public class MotionEvent extends InputEvent {
 public static final int ACTION_DOWN=0,ACTION_UP=1,ACTION_MOVE=2,TOOL_TYPE_FINGER=1;
 public long downTime,eventTime; public int action,source,device; public float x,y,pressure;
 public static class PointerProperties { public int id,toolType; }
 public static class PointerCoords { public float x,y,pressure,size; }
 public static MotionEvent obtain(long d,long e,int a,int count,PointerProperties[] p,PointerCoords[] c,int meta,int buttons,float xp,float yp,int device,int edge,int source,int flags) {
  MotionEvent m=new MotionEvent();m.downTime=d;m.eventTime=e;m.action=a;m.source=source;m.device=device;m.x=c[0].x;m.y=c[0].y;m.pressure=c[0].pressure;return m;
 }
 public void recycle(){}
}''',
'android/hardware/input/InputManager.java':'''package android.hardware.input;
import android.view.*; import java.io.*;
public class InputManager {
 private static final InputManager INSTANCE=new InputManager();
 public static InputManager getInstance(){return INSTANCE;}
 public boolean injectInputEvent(InputEvent input,int mode) throws Exception {
  MotionEvent m=(MotionEvent)input;
  try(PrintWriter out=new PrintWriter(new FileWriter(System.getProperty("touch.log"),true))){out.println(m.action+","+m.downTime+","+m.eventTime+","+m.x+","+m.y+","+m.pressure+","+m.source+","+m.device);}
  return true;
 }
}'''}


def main():
    with tempfile.TemporaryDirectory(prefix='touch-java-check-') as folder:
        folder=Path(folder);classes=folder/'classes';classes.mkdir();files=[]
        for name,source in STUBS.items():
            path=folder/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(source);files.append(str(path))
        subprocess.run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),*files,str(ROOT/'android_touch/TouchBridge.java')],check=True)
        def process(name):
            log=folder/(name+'.csv')
            return subprocess.Popen(['java','-Dtouch.log='+str(log),'-cp',str(classes),'com.loonglens.TouchBridge','720','1280'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE),log
        def rows(path):return [line.split(',') for line in path.read_text().splitlines()] if path.exists() else []
        def done(process,input=None):
            out,err=process.communicate(input=input,timeout=12);assert process.returncode==0,err.decode()
            return [json.loads(line) for line in out.splitlines()]
        p,log=process('gesture');output=done(p,b'1 D 100 200\n2 M 150 250\n3 U\n4 Q\n')
        values=rows(log);assert [r[0] for r in values]==['0','2','1']
        assert len({r[1] for r in values})==1,'Gesture downTime changed between MOVE and UP'
        assert all(int(r[2])>=int(r[1]) and r[6:]==['4098','-1'] for r in values)
        assert [float(r[5]) for r in values]==[1.,1.,0.]
        assert all(item.get('ok',True) for item in output)
        p,log=process('watchdog');p.stdin.write(b'1 D 100 200\n');p.stdin.flush();time.sleep(2.2)
        p.stdin.write(b'2 Q\n');p.stdin.flush();output=done(p)
        assert [r[0] for r in rows(log)]==['0','1']
        assert any(item.get('event')=='released' for item in output),'Heartbeat watchdog did not release'
        p,log=process('eof');done(p,b'1 D 100 200\n2 M 101 201\n')
        assert [r[0] for r in rows(log)]==['0','2','1'],'EOF failed to release finger'
        p,log=process('invalid');output=done(p,b'1 D -1 200\n2 Q\n')
        assert any(item.get('ok') is False for item in output) and rows(log)==[]
    report=dict(passed=True,version=39,stable_down_time=True,android_touchscreen_source=True,
        watchdog_released=True,eof_released=True,invalid_points_rejected=True,
        scope='Actual Java helper executed against independent Android API stubs; not a live Android permission test')
    (ROOT/'touch-helper-check.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
    print('Android touch protocol checks passed:',report)

if __name__=='__main__':main()
