"""Android-only screen and persistent touch input. Never calls desktop input."""
from contextlib import contextmanager
from dataclasses import dataclass,replace
from pathlib import Path
import hashlib
import json
import math
import logging
import statistics
import shlex
import os
import queue
import re
import shutil
import subprocess
import threading
import time
import cv2
import numpy as np
from patrol_windows import PatrolStopped
from resources import ROOT


class BackgroundInputError(RuntimeError):
    pause_input=True


@dataclass(frozen=True)
class InputSettings:
    mode:str='ADB'
    adb_path:str=''
    serial:str='127.0.0.1:5555'
    content_rect:tuple=(0.,32.,570.,1013.)
    package:str=''

    def __post_init__(self):
        if self.mode not in ('ADB','Mouse'):raise ValueError('Choose ADB or Mouse input.')
        if not isinstance(self.adb_path,str):raise ValueError('ADB path must be text.')
        match=re.fullmatch(r'127\.0\.0\.1:([0-9]{1,5})',self.serial)
        if not match or not 1<=int(match[1])<=65535:raise ValueError('Use the BlueStacks loopback address, e.g. 127.0.0.1:5555.')
        if len(self.content_rect)!=4 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in self.content_rect):raise ValueError('Invalid Android screen alignment.')
        l,t,r,b=self.content_rect
        if not(0<=l<r<=570 and 0<=t<b<=1029 and r-l>=400 and b-t>=750):raise ValueError('Android display must fill most of the reference picture.')
        if not isinstance(self.package,str) or self.package and not re.fullmatch(r'[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+',self.package):raise ValueError('Invalid Android app identifier.')
        object.__setattr__(self,'content_rect',tuple(self.content_rect))


def find_adb(configured=''):
    if configured:
        path=Path(configured).expanduser()
        if path.is_file():return str(path.resolve())
        raise BackgroundInputError('ADB executable not found. Choose BlueStacks HD-Adb.exe.')
    for variable in ('ProgramFiles','ProgramFiles(x86)'):
        base=os.environ.get(variable)
        if base:
            for folder in ('BlueStacks_nxt','BlueStacks'):
                path=Path(base)/folder/'HD-Adb.exe'
                if path.is_file():return str(path)
    for name in ('HD-Adb.exe','adb.exe','adb'):
        path=shutil.which(name)
        if path:return path
    raise BackgroundInputError('ADB was not found. Select HD-Adb.exe in the BlueStacks installation folder.')


def active_package(text):
    # Read active records only. A null focus record must not hide a valid
    # resumed-activity record on BlueStacks Android 11.
    fields=('topResumedActivity','mTopResumedActivity','mResumedActivity','ResumedActivity',
            'mFocusedActivity','mFocusedApp','mCurrentFocus','mFocusedWindow')
    for field in fields:
        rows=re.findall(r'^\s*'+re.escape(field)+r'\s*[:=]\s*([^\r\n]+)',text,re.M)
        found=[]
        for row in rows:
            match=re.search(r'(?:^|\s)([A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+)/[^\s}]+',row)
            if match:found.append(match[1])
        if found:return found[0] if len(set(found))==1 else None
    return None


class TouchChannel:
    def __init__(self,process,cancel,timeout=6.):
        self.process=process;self.cancel=cancel;self.events=queue.Queue();self.pending={};self.next_id=1
        self.operation=threading.RLock();self.write_lock=threading.Lock();self.closed=threading.Event()
        self.failure=None;self.down=False;self.diagnostics=[]
        self.reader=threading.Thread(target=self.read,daemon=True,name='ADB-touch-reader');self.reader.start()
        self.error_reader=threading.Thread(target=self.read_errors,daemon=True,name='ADB-touch-errors');self.error_reader.start()
        ready=self.receive(None,timeout)
        if ready.get('ready') is not True or ready.get('protocol')!=1:raise BackgroundInputError('Android touch helper could not start: '+str(ready.get('error','unsupported protocol')))
        self.heartbeat=threading.Thread(target=self.beat,daemon=True,name='ADB-touch-heartbeat');self.heartbeat.start()

    def read(self):
        try:
            for line in iter(self.process.stdout.readline,b''):
                try:message=json.loads(line)
                except (ValueError,UnicodeError):continue
                if message.get('event') in ('released','error'):
                    self.down=False;self.failure='Android released the held touch: '+message.get('reason','channel error')
                else:self.events.put(message)
        finally:
            if not self.closed.is_set():self.failure=self.failure or 'Android touch channel disconnected.'

    def read_errors(self):
        for line in iter(self.process.stderr.readline,b''):
            self.diagnostics=(self.diagnostics+[line.decode('utf-8','replace').strip()])[-8:]

    def check(self,cleanup=False):
        if not cleanup and self.cancel.is_set():raise PatrolStopped('Stopped.')
        if self.failure and not cleanup:raise BackgroundInputError(self.failure)
        if self.process.poll() is not None:raise BackgroundInputError('Android touch channel ended. '+ ' '.join(self.diagnostics)[-300:])

    def write(self,line):
        with self.write_lock:
            self.process.stdin.write((line+'\n').encode('ascii'));self.process.stdin.flush()

    def beat(self):
        while not self.closed.wait(.35):
            try:self.write('0 H')
            except (OSError,ValueError):self.failure='Android touch heartbeat disconnected.';return

    def receive(self,wanted,timeout,cleanup=False):
        deadline=time.monotonic()+timeout
        while True:
            self.check(cleanup)
            if wanted in self.pending:return self.pending.pop(wanted)
            remaining=deadline-time.monotonic()
            if remaining<=0:raise BackgroundInputError('Android touch acknowledgement timed out.')
            try:message=self.events.get(timeout=min(.05,remaining))
            except queue.Empty:continue
            key=message.get('id')
            if key==wanted:return message
            self.pending[key]=message

    def send(self,action,point=None,cleanup=False):
        with self.operation:
            self.check(cleanup);identifier=self.next_id;self.next_id+=1
            text=f'{identifier} {action}'
            if point is not None:text+=' '+str(point[0])+' '+str(point[1])
            self.write(text);result=self.receive(identifier,2. if cleanup else 4.,cleanup)
            self.down=bool(result.get('down',False))
            if not result.get('ok'):raise BackgroundInputError('Android touch rejected: '+str(result.get('error','unknown error')))

    def release(self):
        if self.process.poll() is None:self.send('U',cleanup=True)
        self.down=False

    def close(self):
        if self.closed.is_set():return
        try:
            if self.process.poll() is None:
                try:self.send('Q',cleanup=True)
                except Exception:pass
        finally:
            self.closed.set()
            try:self.process.stdin.close()
            except OSError:pass
            try:self.process.wait(timeout=1.)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=2.)
            self.reader.join(1.);self.error_reader.join(1.)


class AdbBackend:
    def __init__(self,cancel,settings=None,process_factory=None):
        self.cancel=cancel;self.settings=settings or InputSettings();self.factory=process_factory or subprocess.Popen
        self.executable=None;self.size=None;self.touch=None;self.screen=None;self.down=False;self.position=None
        self.capture_mode=None;self.capture_profile={};self.capture_times=[]
        self.connected=False;self.package=self.settings.package or None;self.app_check_at=0.;self.state_lock=threading.RLock()
        self.last_frame=None;self.pending_motion=None;self.game_verified=False
        l,t,r,b=self.settings.content_rect;self.drag_bounds=(l,t,r-1e-6,b-1e-6)

    def __enter__(self):self.executable=find_adb(self.settings.adb_path);return self
    def __exit__(self,*args):self.close()

    def check(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')

    def wait(self,seconds):
        if self.cancel.wait(seconds):self.check()

    def spawn(self,args,stream=False,targeted=True):
        command=[self.executable]+(['-s',self.settings.serial] if targeted else [])+list(args)
        return self.factory(command,stdin=subprocess.PIPE if stream else subprocess.DEVNULL,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),bufsize=0)

    def command(self,*args,timeout=8.,targeted=True):
        self.check();process=self.spawn(args,targeted=targeted);deadline=time.monotonic()+timeout
        try:
            while True:
                self.check()
                if time.monotonic()>=deadline:raise BackgroundInputError('ADB timed out. Check that BlueStacks is running and Android Debug Bridge is enabled.')
                try:output,error=process.communicate(timeout=.05);break
                except subprocess.TimeoutExpired:continue
            self.check()
            if process.returncode:raise BackgroundInputError('ADB failed: '+error.decode('utf-8','replace').strip()[-350:])
            return output
        finally:
            if process.poll() is None:process.kill();process.communicate()

    def connect(self):
        if self.connected:return
        output=self.command('connect',self.settings.serial,targeted=False).lower()
        if any(word in output for word in (b'failed',b'cannot',b'unable',b'refused')):raise BackgroundInputError('Cannot connect to BlueStacks. Enable Android Debug Bridge and check 127.0.0.1:5555 in settings.')
        if self.command('get-state').strip()!=b'device':raise BackgroundInputError('The selected BlueStacks ADB device is not ready or authorized.')
        self.connected=True

    def start_screen(self):
        if self.screen is not None:return
        from adb_screen import ScreenChannel,SCREEN_SCRIPT
        process=self.spawn(('shell','-T','sh','-c',shlex.quote(SCREEN_SCRIPT)),stream=True)
        try:self.screen=ScreenChannel(process,self.cancel)
        except Exception:
            if process.poll() is None:process.kill();process.wait(timeout=2.)
            raise

    def foreground(self):
        from adb_screen import ScreenCommandError
        self.start_screen()
        for mode in ('A','W'):
            try:text=self.screen.request(mode,timeout=2.).decode('utf-8','replace')
            except PatrolStopped:raise
            except ScreenCommandError:continue
            except RuntimeError:
                # A timed-out framed response cannot safely be reused as the
                # response to a later screen request. Close it and stop input.
                self.screen.close();self.screen=None;raise
            package=active_package(text)
            if package:return package
        return None

    def check_app(self,force=False):
        if not force and time.monotonic()<self.app_check_at:return None
        package=self.foreground();self.app_check_at=time.monotonic()+(2. if package else 10.)
        if package and (any(s in package.lower() for s in ('launcher','systemui','permissioncontroller')) or package=='com.android.settings'):
            raise BackgroundInputError('Open Loong Haven inside Android. ADB input stopped because another Android screen is active.')
        if package and self.package and package!=self.package:raise BackgroundInputError('The active Android app changed. ADB input stopped.')
        return package

    def capture_one(self,mode):
        from adb_screen import decode_raw
        started=time.monotonic();payload=self.screen.request(mode)
        if mode=='R':frame=decode_raw(payload)
        else:
            if not payload.startswith(b'\x89PNG\r\n\x1a\n'):raise BackgroundInputError('ADB did not return an Android PNG screenshot.')
            frame=cv2.imdecode(np.frombuffer(payload,np.uint8),cv2.IMREAD_COLOR)
            if frame is None:raise BackgroundInputError('Android screenshot could not be decoded.')
        h,w=frame.shape[:2]
        if not .4<=w/h<=.75:raise BackgroundInputError('Use the game in portrait orientation for ADB mode.')
        if self.size is None:self.size=(w,h)
        elif self.size!=(w,h):raise BackgroundInputError('Android resolution changed. Stop and test the connection again.')
        # Exact full-image statistics, without allocating a float64 copy of
        # every pixel for NumPy std() on each screenshot.
        means,deviations=cv2.meanStdDev(frame)
        average=float(means.mean());variance=float(np.mean(deviations**2+means**2))-average**2
        if average<2 and variance<9:raise BackgroundInputError('Android returned a black screen. BlueStacks may have paused rendering while minimized.')
        return frame,time.monotonic()-started

    def capture_raw(self):
        from adb_screen import UnsupportedRawFrame,ScreenCommandError
        self.check();self.start_screen()
        if self.capture_mode is None:
            # Warm each format once, then measure two fresh frames per format.
            # Choose on this emulator, including transfer AND decoding cost.
            timings={'P':[],'R':[]};raw_supported=True;last=None
            for index,mode in enumerate(('P','R','P','R','P','R')):
                if mode=='R' and not raw_supported:continue
                try:last,elapsed=self.capture_one(mode)
                except (UnsupportedRawFrame,ScreenCommandError):
                    if mode!='R':raise
                    raw_supported=False;continue
                if index>=2:timings[mode].append(elapsed)
            png=statistics.median(timings['P'])
            raw=statistics.median(timings['R']) if raw_supported and timings['R'] else None
            self.capture_mode='R' if raw is not None and raw<png else 'P'
            self.capture_profile=dict(mode='raw' if self.capture_mode=='R' else 'PNG',
                png_ms=round(png*1000,1),raw_ms=round(raw*1000,1) if raw is not None else None,
                persistent=True,measured_on_device=True)
            logging.getLogger('loonglens').info('ADB capture benchmark: %s',self.capture_profile)
            # The returned frame is captured after selecting the transport.
        frame,elapsed=self.capture_one(self.capture_mode)
        self.capture_times=(self.capture_times+[elapsed])[-40:]
        return frame

    def render(self,raw):
        l,t,r,b=self.settings.content_rect;w,h=self.size
        return cv2.warpAffine(raw,np.float32([[(r-l)/w,0,l],[0,(b-t)/h,t]]),(570,1029),flags=cv2.INTER_LINEAR)

    def start_touch(self):
        if self.touch is not None:return
        jar=ROOT/'loonglens-touch.jar';manifest=json.loads((ROOT/'android_touch/BUILD.json').read_text('utf-8'))
        digest=hashlib.sha256(jar.read_bytes()).hexdigest()
        if digest!=manifest['jar_sha256']:raise BackgroundInputError('Android touch helper checksum mismatch. Extract the complete v39 folder again.')
        path='/data/local/tmp/loonglens-touch-'+digest[:16]+'.jar'
        self.command('push',str(jar),path,timeout=15.)
        process=self.spawn(('shell','-T','CLASSPATH='+path,'app_process','/','com.loonglens.TouchBridge',str(self.size[0]),str(self.size[1])),stream=True)
        try:self.touch=TouchChannel(process,self.cancel)
        except Exception:
            if process.poll() is None:process.kill();process.wait(timeout=2.)
            raise

    def verify_game(self,frame):
        from vision import TitleDetector
        package=self.check_app(force=True)
        map_visible=TitleDetector().score(frame)>=.64
        if not map_visible and not (self.game_verified and package is None) and (not self.package or package is None):
            raise BackgroundInputError('Open the large Loong Haven map once, then Test connection. No Windows mouse input was sent.')
        if map_visible:self.game_verified=True
        if package and map_visible:self.package=package
        self.start_touch()
        return dict(package=self.package or '',map_visible=map_visible,width=self.size[0],height=self.size[1],transport='Android screenshots and persistent touch',capture_profile=self.capture_profile.copy())

    def focus(self):
        # The interface name is shared with WindowsBackend. No Windows focus
        # changes, desktop capture or cursor functions occur in this backend.
        self.connect();frame=self.render(self.capture_raw());self.verify_game(frame);self.last_frame=frame

    def capture(self):
        self.check()
        if self.touch is not None:self.touch.check()
        self.check_app();frame=self.render(self.capture_raw())
        if self.pending_motion is not None:
            from vision import patrol_map_mask
            before=self.pending_motion;mask=patrol_map_mask(frame.shape)!=0;deadline=time.monotonic()+2.5
            while float(np.mean(cv2.absdiff(before,frame).max(axis=2)[mask]>10))<.004:
                if time.monotonic()>=deadline:
                    raise BackgroundInputError('No map movement was confirmed after Android touch. Move away from the map edge and retry; minimized BlueStacks may have paused rendering.')
                self.wait(.05);frame=self.render(self.capture_raw())
            self.pending_motion=None
        if self.touch is not None:self.touch.check()
        self.last_frame=frame
        return frame

    def point(self,reference):
        x,y=reference;l,t,r,b=self.settings.content_rect
        if not all(math.isfinite(v) for v in (x,y)) or not(l<=x<r and t<=y<b):raise ValueError('Touch lies outside the Android display area.')
        if self.size is None:raise BackgroundInputError('Capture the Android screen before touching it.')
        w,h=self.size
        return min(w-1,round((x-l)*w/(r-l))),min(h-1,round((y-t)*h/(b-t)))

    def guard(self):
        self.check();self.check_app()
        if self.touch is None:raise BackgroundInputError('Android touch channel has not been initialized.')
        self.touch.check()

    def release(self):
        with self.state_lock:
            if self.down:
                try:
                    if self.touch is not None:self.touch.release()
                finally:self.down=False

    @contextmanager
    def hold_drag(self,start):
        self.guard();point=self.point(start)
        with self.state_lock:
            if self.down:raise BackgroundInputError('Android finger is already down.')
            self.down=True;self.position=start
        try:
            self.touch.send('D',point);self.wait(.025);yield
            self.wait(.18)
        finally:self.release()

    def drag_held_to(self,end):
        self.guard();point=self.point(end)
        if not self.down or not self.touch.down:raise BackgroundInputError('Android touch hold ended before the map movement.')
        before=self.last_frame.copy() if self.last_frame is not None else None
        self.touch.send('M',point);self.position=end
        if before is not None:self.pending_motion=before

    def click(self,reference):
        self.guard();point=self.point(reference)
        with self.state_lock:
            if self.down:raise BackgroundInputError('Android finger is already down.')
            self.down=True
        try:self.touch.send('D',point);self.wait(.05)
        finally:self.release()

    def drag(self,start,end):
        self.point(end)
        with self.hold_drag(start):self.drag_held_to(end)

    def input_not_responding(self,message):
        raise BackgroundInputError(message+' In ADB mode, run Test map pan with BlueStacks minimized to check background rendering.')

    def close(self):
        try:self.release()
        finally:
            try:
                if self.touch is not None:self.touch.close();self.touch=None
            finally:
                if self.screen is not None:self.screen.close();self.screen=None


def align_android_display(raw,desktop):
    """One-time, read-only registration to the user's existing map geometry."""
    desktop=cv2.resize(desktop,(570,1029),interpolation=cv2.INTER_AREA)
    small=cv2.resize(raw,(570,round(raw.shape[0]*570/raw.shape[1])),interpolation=cv2.INTER_AREA)
    sift=cv2.SIFT_create(nfeatures=2400,contrastThreshold=.025)
    a,da=sift.detectAndCompute(cv2.cvtColor(small,cv2.COLOR_BGR2GRAY),None)
    b,db=sift.detectAndCompute(cv2.cvtColor(desktop,cv2.COLOR_BGR2GRAY),None)
    if da is None or db is None:raise ValueError('Open a still map to align Android screenshots.')
    good=[m for pair in cv2.BFMatcher().knnMatch(da,db,k=2) if len(pair)==2 for m,n in [pair] if m.distance<.65*n.distance]
    if len(good)<25:raise ValueError('Not enough shared map detail to align screenshots.')
    source=np.float32([a[m.queryIdx].pt for m in good]);target=np.float32([b[m.trainIdx].pt for m in good])
    matrix,inliers=cv2.estimateAffine2D(source,target,method=cv2.RANSAC,ransacReprojThreshold=2.5,confidence=.999)
    if matrix is None or inliers is None or int(inliers.sum())<22:raise ValueError('Android screen alignment is uncertain.')
    keep=inliers[:,0].astype(bool);source=source[keep];target=target[keep]
    if np.ptp(source,axis=0).min()<100 or abs(matrix[0,1])>.008 or abs(matrix[1,0])>.008:raise ValueError('Keep the same upright game map visible while aligning.')
    ui=(source[:,1]<150)|(source[:,1]>small.shape[0]*.9)|((source[:,0]>480)&(source[:,1]>600))
    if int(ui.sum())<8:raise ValueError('Game controls do not agree with this window alignment.')
    sx,tx=np.polyfit(source[:,0],target[:,0],1);sy,ty=np.polyfit(source[:,1],target[:,1],1)
    error=np.linalg.norm(source*np.array((sx,sy))+np.array((tx,ty))-target,axis=1)
    if not(.75<sx<1.15 and .75<sy<1.15 and np.median(error)<1.8):raise ValueError('Android alignment is not accurate enough.')
    rect=(max(0.,float(tx)),max(0.,float(ty)),min(570.,float(tx+sx*small.shape[1])),min(1029.,float(ty+sy*small.shape[0])))
    if rect[0]>40 or rect[1]>100 or rect[2]<530 or rect[3]<940:raise ValueError('The screenshot does not match the visible Android display.')
    return InputSettings(content_rect=rect).content_rect
