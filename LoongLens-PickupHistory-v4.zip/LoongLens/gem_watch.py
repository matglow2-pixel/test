"""Gem Watch — visible-gameplay alerts for Windows / BlueStacks."""
from __future__ import annotations
import argparse
import json
import logging
from pathlib import Path
import sys
import threading

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-image', type=Path, help='Scan a saved gameplay screenshot without starting the Windows watcher')
    parser.add_argument('--no-hud-mask', action='store_true', help='For cropped reference images only; scan their entire area')
    args = parser.parse_args()
    import cv2
    from gem_detector import GemDetector, load_image
    cv2.setNumThreads(2)
    if args.check_image:
        try:
            image = load_image(args.check_image)
        except ValueError as exc:
            parser.error(str(exc))
        from dataclasses import asdict
        print(json.dumps([asdict(d) for d in GemDetector().detect(image, exclude_hud=not args.no_hud_mask)], indent=2))
        return
    if sys.platform != 'win32':
        parser.error('The live watcher requires Windows. --check-image works on other systems.')
    from win_overlay import find_visible_emulator, window_visible_at
    from gem_watch_worker import WatchWorker
    from resources import user_dir
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    from PIL import Image, ImageTk, ImageDraw
    import winsound

    folder = user_dir()
    folder.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=folder/'gemwatch.log', level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    settings_path = folder/'gemwatch-settings.json'
    settings = {}
    try:
        settings = json.loads(settings_path.read_text('utf-8'))
        if not isinstance(settings, dict):
            settings = {}
    except (ValueError,OSError):
        pass

    class App:
        def __init__(self):
            self.root = tk.Tk()
            self.root.title('Loong Lens · Gem Watch')
            self.root.geometry('460x710')
            self.root.minsize(440,690)
            self.root.configure(bg='#101620')
            self.root.protocol('WM_DELETE_WINDOW',self.close)
            self.closed = False
            self.paused = True
            self.test_mode = False
            self.sound_lock = threading.Lock()
            self.region = settings.get('region')
            if (not isinstance(self.region,(list,tuple)) or len(self.region)!=4
                    or not all(isinstance(v,(int,float)) and 0 <= v <= 1 for v in self.region)
                    or self.region[0]>=self.region[2] or self.region[1]>=self.region[3]):
                self.region = None
            self.worker = WatchWorker(find_visible_emulator, window_visible_at)
            self.worker.configure(region=self.region, reset=True)
            self.state = tk.StringVar(value='Ready — press Start watching')
            self.last_alert = tk.StringVar(value='No alerts yet')
            self.metrics = tk.StringVar(value='Target: 2 scans/sec · three sightings to confirm')
            self.sound = tk.BooleanVar(value=bool(settings.get('sound',True)))
            self.mask_hud = tk.BooleanVar(value=bool(settings.get('mask_hud',True)))
            self.worker.configure(exclude_hud=self.mask_hud.get())
            self.mode = tk.StringVar(value='Balanced')
            self.preview_photo = None
            self.last_frame = None
            self.selector = None
            self.build_ui()
            self.worker.start()
            self.root.after(150,self.tick)

        def build_ui(self):
            style = ttk.Style(self.root)
            style.theme_use('clam')
            style.configure('.',background='#101620',foreground='#e4eaf5',font=('Segoe UI',10))
            style.configure('Muted.TLabel',foreground='#95a5bc')
            style.configure('TButton',background='#253449',padding=(10,7))
            style.map('TButton',background=[('active','#344b69')])
            style.configure('TCheckbutton',background='#101620')
            style.map('TCheckbutton',background=[('active','#253449')])
            style.configure('TCombobox',fieldbackground='#253449',foreground='#e4eaf5')
            style.map('TCombobox',fieldbackground=[('readonly','#253449')],foreground=[('readonly','#e4eaf5')])
            body = ttk.Frame(self.root,padding=20)
            body.pack(fill='both',expand=True)
            ttk.Label(body,text='GEM WATCH',font=('Segoe UI',22,'bold')).pack(anchor='w')
            ttk.Label(body,text='Alerts for gems visible in normal gameplay',style='Muted.TLabel').pack(anchor='w',pady=(0,12))
            ttk.Label(body,textvariable=self.state,wraplength=410,font=('Segoe UI',11,'bold')).pack(anchor='w')
            ttk.Label(body,textvariable=self.last_alert,foreground='#f45bd0',wraplength=410).pack(anchor='w',pady=(5,12))
            row = ttk.Frame(body);row.pack(fill='x',pady=(0,8))
            self.start_button = ttk.Button(row,text='Start watching',command=self.toggle)
            self.start_button.pack(side='left')
            ttk.Button(row,text='Test sound',command=self.test_sound).pack(side='left',padx=8)
            ttk.Button(row,text='Test image',command=self.test_image).pack(side='left')
            ttk.Button(row,text='Exit',command=self.close).pack(side='right')
            row = ttk.Frame(body);row.pack(fill='x',pady=4)
            ttk.Checkbutton(row,text='Sound alerts',variable=self.sound,command=self.save).pack(side='left')
            ttk.Checkbutton(row,text='Mask interface areas',variable=self.mask_hud,command=self.change_mask).pack(side='right')
            row = ttk.Frame(body);row.pack(fill='x',pady=6)
            ttk.Label(row,text='Detection').pack(side='left')
            mode = ttk.Combobox(row,textvariable=self.mode,state='readonly',width=18,
                                values=['Conservative','Balanced','Sensitive'])
            mode.pack(side='right');mode.bind('<<ComboboxSelected>>',self.change_mode)
            row = ttk.Frame(body);row.pack(fill='x',pady=6)
            ttk.Button(row,text='Select scan area',command=self.select_area).pack(side='left')
            ttk.Button(row,text='Reset area',command=self.reset_area).pack(side='left',padx=8)
            ttk.Button(row,text='Re-arm alert',command=self.rearm).pack(side='right')
            ttk.Label(body,text='Live preview · pink boxes are detected candidates',style='Muted.TLabel').pack(anchor='w',pady=(10,4))
            self.preview = tk.Label(body,text='Start watching to see a preview',bg='#172131',fg='#95a5bc',width=42,height=15)
            self.preview.pack(fill='x')
            ttk.Label(body,textvariable=self.metrics,style='Muted.TLabel',wraplength=410).pack(anchor='w',pady=(9,6))
            ttk.Label(body,text='Keep BlueStacks visible and unminimized.\nAnother monitor is fine; covered areas are ignored.\n30-second alert cooldown. Visible gems alert once.',
                      style='Muted.TLabel',wraplength=410,font=('Segoe UI',9)).pack(anchor='w')

        def play_sound(self):
            if not self.sound_lock.acquire(blocking=False):
                return
            def play():
                try:
                    winsound.Beep(950,200)
                    winsound.Beep(1350,300)
                    winsound.Beep(950,200)
                except RuntimeError:
                    winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                finally:
                    self.sound_lock.release()
            threading.Thread(target=play,daemon=True,name='GemWatch-sound').start()

        def test_sound(self):
            self.play_sound()

        def toggle(self):
            if self.test_mode:
                self.test_mode = False
                self.paused = False
                self.worker.watch_game()
                self.start_button.configure(text='Pause')
                self.state.set('Returning to live BlueStacks capture…')
                self.last_alert.set('Live mode — previous photo alerts were tests')
                self.last_frame = None
                return
            self.paused = not self.paused
            self.worker.configure(paused=self.paused)
            self.start_button.configure(text='Start watching' if self.paused else 'Pause')
            self.state.set('Paused' if self.paused else 'Looking for BlueStacks…')

        def test_image(self):
            path = filedialog.askopenfilename(title='Choose a gem or no-gem screenshot',
                                             filetypes=[('Pictures','*.png *.jpg *.jpeg *.webp *.bmp'),('All files','*.*')])
            if not path:
                return
            try:
                image = load_image(path)
                if min(image.shape[:2]) < 60:
                    raise ValueError('Choose a gameplay screenshot at least 60 pixels wide/high.')
            except ValueError as exc:
                messagebox.showerror('Image test failed',str(exc),parent=self.root)
                return
            self.test_mode = True
            self.paused = False
            self.last_frame = None
            self.worker.test_image(image)
            self.start_button.configure(text='Watch game')
            self.state.set('IMAGE TEST — scanning your selected picture…')
            self.last_alert.set('Image test — confirmation and sound run automatically')

        def rearm(self):
            self.worker.configure(region=self.region,reset=True)
            self.last_alert.set('Re-armed — visible gems can alert again')

        def change_mode(self,_=None):
            threshold = {'Conservative':.84,'Balanced':.77,'Sensitive':.70}[self.mode.get()]
            self.worker.configure(threshold=threshold,region=self.region,reset=True)

        def reset_area(self):
            self.region = None
            self.worker.configure(region=None,reset=True)
            self.save()

        def change_mask(self):
            self.worker.configure(exclude_hud=self.mask_hud.get())
            self.save()

        def select_area(self):
            snapshot = self.worker.get()
            frame = snapshot['frame']
            if frame is None:
                messagebox.showinfo('Scan area','Start watching with BlueStacks visible first.',parent=self.root)
                return
            if self.selector is not None and self.selector.winfo_exists():
                self.selector.lift();return
            image = Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
            image.thumbnail((600,800))
            win = self.selector = tk.Toplevel(self.root)
            win.title('Drag a rectangle over terrain, then Save')
            photo = ImageTk.PhotoImage(image)
            canvas = tk.Canvas(win,width=image.width,height=image.height,highlightthickness=0)
            canvas.pack();canvas.create_image(0,0,image=photo,anchor='nw');canvas.photo = photo
            selection = {'start':None,'end':None,'box':None}
            def press(event):
                selection['start'] = (max(0,min(image.width,event.x)),max(0,min(image.height,event.y)))
                selection['end'] = None
                if selection['box']:
                    canvas.delete(selection['box'])
                selection['box'] = canvas.create_rectangle(*selection['start'],*selection['start'],outline='#f45bd0',width=3)
            def drag(event):
                if selection['start'] is None:return
                selection['end'] = (max(0,min(image.width,event.x)),max(0,min(image.height,event.y)))
                canvas.coords(selection['box'],*selection['start'],*selection['end'])
            def save():
                if selection['start'] is None or selection['end'] is None:return
                x0,y0 = selection['start'];x1,y1 = selection['end']
                if abs(x1-x0)<30 or abs(y1-y0)<30:return
                self.region = [min(x0,x1)/image.width,min(y0,y1)/image.height,
                               max(x0,x1)/image.width,max(y0,y1)/image.height]
                self.worker.configure(region=self.region,reset=True)
                self.save();win.destroy()
            canvas.bind('<Button-1>',press);canvas.bind('<B1-Motion>',drag);canvas.bind('<ButtonRelease-1>',drag)
            ttk.Label(win,text='Interface masking follows the panel checkbox.').pack(pady=5)
            ttk.Button(win,text='Save area',command=save).pack(pady=5)

        def save(self):
            try:
                tmp = settings_path.with_suffix('.tmp')
                tmp.write_text(json.dumps(dict(region=self.region,sound=self.sound.get(),mask_hud=self.mask_hud.get()),indent=2),encoding='utf-8')
                tmp.replace(settings_path)
            except OSError:
                logging.exception('Could not save gem watcher preferences')

        def tick(self):
            if self.closed:return
            try:
                snapshot = self.worker.get()
                self.state.set(snapshot['state'])
                for alert in self.worker.drain_alerts():
                    if self.paused:continue
                    prefix = 'IMAGE TEST: GEM DETECTED' if alert.get('test_mode') else 'GEM DETECTED'
                    self.last_alert.set(f"{prefix} at {alert['time']} · {alert['count']} candidate(s)")
                    if self.sound.get():self.play_sound()
                    logging.info('Gem alert: %s',alert)
                frame = snapshot['frame']
                if frame is not None and frame is not self.last_frame:
                    self.last_frame = frame
                    image = Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
                    pen = ImageDraw.Draw(image)
                    for d in snapshot['detections']:
                        pen.rectangle((d.x-3,d.y-3,d.x+d.width+3,d.y+d.height+3),outline='#f45bd0',width=3)
                    if self.region and not self.test_mode:
                        l,t,r,b = self.region
                        pen.rectangle((l*image.width,t*image.height,r*image.width,b*image.height),outline='#41c4ff',width=2)
                    image.thumbnail((400,290))
                    self.preview_photo = ImageTk.PhotoImage(image)
                    self.preview.configure(image=self.preview_photo,text='',width=400,height=290)
                if frame is None:
                    self.last_frame = None
                    self.preview.configure(image='',text='Keep BlueStacks visible to capture gameplay',width=42,height=15)
                self.metrics.set(f"Last scan: {snapshot['scan_ms']:.0f} ms · target 2 scans/sec\nConfirm: 3 sightings over 0.8 sec · re-arm after 10 sec absent")
            except Exception:
                logging.exception('Gem Watch panel update failed')
            self.root.after(150,self.tick)

        def close(self):
            self.closed = True
            self.worker.configure(paused=True)
            self.save()
            self.worker.close()
            self.root.destroy()

    App().root.mainloop()

if __name__ == '__main__':
    main()
