"""Real detector/alert/UI picture-mode smoke check on Linux with mock Windows audio.

The live desktop backend is mocked; image loading, detection, confirmation,
panel updates and sound requests use the actual application implementations.
"""
import os
from pathlib import Path
import sys
import types
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from tkinter import ttk,filedialog
import cv2
import numpy as np
from PIL import Image
from mss.linux import MSS
from gem_detector import ROOT
import gem_watch

OUT=ROOT/'artifacts'
OUT.mkdir(exist_ok=True)
os.environ['XDG_CACHE_HOME']=str(OUT/'image-test-ui-settings')
positive=Path(os.environ.get('GEM_WATCH_TEST_POSITIVE',OUT/'picture-mode-positive.png'))
negative=Path(os.environ.get('GEM_WATCH_TEST_NEGATIVE',OUT/'picture-mode-negative.png'))
if not os.environ.get('GEM_WATCH_TEST_POSITIVE'):
    frame=np.full((1029,570,3),(95,145,105),np.uint8)
    sprite=cv2.imread(str(ROOT/'gem_templates/gem_0.png'))
    frame[440:440+sprite.shape[0],280:280+sprite.shape[1]]=sprite
    cv2.imwrite(str(positive),frame)
if not os.environ.get('GEM_WATCH_TEST_NEGATIVE'):
    cv2.imwrite(str(negative),np.full((1029,570,3),(95,145,105),np.uint8))

class Capture:
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def grab(self,*args):raise AssertionError('Image test should not need desktop capture')

sys.modules['mss']=types.SimpleNamespace(mss=Capture)
sys.modules['win_overlay']=types.SimpleNamespace(find_visible_emulator=lambda:None,window_visible_at=lambda *args:False)
sounds=[]
sys.modules['winsound']=types.SimpleNamespace(Beep=lambda *args:sounds.append(args),MessageBeep=lambda *args:None,MB_ICONEXCLAMATION=48)
files=iter([str(positive),str(negative)])
filedialog.askopenfilename=lambda **kwargs:next(files)
original=tk.Tk.__init__
errors=[]
finished=[]

def descendants(root):
    result=[]
    for w in root.winfo_children():result.append(w);result.extend(descendants(w))
    return result

def start(self,*args,**kwargs):
    original(self,*args,**kwargs)
    def callback_error(*args):
        errors.append(args);traceback.print_exception(*args)
    self.report_callback_exception=callback_error
    def buttons():return {w.cget('text'):w for w in descendants(self) if isinstance(w,ttk.Button)}
    def label_values():
        return [str(self.getvar(w.cget('textvariable'))) for w in descendants(self)
                if isinstance(w,ttk.Label) and w.cget('textvariable')]
    def load_positive():
        buttons()['Test image'].invoke()
        assert 'Watch game' in buttons()
        self.after(2500,positive_check)
    def positive_check():
        labels=label_values()
        assert any('IMAGE TEST: GEM DETECTED' in text for text in labels),labels
        assert len(sounds)==3,sounds
        self.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            cap=screen.grab(dict(left=self.winfo_rootx(),top=self.winfo_rooty(),width=self.winfo_width(),height=self.winfo_height()))
            Image.frombytes('RGB',cap.size,cap.rgb).save(OUT/'image-test-panel-preview.png')
        buttons()['Test image'].invoke()
        self.after(2200,negative_check)
    def negative_check():
        labels=label_values()
        assert any('IMAGE TEST · no gems detected' in text for text in labels),labels
        assert not any('IMAGE TEST: GEM DETECTED' in text for text in labels),labels
        assert len(sounds)==3,'Negative photo unexpectedly sounded an alert'
        buttons()['Watch game'].invoke()
        self.after(650,game_check)
    def game_check():
        labels=label_values()
        assert any('Waiting for a visible BlueStacks window' in text for text in labels),labels
        assert not errors,errors
        finished.append(True)
        buttons()['Exit'].invoke()
        print('Image-test UI passed: real positive image detection + confirmation + sound request; negative image quiet; return to game.')
    self.after(300,load_positive)
    self.after(12000,self.destroy)

tk.Tk.__init__=start
sys.platform='win32';sys.argv=['gem_watch.py']
gem_watch.main()
assert finished and not errors,(finished,errors)
