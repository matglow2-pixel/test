# Gem Watch: visible-screen AFK alerts

Gem Watch looks for the actual multicolored crystal piles shown in the user's `GemsPictures.rar`. It scans visible normal gameplay instead of assuming exact spawn positions. A gem can appear anywhere in the allowed viewing area.

## Version 2: direct image testing and wider-window scaling

The first release normalized every BlueStacks capture to portrait width and searched only a narrow size range. A screenshot displayed in Media Manager's wider sidebar layout could shrink below that range. Version 2 preserves more detail in wide windows and selects template sizes using the observed crystal tip. Reproductions of that sidebar layout are included in the regression checks.

**Test image** now loads a screenshot directly from your PC. It runs the actual detector and temporal alert gate repeatedly and requests the normal alert sound when a pile is confirmed. Photo mode is clearly labeled **IMAGE TEST**; it is not a live-game spawn alert. The image test ignores saved live scan rectangles, interface masks and window-ownership checks so another application's photo viewer cannot interfere.

To test without waiting for a spawn:

1. Start `RUN_GEM_WATCH.bat`, click **Test sound**, then **Test image**.
2. Choose an original gem screenshot (PNG/JPG). Expect pink boxes, a message starting **IMAGE TEST: GEM DETECTED**, and the alert tone after roughly 1–2 seconds on a responsive machine.
3. Click **Test image** again and choose `MyLocationNoGems.png`. Expect **IMAGE TEST · no gems detected** and no new alert sound.
4. Click **Watch game** to return to live BlueStacks capture. Your live scan rectangle and interface-mask settings are preserved.

Loading the same positive photo again re-arms its alert. This checks recognition, confirmation, panel messages and sound requests without needing a real spawn; it does not validate native Windows screen capture or live-game detection.

## Start

1. Extract the whole ZIP into a new writable folder. Install 64-bit Python 3.10–3.13 with Tcl/Tk, as described in `README.md`.
2. Double-click **`RUN_GEM_WATCH.bat`**. It uses the same private `.venv` and pinned dependencies as the map overlay, installing them if necessary.
3. Leave BlueStacks showing your normal AFK gameplay view. **Do not open the large map.** Keep the game visible and unminimized.
4. Click **Test sound** and confirm that you can hear it. Then click **Start watching**.
5. Check the live preview. Pink boxes show candidates; a confirmed gem triggers the sound and updates the panel's last-alert message.

The game does not need keyboard focus. It can remain visible on a second monitor while you use a browser or another application. The watcher reads the desktop: covered areas and minimized windows cannot be reliably checked. Candidate centers and corners must belong to the BlueStacks window before they are allowed to trigger alerts. Detection also needs an unobstructed view of the gem itself; terrain, characters or effects can hide it.

The largest visible window titled `BlueStacks App Player` is selected. Multiple simultaneous emulator instances are not individually selectable in this prototype.

## Controls and behavior

- **Start watching / Pause:** enable or pause scanning. Startup is paused so you can test the sound and position windows first.
- **Test sound:** plays the alert tone even if automatic sound alerts are unchecked.
- **Test image / Watch game:** load a screenshot for the clearly labeled offline alert test, then return to live capture. Automatic tones still follow the **Sound alerts** checkbox.
- **Sound alerts:** enable/disable the automatic tone. This release uses sound and a panel message; it does not send phone, email, or push notifications.
- **Mask interface areas:** exclude the default HUD blocks. If that mask covers visible terrain in your layout, turn it off and use **Select scan area** to define the gameplay rectangle you want checked. Unmasked UI can increase false detections.
- **Detection:** Balanced uses the screenshot-tested threshold. Conservative demands a closer match and may miss gems; Sensitive allows looser matches and may produce false alerts. Those alternate thresholds have not been validated on a live session.
- **Select scan area:** start watching, then drag a rectangle over gameplay in the larger captured preview and save it. This is an optional search area, not a list of spawn coordinates. The interface-mask checkbox also applies inside it.
- **Reset area:** search the default allowed gameplay area again.
- **Re-arm alert:** allow already-visible gems to produce another confirmed alert.

The default mask excludes the header, minimap, right-side event controls, edge strips, and the bottom chat/menu area. Its rectangular exclusions can also cover some terrain around controls. If your HUD layout differs, disable **Mask interface areas**, select the actual visible gameplay area, and inspect the preview.

The target is **two scans per second**, depending on machine speed. A candidate needs **three consecutive sightings spanning at least 0.8 seconds**. A continuously visible gem alerts once; a brief missed detection does not immediately re-arm it. After at least 10 seconds without a matching sighting, it can be treated as a new appearance. There is also a **30-second global alert cooldown**. A new persistent gem seen during that cooldown can alert when it expires.

A gem already visible when watching starts also triggers an alert after confirmation. The watcher detects appearance/presence; it cannot establish the exact spawn time, ownership, who collected it, or a guaranteed one-hour respawn schedule. It does not collect gems or move your character.

Preferences and scan area are saved in **`%LOCALAPPDATA%\LoongLens\gemwatch-settings.json`**. Diagnostic logs are in **`gemwatch.log`** in the same directory. Sensitivity mode starts at Balanced each launch.

## Screenshot validation

The archive supplied **18 positive screenshots containing 19 visible gem piles**, and **one negative screenshot**, `MyLocationNoGems.png`.

Only three positive screenshots supplied the small appearance templates:

- `IMG_1401.png`
- `IMG_1423.png`
- `IMG_1442.png`

On the 15 remaining positive screenshots, the detector found all 16 annotated piles, with no extra detections. Across all 18 positive screenshots it found all 19 annotated piles. Your negative screenshot produced no detections, both with the full-image reference scan and with the live HUD mask.

The reference screenshots have different cropping/UI layouts, so the positive reference evaluation scans their whole images with HUD masking disabled. Live HUD masking, arbitrary locations, doubled resolution, selected-area exclusions, temporal confirmation, cooldown and occlusion filtering are exercised separately by automated tests. Version 2 also checks smaller pictures inside wide sidebar layouts, direct picture-mode alerts, negative picture tests, live-mode return and rejection of results from a previous input source.

These are **small screenshot-set results, not a guarantee against false alerts or missed spawns**. There is only one no-gem example, and it was used during development. We have not tested a long live gameplay session, motion/animation coverage, Windows capture, native occlusion checks or actual Windows audio playback. The Tk panel was exercised on a Linux virtual display with simulated Windows capture and sound backends.

Full-resolution source screenshots and your no-gem screenshot are **not included in the downloadable release**. Only three tiny crystal-pile crops are distributed as detector assets. No screenshots are sent to an online service during operation.

## Offline checks

```sh
python gem_watch.py --check-image path/to/MyLocationNoGems.png
python gem_watch.py --check-image path/to/cropped-reference.png --no-hud-mask
python -m pytest -q
python tools/validate_gem_examples.py path/to/extracted/GemsPictures
```

The last command needs the original image folder and checks all annotated locations, including missing and extra detections. Results are written to `artifacts/gem-validation.json`. The original images are not part of the release.

## First live check on your PC

Test the sound, verify that your empty AFK view produces no pink boxes or alerts, and check a real gem when one becomes available. If another object triggers an alert, save the offending gameplay screenshot for diagnosis. If a real gem is missed, capture it while clearly visible. Additional no-gem scenes and a short gameplay recording would improve validation of false alerts and animation changes.
