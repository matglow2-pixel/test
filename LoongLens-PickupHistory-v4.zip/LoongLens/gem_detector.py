"""Visible-screen gem recognition and per-object alert confirmation.

No map coordinates are used. Color proposes candidates; real crystal/rock
templates confirm their appearance at several sizes. All processing is local.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import math
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent

def load_image(path):
    """Support Windows Unicode paths as well as ordinary screenshot filenames."""
    try:
        raw = np.fromfile(Path(path), dtype=np.uint8)
        image = cv2.imdecode(raw, cv2.IMREAD_COLOR)
    except (OSError, cv2.error):
        image = None
    if image is None:
        raise ValueError('Could not open that image. Choose a PNG, JPG, or another supported picture.')
    return image

@dataclass(frozen=True)
class Detection:
    x: int
    y: int
    width: int
    height: int
    score: float

    @property
    def center(self):
        return self.x + self.width / 2, self.y + self.height / 2

def gameplay_mask(shape):
    """Exclude fixed HUD blocks; an optional selected rectangle further limits it."""
    h, w = shape[:2]
    mask = np.full((h, w), 255, np.uint8)
    # The topmost band can contain emulator/phone chrome. Bottom contains chat,
    # menus and action buttons. The remaining HUD blocks are masked separately.
    mask[:round(.035*h)] = 0
    mask[round(.81*h):] = 0
    mask[:round(.17*h), :round(.44*w)] = 0
    mask[:round(.29*h), round(.69*w):] = 0
    mask[round(.29*h):round(.61*h), round(.86*w):] = 0
    mask[:, :round(.018*w)] = 0
    mask[:, round(.985*w):] = 0
    return mask

class GemDetector:
    SCALES = (1., .85, 1.15, .45, .55, .65, .75, 1.30, 1.50, 1.75)

    def __init__(self, template_dir=None, threshold=.77):
        self.threshold = threshold
        self.templates = []
        paths = sorted(Path(template_dir or ROOT / 'gem_templates').glob('gem_*.png'))
        if not paths:
            raise FileNotFoundError('Gem templates are missing. Extract the complete program folder.')
        for path in paths:
            source = cv2.imread(str(path))
            if source is None:
                raise ValueError(f'Cannot load {path.name}')
            for scale in self.SCALES:
                image = cv2.resize(source, None, fx=scale, fy=scale,
                                   interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
                self.templates.append(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY))

    def detect(self, bgr, region=None, exclude_hud=True):
        """Return gem boxes in the original screenshot's pixel coordinates.

        region is an optional normalized (left, top, right, bottom) rectangle.
        exclude_hud=False is useful for cropped reference screenshots in testing.
        """
        if bgr.ndim != 3 or bgr.shape[2] < 3 or min(bgr.shape[:2]) < 60:
            raise ValueError('Expected a BGR gameplay screenshot at least 60 pixels wide/high.')
        # Keep more detail in wide windows (e.g. Media Manager with a sidebar).
        # Shrinking those to portrait width can erase a crystal's distinctive tip.
        working_width = 900 if bgr.shape[1]/bgr.shape[0] > .85 else 570
        ratio = working_width / bgr.shape[1]
        frame = cv2.resize(bgr[:, :, :3], (working_width, round(bgr.shape[0]*ratio)), interpolation=cv2.INTER_AREA)
        h, w = frame.shape[:2]
        allowed = gameplay_mask(frame.shape) if exclude_hud else np.full((h,w),255,np.uint8)
        if region is not None:
            if (len(region) != 4 or not all(math.isfinite(float(v)) and 0 <= v <= 1 for v in region)
                    or region[2] <= region[0] or region[3] <= region[1]):
                raise ValueError('Scan area must be a nonempty normalized rectangle.')
            left, top, right, bottom = region
            selected = np.zeros_like(allowed)
            selected[round(top*h):round(bottom*h), round(left*w):round(right*w)] = 255
            allowed &= selected
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        purple = cv2.inRange(hsv, (130,45,85), (179,255,255))
        yellow_screen = cv2.inRange(hsv, (12,65,95), (42,255,255))
        blue_screen = cv2.inRange(hsv, (75,45,70), (125,255,255))
        purple &= allowed
        _, _, stats, centers = cv2.connectedComponentsWithStats(purple)
        proposed = []
        for stat, (cx,cy) in zip(stats[1:], centers[1:]):
            _,_,cw,ch,area = stat
            if not (3 <= area <= 320 and 2 <= cw <= 32 and 2 <= ch <= 32):
                continue
            gold_area = (slice(max(0,round(cy)-5),min(h,round(cy)+14)),
                         slice(max(0,round(cx)-2),min(w,round(cx)+18)))
            blue_area = (slice(max(0,round(cy)+2),min(h,round(cy)+27)),
                         slice(max(0,round(cx)-18),min(w,round(cx)+15)))
            if np.count_nonzero(yellow_screen[gold_area]) < 2 or np.count_nonzero(blue_screen[blue_area]) < 2:
                continue
            # Only small neighborhoods need expensive shape comparisons. This
            # still searches the whole allowed screen, without fixed spawn pixels.
            left, top = max(0,round(cx)-39), max(0,round(cy)-26)
            patch = gray[top:min(h,round(cy)+51), left:min(w,round(cx)+40)]
            best = None
            for template in self.templates:
                th,tw = template.shape[:2]
                # The pink crystal is roughly half the complete pile's height.
                # Narrow the template bank using that observed size rather than
                # assuming the whole emulator window has the game's proportions.
                if not .65 <= th / (2 * ch) <= 1.5:
                    continue
                if patch.shape[0] < th or patch.shape[1] < tw:
                    continue
                response = cv2.matchTemplate(patch, template, cv2.TM_CCOEFF_NORMED)
                _, score, _, (px,py) = cv2.minMaxLoc(response)
                minimum_score = max(self.threshold, .84) if tw < 22 else self.threshold
                if not math.isfinite(score) or score < minimum_score:
                    continue
                x,y = left+px,top+py
                # A proposal near an excluded HUD block must not drag the matcher
                # back into it. Require the complete gem core inside the scan mask.
                if not allowed[y:y+th,x:x+tw].all():
                    continue
                core = hsv[y:y+th,x:x+tw]
                pink = cv2.inRange(core, (130,45,85), (179,255,255))
                yellow = cv2.inRange(core, (12,65,95), (42,255,255))
                blue = cv2.inRange(core, (75,45,70), (125,255,255))
                if np.count_nonzero(pink) < 2 or np.count_nonzero(yellow) < 2 or np.count_nonzero(blue) < 2:
                    continue
                if best is None or score > best.score:
                    best = Detection(x,y,tw,th,float(score))
            if best is not None:
                proposed.append(best)
        # The same crystal can propose more than one color component/template.
        keep = []
        for candidate in sorted(proposed, key=lambda d:d.score, reverse=True):
            if all(np.linalg.norm(np.subtract(candidate.center, other.center)) > max(candidate.width, other.width)*.65
                   for other in keep):
                keep.append(candidate)
        return [Detection(round(d.x/ratio), round(d.y/ratio), max(1,round(d.width/ratio)),
                          max(1,round(d.height/ratio)), d.score) for d in keep]

@dataclass
class _Track:
    center: tuple
    first_seen: float
    last_seen: float
    hits: int = 1
    announced: bool = False

class AlertGate:
    """Confirm distinct objects across frames and silence continuously visible ones."""
    def __init__(self, required_hits=3, confirmation_seconds=.8, disappearance_seconds=10., cooldown=30.):
        self.required_hits = required_hits
        self.confirmation_seconds = confirmation_seconds
        self.disappearance_seconds = disappearance_seconds
        self.cooldown = cooldown
        self.reset()

    def reset(self):
        self.tracks = []
        self.last_alert = -float('inf')

    def update(self, detections, now):
        self.tracks = [t for t in self.tracks if now-t.last_seen <= self.disappearance_seconds]
        used = set()
        current = []
        for detection in detections:
            candidates = [(np.linalg.norm(np.subtract(detection.center,t.center)), i, t)
                          for i,t in enumerate(self.tracks) if i not in used]
            distance,i,track = min(candidates,key=lambda item:item[0]) if candidates else (float('inf'),None,None)
            if track is not None and distance < max(20.,detection.width*1.2):
                used.add(i)
                # Consecutive sightings are required; a short flicker does not
                # rearm an announced object, while gaps reset unconfirmed hits.
                if track.hits == 0:
                    track.first_seen = now
                track.center = detection.center
                track.last_seen = now
                track.hits += 1
            else:
                track = _Track(detection.center, now, now)
                self.tracks.append(track)
                used.add(len(self.tracks)-1)
            current.append(track)
        for track in self.tracks:
            if not any(track is seen for seen in current) and not track.announced:
                track.hits = 0
                track.first_seen = now
        ready = [t for t in current if not t.announced and t.hits >= self.required_hits
                 and now-t.first_seen >= self.confirmation_seconds]
        if ready and now-self.last_alert >= self.cooldown:
            for track in ready:
                track.announced = True
            self.last_alert = now
            return True
        return False
