"""Sidebar navigation backed by the existing notebook pages and controllers."""
from tkinter import ttk
from ui_assets import gem_image,line_image


class Sidebar:
    def __init__(self,parent,notebook,on_exit):
        self.notebook=notebook;self.images=[];self.buttons=[]
        self.frame=ttk.Frame(parent,style='Sidebar.TFrame',width=206,padding=(10,22,10,12))
        self.frame.pack(side='left',fill='y');self.frame.pack_propagate(False)
        brand=ttk.Frame(self.frame,style='Sidebar.TFrame');brand.pack(fill='x',padx=8)
        art=gem_image(self.frame,38);self.images.append(art)
        ttk.Label(brand,image=art,style='Sidebar.TLabel').pack(side='left',padx=(0,7))
        ttk.Label(brand,text='Loong Lens',style='Logo.TLabel').pack(side='left')
        ttk.Label(self.frame,text='v38',style='Sidebar.TLabel').pack(anchor='w',padx=55,pady=(4,0))
        ttk.Label(self.frame,text='Loong Haven companion',style='Sidebar.TLabel').pack(anchor='w',padx=12,pady=(12,20))
        ttk.Separator(self.frame).pack(fill='x',padx=6,pady=(0,12))
        for index,(title,kind) in enumerate((('Map Tweaker','map'),('Gem Sniper','target'),('Gem Spy','gem'))):
            icon=gem_image(self.frame,26) if kind=='gem' else line_image(self.frame,kind,26)
            self.images.append(icon)
            button=ttk.Button(self.frame,text='  '+title,image=icon,compound='left',style='Nav.TButton',
                command=lambda i=index:self.notebook.select(i))
            button.pack(fill='x',pady=3);self.buttons.append(button)
        ttk.Button(self.frame,text='Exit',command=on_exit).pack(side='bottom',fill='x',padx=8)
        ttk.Label(self.frame,text='F10 · Emergency stop',style='Sidebar.TLabel').pack(side='bottom',anchor='w',padx=10,pady=14)
        self.notebook.bind('<<NotebookTabChanged>>',self.changed,add='+')

    def changed(self,event=None):
        selected=self.notebook.index(self.notebook.select())
        for i,button in enumerate(self.buttons):button.configure(style='Selected.Nav.TButton' if i==selected else 'Nav.TButton')
