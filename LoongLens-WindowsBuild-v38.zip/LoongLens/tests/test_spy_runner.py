from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
import threading
import faulthandler
import cv2
import numpy as np
import pytest
from camera_patrol import Viewpoint
from gem_detector import Detection
from patrol_live import LiveSettings
from spy_history import SpyHistory
from spy_runner import SpyRunner,scene_quality
from test_live_patrol import Backend,Clock,Locator


@pytest.fixture(scope='module',autouse=True)
def application_opencv_threads():
    previous=cv2.getNumThreads();cv2.setNumThreads(2)
    try:yield
    finally:cv2.setNumThreads(previous)


def texture():
    yy,xx=np.indices((1029,570));value=((xx//12+yy//13)%2)*80
    frame=np.stack((value+60,value+85,value+75),axis=2).astype(np.uint8)
    frame[0,0]=0
    return frame


class SceneBackend(Backend):
    def __init__(self,views,clock,fail_index=None,always_fail=False):
        super().__init__(threading.Event(),clock)
        self.views=views;self.center=(views[0].x,views[0].y);self.camera=self.center
        self.current=0;self.selections=[];self.frame=texture();self.fail_index=fail_index
        self.failed=False;self.always_fail=always_fail;self.contexts=0
    def __enter__(self):self.contexts+=1;return self
    def __exit__(self,*args):self.held=False
    def capture(self):
        if self.always_fail:raise RuntimeError('Temporary capture failure')
        if not self.open:
            if self.current==self.fail_index and not self.failed:
                self.failed=True;raise RuntimeError('Temporary scene failure')
            self.wait(0);return self.frame.copy()
        return super().capture()
    def click(self,point):
        was_open=self.open
        if was_open and point!=LiveSettings().map_close:
            pose=Locator(self).locate(None)
            world=((point[0]-pose.tx)/pose.scale,(pose.ty-point[1])/pose.scale)
            self.current=min(range(len(self.views)),key=lambda i:__import__('math').dist(world,(self.views[i].x,self.views[i].y)))
            self.camera=(self.views[self.current].x,self.views[self.current].y);self.selections.append(self.current)
        super().click(point)
        if not was_open and self.open:self.center=self.camera


def configured(tmp_path,passes=1,fail_index=None,always_fail=False,boxes=None,hook=None):
    views=(Viewpoint(100.,100.,'A',frozenset({(100,100)}),1),Viewpoint(101.,100.,'B',frozenset({(101,100)}),2))
    clock=Clock();backend=SceneBackend(views,clock,fail_index,always_fail);events=[]
    def emit(event):
        events.append(event)
        if hook:hook(runner,event)
        if event['kind']=='spy_pass_complete' and event['run']>=passes:runner.stop()
    runner=SpyRunner(tmp_path,emit,backend_factory=lambda cancel:backend,clock=clock,
                     wall=lambda:datetime(2026,10,18,8).timestamp()+clock.now)
    backend.cancel=runner.cancel
    def wait(seconds):
        if runner.cancel.is_set():return True
        clock.now+=seconds
        return runner.cancel.is_set()
    runner.retry_wait=wait
    default=[Detection(273,503,24,23,.95)]
    runner.detector=SimpleNamespace(threshold=.77,detect=lambda *a,**kw: boxes(backend) if boxes else default)
    runner.locator=Locator(backend);runner.title=SimpleNamespace(score=lambda f:float(f[0,0,0]))
    return runner,backend,events,views


def finish(runner):
    # SQLite commits and PNG writes use real host I/O despite a virtual game clock.
    runner.thread.join(30)
    if runner.running:
        faulthandler.dump_traceback(all_threads=True)
        runner.stop();runner.thread.join(5)
        pytest.fail('Spy fixture exceeded its bounded completion budget; thread stacks printed')
    assert not runner.running


def test_spy_continues_after_gems_without_clicking_them_and_saves_only_new_images(tmp_path):
    runner,backend,events,views=configured(tmp_path,passes=2)
    assert runner.start(views,LiveSettings(approach_gem=True));finish(runner)
    assert backend.selections==[0,1,0,1]
    assert all(point==LiveSettings().map_open for action,point,was_map in backend.inputs if action=='click' and not was_map)
    assert not any(event['kind'] in ('found','gem_clicked') for event in events)
    store=SpyHistory(tmp_path/'sightings.sqlite3')
    assert store.totals()['total']==runner.snapshot()['gems']==2
    assert len(store.standard.list())==2 and {row.source for row in store.standard.list()}=={'Gem Spy'}
    assert len(list((tmp_path/'screenshots').glob('*.png')))==2
    assert all(row['runs']==2 for row in store.encounters())
    assert sum(row['gems'] for row in store.hours())==2
    store.close()


def test_multiple_confirmed_gems_in_one_view_are_all_recorded(tmp_path):
    boxes=lambda backend:[Detection(190,440,24,24,.96),Detection(350,550,24,24,.97)] if backend.current==0 else []
    runner,backend,events,views=configured(tmp_path,boxes=boxes)
    runner.start(views,LiveSettings());finish(runner)
    store=SpyHistory(tmp_path/'sightings.sqlite3')
    assert store.totals()['total']==2 and len(store.standard.list())==2
    assert len(list((tmp_path/'screenshots').glob('*.png')))==2
    store.close()


def test_transient_failure_retries_current_point_without_rescanning_completed_point(tmp_path):
    runner,backend,events,views=configured(tmp_path,fail_index=1)
    runner.start(views,LiveSettings());finish(runner)
    assert backend.selections==[0,1,1]
    assert any('Recovering' in e.get('message','') for e in events)
    store=SpyHistory(tmp_path/'sightings.sqlite3')
    assert store.totals()['total']==2 and len(store.standard.list())==2
    assert any(row['outcome']=='unclear' for row in store.visits())
    assert store.state('checkpoint')['recoveries']==1 and runner.snapshot()['elapsed']>0
    store.close()


def test_stop_during_recovery_never_restarts_the_worker(tmp_path):
    def stop(runner,event):
        if event['kind']=='status' and event['message'].startswith('Recovering'):runner.stop()
    runner,backend,events,views=configured(tmp_path,always_fail=True,hook=stop)
    runner.start(views,LiveSettings());finish(runner)
    assert backend.contexts==1 and runner.cancel.is_set()
    assert runner.snapshot()['gems']==0
    assert not backend.inputs
    store=SpyHistory(tmp_path/'sightings.sqlite3')
    assert [row['outcome'] for row in store.visits()]==['unclear']
    store.close()


def test_progress_time_and_duplicate_state_survive_app_restart(tmp_path):
    def stop_halfway(runner,event):
        if event['kind']=='checked' and event['index']==0:runner.stop()
    runner,backend,events,views=configured(tmp_path,hook=stop_halfway)
    runner.start(views,LiveSettings());finish(runner)
    before=runner.snapshot()
    assert backend.selections==[0] and before['gems']==1
    resumed,second,events,views=configured(tmp_path)
    assert resumed.snapshot()['processed']==1 and resumed.snapshot()['elapsed']>=before['elapsed']
    resumed.start(views,LiveSettings());finish(resumed)
    assert second.selections==[1] and resumed.snapshot()['gems']==2
    assert resumed.snapshot()['elapsed']>before['elapsed']
    assert len(list((tmp_path/'screenshots').glob('*.png')))==2


def test_loading_frames_and_unconfirmed_candidates_are_never_empty_evidence(tmp_path):
    runner,backend,events,views=configured(tmp_path,boxes=lambda b:[])
    backend.frame=np.full((1029,570,3),30,np.uint8);backend.frame[0,0]=0
    runner.start(views,LiveSettings());finish(runner)
    store=SpyHistory(tmp_path/'sightings.sqlite3')
    assert all(row['outcome']=='unclear' and not row['clear_absence'] for row in store.visits())
    assert store.totals()['total']==0 and not list((tmp_path/'screenshots').glob('*.png'))
    store.close()


def test_scene_quality_rejects_blank_loading_and_large_camera_changes():
    scene=texture();assert scene_quality(scene,scene)
    assert not scene_quality(np.zeros_like(scene))
    assert not scene_quality(np.full_like(scene,80))
    assert not scene_quality(scene,255-scene)


def test_real_detector_records_template_gems_and_reuses_encounters_on_next_pass(tmp_path):
    from gem_detector import GemDetector
    from resources import ROOT
    runner,backend,events,views=configured(tmp_path,passes=2)
    image=cv2.imread(str(ROOT/'gem_templates/gem_0.png'));h,w=image.shape[:2]
    backend.frame[400:400+h,240:240+w]=image
    runner.detector=GemDetector()
    runner.start(views,LiveSettings());finish(runner)
    assert runner.snapshot()['gems']==2 and backend.selections==[0,1,0,1]
    store=SpyHistory(tmp_path/'sightings.sqlite3')
    assert len(store.standard.list())==2 and all(row.score>.95 for row in store.standard.list())
    assert len(list((tmp_path/'screenshots').glob('*.png')))==2
    store.close()


def test_terminal_adb_failure_preserves_point_and_does_not_auto_retry(tmp_path):
    from patrol_adb import BackgroundInputError
    runner,backend,events,views=configured(tmp_path)
    def failed():raise BackgroundInputError('Android app changed')
    backend.capture=failed
    runner.start(views,LiveSettings());finish(runner)
    assert backend.contexts==1 and not backend.selections and not backend.inputs
    assert not any('Recovering' in e.get('message','') for e in events)
    assert any('Android app changed' in e.get('message','') for e in events)
    assert runner.snapshot()['gems']==0
