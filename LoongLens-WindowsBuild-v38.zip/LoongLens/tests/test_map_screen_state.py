"""Real map controls with an unreadable title: no repeated minimap/filter tap."""
from pathlib import Path
import threading
from types import SimpleNamespace
import cv2
import numpy as np
import pytest
from map_screen import map_controls_visible,filter_menu_visible
from patrol_live import LivePatrol,LiveSettings
from patrol_windows import PatrolStopped
from vision import TitleDetector
from test_live_patrol import Clock,setup

FIXTURE=Path(__file__).parent/'fixtures/map-controls.png'


def controls():return cv2.imread(str(FIXTURE))


def expanded():
    image=controls();cv2.rectangle(image,(98,58),(560,702),(43,43,43),-1)
    for row in range(9):
        for col in range(3):
            x=110+col*149;y=76+row*57
            cv2.rectangle(image,(x+15,y),(x+115,y+34),(105,212,208),-1)
            cv2.ellipse(image,(x+15,y+17),(15,17),0,90,270,(105,212,208),-1)
            cv2.ellipse(image,(x+115,y+17),(15,17),0,-90,90,(105,212,208),-1)
    return image


def gameplay():
    image=np.full((1029,570,3),(72,116,84),np.uint8)
    image[938:1026,12:124]=controls()[938:1026,12:124]  # Same Back arrow in gameplay.
    return image


@pytest.mark.parametrize('color',[(25,25,25),(190,210,230),(112,82,55)])
def test_map_controls_confirm_open_map_without_a_matching_title(color):
    image=controls();image[31:134,8:246]=color
    detector=TitleDetector();gray=cv2.cvtColor(image[31:133,8:245],cv2.COLOR_BGR2GRAY)
    old=float(cv2.minMaxLoc(cv2.matchTemplate(gray,detector.template,cv2.TM_CCOEFF_NORMED))[1])
    assert old<.64 and map_controls_visible(image)
    assert detector.score(image)>=.64


def test_back_arrow_in_gameplay_does_not_prove_map_open():
    image=gameplay();assert not map_controls_visible(image) and TitleDetector().score(image)<.64


def test_zoom_without_back_does_not_prove_map_open():
    image=controls();image[938:1026,12:124]=0
    assert not map_controls_visible(image) and TitleDetector().score(image)<.64


def test_world_labels_and_rail_still_work_when_portrait_covers_plus():
    image=controls();image[620:700,515:560]=0
    assert map_controls_visible(image) and TitleDetector().score(image)>=.64


def test_expanded_filter_is_recognized_even_when_it_covers_title_and_plus():
    image=expanded();assert filter_menu_visible(image) and map_controls_visible(image)
    assert TitleDetector().score(image)>=.64


def test_yellow_terrain_is_not_a_filter_grid():
    image=np.full((1029,570,3),(105,212,208),np.uint8)
    assert not filter_menu_visible(image) and not map_controls_visible(image)


class Replay:
    def __init__(self,mode='map',back='panel',cancel=None):
        self.mode=mode;self.back=back;self.cancel=cancel or threading.Event();self.clock=Clock()
        self.clicks=[];self.first=None
    def capture(self):
        if self.first is not None:image=self.first;self.first=None;return image.copy()
        return {'map':controls,'filter':expanded,'game':gameplay}[self.mode]()
    def wait(self,seconds):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        self.clock.now+=seconds
    def click(self,point):
        point=tuple(point);self.clicks.append(point)
        if point==LiveSettings().map_close:
            if self.back=='game':self.mode='game'
            elif self.back=='panel':self.mode='map'
            elif self.back=='cancel':self.cancel.set()
        elif point==LiveSettings().map_open:
            # This is the exact old bug: the opener on an open map opens filters.
            self.mode='map' if self.mode=='game' else 'filter'


def opener(backend):
    return LivePatrol((),LiveSettings(),backend.cancel,lambda e:None,title=TitleDetector(),clock=backend.clock)


def test_already_open_weak_title_map_sends_no_minimap_click():
    backend=Replay();engine=opener(backend)
    assert engine.is_map(engine.open_map(backend)) and backend.clicks==[]


def test_single_transitional_frame_does_not_click_minimap_on_open_map():
    backend=Replay();backend.first=gameplay();engine=opener(backend)
    assert engine.is_map(engine.open_map(backend)) and backend.clicks==[]


def test_gameplay_opens_map_once():
    backend=Replay('game');engine=opener(backend)
    assert engine.is_map(engine.open_map(backend))
    assert backend.clicks==[LiveSettings().map_open]


@pytest.mark.parametrize('back',['panel','game'])
def test_existing_filter_is_dismissed_with_calibrated_back_and_progress_kept(back):
    backend=Replay('filter',back);engine=opener(backend);engine.checked.update((2,4));engine.skipped.add(2)
    assert engine.is_map(engine.open_map(backend)) and backend.mode=='map'
    assert backend.clicks==[LiveSettings().map_close]+([LiveSettings().map_open] if back=='game' else [])
    assert engine.checked=={2,4} and engine.skipped=={2}


def test_filter_back_ignored_never_clicks_options_or_repeats_opener():
    backend=Replay('filter','ignored');engine=opener(backend)
    with pytest.raises(RuntimeError,match='filter is still open'):engine.open_map(backend)
    assert backend.clicks==[LiveSettings().map_close]


def test_transitional_frame_after_filter_back_does_not_reopen_filter():
    backend=Replay('filter');click=backend.click
    def transition(point):
        click(point)
        if tuple(point)==LiveSettings().map_close:backend.first=gameplay()
    backend.click=transition;engine=opener(backend)
    assert engine.is_map(engine.open_map(backend))
    assert backend.clicks==[LiveSettings().map_close]


def test_f10_during_filter_recovery_never_reopens_map():
    backend=Replay('filter','cancel');engine=opener(backend)
    with pytest.raises(PatrolStopped):engine.open_map(backend)
    assert backend.clicks==[LiveSettings().map_close]


def real_control_engine(ignored_back=False):
    engine,backend,events=setup();engine.title=TitleDetector();backend.break_back=ignored_back
    original=backend.capture
    def capture():
        fake=original()
        if not backend.open:return gameplay()
        image=controls()
        # Preserve the independently simulated camera outline, not title flags.
        white=(fake[:,:,0]==255)&(fake[:,:,1]==255)&(fake[:,:,2]==255)
        image[white]=255
        return image
    backend.capture=capture
    return engine,backend,events


def test_title_failure_does_not_classify_selected_open_map_as_gameplay():
    engine,backend,events=real_control_engine()
    engine.run(backend,auto=False)
    assert engine.checked=={0} and not backend.open
    assert len(backend.inputs)==2 and backend.inputs[-1][1]==LiveSettings().map_close
    assert not any(p==LiveSettings().map_open for action,p,state in backend.inputs)


def test_ignored_back_stays_map_and_cannot_be_counted_as_inspected():
    engine,backend,events=real_control_engine(ignored_back=True)
    with pytest.raises(RuntimeError,match='map did not close'):engine.run(backend,auto=False)
    assert backend.open and not engine.checked
    assert not any(e['kind']=='frame' for e in events)
