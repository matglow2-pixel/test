from dataclasses import replace
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import cv2
cv2.setNumThreads(2)  # Match the production application thread limit.
import numpy as np
import pytest
from patrol_adb import AdbBackend,InputSettings,active_package,align_android_display
from patrol_windows import PatrolStopped
from resources import ROOT


from adb_fixture import prepare_fixture


def process_factory(folder):
    def spawn(command,**kwargs):
        assert kwargs.get('shell') is not True
        return subprocess.Popen([sys.executable,str(ROOT/'adb_fixture.py'),str(folder),*command[1:]],**kwargs)
    return spawn


@pytest.fixture
def android(tmp_path):
    image=prepare_fixture(tmp_path)
    backend=AdbBackend(threading.Event(),InputSettings(adb_path=str(ROOT/'adb_fixture.py')),process_factory(tmp_path))
    with backend:yield backend,tmp_path,image


def state(folder,**changes):
    path=folder/'state.json';data=json.loads(path.read_text());data.update(changes);path.write_text(json.dumps(data));return data


def touches(folder):
    return [entry[1] for entry in map(json.loads,(folder/'calls.jsonl').read_text().splitlines()) if entry[0]=='touch']


def test_background_capture_and_touch_never_use_windows_cursor_or_focus(android,monkeypatch):
    backend,folder,image=android
    import patrol_windows
    monkeypatch.setattr(patrol_windows,'NativeInput',lambda:pytest.fail('Desktop input constructed'))
    backend.focus();frame=backend.capture();assert frame.shape==(1029,570,3)
    backend.click((285,400))
    assert [r[0] for r in touches(folder)]==['D','U']
    assert touches(folder)[0][1]==[360,480]
    assert not backend.down and not state(folder)['down']


def test_hold_stays_down_across_capture_and_stationary_release(android):
    backend,folder,_=android;backend.focus()
    with backend.hold_drag((285,530)):
        backend.drag_held_to((285,490));backend.capture()
        assert backend.down and state(folder)['down']
    assert [r[0] for r in touches(folder)]==['D','M','U']
    assert not state(folder)['down']


def test_no_focused_window_is_ok_when_map_is_verified(android):
    backend,folder,_=android;state(folder,package=None)
    backend.focus();assert backend.touch is not None and backend.package is None


def test_unknown_app_without_map_requires_visual_confirmation(android):
    backend,folder,_=android;state(folder,package=None,open=False)
    with pytest.raises(RuntimeError,match='Open the large Loong Haven map'):backend.focus()
    assert touches(folder)==[]


def test_known_android_app_switch_stops_before_input(android):
    backend,folder,_=android;backend.focus();state(folder,package='com.other.app');backend.app_check_at=0
    with pytest.raises(RuntimeError,match='active Android app changed'):backend.click((285,400))
    assert touches(folder)==[]


def test_launcher_stops_before_touch_channel(android):
    backend,folder,_=android;state(folder,package='com.bluestacks.launcher')
    with pytest.raises(RuntimeError,match='another Android screen'):backend.focus()
    assert touches(folder)==[]


def test_f10_during_blocked_screenshot_releases_held_android_finger(android):
    backend,folder,_=android;backend.focus();errors=[]
    def run():
        try:
            with backend.hold_drag((285,530)):
                (folder/'block-capture').touch();backend.capture()
        except Exception as exc:errors.append(exc)
    worker=threading.Thread(target=run);worker.start()
    deadline=time.monotonic()+4
    while not (folder/'block-capture').exists() and time.monotonic()<deadline:time.sleep(.02)
    backend.cancel.set();worker.join(4)
    assert not worker.is_alive() and errors and isinstance(errors[0],PatrolStopped)
    assert not state(folder)['down'] and touches(folder)[-1][0]=='U'


def test_resolution_change_and_black_png_stop(android):
    backend,folder,_=android;backend.focus();state(folder,width=900,height=1600)
    with pytest.raises(RuntimeError,match='resolution changed'):backend.capture()
    state(folder,width=720,height=1280,black=True)
    with pytest.raises(RuntimeError,match='black screen'):backend.capture()
    state(folder,black=False,bad_png=True)
    with pytest.raises(RuntimeError,match='PNG screenshot'):backend.capture()


def test_snapshot_coordinates_use_inverse_android_alignment(android):
    backend,folder,_=android;backend.focus()
    assert backend.point((285,530))==(360,650)
    assert backend.point((0,32))==(0,0)
    for point in ((0,0),(570,500),(300,1013),(float('nan'),500)):
        with pytest.raises(ValueError):backend.point(point)


def test_registration_preserves_existing_route_geometry(android):
    backend,folder,desktop=android;backend.connect();raw=backend.capture_raw()
    rect=align_android_display(raw,desktop)
    assert np.max(np.abs(np.asarray(rect)-np.array((0,32,570,1013))))<2
    backend.settings=replace(backend.settings,content_rect=rect)
    result=backend.render(raw)
    from vision import Calibrator
    pose=Calibrator().locate(result)
    assert pose is not None and 12.05<=pose.scale<=12.85


@pytest.mark.parametrize('text,expected',[
    ('mCurrentFocus=null\nmResumedActivity: ActivityRecord{2 u0 com.example.loong/.Game t1}','com.example.loong'),
    ('topResumedActivity=ActivityRecord{3 u0 com.example.loong/.Game t4}','com.example.loong'),
    ('mCurrentFocus=Window{3 u0 com.example.loong/.Game}','com.example.loong'),
    ('Window #3 com.old.app/.Game\nmCurrentFocus=null',None),
    ('mResumedActivity: ActivityRecord{2 u0 com.one.app/.Main}\nmResumedActivity: ActivityRecord{3 u0 com.two.app/.Main}',None)])
def test_foreground_records_do_not_guess_stale_apps(text,expected):assert active_package(text)==expected


@pytest.mark.parametrize('serial',['host:5555','127.0.0.1:0','127.0.0.1:5555;echo x','-s','127.0.0.1:65536'])
def test_only_the_explicit_bluestacks_loopback_is_connected(serial):
    with pytest.raises(ValueError):InputSettings(serial=serial)


def test_adb_is_default_and_input_profile_round_trips():
    assert InputSettings().mode=='ADB'
    value=InputSettings(content_rect=(1.,32.,568.,1010.),package='com.example.loong')
    from dataclasses import asdict
    assert InputSettings(**json.loads(json.dumps(asdict(value))))==value


def test_minimized_pan_probe_confirms_touch_and_restores_map(android,monkeypatch):
    backend,folder,_=android
    monkeypatch.setenv('XDG_CACHE_HOME',str(folder/'cache'))
    from adb_setup_panel import probe_android
    factory=lambda cancel,settings:AdbBackend(cancel,settings,process_factory(folder))
    settings,frame,info=probe_android(factory,backend.settings,backend.cancel,pan=True)
    assert info['pan_verified'] and settings.package=='com.example.loong'
    values=state(folder)
    assert abs(values['dx'])<2 and abs(values['dy'])<2 and not values['down']


def test_frozen_minimized_screen_cannot_pass_pan_probe(android,monkeypatch):
    backend,folder,_=android;state(folder,frozen=True)
    monkeypatch.setenv('XDG_CACHE_HOME',str(folder/'cache'))
    from adb_setup_panel import probe_android
    factory=lambda cancel,settings:AdbBackend(cancel,settings,process_factory(folder))
    with pytest.raises(RuntimeError,match='No map movement was confirmed'):
        probe_android(factory,backend.settings,backend.cancel,pan=True)
    assert not state(folder)['down']
