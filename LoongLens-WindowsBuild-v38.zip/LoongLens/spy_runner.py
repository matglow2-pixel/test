"""Observation-only route runner with durable encounters and cancellable retries."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import logging
import math
import threading
import time
import cv2
import numpy as np
from gem_detector import AlertGate,GemDetector,gameplay_mask
from patrol_live import LivePatrol
from patrol_windows import WindowsBackend,PatrolStopped
from sighting_capture import SightingCapture
from spy_history import SpyHistory,point_key

LOG=logging.getLogger('loonglens')


def scene_quality(frame,previous=None):
    normal=cv2.resize(frame,(285,514),interpolation=cv2.INTER_AREA)
    gray=cv2.cvtColor(normal,cv2.COLOR_BGR2GRAY);mask=gameplay_mask(normal.shape)!=0
    if float(gray[mask].std())<8 or float(np.mean(gray[mask]>25))<.5:return False
    if previous is not None:
        old=cv2.resize(previous,(285,514),interpolation=cv2.INTER_AREA)
        if float(np.mean(cv2.absdiff(old,normal).max(axis=2)[mask]>35))>.4:return False
    return True


class SpyObserver:
    def __init__(self,store,run,emit,capture,submit,clock=time.perf_counter,wall=time.time):
        self.store=store;self.run=run;self.emit=emit;self.capture=capture;self.submit=submit
        self.clock=clock;self.wall=wall

    def unclear(self,view,reason):
        self.store.observe(view,self.run,self.wall(),clear=False,reason=reason)
        self.emit(dict(kind='spy_observed',view=view,outcome='unclear',new=0))

    def __call__(self,patrol,backend,view):
        gate=AlertGate(cooldown=0);started=patrol.clock();deadline=started+patrol.settings.inspect_seconds
        samples=[];previous=None;valid=[];candidates=[];scans=0;good_since=None
        while True:
            patrol.check();frame=backend.capture()
            if patrol.is_map(frame):raise RuntimeError('Map remained open during Spy inspection')
            good=scene_quality(frame,previous);valid.append(good);valid=valid[-3:]
            if not good:good_since=None
            elif good_since is None:good_since=patrol.clock()
            boxes=patrol.detector.detect(frame,exclude_hud=patrol.settings.mask_hud)
            gate.update(boxes if good else [],patrol.clock());scans+=1
            now=self.wall();height,width=frame.shape[:2]
            patrol.send('frame',frame=frame,detections=boxes)
            if good:
                for box in boxes:
                    for sample in samples:
                        if math.dist(box.center,sample['_center'])<max(20,box.width*1.2):
                            sample['last_seen']=now
                for box in gate.new_sightings:
                    samples.append(dict(screen_x=box.center[0]*570/width,screen_y=box.center[1]*1029/height,
                        score=box.score,seen_at=now,last_seen=now,_center=box.center,frame=frame.copy()))
            candidates.extend((box.center,box.width) for box in boxes)
            previous=frame
            pending=[track.first_seen+gate.confirmation_seconds+.2 for track in gate.tracks if track.hits and not track.reported]
            if pending:deadline=max(deadline,min(started+patrol.settings.inspect_seconds+1.,max(pending)))
            if patrol.clock()>=deadline and scans>=3:break
            if patrol.clock()-started>patrol.settings.inspect_seconds+8:raise RuntimeError('Spy inspection timed out')
            remaining=deadline-patrol.clock();backend.wait(min(.2,remaining) if remaining>0 else .2)
        # Unconfirmed candidates, changing/blank/loading scenes cannot provide
        # an absence. Positives still get recorded when independently confirmed.
        unresolved=any(not any(math.dist(center,s['_center'])<max(20,width*1.2) for s in samples)
                       for center,width in candidates)
        clear=len(valid)==3 and all(valid) and good_since is not None and patrol.clock()-good_since>=.8 and not unresolved
        patrol.check()
        fresh=self.store.observe(view,self.run,self.wall(),samples,clear,
                                 '' if clear else 'Unstable scene or unconfirmed candidate; absence unknown')
        for event,sample in fresh:self.submit(event,sample['frame'])
        self.emit(dict(kind='spy_observed',view=view,outcome='present' if samples else 'empty' if clear else 'unclear',new=len(fresh)))


class SpyRunner:
    def __init__(self,folder,emit,backend_factory=WindowsBackend,engine_factory=LivePatrol,
                 clock=time.perf_counter,wall=time.time,retry_wait=None):
        self.folder=folder;self.path=folder/'sightings.sqlite3';self.emit=emit
        self.backend_factory=backend_factory;self.engine_factory=engine_factory;self.clock=clock;self.wall=wall
        self.cancel=threading.Event();self.thread=None;self.backend=None
        self.retry_wait=retry_wait or self.cancel.wait
        self.detector=None;self.locator=None;self.title=None
        self.elapsed=0.;self.started=None;self.gems=0;self.run_number=1;self.processed=0;self.total=0
        self.last_checkpoint=0.;self.views=()
        store=SpyHistory(self.path)
        state=store.state('checkpoint',{})
        self.elapsed=state.get('elapsed',0.);self.run_number=state.get('run',1);self.gems=store.totals()['total']
        self.processed=len(state.get('checked',[]));self.total=state.get('total',0)
        store.close()

    @property
    def running(self):return self.thread is not None and self.thread.is_alive()

    def snapshot(self):
        return dict(elapsed=self.elapsed+(max(0.,self.clock()-self.started) if self.started is not None else 0.),
                    gems=self.gems,run=self.run_number,processed=self.processed,total=self.total)

    def stop(self):
        self.cancel.set()
        release=getattr(self.backend,'release',None)
        if release is not None:
            try:release()
            except Exception:LOG.exception('Could not immediately release Spy input')

    def start(self,views,settings):
        if self.running or not views:return False
        self.views=tuple(views);self.total=len(views)
        # Observation mode ignores Sniper's optional click-on-gem setting.
        settings=replace(settings,approach_gem=False)
        self.cancel.clear()
        def work():
            store=None;capture=None;pool=None;futures=[];checked=set();state={};navigation={}
            current=[0];failures={};consecutive=0
            def save(force=False):
                if store is None or not state.get('route'):return
                now=self.clock()
                if not force and now-self.last_checkpoint<2:return
                state.update(checked=[point_key(self.views[i]) for i in sorted(checked)],run=self.run_number,
                             elapsed=self.snapshot()['elapsed'],total=self.total)
                store.save_state('checkpoint',state);self.last_checkpoint=now
            def complete_captures(wait=False):
                remaining=[]
                for future,event in futures:
                    if not wait and not future.done():remaining.append((future,event));continue
                    try:result=future.result()
                    except Exception as exc:result=capture.unavailable(event,str(exc),'save_error')
                    store.finish_capture(result)
                    self.emit(dict(kind='spy_history_changed'))
                futures[:]=remaining
            def submit(event,frame):
                # The first confirmed frame only; repeats never call submit.
                futures.append((pool.submit(capture.save,event,frame,self.wall()),event))
                self.emit(dict(kind='spy_history_changed'))
            def report(event):
                nonlocal consecutive
                if event['kind']=='view':current[0]=event['index']
                if event['kind']=='checked':
                    self.processed=len(checked);consecutive=0;save(True)
                elif event['kind']=='spy_observed':
                    self.gems=store.totals()['total']
                complete_captures();save()
                self.emit(event)
            message='Stopped.'
            try:
                store=SpyHistory(self.path);state=store.checkpoint(self.views)
                self.elapsed=state['elapsed'];self.started=self.clock();self.run_number=state['run']
                checked.update(i for i,v in enumerate(self.views) if point_key(v) in set(state['checked']))
                self.processed=len(checked);save(True)
                if self.detector is None:self.detector=GemDetector(threshold=settings.threshold)
                self.detector.threshold=settings.threshold
                if self.locator is None:
                    from vision import Calibrator,TitleDetector
                    self.locator=Calibrator(self.folder,wide=True);self.title=TitleDetector()
                capture=SightingCapture(self.folder,reader=object());pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='Spy-photo')
                while not self.cancel.is_set():
                    if len(checked)>=len(self.views):
                        self.emit(dict(kind='spy_pass_complete',run=self.run_number))
                        self.run_number+=1;checked.clear();failures.clear();self.processed=0;save(True)
                        if self.retry_wait(.2):break
                    current[0]=next(i for i in range(len(self.views)) if i not in checked)
                    observer=SpyObserver(store,self.run_number,report,capture,submit,self.clock,self.wall)
                    try:
                        with self.backend_factory(self.cancel) as backend:
                            self.backend=backend
                            engine=self.engine_factory(self.views,settings,self.cancel,report,checked=checked,
                                detector=self.detector,locator=self.locator,title=self.title,clock=self.clock,wall=self.wall,
                                navigation=navigation,observer=observer)
                            engine.run(backend,auto=True)
                    except PatrolStopped:
                        if self.cancel.is_set():break
                        raise
                    except Exception as exc:
                        if self.cancel.is_set():break
                        if getattr(exc,'pause_input',False):raise
                        LOG.exception('Gem Spy retry at route #%s',self.views[current[0]].route_label)
                        index=current[0];observer.unclear(self.views[index],str(exc))
                        failures[index]=failures.get(index,0)+1;consecutive+=1
                        if failures[index]>=2:
                            checked.add(index);self.processed=len(checked)
                            detail='Point marked unclear; retrying it on the next run.'
                        else:detail='Retrying the current point.'
                        # Fresh absolute recognition before any further movement.
                        navigation.clear();state['recoveries']=state.get('recoveries',0)+1;save(True)
                        delay=min(10.,float(2**min(consecutive-1,4)))
                        self.emit(dict(kind='status',message=f'Recovering in {delay:.0f}s. {detail} {exc}'))
                        if self.retry_wait(delay):break
                    finally:self.backend=None
                    complete_captures()
                message='Stopped. Spy progress and histories saved.'
            except Exception as exc:
                # Setup/storage failures are surfaced rather than silently
                # discarding data or recording false empty checks.
                message=f'Gem Spy could not continue: {exc}'
                LOG.exception('Gem Spy setup or storage failure')
            finally:
                if store is not None:
                    try:
                        if pool is not None:pool.shutdown(wait=True);complete_captures(True)
                        save(True)
                    except Exception:LOG.exception('Could not finish Spy checkpoint')
                    finally:store.close()
                if capture is not None:capture.close()
                self.elapsed=self.snapshot()['elapsed'];self.started=None
                self.emit(dict(kind='spy_finished',message=message))
        self.thread=threading.Thread(target=work,daemon=True,name='LoongLens-GemSpy');self.thread.start()
        return True
