"""User-controlled real BlueStacks input and patrol status/history integration."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict,replace
import json
import queue
import time
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from pathlib import Path
import cv2
from PIL import Image,ImageDraw,ImageTk
from patrol_route import load_fixed_route
from patrol_live import LiveSettings,LiveRunner,load_live_config,LIVE_SETTINGS_VERSION
from patrol_windows import WindowsBackend,GlobalPatrolKeys
from route_profiles import RouteProfiles
from sighting_capture import SightingCapture
from resources import user_dir
from sniper_counter import SniperQuota
from patrol_adb import AdbBackend,InputSettings


class LivePatrolPanel:
    def __init__(self,parent,data,services,on_active=lambda active:None):
        self.parent=parent;self.root=parent.winfo_toplevel();self.services=services;self.on_active=on_active
        self.key=tk.StringVar(value='F8');self.endless=tk.BooleanVar(value=False)
        self.status=tk.StringVar(value='Preparing live controls…')
        self.location=tk.StringVar(value='Fixed path starts at Emerald Corner. Route #26, #51 and #72 are excluded.')
        self.count=tk.StringVar(value='Preparing grouped camera checks…')
        self.pass_text=tk.StringVar(value='')
        self.performance=tk.StringVar(value='')
        self.stats_text=tk.StringVar(value='Time spent: 0:00\nGems found: 0')
        self.seen_text=tk.StringVar(value=f'{self.services.sighting_history.sniper_seen()}/5');self.seen_refresh=0.
        self.events=queue.Queue();self.keys=None;self.closed=False;self.busy=False
        self.job=None;self.photo=None;self.futures=[];self.editing=False;self.editor=None;self.switching=False
        self.path=user_dir()/'patrol-live-settings.json'
        self.input_settings=InputSettings();self.adb_map=dict(map_open=(480.,170.),map_close=(64.,980.))
        self.adb_factory=AdbBackend;self.reference_capture=WindowsBackend.peek;self.settings_dialog=None
        try:
            config=json.loads(self.path.read_text('utf-8'))
            self.settings,key,migrated=load_live_config(config)
            try:self.input_settings=InputSettings(**config.get('input',{}))
            except (ValueError,TypeError):self.input_settings=InputSettings()
            try:
                points=config.get('adb_map',self.adb_map)
                validate=replace(self.settings,**points);self.adb_map=dict(map_open=validate.map_open,map_close=validate.map_close)
            except (ValueError,TypeError):pass
            self.key.set(key);self.endless.set(bool(config.get('endless_mode',False)))
            if migrated:self.status.set('Updated Open map to the top-right minimap.')
        except (OSError,ValueError,KeyError,TypeError):self.settings=LiveSettings()
        self.settings=replace(self.settings,approach_gem=True)
        self.base_views=load_fixed_route(data);self.route_path=user_dir()/'camera-route-adjustments.json'
        self.routes=None;self.route_name=tk.StringVar(value='Default')
        warning=None
        try:
            self.routes=RouteProfiles(self.base_views,user_dir())
            views=self.routes.load(self.routes.active)
            self.route_name.set(self.routes.name(self.routes.active))
            if self.routes.active!=RouteProfiles.DEFAULT:self.route_path=self.routes.path(self.routes.active)
        except (OSError,ValueError,TypeError) as exc:
            self.routes=None;views=self.base_views;warning=f'Using Default; saved route list needs attention: {exc}'
        self.runner=LiveRunner(views,self.make_backend,self.events.put,
                               quota=SniperQuota(self.services.sighting_history.path))
        self.runner.set_endless(self.endless.get())
        from sniper_history_panel import DailyGemsControls
        self.daily_gems=DailyGemsControls(self.root,self.runner.quota,self.refresh_seen)
        self.services.sighting_controls.on_daily=self.show_daily_gems
        self.update_count()
        # Patrol captures already have their map location and bypass player OCR.
        self.capture_store=SightingCapture(user_dir(),reader=object())
        self.save_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='Patrol-screenshot')
        self.build_ui();self.bind_keys();self.job=self.root.after(100,self.poll)
        if warning:self.status.set(warning)

    def build_ui(self):
        from ui_theme import FONT,CARD,MUTED,card,row
        from ui_assets import gem_image,line_image
        self.ui_images=[]
        self.loop_mode=tk.BooleanVar(value=True)
        self.gems_value=tk.StringVar(value='0');self.elapsed_value=tk.StringVar(value='00:00')
        self.views_value=tk.StringVar();self.spots_value=tk.StringVar();self.progress_value=tk.StringVar();self.skip_value=tk.StringVar()
        self.run_state=tk.StringVar(value='Ready')
        body=ttk.Frame(self.parent,padding=(22,20));body.pack(fill='both',expand=True)
        self.body=body
        header=ttk.Frame(body);header.pack(fill='x',pady=(0,18))
        intro=ttk.Frame(header);intro.pack(side='left',fill='x',expand=True)
        ttk.Label(intro,text='Gem Sniper',style='Title.TLabel').pack(anchor='w')
        ttk.Label(intro,text='Find gems, collect, and return to Emerald Corner.',style='Muted.TLabel').pack(anchor='w',pady=(4,0))
        quota=ttk.Frame(header,style='Panel.TFrame',padding=(16,10));quota.pack(side='right',padx=(12,0))
        art=gem_image(quota,36);self.ui_images.append(art)
        ttk.Label(quota,image=art,style='Card.TLabel').pack(side='left',padx=(0,10))
        ttk.Label(quota,text='Daily gems',style='Card.TLabel').pack(side='left',padx=(0,16))
        self.seen_label=ttk.Label(quota,textvariable=self.seen_text,style='Quota.TLabel',cursor='hand2')
        self.seen_label.pack(side='left')
        for w in (quota,*quota.winfo_children()):w.bind('<Button-1>',lambda _:self.show_daily_gems())
        # Action bar remains visible while the middle area grows with the window.
        footer=ttk.Frame(body);footer.pack(side='bottom',fill='x',pady=(12,0))
        self.input_label=tk.StringVar();self.update_input_label()
        ttk.Label(footer,textvariable=self.input_label,
                  style='Muted.TLabel',font=(FONT,9),wraplength=1100).pack(anchor='w',pady=(9,0),side='bottom')
        actions=ttk.Frame(footer,style='Panel.TFrame',padding=12);actions.pack(fill='x')
        play=line_image(actions,'play',20,'#073334');self.ui_images.append(play)
        self.snipe=ttk.Button(actions,text='Start sniping',image=play,compound='left',style='Primary.TButton',command=self.start,padding=(20,13))
        self.snipe.pack(side='left')
        loop=ttk.Frame(actions,style='Card.TFrame');loop.pack(side='left',padx=18)
        self.repeat=ttk.Checkbutton(loop,text='  Loop sniping',variable=self.loop_mode,style='Switch.TCheckbutton')
        self.repeat.pack(anchor='w')
        ttk.Label(loop,text='Repeat full routes · F10 stops',style='CardMuted.TLabel').pack(anchor='w')
        reset_icon=line_image(actions,'reset',20);self.ui_images.append(reset_icon)
        self.reset_button=ttk.Button(actions,text='Reset checks',image=reset_icon,compound='left',command=self.reset,padding=(14,13))
        self.reset_button.pack(side='right')
        stop_icon=line_image(actions,'stop',18,'#ffb9c9');self.ui_images.append(stop_icon)
        self.stop_button=ttk.Button(actions,text='Stop  F10',image=stop_icon,compound='left',style='Stop.TButton',command=self.stop,padding=(20,13))
        self.stop_button.pack(side='right',padx=(0,14))
        middle=ttk.Frame(body);middle.pack(fill='both',expand=True)
        middle.columnconfigure(0,weight=3);middle.columnconfigure(1,weight=1,minsize=210);middle.rowconfigure(0,weight=1)
        stack=ttk.Frame(middle);stack.grid(row=0,column=0,sticky='nsew',padx=(0,16))
        self.controls=controls=card(stack,'Sniping controls')
        controls.columnconfigure(0,weight=1)
        fields=ttk.Frame(controls,style='Card.TFrame');fields.pack(side='left',fill='both',expand=True)
        line=row(fields)
        ttk.Label(line,text='Snipe key',style='Card.TLabel',width=9).pack(side='left')
        self.key_box=ttk.Combobox(line,textvariable=self.key,values=('F6','F7','F8','F9'),state='readonly',width=5)
        self.key_box.pack(side='left',padx=(0,14));self.key_box.bind('<<ComboboxSelected>>',self.change_key)
        self.edit_button=ttk.Button(line,text='Edit route',command=self.show_route_editor,padding=(12,7));self.edit_button.pack(side='left')
        line=row(fields);line.pack_configure(pady=(12,0))
        ttk.Label(line,text='Route',style='Card.TLabel',width=9).pack(side='left')
        self.route_box=ttk.Combobox(line,textvariable=self.route_name,state='readonly',width=15)
        self.route_box.pack(side='left',fill='x',expand=True);self.route_box.bind('<<ComboboxSelected>>',self.change_route)
        tools=ttk.Frame(controls,style='Card.TFrame',padding=(12,0,0,0));tools.pack(side='right',fill='y')
        icon=line_image(tools,'history',18);self.ui_images.append(icon)
        self.history_button=ttk.Button(tools,text='History',image=icon,compound='left',command=self.show_history,padding=(9,6));self.history_button.pack(fill='x')
        icon=line_image(tools,'settings',18);self.ui_images.append(icon)
        self.settings_button=ttk.Button(tools,text='Settings',image=icon,compound='left',command=self.show_settings,padding=(9,6));self.settings_button.pack(fill='x',pady=5)
        self.copy_route_button=ttk.Button(tools,text='Save copy…',command=self.copy_route,padding=(9,5));self.copy_route_button.pack(fill='x')
        self.refresh_routes()
        self.status_card=status=card(stack,'Run status');status.pack_configure(fill='both',expand=True)
        ttk.Label(status,textvariable=self.status,style='Status.TLabel',wraplength=600).pack(anchor='w')
        self.location_label=ttk.Label(status,textvariable=self.location,style='CardMuted.TLabel',wraplength=600)
        self.location_label.pack(anchor='w',pady=(7,10))
        metrics=ttk.Frame(status,style='Card.TFrame');metrics.pack(fill='x')
        self.metric_frames=[];self.metric_fonts=[]
        from tkinter import font as tkfont
        self.metric_probe=tkfont.Font(root=self.root,family=FONT,size=20,weight='bold')
        for index,(label,value,kind) in enumerate((('Gems found',self.gems_value,'gem'),('Time spent',self.elapsed_value,'clock'),('Views checked',self.views_value,'map'),('Spawn spots',self.spots_value,'target'))):
            metrics.columnconfigure(index,weight=1,uniform='metrics')
            tile=ttk.Frame(metrics,style='Panel.TFrame',padding=(7,8));tile.grid(row=0,column=index,sticky='nsew',padx=(0,8 if index<3 else 0));self.metric_frames.append(tile)
            ttk.Label(tile,text=label,style='CardMuted.TLabel').pack(anchor='w')
            line=row(tile)
            icon=gem_image(tile,26) if kind=='gem' else line_image(tile,kind,22)
            self.ui_images.append(icon);ttk.Label(line,image=icon,style='Card.TLabel').pack(side='left',padx=(0,5))
            from tkinter import font as tkfont
            numeric_font=tkfont.Font(root=self.root,family=FONT,size=18,weight='bold');self.metric_fonts.append(numeric_font)
            value_label=ttk.Label(line,textvariable=value,style='Metric.TLabel',font=numeric_font);value_label.pack(side='left')
            measured=[None]
            def fit_metric(event=None,tile=tile,value=value,font=numeric_font,measured=measured):
                key=(tile.winfo_width(),value.get())
                if key==measured[0]:return
                measured[0]=key;available=max(35,key[0]-58);chosen=11
                # Measure with an unbound font. Mutating the displayed font
                # while probing sizes can continually invalidate Tk geometry.
                for size in range(20,10,-1):
                    self.metric_probe.configure(size=size)
                    if self.metric_probe.measure(key[1])<=available:chosen=size;break
                if int(font.cget('size'))!=chosen:font.configure(size=chosen)
            tile.bind('<Configure>',fit_metric);value.trace_add('write',lambda *_,fit=fit_metric:fit())
        self.endless_button=ttk.Checkbutton(status,text='Endless mode',variable=self.endless,style='Card.TCheckbutton',command=self.change_endless)
        self.endless_button.pack(anchor='w',pady=(6,2))
        line=row(status)
        ttk.Label(line,text='Progress (views checked)',style='CardMuted.TLabel').pack(side='left')
        ttk.Label(line,textvariable=self.progress_value,style='CardMuted.TLabel').pack(side='right')
        self.progress=ttk.Progressbar(status,maximum=len(self.runner.views));self.progress.pack(fill='x',pady=(5,7))
        ttk.Label(status,textvariable=self.skip_value,style='CardMuted.TLabel').pack(anchor='w')
        ttk.Label(status,textvariable=self.performance,style='CardMuted.TLabel',wraplength=600).pack(anchor='w',pady=(3,0))
        ttk.Label(status,textvariable=self.pass_text,style='CardMuted.TLabel',wraplength=600).pack(anchor='w',pady=(3,0))
        preview_card=ttk.Frame(middle,style='Panel.TFrame',padding=14)
        preview_card.grid(row=0,column=1,sticky='nsew')
        ttk.Label(preview_card,text='Live preview',style='CardTitle.TLabel').pack(anchor='w',pady=(0,10))
        ttk.Label(preview_card,textvariable=self.location,style='CardMuted.TLabel',wraplength=260).pack(side='bottom',anchor='w',pady=(12,0))
        viewport=tk.Frame(preview_card,bg='#09121b');viewport.pack(fill='both',expand=True);viewport.pack_propagate(False)
        self.preview=tk.Label(viewport,bg='#09121b',fg=MUTED,text='Your latest camera check\nwill appear here.',wraplength=185)
        self.preview.pack(fill='both',expand=True)
        # Keep the full-resolution frame so resizing the preview never stretches
        # a previous thumbnail or adds work to map navigation.
        self.preview_image=None;self.preview_job=None
        self.preview.bind('<Configure>',self.resize_preview)
        def wrap(event):
            for widget in (self.location_label,):widget.configure(wraplength=max(180,event.width-34))
            for widget in status.winfo_children():
                if isinstance(widget,ttk.Label):widget.configure(wraplength=max(180,event.width-34))
        status.bind('<Configure>',wrap)
        self.update_count();self.update_stats();self.buttons()

    def update_stats(self):
        values=self.runner.stats.snapshot();minutes,seconds=divmod(int(values['elapsed']),60)
        gems=str(values['gems']);elapsed=f'{minutes:02d}:{seconds:02d}'
        if self.gems_value.get()!=gems:self.gems_value.set(gems)
        if self.elapsed_value.get()!=elapsed:self.elapsed_value.set(elapsed)

    def resize_preview(self,event=None):
        if self.closed or self.preview_job is not None:return
        self.preview_job=self.root.after(80,self.render_preview)

    def render_preview(self):
        self.preview_job=None
        if self.closed or self.preview_image is None:return
        image=self.preview_image.copy();image.thumbnail((max(1,self.preview.winfo_width()-12),max(1,self.preview.winfo_height()-12)),Image.Resampling.LANCZOS)
        self.photo=ImageTk.PhotoImage(image,master=self.preview);self.preview.configure(image=self.photo,text='')

    def refresh_seen(self):
        self.seen_refresh=0.;self.seen_text.set(f'{self.services.sighting_history.sniper_seen()}/5')

    def show_daily_gems(self):
        if self.busy:self.runner.stop()
        self.daily_gems.show()

    def change_endless(self):
        self.runner.set_endless(self.endless.get())
        if self.endless.get():self.loop_mode.set(True)
        self.save_config()

    def show_history(self):
        if self.busy:self.runner.stop()
        self.services.flush_sightings()
        self.services.sighting_controls.show()

    def refresh_routes(self):
        items=self.routes.items() if self.routes is not None else [('default','Default')]
        self.profile_ids={name:ident for ident,name in items}
        self.route_box.configure(values=[name for _,name in items])
        if self.routes is not None:self.route_name.set(self.routes.name(self.routes.active))

    def apply_route(self,views):
        self.runner.views=tuple(views);self.runner.navigation.clear();self.reset()
        if self.routes is not None:
            self.refresh_routes()
            self.route_path=(self.routes.path(self.routes.active) if self.routes.active!=RouteProfiles.DEFAULT
                             else user_dir()/'camera-route-adjustments.json')
        self.status.set(f'Route: {self.route_name.get()}. Checks reset.')

    def change_route(self,event=None):
        ident=self.profile_ids.get(self.route_name.get())
        if self.routes is None or ident is None or self.editing or self.switching:return
        if ident==self.routes.active:return
        self.switching=True;self.runner.stop();self.buttons()
        self.status.set('Stopping sniping before changing routes…')
        def finish():
            if self.closed:return
            if self.runner.running:self.root.after(50,finish);return
            self.drain()
            try:self.apply_route(self.routes.activate(ident))
            except (OSError,ValueError,TypeError) as exc:
                self.refresh_routes();self.status.set(f'Could not change route: {exc}')
            finally:self.switching=False;self.buttons()
        finish()

    def ask_route_name(self,parent=None):
        return simpledialog.askstring('Save route copy','Name this route (Default stays unchanged):',
                                     parent=parent or self.root,initialvalue='My route' if self.routes and len(self.routes.items())==1 else '')

    def copy_route(self):
        if self.routes is None or self.busy or self.editing or self.switching:return
        name=self.ask_route_name()
        if name is None:return
        try:
            self.routes.save_copy(name,self.runner.views)
            self.apply_route(self.runner.views)
        except (OSError,ValueError,TypeError) as exc:messagebox.showerror('Could not save route',str(exc),parent=self.root)

    def show_route_editor(self):
        if self.editor is not None:self.editor.window.lift();return
        if self.editing or self.switching or self.services.owner=='spy':return
        self.editing=True;self.runner.stop();self.buttons()
        def open_when_stopped():
            if self.closed:return
            if self.runner.running:self.root.after(50,open_when_stopped);return
            self.drain()
            from route_editor import RouteEditor
            def close():
                self.editor=None;self.editing=False;self.buttons()
            def save(views):
                if self.routes is None:raise ValueError('Repair the saved route list before saving a route.')
                if self.routes.active==RouteProfiles.DEFAULT:
                    name=self.ask_route_name(self.editor.window)
                    if name is None:return False
                    self.routes.save_copy(name,views)
                else:self.routes.save(self.routes.active,views)
                self.apply_route(views)
                self.status.set('Camera targets saved. Checks reset; the next pass uses your adjusted route.')
            def select_profile(name):
                if self.routes is None:raise ValueError('Saved routes are unavailable.')
                ident=next((ident for ident,label in self.routes.items() if label==name),None)
                if ident is None:raise ValueError('Unknown saved route.')
                views=self.routes.activate(ident);self.apply_route(views)
                return views
            def save_copy(views):
                if self.routes is None:raise ValueError('Saved routes are unavailable.')
                name=self.ask_route_name(self.editor.window)
                if name is None:return None
                self.routes.save_copy(name,views);self.apply_route(views)
                return self.routes.name(self.routes.active),views
            self.editor=RouteEditor(self.root,self.base_views,self.runner.views,save,close,
                route_choices=lambda:[name for _,name in self.routes.items()] if self.routes else ['Default'],
                active_route=self.route_name.get(),on_route_change=select_profile,on_save_copy=save_copy)
        open_when_stopped()

    def buttons(self):
        available=self.services.owner in (None,'sniper')
        ready=self.keys is not None and available and not self.busy and not self.editing and not self.switching and self.settings_dialog is None
        for button in (self.snipe,self.repeat):button.configure(state='normal' if ready else 'disabled')
        self.route_box.configure(state='readonly' if self.services.owner!='spy' and self.routes is not None and not self.editing and not self.switching else 'disabled')
        self.copy_route_button.configure(state='normal' if self.services.owner is None and self.routes is not None and not self.busy and not self.editing and not self.switching else 'disabled')

        self.edit_button.configure(state='normal' if self.services.owner!='spy' and not self.editing else 'disabled')
        self.key_box.configure(state='readonly' if self.services.owner!='spy' else 'disabled')

    def bind_keys(self):
        self.stop(silent=True)
        if self.keys is not None:self.keys.close();self.keys=None
        try:
            self.keys=GlobalPatrolKeys(lambda:self.events.put(dict(kind='advance')),
                self.emergency,key=self.key.get())
            self.status.set(f'Ready. {self.key.get()} starts the fixed path; F10 stops.')
        except Exception as exc:
            self.status.set(str(exc))
            messagebox.showerror('Live controls unavailable',str(exc),parent=self.root)
        self.buttons();self.save_config()

    def change_key(self,event=None):
        self.bind_keys()

    def emergency(self):
        if self.settings_dialog is not None:self.settings_dialog.cancel_test()
        self.runner.stop()  # Called directly on the hotkey thread, without Tk delay.
        if getattr(self,'spy_stop',None):self.spy_stop()
        self.events.put(dict(kind='panic'))

    def start(self,repeat=None):
        if self.settings_dialog is not None:
            self.status.set('Save or close input settings before starting.');return
        if self.keys is None or self.busy or self.editing or self.switching:return
        if not self.endless.get() and self.services.sighting_history.sniper_seen()>=5:
            self.status.set('5/5 gems marked obtained for this game day. Stopped until the 16:00 Sofia reset.');return
        if not self.services.acquire('sniper'):
            self.status.set('Stop Gem Spy before starting Gem Sniper.');return
        self.runner.cooldown['last']=max(self.runner.cooldown['last'],self.services.last_sighting)
        self.runner.cooldown['sound']=max(self.runner.cooldown.get('sound',-float('inf')),self.services.last_sound)
        settings=self.runtime_settings()

        self.on_active(True);self.busy=True;self.buttons()
        self.runner.set_endless(self.endless.get())
        if not self.runner.start(settings,auto=True,repeat=(self.loop_mode.get() or self.endless.get()) if repeat is None else repeat):
            self.busy=False;self.services.release('sniper');self.on_active(False);self.buttons()

    def stop(self,silent=False):
        self.runner.stop()
        if not silent:self.status.set('Stop requested. Touch input is being released.')

    def reset(self):
        if self.busy:
            self.status.set('Stop patrol before resetting its checked locations.');return
        if not self.runner.reset_checks():
            self.status.set('Wait for sniping to stop before resetting checks.');return
        self.pass_text.set('');self.performance.set('');self.stats_text.set(self.runner.stats.text());self.update_stats();self.update_count()
        self.status.set('Checks reset.')

    def update_count(self):
        views=self.runner.views
        checked=self.runner.checked.copy()
        covered=set().union(*(views[i].cells for i in checked)) if checked else set()
        total=set().union(*(view.cells for view in views))
        if hasattr(self,'progress'):self.progress.configure(value=len(checked),maximum=len(views))
        all_spots=set().union(*(view.cells for view in self.base_views))
        self.count.set(f'Processed: {len(self.runner.checked)} / {len(views)} views · Locked skips: {len(self.runner.skipped)}\nSpawn spots processed: {len(covered)} / {len(total)} · Omitted: {len(all_spots-total)}')
        if hasattr(self,'views_value'):
            self.views_value.set(f'{len(checked)} / {len(views)}');self.spots_value.set(f'{len(covered)} / {len(total)}')
            self.progress_value.set(f'{len(checked)} / {len(views)}')
            self.skip_value.set(f'Locked skips: {len(self.runner.skipped)}  ·  Omitted: {len(all_spots-total)}')

    def show_frame(self,frame,boxes=()):
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));pen=ImageDraw.Draw(image)
        for box in boxes:pen.rectangle((box.x,box.y,box.x+box.width,box.y+box.height),outline='#f45bd0',width=3)
        self.preview_image=image
        self.render_preview()

    def drain(self):
        while True:
            try:event=self.events.get_nowait()
            except queue.Empty:break
            kind=event['kind']
            if kind=='advance':
                if not self.closed:self.start()
            elif kind=='panic':self.status.set('F10 emergency stop.')
            elif kind=='status':self.status.set(event['message'])
            elif kind=='view':
                view=event['view']
                self.location.set(f'{"Route #"+view.route_label+" · " if view.route_number else ""}{view.near_zone} ({int(view.x)},{int(view.y)}) • {len(view.cells)} spawn spot(s) in this view')
            elif kind=='frame':self.show_frame(event['frame'],event['detections'])
            elif kind=='checked':self.update_count()
            elif kind=='view_timing':
                suffix=' · locked skip' if event['skipped'] else ''
                self.performance.set(f"Last view: {event['total_seconds']:.1f}s · Map/load {event['map_seconds']:.1f}s · Inspect {event['inspect_seconds']:.1f}s{suffix}")
            elif kind=='pass_complete':
                times=[]
                for run in event['recent_passes']:
                    minutes,seconds=divmod(int(run['elapsed']),60)
                    times.append(f"#{run['number']} {minutes}:{seconds:02d}")
                self.pass_text.set(f"Passes completed: {event['passes']}\nLast 3 runs: "+' · '.join(times));self.update_count()
            elif kind=='pass_started':self.update_count()
            elif kind=='found':
                self.status.set('GEM FOUND — saving the scene, then clicking the gem once…');self.seen_refresh=0.
                if event.get('seen_id'):
                    self.services.sighting_history.mark_sniper_seen(event['seen_id'],event['seen_at'])
                if self.services.sound.get() and event.get('sound',True):
                    self.services.last_sound=self.runner.cooldown.get('sound',self.services.last_sound);self.services.play_sound()
                if event['event'] is not None:
                    self.services.pending_sightings.append(event['event'])
                    self.services.last_sighting=self.runner.cooldown['last']
                else:
                    if event.get('seen_event'):self.services.pending_sightings.append(event['seen_event'])
                    self.status.set('Gem found — clicking it. Photo saving is within the 20-second cooldown.')
            elif kind=='capture':
                captured_at=event.get('captured_at',__import__('time').time())
                self.futures.append((self.save_pool.submit(self.capture_store.save,event['event'],event['frame'],captured_at),event['event']))
            elif kind=='sighting':self.services.pending_sightings.append(event['event'])
            elif kind=='finished':
                self.services.release('sniper')
                self.busy=False;self.on_active(False);self.buttons()
                self.status.set(event['message'])
        waiting=[]
        for future,event in self.futures:
            if not future.done():waiting.append((future,event));continue
            try:self.services.pending_sightings.append(future.result())
            except Exception as exc:self.services.pending_sightings.append(self.capture_store.unavailable(event,str(exc),'save_error'))
        self.futures=waiting
        self.services.flush_sightings()

    def poll(self):
        self.job=None
        if self.closed:return
        try:
            self.drain()
            self.stats_text.set(self.runner.stats.text());self.update_stats()
            if time.time()>=self.seen_refresh:
                self.refresh_seen();self.seen_refresh=time.time()+1;self.daily_gems.refresh()
        except Exception:
            import logging
            self.runner.stop();logging.exception('Live patrol panel update failed')
            self.status.set('Patrol stopped after a display error; see loonglens.log.')
        self.job=self.root.after(100,self.poll)

    def save_config(self):
        try:
            tmp=self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps(dict(version=LIVE_SETTINGS_VERSION,settings=asdict(self.settings),key=self.key.get(),endless_mode=self.endless.get(),input=asdict(self.input_settings),adb_map=self.adb_map),indent=2),'utf-8')
            tmp.replace(self.path)
        except OSError:
            import logging
            logging.exception('Could not save patrol settings')

    def make_backend(self,cancel):
        return self.adb_factory(cancel,self.input_settings) if self.input_settings.mode=='ADB' else WindowsBackend(cancel)

    def runtime_settings(self,approach_gem=True):
        points=self.adb_map if self.input_settings.mode=='ADB' else {}
        return replace(self.settings,**points,threshold={'Conservative':.84,'Balanced':.77,'Sensitive':.70}[self.services.mode.get()],
            mask_hud=self.services.mask_hud.get(),approach_gem=approach_gem)

    def update_input_label(self):
        if hasattr(self,'input_label'):
            mode='ADB: mouse stays free.' if self.input_settings.mode=='ADB' else 'Mouse: keep BlueStacks visible.'
            self.input_label.set(mode+' Daily gems: edit obtained. On a gem: wait 20s, return to Emerald Corner.')

    def show_settings(self):
        if self.busy or self.services.owner is not None:
            self.status.set('Stop Gem Sniper and Gem Spy before changing settings.');return
        if self.settings_dialog is not None:self.settings_dialog.window.lift();return
        from adb_setup_panel import InputDialog
        self.settings_dialog=InputDialog(self);self.buttons()

    def close(self):
        if self.closed:return
        self.closed=True;self.runner.stop()
        if self.settings_dialog is not None:self.settings_dialog.close(wait=True)
        if self.job is not None:self.root.after_cancel(self.job);self.job=None
        if self.preview_job is not None:self.root.after_cancel(self.preview_job);self.preview_job=None
        if self.keys is not None:self.keys.close();self.keys=None
        if self.runner.thread is not None:self.runner.thread.join(timeout=3)
        self.drain();self.save_pool.shutdown(wait=True);self.drain()
        self.capture_store.close();self.save_config()
        if self.daily_gems.window is not None:self.daily_gems.window.destroy()
