"""Read large-map controls independently of the terrain behind its title."""
import cv2
import numpy as np


def normal(frame):
    return frame if frame.shape[:2]==(1029,570) else cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)


def white_parts(frame,bounds):
    x,y,w,h=bounds
    crop=frame[y:y+h,x:x+w]
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)
    white=cv2.inRange(hsv,np.array((0,0,175)),np.array((179,75,255)))
    _,labels,stats,_=cv2.connectedComponentsWithStats(white)
    return [(x+a,y+b,c,d,area,labels[b:b+d,a:a+c]==i)
            for i,(a,b,c,d,area) in enumerate(stats) if i and area>=12]


def back_arrow_visible(frame):
    for x,y,w,h,area,mask in white_parts(frame,(12,938,112,88)):
        if not (12<=w<=35 and 18<=h<=46 and 1.1<=h/w<=2.2):continue
        yy,xx=np.nonzero(mask)
        upper=xx[yy<h*.25];lower=xx[yy>=h*.75];middle=xx[(yy>=h*.4)&(yy<=h*.6)]
        if min(len(upper),len(lower),len(middle))<3:continue
        if min(upper.mean(),lower.mean())-middle.mean()>w*.20:return True
    return False


def zoom_controls_visible(frame):
    parts=white_parts(frame,(485,610,80,325))
    plus=[];minus=[]
    for x,y,w,h,area,mask in parts:
        if 8<=w<=25 and 2<=h<=9 and w/h>=2.2 and 850<=y<=929:
            minus.append((x+w/2,y+h/2))
        if not (8<=w<=25 and 8<=h<=23 and .65<=w/h<=1.5 and 615<=y<=715):continue
        binary=cv2.resize(mask.astype(np.uint8),(15,15),interpolation=cv2.INTER_NEAREST)
        if binary[6:9,:].mean()>.55 and binary[:,6:9].mean()>.55:plus.append((x+w/2,y+h/2))
    for a,b in plus:
        for c,d in minus:
            if abs(a-c)>6 or not 170<=d-b<=300:continue
            # The dark vertical rail joins the + and −. A moving portrait may
            # obscure part of it; unrelated white HUD glyphs do not prove a map.
            rail=frame[round(b)+15:round(d)-12,max(0,round((a+c)/2)-3):round((a+c)/2)+4]
            hsv=cv2.cvtColor(rail,cv2.COLOR_BGR2HSV)
            if np.mean(((hsv[:,:,2]<155)&(hsv[:,:,1]<100)).any(axis=1))>=.65:return True
    return False


def world_tabs_visible(frame):
    # Four or more separated world-name labels share the bottom baseline.
    # Gameplay has the Back arrow too, but only its two Explore labels here.
    hsv=cv2.cvtColor(frame[948:1014,135:565],cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,np.array((0,0,175)),np.array((179,95,255)))
    words=cv2.dilate(mask,np.ones((1,5),np.uint8))
    _,_,stats,centers=cv2.connectedComponentsWithStats(words)
    labels=[center for (x,y,w,h,area),center in zip(stats[1:],centers[1:]) if 28<=w<=100 and 6<=h<=22]
    return any(sum(abs(y-b)<9 for a,b in labels)>=4 for x,y in labels)


def zoom_rail_visible(frame):
    for x,y,w,h,area,mask in white_parts(frame,(485,845,80,90)):
        if not (8<=w<=25 and 2<=h<=9 and w/h>=2.2):continue
        cx=round(x+w/2);rail=frame[y-215:y-12,cx-3:cx+4]
        hsv=cv2.cvtColor(rail,cv2.COLOR_BGR2HSV)
        if np.mean(((hsv[:,:,2]<155)&(hsv[:,:,1]<100)).any(axis=1))>=.65:return True
    return False


def filter_menu_visible(frame):
    """The expanded filter has repeated yellow pill buttons in three columns."""
    frame=normal(frame);crop=frame[50:730,85:565]
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)
    yellow=cv2.inRange(hsv,np.array((20,75,120)),np.array((45,255,255)))
    if cv2.countNonZero(yellow)<12_000:return False
    _,_,stats,centers=cv2.connectedComponentsWithStats(yellow)
    buttons=[]
    for (x,y,w,h,area),center in zip(stats[1:],centers[1:]):
        if 75<=w<=170 and 20<=h<=65 and 2.3<=w/h<=5 and .5<=area/(w*h)<=.96:buttons.append(center)
    if len(buttons)<8:return False
    # Repeated rows and columns distinguish the filter from yellow terrain.
    rows=[];columns=[]
    for axis,groups,tolerance in ((0,columns,18),(1,rows,12)):
        for value in sorted(p[axis] for p in buttons):
            if not groups or value-np.mean(groups[-1])>tolerance:groups.append([value])
            else:groups[-1].append(value)
    return sum(len(g)>=3 for g in columns)>=3 and sum(len(g)>=2 for g in rows)>=4


def map_controls_visible(frame):
    frame=normal(frame)
    return back_arrow_visible(frame) and (zoom_controls_visible(frame) or
        zoom_rail_visible(frame) and world_tabs_visible(frame) or filter_menu_visible(frame))
