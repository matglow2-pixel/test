"""Rebuild the small Android-only touch JAR from the included Java source."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def build(cache,output):
    manifest=json.loads((ROOT/'android_touch/BUILD.json').read_text())
    source=ROOT/'android_touch/TouchBridge.java'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256'],'Touch source checksum mismatch'
    cache.mkdir(parents=True,exist_ok=True)
    for name,item in manifest['tools'].items():
        file=cache/('platform.zip' if name=='platform' else 'r8.jar')
        if not file.exists():
            with urllib.request.urlopen(item['url'],timeout=60) as response:file.write_bytes(response.read())
        assert hashlib.sha256(file.read_bytes()).hexdigest()==item['sha256'],name+' tool checksum mismatch'
    with zipfile.ZipFile(cache/'platform.zip') as archive:
        name=next(n for n in archive.namelist() if n.endswith('/android.jar'));(cache/'android.jar').write_bytes(archive.read(name))
    with tempfile.TemporaryDirectory(prefix='loonglens-touch-') as tmp:
        tmp=Path(tmp);classes=tmp/'classes';classes.mkdir();dex=tmp/'dex';dex.mkdir()
        subprocess.run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-classpath',str(cache/'android.jar'),'-d',str(classes),str(source)],check=True)
        with zipfile.ZipFile(tmp/'classes.jar','w') as archive:
            for file in sorted(classes.rglob('*.class')):archive.write(file,file.relative_to(classes).as_posix())
        subprocess.run(['java','-cp',str(cache/'r8.jar'),'com.android.tools.r8.D8','--min-api','26','--lib',str(cache/'android.jar'),'--output',str(dex),str(tmp/'classes.jar')],check=True)
        output.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as archive:
            item=zipfile.ZipInfo('classes.dex',(1980,1,1,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.create_system=3
            archive.writestr(item,(dex/'classes.dex').read_bytes())
    return hashlib.sha256(output.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--cache',type=Path,required=True);parser.add_argument('--verify',action='store_true');args=parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='touch-verify-') as tmp:
        out=Path(tmp)/'touch.jar' if args.verify else ROOT/'loonglens-touch.jar';digest=build(args.cache,out)
        if args.verify:
            expected=json.loads((ROOT/'android_touch/BUILD.json').read_text())['jar_sha256']
            assert digest==expected,'Rebuilt Android touch JAR differs from the packaged source build'
        print('Android touch source/JAR verified:',digest)

if __name__=='__main__':main()
