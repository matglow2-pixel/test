# v38 — BlueStacks ADB background mode

ADB is now the default input mode for Gem Sniper and Gem Spy. Android screenshots
and a persistent Android touch session replace desktop screenshots/mouse input.
The Windows mouse and foreground window stay untouched. Mouse mode is still an
explicit option in Settings and never serves as an automatic fallback.

1. Enable Android Debug Bridge in BlueStacks Settings → Advanced. Keep the
   selected device at `127.0.0.1:5555` unless your BlueStacks reports another port.
2. Open the large Loong Haven map. In Gem Sniper → Settings, use **Test connection /
   preview** while BlueStacks is visible. This can align Android pixels with your
   existing routes using a read-only window capture.
3. Minimize BlueStacks and use **Test map pan (minimized)**. It moves the camera
   slightly and restores it. It never clicks a gem or walks your character.
4. Save, then start Sniper or Spy. Keep the game active inside Android.

BlueStacks must remain running and continue rendering while minimized. The pan
test diagnoses paused rendering; a failed test does not claim background support.
Resolution changes, black/corrupt screenshots, known app switches and transport
failures stop ADB input while preserving progress. F10 cancels active commands,
releases the Android finger and stays stopped. A helper watchdog releases a held
touch after loss of heartbeat. Unknown Android focus metadata is accepted when
the large game map is visually confirmed; a null focus is not treated as failure.

The full package includes the EXE, all source/assets and the small compiled touch
helper. Existing BlueStacks HD-Adb.exe is reused; no APK, root, Java or Android SDK
installation is needed on your PC. `android_touch/` contains the Java source,
build manifest and reproducible build instructions. Existing histories, Obtained
choices, routes, counters, Endless, collection/return and heatmaps are retained.

Windows validation uses an independent simulated Android subprocess and real Tk
windows. It verifies screenshots, held gestures, map pan/restore, cancellation,
saved settings and unchanged Windows cursor/foreground. The actual Java helper
is also executed against Android API stubs and rebuilt from pinned tools. These
checks do not prove live BlueStacks permissions or minimized rendering: run the
included pan test on your PC.

