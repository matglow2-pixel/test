"""Disposable ADB process fixture used only by transport validation tools."""
import json
from pathlib import Path
import sys
import time


def prepare_fixture(folder,assets=None):
    assets=Path(assets) if assets is not None else Path(__file__).resolve().parent
    import cv2
    import numpy as np
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);(folder/'fixture-marker').touch()
    atlas=cv2.imread(str(assets/'loong_haven_default_atlas.png'))
    tx=285-130*12.45;ty=530+160*12.45
    image=cv2.warpAffine(atlas,np.float32([[1,0,tx],[0,1,ty-279*12.45]]),(570,1029))
    ui=cv2.imread(str(assets/'tests/fixtures/map-controls.png'))
    for l,t,r,b in ((12,938,124,1026),(520,620,557,927),(138,940,555,1016)):image[t:b,l:r]=ui[t:b,l:r]
    title=cv2.imread(str(assets/'loong_title_template.png'));h,w=title.shape[:2];image[55:55+h,20:20+w]=title
    cv2.imwrite(str(folder/'map.png'),image)
    game=np.random.default_rng(3).integers(60,150,(1029,570,3),dtype=np.uint8);cv2.imwrite(str(folder/'game.png'),game)
    state=dict(width=720,height=1280,package='com.example.loong',open=True,dx=0.,dy=0.,down=False)
    (folder/'state.json').write_text(json.dumps(state))
    return image


def main():
    root=Path(sys.argv[1]);args=sys.argv[2:]
    if not (root/'fixture-marker').is_file():raise SystemExit('Missing disposable ADB fixture marker')
    state_path=root/'state.json'
    def read():return json.loads(state_path.read_text())
    def write(state):
        temporary=root/'state.next';temporary.write_text(json.dumps(state));temporary.replace(state_path)
    def log(kind,value):
        with (root/'calls.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps([kind,value])+'\n')
    log('command',args)
    if args[:1]==['connect']:print('connected to '+args[1]);return
    if args[:2]!=['-s','127.0.0.1:5555']:raise SystemExit(2)
    args=args[2:]
    if args==['get-state']:print('device');return
    if args[:3]==['shell','dumpsys','activity']:
        package=read().get('package')
        print('mResumedActivity: ActivityRecord{9 u0 '+package+'/.Game t4}' if package else 'mResumedActivity=null');return
    if args[:3]==['shell','dumpsys','window']:print('mCurrentFocus=null');return
    if args[:1]==['push']:print('1 file pushed');return
    if 'app_process' in args:
        print('{"ready":true,"protocol":1,"sdk":30}',flush=True)
        down=False;position=None
        for line in sys.stdin:
            fields=line.split();identifier=int(fields[0]);action=fields[1]
            if action=='H':continue
            state=read()
            if action=='D':down=True;position=list(map(int,fields[2:4]));state['moved']=False
            elif action=='M':
                if not down:print(json.dumps(dict(id=identifier,ok=False,error='not down')),flush=True);continue
                current=list(map(int,fields[2:4]));sx=570/state['width'];sy=981/state['height']
                if not state.get('frozen'):
                    state['dx']+=(current[0]-position[0])*sx;state['dy']+=(current[1]-position[1])*sy
                position=current;state['moved']=True
            elif action in ('U','Q'):
                if down and not state.get('moved') and position is not None:
                    x=position[0]*570/state['width'];y=32+position[1]*981/state['height']
                    if not state['open'] and 400<x<550 and 70<y<245:state['open']=True
                    elif state['open'] and 15<x<110 and 945<y<1013:state['open']=False
                    elif state['open']:state['camera']=[x,y]
                down=False
            state['down']=down;write(state);log('touch',[action,position])
            print(json.dumps(dict(id=identifier,ok=True,down=down)),flush=True)
            if action=='Q':return
        if down:state=read();state['down']=False;write(state);log('touch',['EOF_UP',position])
        return
    if args==['exec-out','screencap','-p']:
        if (root/'block-capture').exists():time.sleep(30)
        import cv2
        import numpy as np
        state=read()
        if state.get('bad_png'):sys.stdout.buffer.write(b'bad image');return
        if state.get('black'):image=np.zeros((state['height'],state['width'],3),np.uint8)
        else:
            base=cv2.imread(str(root/'map.png'))
            if state['open']:
                image=cv2.warpAffine(base,np.float32([[1,0,state['dx']],[0,1,state['dy']]]),(570,1029))
                for l,t,r,b in ((0,0,570,135),(410,40,570,240),(0,929,570,1029),(490,610,570,929)):image[t:b,l:r]=base[t:b,l:r]
                if state.get('camera'):
                    x,y=state['camera'];cv2.rectangle(image,(round(x-42),round(y-75)),(round(x+42),round(y+75)),(255,255,255),2)
            else:image=cv2.imread(str(root/'game.png'))
            image=cv2.resize(image[32:1013],(state['width'],state['height']))
        ok,png=cv2.imencode('.png',image);sys.stdout.buffer.write(png.tobytes());return
    raise SystemExit('Unsupported fixture command: '+repr(args))

if __name__=='__main__':main()
