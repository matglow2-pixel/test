# v37 — map state and filter recovery

Fixes the v36 Golden Plain/filter stop. A weak match for the Loong Haven title must not turn the large map into "gameplay": its independent Back, zoom and world-tab controls now provide a second source of evidence. The shared recognition change also protects map closing and inspection.

Before an opener, a negative first capture is rechecked; an already visible map receives no minimap tap. No fixed wait is added to ordinary map checks. A detected expanded filter receives one click on the calibrated Back button. Whether this closes only the filter or the map too is observed before proceeding. If the filter remains, the app stops with its checked locations preserved. Stop/F10 interrupts recovery.

The click exclusions and drag geometry are unchanged: no new input padding or portal limitations. The complete v36 UI, icon, route profiles, persistent Obtained counter, Endless mode, histories and heatmap are retained.

Regression coverage uses only ordinary map-control pixels from the previous user recording, with all other pixels removed. It covers unreadable/obscured title, the gameplay Back arrow, covered zoom +, an open filter, failed close, cancellation and preventing uninspected checks. Windows packaging retains all v36 source/assets and rebuilds the EXE.
