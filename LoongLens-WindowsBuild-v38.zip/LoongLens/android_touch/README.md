# Android touch channel

`TouchBridge.java` runs as Android's ADB shell user through `app_process`. It uses Android InputManager and MotionEvent; it does not access the game process, install an APK, require root or control the Windows mouse. The JAR is pushed to `/data/local/tmp/loonglens-touch-<hash>.jar` in the explicitly selected BlueStacks device. The shared ADB server and emulator are left running.

The line protocol keeps a finger down across screenshots and MOVE commands. A gesture uses one downTime, pressure and finger identity throughout. UP occurs at a stationary endpoint. A heartbeat watchdog releases the finger after 1.8 seconds without host commands. EOF and normal shutdown also release it. F10 cancels host commands and sends UP through the existing channel.

`BUILD.json` records the Java source hash, JAR hash and pinned compiler dependencies. The JAR contains this project's DEX code only; compiler tools and the Android SDK are not distributed in the app.

Rebuild with Java 21 and Python:

```
python tools/build_android_touch.py --cache ../android-build-cache --verify
```

The platform archive and R8 are downloaded from Google's HTTPS repositories and verified against their pinned hashes before use. Normal Loong Lens operation does not download these tools or require Java on Windows; Android supplies its own runtime.
