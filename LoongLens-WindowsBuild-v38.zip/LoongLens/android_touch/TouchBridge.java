package com.loonglens;

import android.os.Build;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

/** Shell-UID touch channel. No APK, game hooks, root or Windows input. */
public final class TouchBridge {
    private final Object manager;
    private final Method inject;
    private final int width, height;
    private boolean down;
    private float x, y;
    private long downTime, alive;
    private volatile boolean closing;

    private TouchBridge(int width, int height) throws Exception {
        if (width < 100 || height < 100) throw new IllegalArgumentException("Invalid display size");
        this.width=width; this.height=height;
        Class<?> type;
        try { type=Class.forName("android.hardware.input.InputManagerGlobal"); }
        catch (ClassNotFoundException e) { type=Class.forName("android.hardware.input.InputManager"); }
        manager=type.getMethod("getInstance").invoke(null);
        inject=type.getMethod("injectInputEvent",InputEvent.class,int.class);
        alive=SystemClock.uptimeMillis();
    }

    private static synchronized void output(String value) {
        System.out.println(value); System.out.flush();
    }

    private boolean event(int action,float px,float py) throws Exception {
        long now=SystemClock.uptimeMillis();
        MotionEvent.PointerProperties property=new MotionEvent.PointerProperties();
        property.id=0; property.toolType=MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords coord=new MotionEvent.PointerCoords();
        coord.x=px; coord.y=py; coord.pressure=action==MotionEvent.ACTION_UP ? 0f : 1f; coord.size=1f;
        MotionEvent motion=MotionEvent.obtain(downTime,now,action,1,
            new MotionEvent.PointerProperties[]{property},new MotionEvent.PointerCoords[]{coord},
            0,0,1f,1f,-1,0,InputDevice.SOURCE_TOUCHSCREEN,0);
        try {
            // Async injection keeps the watchdog independent of a slow game.
            return Boolean.TRUE.equals(inject.invoke(manager,motion,0));
        } finally { motion.recycle(); }
    }

    private synchronized void up() throws Exception {
        if (!down) return;
        try { if (!event(MotionEvent.ACTION_UP,x,y)) throw new IllegalStateException("Android rejected touch release"); }
        finally { down=false; }
    }

    private synchronized boolean command(String action,String[] parts) throws Exception {
        alive=SystemClock.uptimeMillis();
        if (action.equals("H")) return true;
        if (action.equals("Q")) { up(); closing=true; return true; }
        if (action.equals("U")) { up(); return true; }
        if (parts.length!=4) throw new IllegalArgumentException("Expected coordinates");
        float px=Float.parseFloat(parts[2]),py=Float.parseFloat(parts[3]);
        if (Float.isNaN(px)||Float.isNaN(py)||Float.isInfinite(px)||Float.isInfinite(py)
            ||px<0||py<0||px>=width||py>=height) throw new IllegalArgumentException("Touch outside Android display");
        if (action.equals("D")) {
            if (down) throw new IllegalStateException("Finger already down");
            downTime=SystemClock.uptimeMillis();
            if (!event(MotionEvent.ACTION_DOWN,px,py)) throw new IllegalStateException("Android rejected touch");
            down=true; x=px; y=py; return true;
        }
        if (action.equals("M")) {
            if (!down) throw new IllegalStateException("Finger is not down");
            if (!event(MotionEvent.ACTION_MOVE,px,py)) throw new IllegalStateException("Android rejected move");
            x=px; y=py; return true;
        }
        throw new IllegalArgumentException("Unknown touch command");
    }

    private void run() throws Exception {
        Thread watchdog=new Thread(new Runnable() {
            public void run() {
                while (!closing) {
                    try {
                        Thread.sleep(150);
                        synchronized (TouchBridge.this) {
                            if (down && SystemClock.uptimeMillis()-alive>1800) {
                                up(); output("{\"event\":\"released\",\"reason\":\"heartbeat expired\"}");
                            }
                        }
                    } catch (Exception e) {
                        output("{\"event\":\"error\",\"reason\":\"touch watchdog failed\"}"); closing=true;
                    }
                }
            }
        },"LoongLens-touch-watchdog");
        watchdog.setDaemon(true); watchdog.start();
        output("{\"ready\":true,\"protocol\":1,\"sdk\":"+Build.VERSION.SDK_INT+"}");
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
        try {
            String line;
            while (!closing && (line=input.readLine())!=null) {
                String[] parts=line.trim().split("\\s+");
                if (parts.length<2) continue;
                int id;
                try { id=Integer.parseInt(parts[0]); } catch (NumberFormatException e) { continue; }
                if (id<0) continue;
                try {
                    command(parts[1],parts);
                    if (id!=0) output("{\"id\":"+id+",\"ok\":true,\"down\":"+down+"}");
                } catch (Exception e) {
                    try { up(); } catch (Exception ignored) { }
                    Throwable cause=e.getCause();
                    String message=(cause==null?e:cause).toString().replace("\\","/").replace("\"","'").replace('\n',' ');
                    if (id!=0) output("{\"id\":"+id+",\"ok\":false,\"error\":\""+message+"\"}");
                }
            }
        } finally { closing=true; up(); }
    }

    public static void main(String[] args) {
        try { new TouchBridge(Integer.parseInt(args[0]),Integer.parseInt(args[1])).run(); }
        catch (Throwable e) { output("{\"ready\":false,\"error\":\"Android touch channel could not start\"}"); e.printStackTrace(System.err); System.exit(1); }
    }
}
