"""Map-grid to reference-screen coordinate transform (screen Y points down)."""
from dataclasses import dataclass

@dataclass
class Match:
    scale: float
    tx: float
    ty: float
    count: int
    error: float
    matches: list
    source: str = 'atlas'

    def project(self, x, y):
        return self.scale * x + self.tx, -self.scale * y + self.ty
