"""Visible edge dots must be clicked without dragging onto excluded controls."""
import math
import pytest
from camera_patrol import Viewpoint
from patrol_route import map_clickable
from patrol_live import LivePatrol
from test_live_patrol import setup


SAFE_POINTS=((20,110),(400,110),(20,500),(530,300),(530,590),(480,850),(20,920),(400,920),(495,910))


@pytest.mark.parametrize('point',SAFE_POINTS)
def test_user_outlined_surface_is_clickable(point):
    assert map_clickable(point)


@pytest.mark.parametrize('point',[(450,150),(540,220),(530,700),(515,910),(450,960),(15,50),(-5,300),(570,500),(20,940),(float('nan'),500),(300,float('inf'))])
def test_legend_zoom_tabs_chrome_and_outside_are_excluded(point):
    assert not map_clickable(point)


@pytest.mark.parametrize('point',SAFE_POINTS)
def test_visible_edge_dot_is_selected_directly_without_any_map_drag(point):
    engine,backend,events=setup()
    # Independently place the target at the requested reference pixel using
    # the backend's known world transform; the map is already open and stable.
    x=100+(point[0]-285)/12.45;y=100+(500-point[1])/12.45
    view=Viewpoint(x,y,'Visible edge',frozenset({(math.floor(x),math.floor(y))}),1)
    patrol=LivePatrol((view,),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    patrol.run(backend)
    assert patrol.checked=={0}
    assert not any(action[0]=='drag' for action in backend.inputs)
    assert backend.inputs[0][0]=='click' and backend.inputs[0][1]==pytest.approx(point)


@pytest.mark.parametrize('point',[(450,150),(530,700),(450,960)])
def test_target_over_a_control_is_dragged_to_map_surface_before_selection(point):
    engine,backend,events=setup()
    x=100+(point[0]-285)/12.45;y=100+(500-point[1])/12.45
    view=Viewpoint(x,y,'Behind control',frozenset({(math.floor(x),math.floor(y))}),1)
    patrol=LivePatrol((view,),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    patrol.run(backend)
    assert patrol.checked=={0} and backend.inputs[0][0]=='drag'
    first_click=next(action for action in backend.inputs if action[0]=='click')
    assert map_clickable(first_click[1]) and first_click[1]!=pytest.approx(point)
