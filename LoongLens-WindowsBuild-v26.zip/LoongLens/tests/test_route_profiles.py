"""Named variants keep Default and legacy edits intact and switch only after stop."""
import json
from types import SimpleNamespace

import pytest

from resources import ResourceStore
from patrol_route import load_fixed_route,add_camera_view,save_camera_adjustments
from route_profiles import RouteProfiles


@pytest.fixture
def route():return load_fixed_route(ResourceStore().data)


def test_default_is_immutable_and_named_variants_survive_restart(route,tmp_path):
    profiles=RouteProfiles(route,tmp_path)
    busy=profiles.save_copy('Busy zones',route[1:])
    full=profiles.save_copy('Full plus extra',add_camera_view(route,0))
    assert profiles.load('default')==route
    assert len(profiles.activate(busy))==75
    restored=RouteProfiles(route,tmp_path)
    assert restored.active==busy and restored.load(busy)==route[1:]
    assert len(restored.load(full))==77
    with pytest.raises(ValueError,match='cannot be overwritten'):restored.save('default',route[1:])
    assert restored.load('default')==route


def test_existing_v24_route_is_imported_without_changing_legacy_file(route,tmp_path):
    legacy=tmp_path/'camera-route-adjustments.json'
    edited=add_camera_view(route,11)
    save_camera_adjustments(route,edited,legacy)
    before=legacy.read_bytes()
    profiles=RouteProfiles(route,tmp_path)
    assert profiles.name(profiles.active)=='My route'
    assert profiles.load(profiles.active)==edited
    profiles.save(profiles.active,edited[1:])
    assert legacy.read_bytes()==before
    assert profiles.load('default')==route


@pytest.mark.parametrize('name',['Default',' default ','BUSY ZONES','', '\n', 'x'*49])
def test_reserved_duplicate_or_invalid_names_do_not_overwrite_profiles(route,tmp_path,name):
    profiles=RouteProfiles(route,tmp_path)
    ident=profiles.save_copy('Busy zones',route[1:])
    original=profiles.index.read_bytes();data=profiles.path(ident).read_bytes()
    with pytest.raises(ValueError):profiles.save_copy(name,route)
    assert profiles.index.read_bytes()==original and profiles.path(ident).read_bytes()==data


def test_route_names_never_become_filesystem_paths(route,tmp_path):
    profiles=RouteProfiles(route,tmp_path)
    ident=profiles.save_copy('../outside',route)
    assert profiles.path(ident).resolve().is_relative_to((tmp_path/'routes').resolve())
    assert not (tmp_path.parent/'outside').exists()


def test_bad_saved_route_or_index_is_not_replaced_with_default(route,tmp_path):
    profiles=RouteProfiles(route,tmp_path)
    ident=profiles.save_copy('Busy zones',route[1:])
    profiles.activate('default');index=profiles.index.read_bytes()
    profiles.path(ident).write_text('{broken')
    with pytest.raises(ValueError):profiles.activate(ident)
    assert profiles.active=='default' and profiles.index.read_bytes()==index
    profiles.index.write_text('{broken-index')
    with pytest.raises(ValueError):RouteProfiles(route,tmp_path)
    assert profiles.index.read_text()=='{broken-index'


def test_missing_named_route_cannot_silently_become_default(route,tmp_path):
    profiles=RouteProfiles(route,tmp_path)
    ident=profiles.save_copy('Busy zones',route[1:])
    profiles.path(ident).unlink()
    with pytest.raises(ValueError,match='missing'):RouteProfiles(route,tmp_path)


def test_switch_requests_stop_and_waits_before_replacing_route(route,tmp_path):
    from patrol_live_panel import LivePatrolPanel
    profiles=RouteProfiles(route,tmp_path)
    busy=profiles.save_copy('Busy zones',route[1:]);profiles.activate('default')
    pending=[];stops=[];applied=[]
    runner=SimpleNamespace(running=True,stop=lambda:stops.append(True))
    panel=object.__new__(LivePatrolPanel)
    panel.routes=profiles;panel.route_name=SimpleNamespace(get=lambda:'Busy zones')
    panel.profile_ids={'Busy zones':busy};panel.editing=False;panel.switching=False;panel.closed=False
    panel.runner=runner;panel.buttons=lambda:None;panel.drain=lambda:None
    panel.status=SimpleNamespace(set=lambda value:None)
    panel.root=SimpleNamespace(after=lambda delay,callback:pending.append(callback))
    panel.apply_route=lambda views:applied.append(views)
    panel.change_route()
    assert stops and not applied and profiles.active=='default' and panel.switching
    runner.running=False;pending.pop()()
    assert applied==[route[1:]] and profiles.active==busy and not panel.switching
