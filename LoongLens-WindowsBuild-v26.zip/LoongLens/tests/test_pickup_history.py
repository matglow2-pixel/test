import csv
import sqlite3
from datetime import datetime, timedelta

import numpy as np
import pytest

from pickup_history import PickupHistory, countdown, nearby_markers
from pose import Match
from resources import Renderer, ResourceStore


def test_log_restart_preserves_actual_location_and_reference_marker(tmp_path):
    path = tmp_path / 'local' / 'pickups.sqlite3'
    history = PickupHistory(path)
    first = history.record(158, 67, collected_at=1000, anchor=(150, 70), note='Near tower')
    history.record(155, 65, collected_at=1300, anchor=(150, 70))
    history.record(160, 64, collected_at=900, anchor=(150, 70))  # delayed entry
    history.close()
    restarted = PickupHistory(path)
    assert len(restarted.list()) == 3
    assert restarted.get(first.id).x == 158
    assert restarted.get(first.id).marker_x == 150
    newest = restarted.latest_locations()
    assert len(newest) == 1 and newest[0].collected_at == 1300
    assert newest[0].label(2500) == '10:00'  # deadline survives restart
    restarted.remove(newest[0].id)
    assert restarted.latest_locations()[0].id == first.id
    restarted.close()


def test_equal_timestamps_and_separate_spots(tmp_path):
    history = PickupHistory(tmp_path / 'history.db')
    history.record(100, 100, collected_at=1000)
    last = history.record(100, 100, timer_minutes=60, collected_at=1000)
    other = history.record(101, 100, collected_at=1000)
    assert {p.id for p in history.latest_locations()} == {last.id, other.id}
    assert last.label(1000) == '60:00'
    assert countdown(.01) == '00:01'
    assert last.label(4600) == 'Check'
    history.close()


@pytest.mark.parametrize('changes', [dict(x=-1), dict(x=280), dict(y='nan'),
    dict(timer_minutes=0), dict(timer_minutes=30.5), dict(timer_minutes='inf'),
    dict(collected_at=-1), dict(collected_at=float('inf')), dict(map_id=2),
    dict(anchor=(1,)), dict(anchor=(1, 280)), dict(x='')])
def test_invalid_entry_leaves_existing_history_intact(tmp_path, changes):
    history = PickupHistory(tmp_path / 'history.db')
    history.record(100, 100)
    args = dict(x=158, y=67)
    args.update(changes)
    with pytest.raises(ValueError):
        history.record(**args)
    assert len(history.list()) == 1
    history.close()


def test_daily_count_uses_local_date_and_counts_pickups(tmp_path):
    history = PickupHistory(tmp_path / 'history.db')
    now = datetime.now().replace(hour=12, minute=0, second=0, microsecond=0)
    # Stay in the past even when this test runs before noon.
    now -= timedelta(days=1)
    history.record(1, 1, collected_at=(now - timedelta(hours=13)).timestamp())
    history.record(1, 1, collected_at=(now - timedelta(hours=1)).timestamp())
    history.record(2, 2, collected_at=now.timestamp())
    assert history.today_count(now.timestamp()) == 2
    history.close()


def test_csv_keeps_all_events_coordinates_times_and_plain_text_notes(tmp_path):
    history = PickupHistory(tmp_path / 'history.db')
    history.record(158, 67, collected_at=1000, anchor=(150, 70), note=' =HYPERLINK("x")')
    history.record(157, 68, collected_at=2000, anchor=(150, 70), note='comma, quote " and\nnewline')
    path = tmp_path / 'export.csv'
    history.export_csv(path)
    with path.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 2
    assert rows[1]['x'] == '158.0' and rows[1]['timer_marker_x'] == '150.0'
    assert rows[1]['collected_at_utc'].endswith('+00:00')
    assert rows[1]['note'].startswith("'")
    assert rows[0]['note'] == 'comma, quote " and\nnewline'
    history.close()


def test_old_database_is_migrated_without_losing_pickups(tmp_path):
    path = tmp_path / 'old.db'
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE pickups(id INTEGER PRIMARY KEY,map_id INTEGER,x REAL,y REAL,collected_at REAL,timer_minutes INTEGER,note TEXT)')
        db.execute("INSERT INTO pickups VALUES(1,14,158,67,1000,30,'old')")
    history = PickupHistory(path)
    assert history.get(1).note == 'old'
    assert history.latest_locations()[0].marker_x == 158
    history.close()


def test_nearby_dots_use_game_coordinates_instead_of_internal_centers():
    nearby = nearby_markers(158, 67, np.array([[150.5, 70.5], [100.5, 100.5]]))
    assert nearby[0][:2] == (150, 70)
    assert nearby[0][2] == pytest.approx(np.hypot(8, 3))
    assert nearby_markers(158, 67, np.empty((0, 2))) == []


def scene(tmp_path, known=True):
    history = PickupHistory(tmp_path / 'scene.db')
    pickup = history.record(105, 100, collected_at=1000, anchor=(100, 100))
    store = ResourceStore()
    store.points['gems'] = np.array([[100.5, 100.5]]) if known else np.empty((0, 2))
    pose = Match(12.45, 250 - 100.5 * 12.45, 460 + 100.5 * 12.45, 10, 0, [])
    return history, pickup, Renderer(store), pose


def test_countdown_cache_changes_once_per_displayed_second(tmp_path):
    history, pickup, renderer, pose = scene(tmp_path)
    image, counts, changed = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=1000.1)
    assert changed and counts['gems'] == 1
    assert image.getpixel((250, 460))[:3] == (104, 184, 255)
    cached, _, changed = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=1000.9)
    assert cached is image and not changed
    _, _, changed = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=1001.1)
    assert changed
    history.close()


def test_timer_marker_follows_pan_and_expiry_restores_normal_dot(tmp_path):
    history, pickup, renderer, pose = scene(tmp_path)
    moved = Match(pose.scale, pose.tx + 75, pose.ty + 20, 10, 0, [])
    image, _, _ = renderer.render((570, 1029), moved, {'gems': True}, pickup_markers=[pickup], now=1100)
    assert image.getpixel((325, 480))[:3] == (104, 184, 255)
    assert not image.getpixel((250, 460))[3]
    expired, _, _ = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=2800)
    assert expired.getpixel((250, 460))[:3] == (255, 203, 91)
    restored, _, _ = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=3400)
    assert restored.getpixel((250, 460))[:3] == (244, 91, 208)
    assert len(history.list()) == 1
    history.close()


def test_custom_timer_marker_and_disabled_layer(tmp_path):
    history, pickup, renderer, pose = scene(tmp_path, known=False)
    image, counts, _ = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=1000)
    assert counts['gems'] == 1 and image.getpixel((250, 460))[3]
    hidden, counts, _ = renderer.render((570, 1029), pose, {}, pickup_markers=[pickup], now=1000)
    assert not np.asarray(hidden)[:, :, 3].any() and counts['gems'] == 0
    history.close()


@pytest.mark.parametrize('position', [(250, 45), (410, 80), (540, 785), (250, 930)])
def test_timer_labels_respect_fixed_interface_masks(tmp_path, position):
    history, pickup, renderer, _ = scene(tmp_path)
    px, py = position
    pose = Match(12.45, px - 100.5 * 12.45, py + 100.5 * 12.45, 10, 0, [])
    image, _, _ = renderer.render((570, 1029), pose, {'gems': True}, pickup_markers=[pickup], now=1000)
    alpha = np.asarray(image)[:, :, 3]
    assert not alpha[:36].any() and not alpha[938:].any()
    assert not alpha[36:233, 422:].any() and not alpha[788:938, 519:].any()
    history.close()
