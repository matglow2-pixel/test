"""Check detached entry-point lifecycle with native APIs simulated on Linux."""
import ctypes
from pathlib import Path
import runpy
import sys
from types import SimpleNamespace

import pytest


class NativeCall:
    def __init__(self, callback): self.callback = callback
    def __call__(self, *args): return self.callback(*args)


def setup_native(monkeypatch, existing=False):
    closed, restored, focused = [], [], []
    kernel = SimpleNamespace(CreateMutexW=NativeCall(lambda *args: 321),
                             CloseHandle=NativeCall(lambda handle: closed.append(handle)))
    user = SimpleNamespace(FindWindowW=NativeCall(lambda *args: 999),
                           ShowWindow=NativeCall(lambda *args: restored.append(args)),
                           SetForegroundWindow=NativeCall(lambda hwnd: focused.append(hwnd)))
    monkeypatch.setattr(ctypes, 'WinDLL', lambda name, **kwargs: kernel if name == 'kernel32' else user, raising=False)
    monkeypatch.setattr(ctypes, 'get_last_error', lambda: 183 if existing else 0, raising=False)
    return closed, restored, focused


@pytest.mark.parametrize('existing', [False, True])
def test_first_launch_opens_app_and_second_launch_focuses_existing_window(monkeypatch, existing):
    closed, restored, focused = setup_native(monkeypatch, existing)
    started = []
    monkeypatch.setitem(sys.modules, 'loong_lens', SimpleNamespace(main=lambda: started.append(True)))
    run = runpy.run_path(str(Path(__file__).resolve().parents[1] / 'launch_app.pyw'))['run']
    run()
    assert started == ([] if existing else [True])
    assert closed == [321]
    assert focused == ([999] if existing else [])
    assert restored == ([(999, 9)] if existing else [])


def test_startup_failure_releases_instance_handle_so_retry_can_start(monkeypatch):
    closed, _, _ = setup_native(monkeypatch)
    def fail(): raise RuntimeError('Startup failed')
    monkeypatch.setitem(sys.modules, 'loong_lens', SimpleNamespace(main=fail))
    run = runpy.run_path(str(Path(__file__).resolve().parents[1] / 'launch_app.pyw'))['run']
    with pytest.raises(RuntimeError, match='Startup failed'):
        run()
    assert closed == [321]
