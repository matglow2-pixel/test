from concurrent.futures import Future
import cv2
import numpy as np
import pytest
from tracker import VisualWorker
from resources import ROOT
from pose import Match

class Capture:
    def __init__(self, frame):
        self.frame = frame
        self.calls = 0

    def grab(self, _):
        self.calls += 1
        return self.frame

class Pool:
    def __init__(self):
        self.calls = 0

    def submit(self, *args):
        self.calls += 1
        return Future()  # deliberately slow: only one in-flight request is allowed

    def shutdown(self, **kwargs):
        pass

@pytest.fixture
def worker(tmp_path):
    worker = VisualWorker(lambda: (0, 0, 570, 1029), tmp_path)
    worker.pool.shutdown()
    worker.pool = Pool()
    worker.title.score = lambda frame: 1.
    yield worker
    worker.close()

@pytest.fixture
def capture():
    atlas = cv2.imread(str(ROOT / 'loong_haven_default_atlas.png'))
    return Capture(atlas[1300:2329, 900:1470].copy())

def test_only_one_background_request_even_when_frames_keep_arriving(worker, capture):
    for now in [10., 10.1, 10.2, 10.5, 10.9]:
        worker.step(capture, now)
    assert worker.pool.calls == 1
    assert capture.calls == 5

def test_closing_map_hides_in_the_same_step(worker, capture):
    worker.step(capture, 10.)
    worker.pose = Match(12.45, -900, 2173.55, 10, 0, [])
    worker.title.score = lambda frame: 0.
    worker.step(capture, 10.1)
    assert not worker.get()['open'] and worker.get()['match'] is None
    assert not worker.session.active

def test_close_reopen_discards_completed_old_search(worker, capture):
    worker.step(capture, 10.)
    pending = worker.future
    worker.title.score = lambda frame: 0.
    worker.step(capture, 10.1)
    pending.set_result((Match(12.45, -900, 2173.55, 99, 0, []), 10.))
    worker.title.score = lambda frame: 1.
    worker.step(capture, 10.2)
    assert worker.get()['open'] and worker.get()['match'] is None
    assert worker.pool.calls == 2

def test_pause_hides_without_capturing(worker, capture):
    worker.pause(True)
    worker.step(capture, 10.)
    assert capture.calls == 0 and not worker.get()['open']

def test_foreground_loss_hides_without_capturing(worker, capture):
    worker.find_window = lambda: None
    worker.step(capture, 10.)
    assert capture.calls == 0 and worker.get()['match'] is None

def test_valid_background_search_is_displayed(worker, capture):
    worker.step(capture, 10.)
    worker.future.set_result((Match(12.45, -900, 2173.55, 99, .1, [], 'test'), 12.))
    worker.step(capture, 10.1)
    assert worker.get()['match'].source == 'test'
    assert worker.get()['scan_ms'] == 12.

def test_saved_diagnostics_retain_last_map_when_panel_takes_focus(worker,capture):
    worker.step(capture,10.)
    worker.find_window=lambda:None
    worker.step(capture,10.1)
    frame,details=worker.get_diagnostics()
    assert frame.shape==(1029,570,3)
    assert details['title_score']==1.
    assert details['rect']==[0,0,570,1029]

def test_diagnostics_record_title_failure(worker,capture):
    worker.title.score=lambda frame:.2
    worker.step(capture,10.)
    _,details=worker.get_diagnostics()
    assert details['state']=='Map closed' and details['title_score']==.2
