"""Removed targets stay omitted across saves and passes; spawn data stays intact."""
from dataclasses import replace
import json
import pytest

from resources import ResourceStore
from patrol_route import (load_fixed_route,add_camera_view,remove_camera_view,
                          restore_camera_originals,save_camera_adjustments,
                          load_camera_adjustments,apply_camera_adjustments)


@pytest.fixture
def route():return load_fixed_route(ResourceStore().data)


def test_remove_original_persists_order_and_reduced_coverage(route,tmp_path):
    index=next(i for i,v in enumerate(route) if v.route_label=='12')
    edited=remove_camera_view(route,index)
    path=tmp_path/'route.json';save_camera_adjustments(route,edited,path)
    assert load_camera_adjustments(route,path)==edited
    document=json.loads(path.read_text())
    assert document['version']==3 and document['removed']==['12']
    assert len(edited)==75 and len(set().union(*(v.cells for v in edited)))==79
    assert len(ResourceStore().data['gems'])==86
    assert [v.route_label for v in edited]==[v.route_label for v in route if v.route_label!='12']


def test_remove_original_keeps_its_extras_and_allows_more_extras(route,tmp_path):
    index=next(i for i,v in enumerate(route) if v.route_label=='40b')
    edited=add_camera_view(route,index)
    edited=remove_camera_view(edited,index)
    edited=add_camera_view(edited,index)
    assert [v.route_label for v in edited[index:index+3]]==['40b+1','40b+2','41']
    path=tmp_path/'route.json';save_camera_adjustments(route,edited,path)
    assert load_camera_adjustments(route,path)==edited
    assert edited[index].cells==route[index].cells


def test_one_extra_can_remain_after_every_original_is_removed(route,tmp_path):
    expanded=add_camera_view(route,0)
    edited=(expanded[1],)
    path=tmp_path/'route.json';save_camera_adjustments(route,edited,path)
    assert load_camera_adjustments(route,path)==edited
    restored=restore_camera_originals(route,edited)
    assert restored[:2]==(route[0],edited[0]) and len(restored)==77


def test_restore_originals_preserves_other_camera_edits_and_extras(route):
    edited=add_camera_view(route,0)
    edited=list(remove_camera_view(edited,0))
    edited[-1]=replace(edited[-1],y=edited[-1].y+.25)
    restored=restore_camera_originals(route,edited)
    assert restored[0]==route[0]
    assert restored[1]==edited[0] and restored[-1]==edited[-1]
    assert [v.route_label for v in restored if not v.route_parent]==[v.route_label for v in route]


def test_last_point_cannot_be_removed_or_empty_profile_saved(route,tmp_path):
    path=tmp_path/'route.json'
    for action in (lambda:remove_camera_view((route[0],),0),
                   lambda:save_camera_adjustments(route,(),path),
                   lambda:apply_camera_adjustments(route,dict(version=3,targets={},removed=[v.route_label for v in route]))):
        with pytest.raises(ValueError,match='at least one'):action()
    assert not path.exists()


@pytest.mark.parametrize('removed',[['26'],['12','12'],[None],['12+1'],'12'])
def test_invalid_removed_ids_are_rejected(route,removed):
    with pytest.raises(ValueError):apply_camera_adjustments(route,dict(version=3,targets={},removed=removed))


def test_removal_does_not_allow_reordering_or_changed_spawn_identity(route,tmp_path):
    edited=remove_camera_view(route,0)
    for invalid in (tuple(reversed(edited)),(replace(edited[0],cells=frozenset({(0,0)})),)+edited[1:]):
        with pytest.raises(ValueError):save_camera_adjustments(route,invalid,tmp_path/'route.json')


def test_first_removal_backs_up_old_profile_without_overwriting_it(route,tmp_path):
    path=tmp_path/'camera-route-adjustments.json'
    save_camera_adjustments(route,route,path)
    old=path.read_bytes()
    save_camera_adjustments(route,route[1:],path)
    backup=path.with_suffix('.pre-v26.json')
    assert backup.read_bytes()==old
    save_camera_adjustments(route,route[2:],path)
    assert backup.read_bytes()==old
    save_camera_adjustments(route,restore_camera_originals(route,route[2:]),path)
    assert json.loads(path.read_text())['version']==2


def test_removed_first_point_is_not_inspected_and_remaining_extra_still_runs():
    from patrol_live import LivePatrol
    from test_live_patrol import setup
    engine,backend,events=setup()
    base=tuple(replace(v,route_number=i+1) for i,v in enumerate(engine.views))
    views=remove_camera_view(add_camera_view(base,0),0)
    patrol=LivePatrol(views,engine.settings,engine.cancel,events.append,detector=engine.detector,
                      locator=engine.locator,title=engine.title,clock=engine.clock)
    patrol.run(backend)
    assert [e['view'].route_label for e in events if e['kind']=='view']==['1+1','2']
    assert patrol.checked=={0,1}
