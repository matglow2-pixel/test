import cv2
import numpy as np
import pytest
from map_alignment import PORTALS,find_portals,align_portals
from terrain_alignment import align_terrain
from resources import ROOT
from vision import Calibrator

def test_landmark_constellation_from_reported_nimbuville_tower_view():
    # Approximate centers read from the user's inline map screenshot; this
    # checks geometry, not pixel recognition of that unavailable image file.
    observed=np.array([[203,128],[465,302],[339,626],[177,891]],float)
    pose=align_portals(observed)
    assert pose is not None and pose.count==4 and pose.error<2
    assert abs(pose.scale-12.5)<.1
    assert abs(pose.tx+1648)<5 and abs(pose.ty-1728)<5

def test_portal_match_survives_false_icons_and_small_coordinate_noise():
    observed=np.array([[203,128],[465,302],[339,626],[177,891],[91,520],[450,750]],float)
    pose=align_portals(observed)
    assert pose is not None and pose.count==4

def test_three_portals_cannot_establish_unlabeled_constellation():
    assert align_portals(np.array([[203,128],[465,302],[339,626]],float)) is None

def test_random_markers_do_not_align():
    assert align_portals(np.array([[20,240],[410,340],[70,500],[460,860]],float)) is None

def test_other_zoom_is_rejected():
    world=PORTALS[[7,8,9,24]]
    observed=world*np.array([10.,-10.])+[-1200,1400]
    assert align_portals(observed) is None

def test_portal_pixel_detection_ignores_legend_icon():
    frame=np.full((1029,570,3),(112,184,152),np.uint8)
    color=tuple(map(int,cv2.cvtColor(np.uint8([[[95,180,215]]]),cv2.COLOR_HSV2BGR)[0,0]))
    expected=[(203,128),(465,302),(339,626),(177,891)]
    for point in expected+[(446,75)]:cv2.circle(frame,point,8,color,-1)
    found=find_portals(frame)
    assert len(found)==4
    pose=align_portals(found)
    assert pose is not None and pose.count==4

@pytest.mark.parametrize('x,y',[(1639,1752),(1600,1500),(2000,1700),(900,1300),(500,1000),(1200,200),(1500,400)])
def test_terrain_fallback_on_real_atlas_pixels(x,y):
    cv2.setNumThreads(2)
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    result=align_terrain(atlas[y:y+1029,x:x+570].copy())
    assert result is not None
    # Coarse tile-phase matching is lower precision than the feature/portal fit.
    assert abs(result.tx+x)<7 and abs(result.ty-(279*12.45-y))<7

def test_uniform_terrain_cannot_calibrate():
    assert align_terrain(np.full((1029,570,3),(112,184,152),np.uint8)) is None

def test_calibrator_uses_portals_when_features_are_missing():
    calibrator=Calibrator()
    calibrator.index.locate=lambda *args:None
    frame=np.full((1029,570,3),(112,184,152),np.uint8)
    color=tuple(map(int,cv2.cvtColor(np.uint8([[[95,180,215]]]),cv2.COLOR_HSV2BGR)[0,0]))
    for point in [(203,128),(465,302),(339,626),(177,891)]:cv2.circle(frame,point,8,color,-1)
    pose=calibrator.locate(frame)
    assert pose is not None and pose.source.startswith('portals')
