"""Actual screenshot registration around islands, without any zone OCR."""
import threading
from types import SimpleNamespace
import cv2
import numpy as np
import pytest
from vision import track_map_pan,patrol_map_mask
from patrol_live import LivePatrol,LiveSettings
from camera_patrol import Viewpoint
from pose import Match
from resources import ROOT


@pytest.fixture(scope='module')
def atlas():
    cv2.setNumThreads(2)
    return cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))


def render(atlas,x,y):
    pose=Match(12.45,285-x*12.45,500+y*12.45,0,0,[])
    image=cv2.warpAffine(atlas,np.float32([[1,0,pose.tx],[0,1,pose.ty-279*12.45]]),(570,1029))
    return image,pose


@pytest.mark.parametrize('x,y,delta',[(49.5,34.5,(-100,125)),(49.5,34.5,(100,-125)),
                                      (55.5,110.5,(-200,200)),(205.5,186.5,(-100,125))])
def test_overlap_recognises_pan_even_when_no_absolute_zone_is_found(atlas,x,y,delta):
    before,known=render(atlas,x,y)
    frame,expected=render(atlas,x-delta[0]/12.45,y+delta[1]/12.45)
    result=track_map_pan(before,frame,known,delta)
    assert result is not None
    assert abs(result.tx-expected.tx)<1.5 and abs(result.ty-expected.ty)<1.5


def test_hud_or_stationary_background_cannot_fake_a_pan(atlas):
    before,known=render(atlas,49.5,34.5)
    assert track_map_pan(before,before,known,(-100,125)) is None
    empty=np.full_like(before,50)
    assert track_map_pan(empty,empty,known,(0,0)) is None


def test_sparse_island_pan_and_next_reopen_survive_missing_absolute_matches(atlas):
    class Backend:
        center=(49.5,34.5);open=True;now=0.;inputs=[]
        def wait(self,t):self.now+=t
        def focus(self):pass
        def capture(self):
            if not self.open:return np.zeros((1029,570,3),np.uint8)
            frame,_=render(atlas,*self.center);frame[0,0]=255
            return frame
        def click(self,p):
            self.inputs.append(('click',p))
            if not self.open:self.open=True
            elif p==LiveSettings().map_close:self.open=False
        def drag(self,a,b):
            self.inputs.append(('drag',a,b));self.wait(.36)
            self.center=(self.center[0]-(b[0]-a[0])/12.45,self.center[1]+(b[1]-a[1])/12.45)
    backend=Backend();events=[]
    def locate(frame):
        if backend.center==(49.5,34.5):return render(atlas,*backend.center)[1]
        return None  # Reproduce an island pan losing absolute recognition.
    views=tuple(Viewpoint(x,y,'Area',frozenset({(int(x),int(y))})) for x,y in [(49.5,34.5),(79.5,89.5),(86.5,90.5)])
    engine=LivePatrol(views,LiveSettings(),threading.Event(),events.append,
        detector=SimpleNamespace(detect=lambda *a,**kw:[]),locator=SimpleNamespace(locate=locate),
        title=SimpleNamespace(score=lambda f:float(f[0,0,0]>0)),clock=lambda:backend.now)
    engine.run(backend)
    assert len(engine.checked)==3
    assert any(e[0]=='drag' for e in backend.inputs)
    assert sum(e[0]=='click' and e[1]==(480.,170.) for e in backend.inputs)==2


def test_immutable_reference_reuses_only_source_features_for_fresh_images(atlas,monkeypatch):
    before,known=render(atlas,180.5,186.5);before.setflags(write=False)
    frames=[render(atlas,180.5+shift/12.45,186.5) for shift in (70,110)]
    real=cv2.SIFT_create;calls=[]
    class Counter:
        def __init__(self,*a,**kw):self.inner=real(*a,**kw)
        def detectAndCompute(self,*a,**kw):calls.append(True);return self.inner.detectAndCompute(*a,**kw)
    monkeypatch.setattr(cv2,'SIFT_create',Counter)
    for frame,expected in frames:
        found=track_map_pan(before,frame,known,(-100,0))
        assert found is not None and abs(found.tx-expected.tx)<1.5
    assert len(calls)==3  # One source + two independently recognised screenshots.
