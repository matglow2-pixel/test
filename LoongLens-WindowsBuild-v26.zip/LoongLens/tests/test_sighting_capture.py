from datetime import datetime
from pathlib import Path
import sqlite3
from types import SimpleNamespace

import cv2
import numpy as np
import pytest

from gem_detector import Detection
from gem_watch_worker import WatchWorker
from location_ocr import Location, TextLine, parse_location
from sighting_capture import SightingCapture
from sighting_history import SightingHistory


def event(identifier='gem:1', seen_at=1000, **changes):
    return dict(event_id=identifier, seen_at=seen_at, screen_x=116, screen_y=311, score=.95,
                test_mode=False, capture_status='pending', **changes)


class Reader:
    def read(self, frame):
        return Location('Loong Haven III', int(frame[0,0,0]), 121)


def frame(value=193):
    return np.full((1029,570,3), value, np.uint8)


class Screen:
    pixels = frame(120)
    def grab(self, _): return self.pixels


def make_worker(tmp_path, visible_at=lambda *args: True):
    capture = SightingCapture(tmp_path, Reader())
    worker = WatchWorker(lambda:(123,(0,0,570,1029)), visible_at, capture=capture)
    worker.map_title = SimpleNamespace(score=lambda frame: 0)
    worker.detector.detect = lambda *args,**kwargs: [Detection(100,300,32,22,.95)]
    worker.configure(paused=False)
    return worker


def step(worker, screen, monkeypatch, now, epoch=1000):
    monkeypatch.setattr('gem_watch_worker.time.perf_counter', lambda: now)
    monkeypatch.setattr('gem_watch_worker.time.time', lambda: epoch+now)
    worker.step(screen, now)


def test_alert_is_immediate_but_location_uses_new_frame_after_five_seconds(tmp_path, monkeypatch):
    worker = make_worker(tmp_path)
    screen = Screen()
    epoch = datetime(2026,10,14,8,8,57).timestamp()  # Capture crosses into 08:09; spotting stays 08:08.
    for now in (0,.5,1): step(worker,screen,monkeypatch,now,epoch)
    initial = worker.drain_sightings()
    assert len(initial)==1 and initial[0]['capture_status']=='pending'
    assert len(worker.drain_alerts())==1
    step(worker,screen,monkeypatch,5.99,epoch)
    assert not list(tmp_path.rglob('*.png'))
    screen.pixels = frame(193)
    step(worker,screen,monkeypatch,6,epoch)
    worker.close()  # Wait for only the background file/OCR work, never sleep five seconds.
    completed = worker.drain_sightings()
    assert len(completed)==1
    row = completed[0]
    assert row['seen_at']==epoch+1 and row['captured_at']==epoch+6
    assert (row['zone'],row['game_x'],row['game_y'])==('Loong Haven III',193,121)
    image = cv2.imread(row['screenshot_path'])
    assert np.array_equal(image,screen.pixels)
    history = SightingHistory(tmp_path/'sightings.sqlite3')
    history.record(initial+completed)
    history.record(initial)  # A retried early event cannot erase the completed result.
    history.close()
    restarted = SightingHistory(tmp_path/'sightings.sqlite3')
    saved = restarted.list()[0]
    assert saved.spotted=='Loong Haven III (193,121) 14/10/26 08:08'
    assert saved.source_label=='Live game · Open screenshot'
    assert Path(saved.screenshot_path).is_file() and len(restarted.list())==1
    restarted.close()


@pytest.mark.parametrize('reason', ['paused','missing','changed_window','covered','photo'])
def test_interrupted_capture_never_uses_stale_or_other_window_pixels(tmp_path, monkeypatch, reason):
    visible = lambda hwnd,x,y: not (reason=='covered' and x>450 and y<200)
    worker = make_worker(tmp_path, visible)
    screen=Screen()
    for now in (0,.5,1): step(worker,screen,monkeypatch,now)
    worker.drain_sightings()
    if reason=='paused': worker.configure(paused=True)
    elif reason=='missing': worker.find_window=lambda:None
    elif reason=='changed_window': worker.find_window=lambda:(124,(0,0,570,1029))
    elif reason=='photo': worker.test_image(frame(210))
    step(worker,screen,monkeypatch,6)
    worker.close()
    events=worker.drain_sightings()
    original = next(row for row in events if row['event_id'].endswith(':1'))
    assert original['capture_status'] in ('unavailable','cancelled')
    assert not original.get('screenshot_path') and not original.get('game_x')
    assert not list(tmp_path.rglob('*.png'))


def test_two_sightings_keep_their_own_deadline_frames_and_files(tmp_path):
    service=SightingCapture(tmp_path,Reader())
    first,second=event('first'),event('second',seen_at=1001)
    service.schedule(first,(123,(0,0,570,1029)),0)
    service.schedule(second,(123,(0,0,570,1029)),1)
    service.due(5,frame(193),(123,(10,20,570,1029)),True)
    service.due(6,frame(200),(123,(10,20,570,1029)),True)
    result=service.close()
    by_id={row['event_id']:row for row in result}
    assert by_id['first']['game_x']==193 and by_id['second']['game_x']==200
    assert by_id['first']['screenshot_path']!=by_id['second']['screenshot_path']
    assert len(list(tmp_path.rglob('*.png')))==2


def test_reset_and_panning_inside_cooldown_save_one_history_row_and_one_png(tmp_path,monkeypatch):
    worker=make_worker(tmp_path)
    screen=Screen()
    all_events=[]
    for now in (0,.5,1,6):
        step(worker,screen,monkeypatch,now)
        all_events.extend(worker.drain_sightings())
    # Reproduce a scan reset, then a moved gem box in the same place/session.
    worker.configure(reset=True)
    for now in (7,7.5,8):
        step(worker,screen,monkeypatch,now)
        all_events.extend(worker.drain_sightings())
    worker.detector.detect=lambda *args,**kwargs:[Detection(350,500,32,22,.95)]
    for now in (9,9.5,10,15,20):
        step(worker,screen,monkeypatch,now)
        all_events.extend(worker.drain_sightings())
    worker.close()
    all_events.extend(worker.drain_sightings())
    history=SightingHistory(tmp_path/'sightings.sqlite3')
    history.record(all_events)
    rows=history.list()
    assert len(rows)==1 and rows[0].capture_status=='ready'
    assert len(list(tmp_path.rglob('*.png')))==1
    assert not worker.capture.waiting
    history.close()


@pytest.mark.parametrize('change', ['photo','pause'])
def test_source_change_or_pause_during_deadline_capture_discards_that_frame(tmp_path,monkeypatch,change):
    worker=make_worker(tmp_path)
    class ReentrantScreen(Screen):
        callback=None
        def grab(self,_):
            if self.callback is not None:
                callback,self.callback=self.callback,None
                callback()
            return self.pixels
    screen=ReentrantScreen()
    for now in (0,.5,1): step(worker,screen,monkeypatch,now)
    worker.drain_sightings()
    screen.callback=(lambda:worker.test_image(frame(210))) if change=='photo' else (lambda:worker.configure(paused=True))
    step(worker,screen,monkeypatch,6)
    worker.close()
    completed=worker.drain_sightings()
    assert len(completed)==1 and completed[0]['capture_status']=='cancelled'
    assert not list(tmp_path.rglob('*.png'))


def test_ocr_failure_keeps_the_saved_image_without_inventing_coordinates(tmp_path):
    class BrokenReader:
        def read(self, _): raise RuntimeError('Cannot read text')
    service=SightingCapture(tmp_path,BrokenReader())
    service.schedule(event(),(123,(0,0,570,1029)),0)
    service.due(5,frame(),(123,(0,0,570,1029)),True)
    result=service.close()[0]
    assert result['capture_status']=='ocr_error' and Path(result['screenshot_path']).is_file()
    assert result['game_x'] is None and result['zone'] is None


def test_old_history_schema_is_preserved_and_only_pending_rows_are_recovered(tmp_path):
    path=tmp_path/'old.sqlite3'
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE sightings(id INTEGER PRIMARY KEY,event_id TEXT UNIQUE,seen_at REAL,screen_x REAL,screen_y REAL,score REAL,test_mode INTEGER)')
        db.execute("INSERT INTO sightings VALUES(1,'old',1000,116,311,.95,0)")
    history=SightingHistory(path)
    history.record([event('pending',seen_at=1001)])
    history.recover_pending()
    assert len(history.list())==2 and history.get(1).capture_status=='legacy'
    assert history.list()[0].capture_status=='interrupted'
    assert 'Location unavailable' in history.get(1).spotted
    history.close()


def line(text, bounds, score=.99): return TextLine(text,score,bounds)


def test_minimap_label_format_normalizes_roman_glyphs_and_comma_spacing():
    found=parse_location([line('Loong Haven lll',(5,10,145,30)),line('(193, 121)',(20,32,130,52))])
    assert found==Location('Loong Haven III',193,121)
    assert parse_location([line('lronpeak',(5,10,145,30)),line('（31.186）',(20,32,130,52))])==Location('Ironpeak',31,186)


@pytest.mark.parametrize('text,score,bounds', [('(280,121)',.99,(20,32,130,52)),('(193,121)',.7,(20,32,130,52)),
    ('193/300',.99,(20,32,130,52)),('(193,121)',.99,(300,300,430,320))])
def test_low_confidence_out_of_range_and_unrelated_text_are_not_locations(text,score,bounds):
    assert parse_location([line('Loong Haven III',(5,10,145,30)),line(text,bounds,score)]) is None


def test_ambiguous_labels_are_rejected():
    lines=[line('Loong Haven III',(5,10,145,30)),line('(193,121)',(20,32,130,52)),
           line('Loong Haven II',(5,100,145,120)),line('(200,130)',(20,122,130,142))]
    assert parse_location(lines) is None
