import time
import cv2
import numpy as np
import pytest
from resources import ROOT
from vision import AtlasIndex, MotionTracker, Session, TitleDetector, reconcile
from pose import Match

@pytest.fixture(scope='module')
def atlas():
    cv2.setNumThreads(2)
    return cv2.imread(str(ROOT / 'loong_haven_default_atlas.png'))

@pytest.fixture(scope='module')
def index(tmp_path_factory):
    idx = AtlasIndex(tmp_path_factory.mktemp('index'))
    idx.prepare()
    return idx

@pytest.mark.parametrize('x,y', [(900,1300), (1600,1500), (2000,1700)])
def test_absolute_alignment(index, atlas, x, y):
    match = index.locate(atlas[y:y+1029, x:x+570].copy())
    assert match is not None
    assert abs(match.scale - 12.45) < .05
    assert abs(match.tx + x) < 3
    assert abs(match.ty - (279*12.45-y)) < 3

@pytest.mark.parametrize('zoom', [.8, 1.2, 1.4])
def test_nondefault_zoom_is_rejected(index, atlas, zoom):
    x, y = 1300, 1300
    frame = cv2.resize(atlas[y:y+round(1029/zoom), x:x+round(570/zoom)], (570,1029))
    match = index.locate(frame)
    assert match is None

def test_blank_and_noise_do_not_calibrate(index):
    assert index.locate(np.zeros((1029,570,3), np.uint8)) is None
    frame = np.random.default_rng(5).integers(0, 255, (1029,570,3), dtype=np.uint8)
    assert index.locate(frame) is None

def test_index_cache_round_trip(index):
    other = AtlasIndex(index.cache_dir)
    other.prepare()
    np.testing.assert_array_equal(index.points, other.points)
    np.testing.assert_array_equal(index.descriptors, other.descriptors)

def test_corrupt_cache_rebuilds(index):
    path = next(index.cache_dir.glob('*.npz'))
    path.write_bytes(b'not an index')
    other = AtlasIndex(index.cache_dir)
    other.prepare()
    assert other.ready and len(other.descriptors) > 100

def test_motion_tracks_pan(atlas):
    x, y = 1300, 1300
    initial = atlas[y:y+1029, x:x+570].copy()
    moved = atlas[y+8:y+8+1029, x+13:x+13+570].copy()
    tracker = MotionTracker()
    tracker.prime(initial)
    pose = Match(12.45, -x, 279*12.45-y, 10, 0, [])
    result = tracker.update(moved, pose)
    assert result is not None
    assert abs(result.tx - (pose.tx-13)) < 1.5
    assert abs(result.ty - (pose.ty-8)) < 1.5

def test_stationary_motion_returns_same_pose(atlas):
    frame = atlas[1300:2329, 1300:1870].copy()
    motion = MotionTracker(); motion.prime(frame)
    pose = Match(12.45, -1300, 2173.55, 10, 0, [])
    assert motion.update(frame.copy(), pose) is pose

def test_old_session_result_is_never_accepted():
    session = Session()
    session.update(True, (0,0,570,1029))
    ticket = session.ticket(np.zeros((1029,570,3), np.uint8), 1.)
    assert session.accepts(ticket, 1.1)
    session.update(False, session.rect)
    session.update(True, session.rect)
    assert not session.accepts(ticket, 1.2)

def test_resize_and_expired_results_are_rejected():
    session = Session(); session.update(True, (0,0,570,1029))
    ticket = session.ticket(np.zeros((10,10,3), np.uint8), 1.)
    assert not session.accepts(ticket, 4.)
    session.update(True, (0,0,600,1000))
    assert not session.accepts(ticket, 1.2)

def test_title_gate_uses_actual_template():
    title = TitleDetector()
    frame = np.zeros((1029,570,3), np.uint8)
    assert title.score(frame) < .64
    template = cv2.imread(str(ROOT / 'loong_title_template.png'))
    h,w = template.shape[:2]
    frame[50:50+h, 20:20+w] = template
    assert title.score(frame) > .99
