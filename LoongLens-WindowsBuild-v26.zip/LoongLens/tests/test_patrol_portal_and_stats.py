import contextlib
import json
import math
import numpy as np
import pytest
from camera_patrol import build_plan,load_spawns,camera_click_clear,PatrolSettings
from resources import ROOT
from patrol_live import PatrolRunStats,LiveRunner,LiveSettings
from test_live_patrol import Clock,setup


def test_reported_portal_dot_moves_but_all_77_views_and_86_spots_are_retained():
    plan=build_plan(load_spawns(json.loads((ROOT/'loong_haven_map_data.json').read_text())))
    assert len(plan.views)==77 and len(plan.cells)==86
    view=next(v for v in plan.views if (182,140) in v.cells)
    assert math.dist((184.75,139.05),(184,138))<2.5  # Reproduce the old intercepted click.
    assert camera_click_clear(view.x,view.y)
    assert math.dist((view.x,view.y),(184,138))>=2.5
    left,bottom,right,top=view.bounds(plan.settings)
    assert left+.6<=182.5<=right-.6 and bottom+.6<=140.5<=top-.6


def test_live_click_cannot_activate_the_reported_portal():
    data=json.loads((ROOT/'loong_haven_map_data.json').read_text())
    points=tuple(s for s in load_spawns(data) if s.zone=='Loong Haven IV')
    engine,backend,events=setup()
    engine.views=build_plan(points).views;backend.center=(182.,140.)
    original=backend.click
    def click(point):
        if backend.open and point!=LiveSettings().map_close:
            portal=engine.locator.locate(backend.capture()).project(184,138)
            assert math.dist(point,portal)>=2.5*12.45
        original(point)
    backend.click=click
    engine.run(backend)
    assert engine.checked=={0} and len(backend.inputs)==2


def test_timer_keeps_running_between_resumes_and_freezes_only_on_completion():
    clock=Clock();stats=PatrolRunStats(clock)
    assert stats.text()=='Time spent: 0:00\nGems found: 0'
    stats.start();clock.now+=461;stats.found();stats.found()
    assert stats.text()=='Time spent: 7:41\nGems found: 2'
    clock.now+=19;stats.start()  # Resuming must not restart the pass clock.
    assert stats.text()=='Time spent: 8:00\nGems found: 2'
    stats.complete();clock.now+=1000
    assert stats.text()=='Time spent: 8:00\nGems found: 2'
    stats.reset();assert stats.text()=='Time spent: 0:00\nGems found: 0'


def test_runner_counts_confirmed_gems_across_resumed_checks_and_stops_clock():
    engine,backend,events=setup(positive=True)
    runner=LiveRunner(engine.views,lambda cancel:contextlib.nullcontext(backend),events.append,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title
    assert runner.start(LiveSettings(approach_gem=False));runner.thread.join(3)
    assert not runner.running and runner.stats.snapshot()['gems']==1
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=100
    assert runner.stats.snapshot()['elapsed']==elapsed+100
    assert runner.start(LiveSettings(approach_gem=False));runner.thread.join(3)
    assert not runner.running and runner.checked=={0,1}
    assert runner.stats.snapshot()['gems']==2
    assert runner.stats.snapshot()['elapsed']>elapsed
    assert not runner.start(LiveSettings())  # No artificial extra timed run after completion.
    finished=runner.stats.snapshot()['elapsed'];backend.clock.now+=100
    assert runner.stats.snapshot()['elapsed']==finished
    assert [e['stats']['gems'] for e in events if e['kind']=='finished']==[1,2]


def test_runner_error_keeps_pass_clock_running_without_counting_a_gem():
    engine,backend,events=setup();backend.break_back=True
    runner=LiveRunner(engine.views,lambda cancel:contextlib.nullcontext(backend),events.append,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title
    assert runner.start(LiveSettings(approach_gem=False));runner.thread.join(3)
    assert not runner.running and runner.stats.snapshot()['gems']==0
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=100
    assert runner.stats.snapshot()['elapsed']==elapsed+100
    assert 'did not close' in next(e['message'] for e in events if e['kind']=='finished')
