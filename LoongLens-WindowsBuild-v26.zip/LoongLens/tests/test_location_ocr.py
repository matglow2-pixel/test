import cv2
import numpy as np
import pytest

from location_ocr import Location, LocationReader


@pytest.fixture(scope='module')
def reader():
    return LocationReader()


@pytest.mark.parametrize('scale', [1., 1.5])
def test_bundled_models_read_the_requested_minimap_format(reader, scale):
    image=np.full((1029,570,3),(95,145,105),np.uint8)
    cv2.rectangle(image,(332,228),(554,291),(55,60,50),-1)
    cv2.putText(image,'Loong Haven III',(346,253),cv2.FONT_HERSHEY_SIMPLEX,.55,(240,240,240),1,cv2.LINE_AA)
    cv2.putText(image,'(193,121)',(369,279),cv2.FONT_HERSHEY_SIMPLEX,.55,(240,240,240),1,cv2.LINE_AA)
    if scale!=1:
        image=cv2.resize(image,None,fx=scale,fy=scale,interpolation=cv2.INTER_CUBIC)
    assert reader.read(image)==Location('Loong Haven III',193,121)


def test_blank_screen_does_not_invent_a_location(reader):
    assert reader.read(np.zeros((1029,570,3),np.uint8)) is None
