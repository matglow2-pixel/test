"""Continuous passes must stop on F10, finds and errors, including at boundaries."""
import contextlib
from patrol_live import LiveRunner,LiveSettings
from test_live_patrol import setup


def runner_for(engine,backend,emit):
    runner=LiveRunner(engine.views,lambda cancel:contextlib.nullcontext(backend),emit,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title
    backend.cancel=runner.cancel
    return runner


def test_loop_repeats_and_revisits_the_same_first_spot_until_f10():
    engine,backend,events=setup()
    def emit(event):
        events.append(event)
        if event['kind']=='pass_complete' and event['passes']==2:runner.stop()
    runner=runner_for(engine,backend,emit)
    assert runner.start(LiveSettings(approach_gem=False),repeat=True)
    runner.thread.join(5)
    assert not runner.running and runner.cancel.is_set()
    assert runner.passes==2
    assert [e['index'] for e in events if e['kind']=='view']==[0,1,0,1]
    assert len([e for e in events if e['kind']=='pass_started'])==1
    assert len([e for e in events if e['kind']=='finished'])==1
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=30
    assert runner.stats.snapshot()['elapsed']==elapsed+30


def test_find_on_final_view_stops_loop_instead_of_restarting():
    engine,backend,events=setup(positive=True)
    engine.views=engine.views[:1]
    runner=runner_for(engine,backend,events.append)
    assert runner.start(LiveSettings(approach_gem=False),repeat=True)
    runner.thread.join(5)
    assert not runner.running and runner.passes==1
    assert runner.stats.snapshot()['gems']==1
    assert not any(e['kind']=='pass_started' for e in events)
    assert len([e for e in events if e['kind']=='found'])==1


def test_find_in_later_pass_stops_and_preserves_saving_cooldown():
    engine,backend,events=setup()
    empty=engine.detector.detect
    def emit(event):
        events.append(event)
        if event['kind']=='pass_started':
            engine.detector.detect=lambda *a,**kw:[__import__('types').SimpleNamespace(center=(200,400),score=.95,width=20)]
            runner.cooldown['last']=backend.clock.now
    runner=runner_for(engine,backend,emit)
    assert runner.start(LiveSettings(approach_gem=False),repeat=True)
    runner.thread.join(5)
    assert not runner.running and runner.passes==1 and runner.checked=={0}
    assert runner.stats.snapshot()['gems']==1
    assert next(e for e in events if e['kind']=='found')['event'] is None
    assert not any(e['kind']=='capture' for e in events)


def test_error_does_not_start_another_pass_or_clear_progress():
    engine,backend,events=setup();backend.break_back=True
    runner=runner_for(engine,backend,events.append)
    assert runner.start(LiveSettings(),repeat=True)
    runner.thread.join(5)
    assert not runner.running and runner.passes==0 and runner.checked==set()
    assert not any(e['kind']=='pass_started' for e in events)
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=30
    assert runner.stats.snapshot()['elapsed']==elapsed+30


def test_loop_can_start_after_completed_single_pass_but_snipe_does_not_repeat():
    engine,backend,events=setup()
    runner=runner_for(engine,backend,events.append)
    assert runner.start(LiveSettings())
    runner.thread.join(5)
    assert not runner.running and runner.passes==1
    assert not runner.start(LiveSettings())
    def emit(event):
        events.append(event)
        if event['kind']=='pass_complete':runner.stop()
    runner.emit=emit
    assert runner.start(LiveSettings(),repeat=True)
    runner.thread.join(5)
    assert not runner.running and runner.passes==2 and runner.checked=={0,1}


def test_loop_total_never_resets_recent_three_times_are_independent_and_reset_is_explicit():
    engine,backend,events=setup()
    def emit(event):
        events.append(event)
        if event['kind']=='pass_complete' and event['passes']>=4:runner.stop()
    runner=runner_for(engine,backend,emit)
    assert runner.start(LiveSettings(approach_gem=False),repeat=True);runner.thread.join(5)
    assert not runner.running and runner.passes==4
    completed=[e for e in events if e['kind']=='pass_complete']
    assert [p['number'] for p in runner.recent_passes]==[4,3,2]
    assert [p['number'] for p in completed[1]['recent_passes']]==[2,1]  # Old events remain unchanged.
    total=runner.stats.snapshot()['elapsed']
    assert total>=sum(e['stats']['elapsed'] for e in completed)
    assert all(e['stats']['elapsed']<total/2 for e in completed)
    # Resuming an already-completed loop pass must retain the total and finds.
    runner.stats.found();backend.clock.now+=30
    assert runner.start(LiveSettings(approach_gem=False),repeat=True);runner.thread.join(5)
    if runner.running:runner.stop();runner.thread.join(5)
    assert runner.stats.snapshot()['elapsed']>=total+30
    assert runner.stats.snapshot()['gems']==1
    assert runner.reset_checks()
    assert runner.stats.text()=='Time spent: 0:00\nGems found: 0'
    assert runner.pass_stats.snapshot()['elapsed']==0
    assert runner.passes==0 and not runner.recent_passes and not runner.loop_session and not runner.checked


def test_gem_stops_later_loop_pass_without_resetting_total_or_previous_run_times():
    engine,backend,events=setup()
    def emit(event):
        events.append(event)
        if event['kind']=='pass_started':
            runner.stats.found()  # A previously recorded find in this session.
            engine.detector.detect=lambda *a,**kw:[__import__('types').SimpleNamespace(center=(200,400),score=.95,width=20)]
    runner=runner_for(engine,backend,emit)
    assert runner.start(LiveSettings(approach_gem=True),repeat=True);runner.thread.join(5)
    assert not runner.running and runner.passes==1 and runner.checked=={0}
    assert runner.stats.snapshot()['gems']==2
    assert runner.stats.snapshot()['elapsed']>runner.last_pass['elapsed']
    assert len(runner.recent_passes)==1
    assert backend.inputs[-1][1]==(200.,400.)
