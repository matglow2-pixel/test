"""Regression for inertial pans losing the eastern snowy map edge."""
import math
import threading
from types import SimpleNamespace
import cv2
import pytest
from camera_patrol import Spawn
from patrol_live import LivePatrol,LiveSettings,MapAlignmentLost
from patrol_windows import WindowsBackend,PatrolStopped
from test_live_patrol import setup
from test_patrol_pan_tracking import render
from vision import track_map_pan
from resources import ROOT


def overshoot_engine(recover=True):
    engine,backend,events=setup(spawns=(Spawn(100.5,100.5,'Done'),Spawn(205.5,186.5,'Frosted Plain')))
    engine.checked.add(0);backend.center=(170.,186.5)
    original_drag=backend.drag;calls=[]
    def drag(a,b):
        calls.append((a,b));original_drag(a,b)
        if len(calls)==1:
            # The map coasts far beyond the request, leaving a near-empty view.
            backend.center=(170.-5*(b[0]-a[0])/12.45,186.5+5*(b[1]-a[1])/12.45)
    backend.drag=drag
    original_locate=engine.locator.locate
    restored=[]
    def locate(frame):
        if calls and not recover:return None
        if calls and not restored:
            if backend.center[0]>184:return None
            restored.append(True)
        return original_locate(frame)
    engine.locator=SimpleNamespace(locate=locate)
    return engine,backend,events,calls


def test_overshoot_recovers_without_losing_previously_checked_locations():
    engine,backend,events,calls=overshoot_engine()
    engine.run(backend)
    assert engine.checked=={0,1}
    assert any('Recovering map alignment' in e.get('message','') for e in events)
    assert any('Map recovered' in e.get('message','') for e in events)
    assert not engine.navigation.get('pending') and engine.pan_scale<1
    assert all(math.dist(a,b)<=120.0001 for a,b in calls)
    assert calls[0][1][0]<calls[0][0][0]
    assert any(b[0]>a[0] for a,b in calls[1:])  # Backtrack, not another outward swipe.
    assert len([x for x in backend.inputs if x[0]=='click'])==2


def test_failed_recovery_is_bounded_and_never_clicks_an_unrecognised_dot():
    engine,backend,events,calls=overshoot_engine(recover=False)
    with pytest.raises(MapAlignmentLost,match='recovery'):engine.run(backend)
    assert engine.checked=={0} and len(calls)==7  # One pan, at most six reverse pans.
    assert engine.navigation['recovery_exhausted']
    assert not any(x[0]=='click' for x in backend.inputs)
    assert not any(e['kind'] in ('found','capture') for e in events)


def test_emergency_stop_prevents_recovery_mouse_input():
    engine,backend,events,calls=overshoot_engine()
    def emit(event):
        events.append(event)
        if 'Recovering map alignment' in event.get('message',''):engine.cancel.set()
    engine.emit=emit
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert len(calls)==1 and engine.checked=={0}


def test_focus_failure_is_not_treated_as_permission_to_backtrack():
    engine,backend,events,calls=overshoot_engine()
    original=backend.capture
    def capture():
        if calls:raise RuntimeError('BlueStacks lost focus')
        return original()
    backend.capture=capture
    with pytest.raises(RuntimeError,match='focus'):engine.run(backend)
    assert len(calls)==1 and engine.checked=={0}


def test_drag_pauses_at_endpoint_before_releasing_mouse():
    backend=WindowsBackend.__new__(WindowsBackend)
    backend.cancel=threading.Event();backend.down=False;actions=[]
    backend.api=SimpleNamespace(mouse=lambda flag:actions.append(('button',flag)))
    backend.move=lambda point:actions.append(('move',point))
    backend.guard=lambda:None
    backend.wait=lambda seconds:actions.append(('wait',seconds))
    backend.drag((285,500),(365,500))
    assert actions[-3:]==[('move',(365.,500.)),('wait',.18),('button',4)]
    total=sum(seconds for kind,seconds in actions if kind=='wait')
    assert .25<=total<.45  # Keep the anti-fling hold; shorten mouse motion.
    assert [v for k,v in actions if k=='button']==[2,4]
    assert not backend.down


def test_actual_screenshot_overlap_can_measure_inertia_beyond_requested_drag():
    cv2.setNumThreads(2)
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    before,known=render(atlas,180.5,186.5)
    frame,expected=render(atlas,180.5+180/12.45,186.5)
    result=track_map_pan(before,frame,known,(-70.,0.))
    assert result is not None
    assert abs(result.tx-expected.tx)<1.5 and abs(result.ty-expected.ty)<1.5


def test_resume_can_recover_the_pending_pan_using_previous_engine_state():
    engine,backend,events,calls=overshoot_engine()
    def emit(event):
        events.append(event)
        if 'Recovering map alignment' in event.get('message',''):engine.cancel.set()
    engine.emit=emit
    with pytest.raises(PatrolStopped):engine.run(backend)
    state=engine.navigation
    assert state.get('pending')
    engine.cancel.clear()
    resumed=LivePatrol(engine.views,engine.settings,engine.cancel,events.append,checked=engine.checked,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock,navigation=state)
    resumed.run(backend)
    assert resumed.checked=={0,1} and not state.get('pending')


def test_successful_overshoot_measurement_reduces_next_drag_distance():
    engine,backend,events=setup();backend.center=(100.,100.)
    original=backend.drag
    def drag(a,b):
        before=backend.center;original(a,b)
        backend.center=(before[0]-2*(b[0]-a[0])/12.45,before[1]+2*(b[1]-a[1])/12.45)
    backend.drag=drag
    pose=engine.locator.locate(backend.capture())
    engine.pan(backend,backend.capture(),pose,(-100.,0.))
    assert engine.pan_scale==pytest.approx(.5)
    assert engine.navigation['pan_scale']==pytest.approx(.5)


def test_cold_index_preparation_does_not_consume_alignment_deadline():
    engine,backend,events=setup();original=engine.locator.locate
    index=SimpleNamespace(ready=False)
    def prepare():backend.wait(10);index.ready=True
    index.prepare=prepare
    def locate(frame):
        if not index.ready:prepare()
        return original(frame)
    engine.locator=SimpleNamespace(index=index,locate=locate)
    engine.run(backend,auto=False)
    assert engine.checked=={0} and index.ready
    assert any('Preparing map recognition cache' in e.get('message','') for e in events)


def test_recovery_cannot_use_stationary_scenery_outside_the_known_map():
    from pose import Match
    cv2.setNumThreads(2)
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    scenery,_=render(atlas,180.5,186.5)
    # Map corner with no map terrain: persistent background cannot supply anchors.
    empty_corner=Match(12.45,285,500+280*12.45,0,0,[])
    assert track_map_pan(scenery,scenery,empty_corner,(0,0),recovery=True) is None


def test_longer_fixed_drag_holds_through_all_motion_and_releases_at_rest():
    backend=WindowsBackend.__new__(WindowsBackend)
    backend.cancel=threading.Event();backend.down=False;actions=[]
    backend.api=SimpleNamespace(mouse=lambda flag:actions.append(('button',flag)))
    backend.move=lambda point:actions.append(('move',point))
    backend.guard=lambda:None
    backend.wait=lambda seconds:actions.append(('wait',seconds))
    backend.drag((75,500),(495,500))
    assert [value for kind,value in actions if kind=='button']==[2,4]
    assert actions[-3:]==[('move',(495.,500.)),('wait',.18),('button',4)]
    assert sum(kind=='move' for kind,value in actions)==19
    assert sum(value for kind,value in actions if kind=='wait')==pytest.approx(.54)
    assert not backend.down
