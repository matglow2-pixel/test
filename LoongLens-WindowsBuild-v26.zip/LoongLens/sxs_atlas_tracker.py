"""Loong Haven v6 default-zoom absolute calibration.

The reference atlas was stitched from 37 user-provided NORMAL-zoom map screenshots,
registered to the published 280x280 game-coordinate grid.  Matching is read-only:
no interaction with game memory, network, ADB or input.

Only run full matching in a background thread, never the 30FPS movement/display path.
"""
from __future__ import annotations
from pathlib import Path
import cv2
import numpy as np
from pose import Match

PATH = Path(__file__).resolve().parent
RATIO = .29
ATLAS_BGR = cv2.imread(str(PATH / 'loong_haven_default_atlas.png'))
if ATLAS_BGR is None:
    raise FileNotFoundError('Missing loong_haven_default_atlas.png')
ATLAS = cv2.resize(ATLAS_BGR, None, fx=RATIO, fy=RATIO, interpolation=cv2.INTER_AREA)
del ATLAS_BGR
# UI-safe map windows. First succeeds in most scenes; fallbacks cover map edges.
PATCHES = [(65,230,350,320), (35,440,350,350), (140,210,310,390), (85,290,310,365)]
GRID_SCALE = 12.45
MAP_HEIGHT = 280


def _patch_match(frame, box):
    x,y,w,h = box
    block = frame[y:y+h,x:x+w]
    if block.shape[:2] != (h,w):
        return None
    mx=block.max(axis=2).astype(np.int16)
    mn=block.min(axis=2).astype(np.int16)
    active=(mx>93) & (mx-mn>25)
    coverage=float(np.mean(active))
    if coverage<.40:
        return None
    image=cv2.resize(block,None,fx=RATIO,fy=RATIO,interpolation=cv2.INTER_AREA)
    response=cv2.matchTemplate(ATLAS,image,cv2.TM_CCOEFF_NORMED)
    _,score,_,best=cv2.minMaxLoc(response)
    if not np.isfinite(score):
        return None
    bx,by=best
    # A second equally good place far away means the terrain match is ambiguous.
    gap_radius=16
    response[max(0,by-gap_radius):min(response.shape[0],by+gap_radius+1),
             max(0,bx-gap_radius):min(response.shape[1],bx+gap_radius+1)] = -2.
    second=float(cv2.minMaxLoc(response)[1])
    atlas_shift=(np.array(best,dtype=np.float64)/RATIO - np.array([x,y],dtype=np.float64))
    return {'score':float(score),'margin':float(score-second),'shift':atlas_shift,'coverage':coverage}


def align_atlas(frame, previous_scale=None):
    """Absolute map-to-screen pose from the screenshot atlas.

    Requires normal/default zoom (approx. 12.45 pixels per game tile).
    Fail closed rather than inventing positions outside atlas coverage.
    """
    if frame.shape[:2]!=(1029,570):
        frame=cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)
    # Never pretend a different zoom is aligned with the normal-zoom atlas.
    if previous_scale is not None and not (11.8 < previous_scale < 13.1):
        return None
    candidate=[]
    for idx,box in enumerate(PATCHES):
        found=_patch_match(frame,box)
        if found is None:continue
        candidate.append(found)
        score=found['score']; margin=found['margin']
        # Fast path, usually a single ~90ms search.
        if idx==0 and score>=.775 and margin>=.085:
            break
        # A confident result of a fallback patch also finishes early.
        if idx>0 and score>=.78 and margin>=.09:
            break
    if not candidate:return None
    candidate.sort(key=lambda c:c['score'],reverse=True)
    best=candidate[0]
    score=best['score']; margin=best['margin']
    # Independent patches can support a lower-confidence location if they agree.
    agreement=sum(1 for c in candidate if np.linalg.norm(c['shift']-best['shift'])<9.5 and c['score']>=.62)
    valid=(score>=.765 and margin>=.09) or (score>=.69 and agreement>=2 and margin>=.065)
    if not valid:return None
    delta=best['shift']  # atlas_xy = normalized_screen_xy + delta
    tx=-float(delta[0])
    ty=float((MAP_HEIGHT-1)*GRID_SCALE-delta[1])
    return Match(GRID_SCALE,tx,ty,max(1,agreement),max(.3,(1-score)*7),[],
                 f'atlas {score:.3f} ({agreement} checks)')
