"""Default-zoom map alignment from the published portal-coordinate constellation."""
from __future__ import annotations
import json
from pathlib import Path
import cv2
import numpy as np
from pose import Match

DATA=json.loads((Path(__file__).resolve().parent/'loong_haven_map_data.json').read_text('utf-8'))
PORTALS=np.array([[p['position']['x'],p['position']['y']] for p in DATA['portals']],float)

def find_portals(frame):
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,(89,75,65),(110,255,255))
    _,_,stats,centers=cv2.connectedComponentsWithStats(mask)
    h,w=frame.shape[:2]
    result=[]
    for (x,y,pw,ph,area),(cx,cy) in zip(stats[1:],centers[1:]):
        if not(24<area<380 and 6<pw<38 and 6<ph<38 and .55<pw/ph<1.7):continue
        if not(12<cx<w-18 and 35<cy<.90*h):continue
        if cx>.73*w and cy<.23*h:continue
        result.append((cx,cy))
    return np.array(result,float).reshape(-1,2)

def _pairs(scale,tx,ty,observed,radius=6.):
    expected=PORTALS*np.array([scale,-scale])+[tx,ty]
    distances=np.linalg.norm(expected[:,None]-observed[None,:],axis=2)
    near=np.argmin(distances,axis=1)
    order=np.argsort(distances[np.arange(len(PORTALS)),near])
    used=set();pairs=[]
    for world in order:
        screen=int(near[world]);error=float(distances[world,screen])
        if error<=radius and screen not in used:
            used.add(screen);pairs.append((int(world),screen,error))
    return pairs

def align_portals(observed,prior_scale=None):
    observed=np.asarray(observed,float).reshape(-1,2)
    if len(observed)<4 or not np.isfinite(observed).all():return None
    # Fixed-zoom translation hypotheses are much cheaper than arbitrary portal
    # pair permutations. Each accepted fit needs four distinct real markers.
    candidates=[]
    for scale in np.arange(12.05,12.851,.05):
        projected=PORTALS*np.array([scale,-scale])
        shifts=(observed[:,None,:]-projected[None,:,:]).reshape(-1,2)
        expected=projected[None,:,:]+shifts[:,None,:]
        distances=np.linalg.norm(expected[:,:,None,:]-observed[None,None,:,:],axis=3)
        nearest=distances.min(axis=2)
        counts=(nearest<6.).sum(axis=1)
        for index in np.flatnonzero(counts>=4):
            tx,ty=shifts[index]
            pairs=_pairs(scale,tx,ty,observed)
            if len(pairs)<4:continue
            world=PORTALS[[p[0] for p in pairs]]
            screen=observed[[p[1] for p in pairs]]
            n=len(pairs)
            matrix=np.zeros((2*n,3),float)
            matrix[:n,0]=world[:,0];matrix[:n,1]=1
            matrix[n:,0]=-world[:,1];matrix[n:,2]=1
            fitted,*_=np.linalg.lstsq(matrix,np.r_[screen[:,0],screen[:,1]],rcond=None)
            sc,px,py=fitted
            if not 12.05<=sc<=12.85:continue
            refined=_pairs(sc,px,py,observed,radius=4.5)
            if len(refined)<4:continue
            error=float(np.mean([p[2] for p in refined]))
            matched=observed[[p[1] for p in refined]]
            if error>3.2 or np.ptp(matched[:,0])<65 or np.ptp(matched[:,1])<100:continue
            candidate=Match(float(sc),float(px),float(py),len(refined),error,refined,
                            f'portals {len(refined)} anchors · error {error:.1f}px')
            if not any(abs(candidate.tx-c.tx)<8 and abs(candidate.ty-c.ty)<8
                       and abs(candidate.scale-c.scale)<.05 for c in candidates):
                candidates.append(candidate)
    candidates.sort(key=lambda m:(-m.count,m.error))
    if not candidates:return None
    best=candidates[0]
    # Equally supported far-away constellations are ambiguous, not proof.
    for other in candidates[1:]:
        if other.count==best.count and other.error<=best.error+1.2:
            point=np.array(best.project(169,114))-other.project(169,114)
            if np.linalg.norm(point)>20:return None
    return best
