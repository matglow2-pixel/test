"""Fast, general Loong Haven calibration using the extracted world terrain grid.

No OCR templates or zone names needed: compares the visible TERRAIN PATTERN
against the game's 280x280 ground-category bitmap. Original map data came from
an externally published map-viewer export (not a verified client config dump).
No game API, memory read, network traffic, input injection or ADB is used.
"""
from __future__ import annotations
import base64
import json
from pathlib import Path

import cv2
import numpy as np
from pose import Match

BASE=Path(__file__).resolve().parent
WORLD=json.loads((BASE/'loong_haven_terrain.json').read_text('utf-8'))
RAW=np.frombuffer(base64.b64decode(WORLD['ground']),np.uint8).reshape(WORLD['height'],WORLD['width'])
# Screen Y increases downward; world Y increases upward.
# Ground 0 = lighter tiles; 4/5 = darker tiles. Palette varies by biome.
TERRAIN=np.flipud(np.where(RAW==0,1.,np.where((RAW==4)|(RAW==5),-1.,0.))).astype('float32')


def classify_screen(frame):
    """Light/dark terrain in the atlas's green, brown and snow palettes.

    Palette centers come from the most frequent tile colors in the supplied
    atlas; distant colors (icons, text, water, highlights) remain unknown.
    """
    light=np.array([[116,188,156],[100,132,148],[220,212,188]],np.float32)
    dark=np.array([[92,132,76],[68,92,124],[188,164,124]],np.float32)
    palette=np.concatenate([light,dark])
    pixels=frame.astype(np.float32)
    distance=np.stack([np.sum((pixels-color)**2,axis=2) for color in palette])
    closest=np.argmin(distance,axis=0)
    reliable=np.min(distance,axis=0)<=22**2
    out=np.zeros(frame.shape[:2],np.float32)
    out[reliable & (closest<3)]=1.
    out[reliable & (closest>=3)]=-1.
    return out


def _scan_at_scale(categories, scale, grid_step=2.3):
    """Compute best terrain-pattern correlation, across fractional tile phases."""
    height,width=categories.shape
    x_start,x_stop=70,min(414,width-18)
    y_start,y_stop=int(.242*height),int(.791*height)
    xs0=np.arange(x_start+1,x_stop-scale,scale)
    ys0=np.arange(y_start+1,y_stop-scale,scale)
    if len(xs0)<13 or len(ys0)<20:
        return None
    best=None
    for xp in np.arange(1.0,scale,grid_step):
        xs=np.rint(xs0+xp).astype(int)
        if xs[-1]>=width:continue
        for yp in np.arange(1.0,scale,grid_step):
            ys=np.rint(ys0+yp).astype(int)
            if ys[-1]>=height:continue
            patch=categories[np.ix_(ys,xs)]
            if np.count_nonzero(patch)<.44*patch.size:
                continue
            response=cv2.matchTemplate(TERRAIN,patch,cv2.TM_CCORR_NORMED)
            _,score,_,loc=cv2.minMaxLoc(response)
            second_response=response.copy()
            ix,iy=loc
            second_response[max(0,iy-4):iy+5,max(0,ix-4):ix+5]=-1.
            second=float(cv2.minMaxLoc(second_response)[1])
            if not np.isfinite(score) or score-second<.08:
                continue
            if best is None or score>best[0]:
                ix,iy=loc
                # The sample at screen xs[0],ys[0] corresponds to world tile
                # x=ix, y=(height-1-iy), adjusted for +0.5 tile center below.
                tx=float(xs[0]-scale*ix)
                ty=float(ys[0]+scale*(WORLD['height']-1-iy))
                best=(score,Match(float(scale),tx,ty,int(patch.size),
                                 float((1-score)*10),[],f'terrain {score:.3f}'))
    return best


def align_terrain(frame,previous_scale=None):
    """Find map pose over ALL 280x280 tiles. Conservative fail-closed threshold.

    Search only normal zoom (or a close trusted prior). This coarse fallback
    runs off the UI/capture threads; feature and portal fits take priority.
    """
    if frame.shape[:2]!=(1029,570):
        frame=cv2.resize(frame,(570,1029))
    classes=classify_screen(frame)
    normal=12.45
    scales=[float(previous_scale)] if previous_scale and 12.05<=previous_scale<=12.85 else []
    if all(abs(normal-s)>.18 for s in scales):scales.append(normal)
    best=None
    for scale in scales:
        try:r=_scan_at_scale(classes,scale)
        except cv2.error:r=None
        if r is not None and (best is None or r[0]>best[0]):best=r
        if best and best[0]>=.80:break
    # Default zoom only. Reject competing far-away terrain patches using
    # the peak margin stored by _scan_at_scale.
    return best[1] if best and best[0]>=.86 else None
