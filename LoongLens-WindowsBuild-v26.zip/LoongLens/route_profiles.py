"""Named personal routes, with an immutable bundled Default and safe migration."""
import json
from pathlib import Path
import re
import uuid

from patrol_route import load_camera_adjustments,save_camera_adjustments


class RouteProfiles:
    DEFAULT='default'

    def __init__(self,base,folder):
        self.base=tuple(base);self.folder=Path(folder)
        self.index=self.folder/'route-profiles.json'
        self.directory=self.folder/'routes'
        self.profiles=[];self.active=self.DEFAULT
        if self.index.exists():
            document=json.loads(self.index.read_text('utf-8'))
            if not isinstance(document,dict) or document.get('version')!=1 or not isinstance(document.get('profiles'),list):
                raise ValueError('Saved route list has an unsupported format.')
            names={'default'};ids=set()
            for profile in document['profiles']:
                if not isinstance(profile,dict):raise ValueError('Invalid saved route entry.')
                ident,name=profile.get('id'),profile.get('name')
                if not isinstance(ident,str) or not re.fullmatch('[0-9a-f]{32}',ident) or ident in ids:
                    raise ValueError('Saved route IDs must be unique internal IDs.')
                cleaned=self.validate_name(name,names)
                if cleaned!=name:raise ValueError('Invalid saved route name.')
                names.add(name.casefold());ids.add(ident)
                self.profiles.append(dict(id=ident,name=name))
            active=document.get('active')
            if not isinstance(active,str) or (active!=self.DEFAULT and active not in ids):raise ValueError('Selected route is missing from the route list.')
            self.active=active
            self.load(active)  # A broken named route must not silently become Default.
        else:
            legacy=self.folder/'camera-route-adjustments.json'
            if legacy.exists():
                views=load_camera_adjustments(self.base,legacy)
                if views!=self.base:self.save_copy('My route',views)

    @staticmethod
    def validate_name(name,existing):
        if not isinstance(name,str):raise ValueError('Enter a route name.')
        name=name.strip()
        if not name or len(name)>48 or any(ord(c)<32 or ord(c)==127 for c in name):
            raise ValueError('Use a route name with 1–48 visible characters.')
        if name.casefold() in existing:raise ValueError('That route name already exists. Default is reserved.')
        return name

    def items(self):return [(self.DEFAULT,'Default')]+[(p['id'],p['name']) for p in self.profiles]

    def name(self,ident):
        if ident==self.DEFAULT:return 'Default'
        return next(p['name'] for p in self.profiles if p['id']==ident)

    def path(self,ident):
        if ident==self.DEFAULT:raise ValueError('Default is built in and cannot be overwritten. Save a copy.')
        if ident not in {p['id'] for p in self.profiles}:raise ValueError('Unknown saved route.')
        return self.directory/(ident+'.json')

    def load(self,ident):
        if ident==self.DEFAULT:return self.base
        path=self.path(ident)
        if not path.is_file():raise ValueError('This saved route file is missing.')
        return load_camera_adjustments(self.base,path)

    def _write_index(self,profiles,active):
        self.folder.mkdir(parents=True,exist_ok=True)
        temporary=self.index.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(dict(version=1,active=active,profiles=profiles),indent=2)+'\n','utf-8')
        temporary.replace(self.index)

    def save_copy(self,name,views):
        name=self.validate_name(name,{label.casefold() for _,label in self.items()})
        self.directory.mkdir(parents=True,exist_ok=True)
        ident=uuid.uuid4().hex;path=self.directory/(ident+'.json')
        while path.exists():ident=uuid.uuid4().hex;path=self.directory/(ident+'.json')
        save_camera_adjustments(self.base,views,path)
        profiles=self.profiles+[dict(id=ident,name=name)]
        try:self._write_index(profiles,ident)
        except OSError:
            path.unlink();raise
        self.profiles=profiles;self.active=ident
        return ident

    def save(self,ident,views):
        save_camera_adjustments(self.base,views,self.path(ident))

    def activate(self,ident):
        views=self.load(ident)
        self._write_index(self.profiles,ident)
        self.active=ident
        return views
