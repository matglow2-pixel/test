"""Shared desktop styling and small layout helpers; no application state."""
import os
from tkinter import ttk

FONT = 'Segoe UI' if os.name == 'nt' else 'Helvetica'

BG = '#101620'
CARD = '#182332'
TEXT = '#e6edf6'
MUTED = '#9aacbf'
ACCENT = '#70dfca'


def apply_theme(root):
    style = ttk.Style(root)
    style.theme_use('clam')
    style.configure('.', background=BG, foreground=TEXT, font=(FONT, 10))
    style.configure('TFrame', background=BG)
    style.configure('TLabel', background=BG)
    style.configure('Muted.TLabel', foreground=MUTED)
    style.configure('Title.TLabel', font=(FONT, 22, 'bold'))
    style.configure('Brand.TLabel', font=(FONT, 12, 'bold'))
    style.configure('Card.TFrame', background=CARD)
    style.configure('Card.TLabel', background=CARD)
    style.configure('CardMuted.TLabel', background=CARD, foreground=MUTED, font=(FONT, 9))
    style.configure('CardTitle.TLabel', background=CARD, foreground=ACCENT, font=(FONT, 10, 'bold'))
    style.configure('Status.TLabel', background=CARD, font=(FONT, 11, 'bold'))
    style.configure('Alert.TLabel', background=CARD, foreground='#f486dd')
    style.configure('Stats.TLabel', background=CARD, font=(FONT, 11, 'bold'))
    style.configure('TButton', background='#28394d', foreground=TEXT, borderwidth=0, padding=(12, 9))
    style.map('TButton', background=[('disabled', '#202b39'), ('pressed', '#354d66'), ('active', '#354d66')],
              foreground=[('disabled', '#718195')])
    style.configure('Primary.TButton', background=ACCENT, foreground='#102c29', font=(FONT, 10, 'bold'))
    style.map('Primary.TButton', background=[('disabled', '#263d3e'), ('active', '#94ebdb')],
              foreground=[('disabled', '#7a9596'), ('active', '#102c29')])
    style.configure('Stop.TButton', background='#523143', foreground='#ffdce7')
    style.map('Stop.TButton', background=[('active', '#704157')])
    for prefix, bg in (('', BG), ('Card.', CARD)):
        style.configure(prefix+'TCheckbutton', background=bg, padding=(0, 4))
        style.map(prefix+'TCheckbutton', background=[('active', bg)], foreground=[('disabled', '#718195')])
    style.configure('TEntry', fieldbackground='#233348', foreground=TEXT, insertcolor=TEXT, padding=5)
    style.configure('TCombobox', fieldbackground='#233348', background='#28394d', foreground=TEXT, padding=4)
    style.map('TCombobox', fieldbackground=[('readonly', '#233348')], foreground=[('readonly', TEXT)],
              selectbackground=[('readonly', '#233348')], selectforeground=[('readonly', TEXT)])
    root.option_add('*TCombobox*Listbox.background', '#233348')
    root.option_add('*TCombobox*Listbox.foreground', TEXT)
    style.configure('Treeview', background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=30, borderwidth=0)
    style.configure('Treeview.Heading', background='#28394d', foreground=TEXT, padding=(8, 7), relief='flat')
    style.map('Treeview', background=[('selected', '#35516b')], foreground=[('selected', '#ffffff')])
    style.configure('Horizontal.TScale', troughcolor='#28394d', background=ACCENT, borderwidth=0)
    style.configure('TNotebook', background=BG, borderwidth=0, tabmargins=(14, 0, 14, 0))
    style.configure('TNotebook.Tab', background=BG, foreground=MUTED, padding=(17, 12), borderwidth=0)
    style.map('TNotebook.Tab', background=[('selected', '#26384b')], foreground=[('selected', TEXT)])
    style.configure('Horizontal.TProgressbar', background=ACCENT, troughcolor='#28394d', borderwidth=0, lightcolor=ACCENT, darkcolor=ACCENT)
    style.configure('TSeparator', background='#2a394b')
    return style


def heading(parent, title, description):
    ttk.Label(parent, text=title, style='Title.TLabel').pack(anchor='w')
    ttk.Label(parent, text=description, style='Muted.TLabel', wraplength=470).pack(anchor='w', pady=(3, 14))


def card(parent, title=None):
    frame = ttk.Frame(parent, style='Card.TFrame', padding=12)
    frame.pack(fill='x', pady=(0, 8))
    if title:
        ttk.Label(frame, text=title, style='CardTitle.TLabel').pack(anchor='w', pady=(0, 7))
    return frame


def row(parent):
    frame = ttk.Frame(parent, style='Card.TFrame')
    frame.pack(fill='x')
    return frame
