"""Manual pickup controls. Seeing or losing a gem never records a pickup."""
from __future__ import annotations
import math
import sqlite3
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from pickup_history import nearby_markers


def coordinate(value):
    return f'{value:g}'


class PickupControls:
    def __init__(self, root, history, store, on_change, default_minutes=30):
        self.root = root
        self.history = history
        self.store = store
        self.on_change = on_change
        self.default_minutes = default_minutes
        self.markers = history.latest_locations()
        self.summary = tk.StringVar(root)
        self.collect_window = None
        self.history_window = None
        self.rows = []
        self.tree = None
        self.last_refresh = 0.
        self.refresh(force=True)

    def refresh(self, force=False, now=None):
        now = time.time() if now is None else now
        if not force and time.monotonic() - self.last_refresh < 1:
            return
        self.last_refresh = time.monotonic()
        if force:
            self.markers = self.history.latest_locations()
            self.rows = self.history.list(limit=1000)
        self.summary.set(f'Pickups today: {self.history.today_count(now)} · manual log')
        if self.tree is not None and self.tree.winfo_exists():
            existing = set(self.tree.get_children())
            wanted = {str(p.id) for p in self.rows}
            for removed in existing - wanted:
                self.tree.delete(removed)
            for index, pickup in enumerate(self.rows):
                values = (pickup.local_time, coordinate(pickup.x), coordinate(pickup.y),
                          f'{coordinate(pickup.marker_x)}, {coordinate(pickup.marker_y)}',
                          pickup.label(now), f'{pickup.timer_minutes} min', pickup.note)
                key = str(pickup.id)
                if key in existing:
                    self.tree.item(key, values=values)
                else:
                    self.tree.insert('', index, iid=key, values=values)
                self.tree.move(key, '', index)

    def changed(self):
        self.refresh(force=True)
        self.on_change()

    def show_collect(self):
        if self.collect_window is not None and self.collect_window.winfo_exists():
            self.collect_window.lift()
            return
        window = self.collect_window = tk.Toplevel(self.root)
        window.title('Mark gem collected')
        window.transient(self.root)
        window.resizable(False, False)
        body = ttk.Frame(window, padding=20)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='Record a gem you have picked up', font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        ttk.Label(body, text="Enter the pickup X,Y shown by the game's minimap.\nThis window stays open while you check the game.",
                  style='Muted.TLabel').pack(anchor='w', pady=(6, 12))
        grid = ttk.Frame(body)
        grid.pack(fill='x')
        x = tk.StringVar(window)
        y = tk.StringVar(window)
        minutes = tk.StringVar(window, value=str(self.default_minutes))
        ago = tk.StringVar(window, value='0')
        fields = [('Pickup X', x), ('Pickup Y', y), ('Check after (minutes)', minutes), ('Picked up minutes ago', ago)]
        entries = []
        for row, (label, variable) in enumerate(fields):
            ttk.Label(grid, text=label).grid(row=row, column=0, sticky='w', pady=4, padx=(0, 12))
            entry = ttk.Entry(grid, textvariable=variable, width=20)
            entry.grid(row=row, column=1, sticky='ew', pady=4)
            entries.append(entry)
        ttk.Label(body, text='Timer marker on the large map').pack(anchor='w', pady=(12, 4))
        selected = tk.StringVar(window, value='At entered coordinates')
        combo = ttk.Combobox(body, textvariable=selected, state='readonly', width=48,
                             values=['At entered coordinates'])
        combo.pack(fill='x')
        choices = {'At entered coordinates': None}

        def update_choices(*_):
            choices.clear()
            choices['At entered coordinates'] = None
            try:
                points = nearby_markers(float(x.get()), float(y.get()), self.store.points['gems'])
            except ValueError:
                points = []
            for mx, my, distance in points:
                label = f'Known dot ({coordinate(mx)}, {coordinate(my)}) · {distance:.1f} tiles away'
                choices[label] = (mx, my)
            combo.configure(values=list(choices))
            recommended = next((label for label, anchor in choices.items() if anchor is not None), None)
            selected.set(recommended if points and points[0][2] <= 10 else 'At entered coordinates')

        x.trace_add('write', update_choices)
        y.trace_add('write', update_choices)
        ttk.Label(body, text='Defaults to the nearest known dot within 10 tiles.\nChoose the right dot, or keep the entered position.',
                  style='Muted.TLabel').pack(anchor='w', pady=(5, 10))
        ttk.Label(body, text='Note (optional)').pack(anchor='w')
        note = tk.StringVar(window)
        ttk.Entry(body, textvariable=note).pack(fill='x', pady=(4, 10))
        error = tk.StringVar(window)
        ttk.Label(body, textvariable=error, foreground='#ffaaaa', wraplength=390).pack(anchor='w')
        ttk.Label(body, text='The countdown is a reminder to check, not a confirmed respawn.',
                  style='Muted.TLabel', wraplength=390).pack(anchor='w', pady=(6, 10))

        def save():
            try:
                elapsed = float(ago.get())
                if not math.isfinite(elapsed) or not 0 <= elapsed <= 1440:
                    raise ValueError('Minutes ago must be between 0 and 1440.')
                anchor = choices.get(selected.get())
                self.history.record(x.get(), y.get(), minutes.get(),
                                    collected_at=time.time() - elapsed * 60, note=note.get(), anchor=anchor)
                self.default_minutes = int(float(minutes.get()))
                self.changed()
            except (ValueError, OSError, sqlite3.Error) as exc:
                error.set(str(exc))
                return
            window.destroy()

        buttons = ttk.Frame(body)
        buttons.pack(fill='x')
        ttk.Button(buttons, text='Mark collected', command=save).pack(side='left')
        ttk.Button(buttons, text='Cancel', command=window.destroy).pack(side='right')
        window.bind('<Escape>', lambda _: window.destroy())
        entries[0].focus_set()

    def show_history(self):
        if self.history_window is not None and self.history_window.winfo_exists():
            self.history_window.lift()
            return
        window = self.history_window = tk.Toplevel(self.root)
        window.title('Gem pickup history')
        window.transient(self.root)
        window.geometry('940x420')
        window.minsize(650, 300)
        body = ttk.Frame(window, padding=16)
        body.pack(fill='both', expand=True)
        ttk.Label(body, textvariable=self.summary, font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        ttk.Label(body, text='Newest 1,000 pickups shown · Export saves the entire history · Times use your PC clock',
                  style='Muted.TLabel', wraplength=850).pack(anchor='w', pady=(5, 12))
        table = ttk.Frame(body)
        table.pack(fill='both', expand=True)
        columns = ('time', 'x', 'y', 'marker', 'remaining', 'duration', 'note')
        self.tree = ttk.Treeview(table, columns=columns, show='headings', selectmode='browse')
        headings = [('time', 'Collected (local time)', 168), ('x', 'X', 50), ('y', 'Y', 50),
                    ('marker', 'Timer dot X,Y', 100), ('remaining', 'Check in', 80),
                    ('duration', 'Reminder', 85), ('note', 'Note', 240)]
        for name, label, width in headings:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=width, minwidth=40, stretch=name == 'note')
        vertical = ttk.Scrollbar(table, orient='vertical', command=self.tree.yview)
        horizontal = ttk.Scrollbar(table, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.tree.grid(row=0, column=0, sticky='nsew')
        vertical.grid(row=0, column=1, sticky='ns')
        horizontal.grid(row=1, column=0, sticky='ew')
        table.rowconfigure(0, weight=1)
        table.columnconfigure(0, weight=1)
        buttons = ttk.Frame(body)
        buttons.pack(fill='x', pady=(12, 0))
        ttk.Button(buttons, text='Export history CSV', command=self.export).pack(side='left')
        ttk.Button(buttons, text='Remove selected', command=self.remove_selected).pack(side='left', padx=8)
        ttk.Button(buttons, text='Close', command=window.destroy).pack(side='right')
        self.refresh(force=True)

    def remove_selected(self):
        selection = self.tree.selection()
        if not selection:
            return
        try:
            self.history.remove(int(selection[0]))
            self.changed()
        except sqlite3.Error as exc:
            messagebox.showerror('Could not remove pickup', str(exc), parent=self.history_window)

    def export(self):
        path = filedialog.asksaveasfilename(parent=self.history_window, title='Export pickup history',
                                          initialfile='LoongLens-pickups.csv', defaultextension='.csv',
                                          filetypes=[('CSV', '*.csv')])
        if not path:
            return
        try:
            self.history.export_csv(path)
        except (OSError, sqlite3.Error) as exc:
            messagebox.showerror('Could not export history', str(exc), parent=self.history_window)
            return
        messagebox.showinfo('History exported', f'Saved pickup history to:\n{path}', parent=self.history_window)
