@echo off
setlocal
cd /d "%~dp0"
call "%~dp0RUN_LOONG_LENS.bat" --tab watch
exit /b %errorlevel%
