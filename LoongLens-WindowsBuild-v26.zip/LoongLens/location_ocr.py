"""Read the zone/coordinate badge beneath the minimap using offline PP-OCRv4."""
from dataclasses import dataclass
import math
from pathlib import Path
import re

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class TextLine:
    text: str
    score: float
    bounds: tuple  # left, top, right, bottom in the OCR crop


@dataclass(frozen=True)
class Location:
    zone: str
    x: int
    y: int


def parse_location(lines):
    """Require a numeric pair and a nearby readable name directly above it."""
    candidates = []
    for numbers in lines:
        if numbers.score < .8:
            continue
        text = numbers.text.strip().translate(str.maketrans({'O': '0', 'o': '0', '|': '1'}))
        found = re.fullmatch(r'[\(\[（]?\s*(\d{1,3})\s*[,，.]\s*(\d{1,3})\s*[\)\]）]?', text)
        if not found:
            continue
        x, y = map(int, found.groups())
        if not (0 <= x < 280 and 0 <= y < 280):
            continue
        left, top, right, bottom = numbers.bounds
        height = max(1, bottom-top)
        center = (left+right)/2
        above = []
        for name in lines:
            if name is numbers or name.score < .8 or not re.search(r'[A-Za-z]{3}', name.text):
                continue
            nl, nt, nr, nb = name.bounds
            if not -height*.3 <= top-nb <= height*3:
                continue
            if abs((nl+nr)/2-center) > max(right-left, nr-nl)*.4:
                continue
            zone = re.sub(r'\s+', ' ', name.text).strip()
            if zone.casefold() == 'lronpeak':
                zone = 'Ironpeak'
            if len(zone) > 55 or not re.fullmatch(r"[A-Za-z0-9 '’\-]+", zone):
                continue
            if re.fullmatch(r'Loong\s*Haven', zone, re.IGNORECASE):
                continue  # A dropped Roman suffix is an incomplete zone name.
            roman = re.fullmatch(r'Loong\s*Haven\s*([IVXil1|]+)', zone, re.IGNORECASE)
            if roman:
                suffix = roman.group(1).upper().replace('L', 'I').replace('1', 'I').replace('|', 'I')
                valid = ('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV','XV','XVI','XVII','XVIII')
                if suffix not in valid:
                    continue
                zone = 'Loong Haven ' + suffix
            above.append((abs(top-nb), -name.score, zone))
        if above:
            zone = min(above)[2]
            candidates.append((numbers.score, Location(zone, x, y)))
    if not candidates:
        return None
    locations = {(loc.zone, loc.x, loc.y) for _, loc in candidates}
    # Ambiguous badges must not silently choose somebody else's coordinates.
    return max(candidates, key=lambda item: item[0])[1] if len(locations) == 1 else None


class LocationReader:
    def __init__(self):
        self.detector = None
        self.recognizer = None

    def prepare(self):
        if self.detector is not None:
            return
        import onnxruntime as ort
        options = ort.SessionOptions()
        options.intra_op_num_threads = 2
        options.inter_op_num_threads = 1
        options.log_severity_level = 3
        detector = ort.InferenceSession(str(ROOT/'ocr_models/ch_PP-OCRv4_det_infer.onnx'),
            sess_options=options, providers=['CPUExecutionProvider'])
        recognizer = ort.InferenceSession(str(ROOT/'ocr_models/ch_PP-OCRv4_rec_infer.onnx'),
            sess_options=options, providers=['CPUExecutionProvider'])
        characters = recognizer.get_modelmeta().custom_metadata_map['character'].splitlines()
        self.characters = ['blank'] + characters + [' ']
        self.detector, self.recognizer = detector, recognizer

    def read(self, frame):
        lines = self.read_lines(frame)
        return parse_location(lines)

    def read_lines(self, frame):
        self.prepare()
        h, w = frame.shape[:2]
        crop = frame[round(h*.05):round(h*.43), round(w*.48):w]
        if min(crop.shape[:2]) < 20:
            return []
        scale = min(2., 960/max(crop.shape[:2]))
        dh = max(32, round(crop.shape[0]*scale/32)*32)
        dw = max(32, round(crop.shape[1]*scale/32)*32)
        image = cv2.resize(crop, (dw, dh), interpolation=cv2.INTER_CUBIC)
        normalized = image.astype(np.float32)/255
        normalized = (normalized-[.485,.456,.406])/[.229,.224,.225]
        input_name = self.detector.get_inputs()[0].name
        probability = self.detector.run(None, {input_name: normalized.transpose(2,0,1)[None].astype(np.float32)})[0][0,0]
        contours, _ = cv2.findContours((probability>.3).astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        rectangles = []
        for contour in contours:
            rect = cv2.minAreaRect(contour)
            (cx, cy), (bw, bh), angle = rect
            if min(bw, bh) < 4 or max(bw, bh) < 12:
                continue
            mask = np.zeros(probability.shape, np.uint8)
            cv2.fillPoly(mask, [contour], 1)
            if cv2.mean(probability, mask)[0] < .55:
                continue
            expand = bw*bh*1.5/(2*(bw+bh))
            points = cv2.boxPoints(((cx,cy),(bw+expand*2,bh+expand*2),angle))
            points *= [dw/probability.shape[1], dh/probability.shape[0]]
            points[:,0] = points[:,0].clip(0,dw-1)
            points[:,1] = points[:,1].clip(0,dh-1)
            rectangles.append((float(points[:,0].min()),float(points[:,1].min()),
                               float(points[:,0].max()),float(points[:,1].max())))
        # Detection can split narrow Roman suffixes into their own box. Join
        # nearby fragments on the same baseline before recognition, preserving
        # the full zone name rather than treating 'Loong Haven' as complete.
        grouped = []
        for bounds in sorted(rectangles,key=lambda b:b[0]):
            left,top,right,bottom = bounds
            for index,(gl,gt,gr,gb) in enumerate(grouped):
                height=max(bottom-top,gb-gt)
                overlap=min(bottom,gb)-max(top,gt)
                if (abs((top+bottom-gt-gb)/2)<height*.35
                        and overlap>=min(bottom-top,gb-gt)*.6
                        and left-gr<height*1.2):
                    grouped[index]=(min(left,gl),min(top,gt),max(right,gr),max(bottom,gb))
                    break
            else:
                grouped.append(bounds)
        lines = []
        for bounds in grouped:
            left,top,right,bottom = bounds
            width, height = right-left, bottom-top
            if height > width*1.5 or width/height > 28:
                continue
            text_image=image[max(0,int(top)):min(dh,math.ceil(bottom)),max(0,int(left)):min(dw,math.ceil(right))]
            if not text_image.size:
                continue
            text, score = self.recognize(text_image)
            if re.match(r'^Loong\s*Haven',text,re.IGNORECASE):
                # Very narrow Roman strokes can be missed by detection
                # entirely. Read the pixels immediately after the name as
                # well; do not infer a suffix from a reference coordinate.
                extended_right=min(dw,math.ceil(right+height*2))
                extended=image[max(0,int(top)):min(dh,math.ceil(bottom)),max(0,int(left)):extended_right]
                full_text, full_score=self.recognize(extended)
                if re.fullmatch(r'Loong\s*Haven\s*[IVXil1|]+',full_text,re.IGNORECASE) and full_score>=.8:
                    text, score=full_text, full_score
            if text:
                lines.append(TextLine(text,score,bounds))
        return lines

    def recognize(self, image):
        width = min(1024, max(1, math.ceil(48*image.shape[1]/image.shape[0])))
        resized = cv2.resize(image,(width,48)).astype(np.float32).transpose(2,0,1)/127.5-1
        padded = np.zeros((1,3,48,max(320,width)),np.float32)
        padded[0,:,:,:width] = resized
        output = self.recognizer.run(None,{self.recognizer.get_inputs()[0].name:padded})[0][0]
        indices = output.argmax(axis=1)
        scores = output.max(axis=1)
        text, confidence = [], []
        previous = None
        for index, score in zip(indices,scores):
            if index and index != previous and index < len(self.characters):
                text.append(self.characters[index]); confidence.append(float(score))
            previous = index
        return ''.join(text), float(np.mean(confidence)) if confidence else 0.
