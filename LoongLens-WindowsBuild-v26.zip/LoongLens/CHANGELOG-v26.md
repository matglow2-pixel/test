# v26 — v24 baseline, shorter personal routes and faster map handling

This release starts from v24. It uses the original Windows mouse input and
desktop screenshot capture; the v25 ADB backend is not included. Keep
BlueStacks visible and focused during Gem Sniping.

## Saved routes

**Edit route → Run route** selects the route that Gem Sniping will run. The
built-in **Default** is protected. Use **Save as…** to name a variant such as
**Busy zones**, edit/remove its targets and save. Unsaved changes are protected
when switching the editor dropdown. A route selector and Save copy button are
also available on the main Gem Sniping tab.

Each named route retains its own camera positions, extra views and removals.
The selected route persists across app restarts. Changing routes stops any
active sniping, waits for input to be released, and resets pass progress, timing
and find counters. Existing saved v24 edits are imported as **My route** without
changing the original `camera-route-adjustments.json`. History is shared and kept.

## Remove camera points

In Edit route, select a target and use **Remove selected**. This works for
original targets and added extra views. Removed targets are skipped in both
single and repeating passes, with the order and original IDs of the remaining
points preserved. At least one target must remain.

**Undo remove** restores a removal while the editor is open. **Restore
originals** reinstates omitted original targets at their default coordinates,
retaining surviving target adjustments and extra views. **Reset route to
defaults** restores the complete default route and removes all extras.
The default exclusions (#26, #51 and #72) remain excluded.

Removing an original target keeps its extra views. Those extras still run and
can have more extra views added after them. Remove them separately if you want
to skip their inspections too. Spawn coordinates in the original map/history
database are not deleted. The editor and Sniping panel show how many listed
spawn spots are omitted from the personal route. A shorter route may inspect
fewer locations; it is not equivalent to covering all default spawn spots.

Use **Save & reset checks** to apply the route and clear old pass progress and
timing. Existing v24 adjustments and extras load automatically as My route.
Named profiles live under `%LOCALAPPDATA%\LoongLens\routes`; the selection/list
is in `route-profiles.json`. Profiles with removed originals use format version
3. The first such save preserves an existing v1/v2 named profile as a
`.pre-v26.json` sibling. That backup is not overwritten. Routes without removed
originals continue using version 2, and the original v24 route file is retained.

## Speed changes

- Reuse the just-opened map screenshot for the first alignment observation.
- Confirm an already recognized map pose against a fresh, nearly unchanged
  textured frame, avoiding repeated feature extraction. Moving or flat frames
  still use full recognition. Two observations remain required, and a fresh
  pre-click screenshot still checks for movement.
- Avoid an immediate duplicate closed-map screenshot when selection closes
  the map automatically.
- Cap the final inspection polling wait at the configured deadline instead
  of adding an unnecessary full polling interval.
- Show **Last view**, **Map/load** and **Inspect** times for comparison on your PC.

The default 0.5-second loading wait, 1.2-second empty-view inspection window,
three-sighting/0.8-second gem confirmation and late-candidate extension are
unchanged. Focus, obstruction, alignment, portal and F10 guards remain. This
release does not claim measured live-game speed or detector accuracy on your PC.

`tools/benchmark_sniping.py` verifies all 76 default camera selections against
independent atlas geometry and reports screenshot/matching counts and timing.
It uses real atlas pixels with simulated input, loading and empty detection.
The complete download includes the Windows comparison under `validation/`;
those numbers are not a live BlueStacks pass.

## Install

Exit the old app completely, extract the complete folder and launch its new
`LoongLens.exe`. Settings, screenshots and history stay in
`%LOCALAPPDATA%\LoongLens`; do not delete that directory. The complete 7z contains
the EXE, source, assets, OCR models, launchers, tests, tools and validation reports.
