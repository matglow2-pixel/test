"""Real Windows mouse input, scoped to the selected foreground BlueStacks window."""
from __future__ import annotations
import ctypes
from ctypes import wintypes
import threading
import time
import math
import numpy as np


class PatrolStopped(RuntimeError):
    pass


class NativeInput:
    def __init__(self):
        self.user=ctypes.WinDLL('user32',use_last_error=True)
        ULONG_PTR=ctypes.c_size_t
        class Mouse(ctypes.Structure):
            _fields_=[('dx',wintypes.LONG),('dy',wintypes.LONG),('mouseData',wintypes.DWORD),
                      ('dwFlags',wintypes.DWORD),('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
        class Keyboard(ctypes.Structure):
            _fields_=[('wVk',wintypes.WORD),('wScan',wintypes.WORD),('dwFlags',wintypes.DWORD),
                      ('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
        class Hardware(ctypes.Structure):
            _fields_=[('uMsg',wintypes.DWORD),('wParamL',wintypes.WORD),('wParamH',wintypes.WORD)]
        class Payload(ctypes.Union):
            _fields_=[('mi',Mouse),('ki',Keyboard),('hi',Hardware)]
        class Input(ctypes.Structure):
            _anonymous_=('data',)
            _fields_=[('type',wintypes.DWORD),('data',Payload)]
        self.Input=Input
        self.user.SendInput.argtypes=[wintypes.UINT,ctypes.POINTER(Input),ctypes.c_int]
        self.user.SendInput.restype=wintypes.UINT
        self.user.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int]
        self.user.SetCursorPos.restype=wintypes.BOOL
        self.user.GetForegroundWindow.restype=wintypes.HWND
        self.user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT]
        self.user.GetAncestor.restype=wintypes.HWND
        self.user.SetForegroundWindow.argtypes=[wintypes.HWND]
        self.user.SetForegroundWindow.restype=wintypes.BOOL
        self.user.GetWindowRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
        self.user.GetWindowRect.restype=wintypes.BOOL

    def mouse(self,flags):
        event=self.Input();event.type=0;event.mi.dwFlags=flags
        if self.user.SendInput(1,ctypes.byref(event),ctypes.sizeof(event))!=1:
            raise OSError('Windows refused mouse input. Run Loong Lens and BlueStacks at the same privilege level.')

    def key(self,vk,up=False):
        event=self.Input();event.type=1;event.ki.wVk=vk;event.ki.dwFlags=2 if up else 0
        if self.user.SendInput(1,ctypes.byref(event),ctypes.sizeof(event))!=1:
            raise OSError('Windows refused the keyboard input test.')


class WindowsBackend:
    def __init__(self,cancel,find=None):
        from win_overlay import find_visible_emulator,window_visible_at
        self.find=find or find_visible_emulator
        self.visible_at=window_visible_at
        self.cancel=cancel;self.api=NativeInput();self.target=None;self.screen=None
        self.down=False

    def __enter__(self):
        import mss
        self.screen=mss.mss();return self

    def __exit__(self,*args):
        self.release()
        if self.screen is not None:self.screen.close()

    def wait(self,seconds):
        if self.cancel.wait(seconds):raise PatrolStopped('Stopped.')

    def focus(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        self.target=self.find()
        if self.target is None:raise RuntimeError('BlueStacks was not found. Keep its window visible.')
        hwnd,_=self.target
        self.api.user.SetForegroundWindow(hwnd)
        self.wait(.25)
        self.guard()

    def guard(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')
        hwnd,rect=self.target
        current=wintypes.RECT()
        if not self.api.user.GetWindowRect(hwnd,ctypes.byref(current)):
            raise RuntimeError('BlueStacks was closed.')
        bounds=(current.left,current.top,current.right-current.left,current.bottom-current.top)
        if bounds!=tuple(rect):raise RuntimeError('BlueStacks moved or resized. Start the check again.')
        active=self.api.user.GetAncestor(self.api.user.GetForegroundWindow(),2)
        if active!=hwnd:raise RuntimeError('BlueStacks lost focus; patrol stopped.')

    def point(self,reference):
        rx,ry=reference
        if not (math.isfinite(rx) and math.isfinite(ry) and 0<=rx<570 and 0<=ry<1029):
            raise ValueError('Input point is outside the BlueStacks screenshot.')
        x,y,w,h=self.target[1]
        return round(x+rx*w/570),round(y+ry*h/1029)

    def move(self,reference):
        self.guard();point=self.point(reference)
        if not self.visible_at(self.target[0],*point):raise RuntimeError('Another window covers the click point.')
        if not self.api.user.SetCursorPos(*point):raise OSError('Windows could not move the mouse.')
        self.guard()

    def release(self):
        if self.down:
            try:self.api.mouse(0x0004)
            finally:self.down=False

    def click(self,reference):
        self.move(reference)
        try:
            self.guard();self.down=True;self.api.mouse(0x0002);self.wait(.05)
        finally:self.release()

    def drag(self,start,end):
        self.move(start)
        try:
            self.guard();self.down=True;self.api.mouse(0x0002)
            steps=max(4,min(18,math.ceil(math.dist(start,end)/24)))
            for i in range(1,steps+1):
                self.wait(.02)
                self.move((start[0]+(end[0]-start[0])*i/steps,start[1]+(end[1]-start[1])*i/steps))
            # Release from a stationary endpoint, rather than a moving swipe.
            # This prevents the game's fling/inertia from carrying the map on.
            self.wait(.18)
        finally:self.release()

    def capture(self):
        self.guard()
        hwnd,(x,y,w,h)=self.target
        # No other desktop window may contribute pixels to detection/history.
        if not all(self.visible_at(hwnd,x+px,y+py)
                   for py in np.linspace(10,h-11,max(2,(h+47)//48))
                   for px in np.linspace(10,w-11,max(2,(w+47)//48))):
            raise RuntimeError('BlueStacks is covered. Move Loong Lens and other windows aside.')
        return np.asarray(self.screen.grab(dict(left=x,top=y,width=w,height=h)))[:,:,:3].copy()

    @staticmethod
    def peek():
        """A calibration screenshot; no focus changes or inputs."""
        import mss
        from win_overlay import find_visible_emulator
        target=find_visible_emulator()
        if target is None:raise RuntimeError('Keep BlueStacks visible first.')
        _,(x,y,w,h)=target
        with mss.mss() as screen:
            return np.asarray(screen.grab(dict(left=x,top=y,width=w,height=h)))[:,:,:3].copy()


class GlobalPatrolKeys:
    """Register only while live controls are enabled; stop callback is immediate."""
    def __init__(self,advance,stop,key='F8'):
        self.advance=advance;self.stop=stop;self.key=key
        self.ready=threading.Event();self.thread_id=None;self.error=None
        self.thread=threading.Thread(target=self._run,daemon=True,name='LoongLens-hotkeys')
        self.thread.start()
        if not self.ready.wait(3):raise RuntimeError('Could not start the global hotkeys.')
        if self.error:raise RuntimeError(self.error)

    def _run(self):
        user=ctypes.WinDLL('user32',use_last_error=True)
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.thread_id=kernel.GetCurrentThreadId()
        # Create the message queue before another thread can request shutdown.
        msg=wintypes.MSG();user.PeekMessageW(ctypes.byref(msg),None,0,0,0)
        registered=[]
        try:
            for ident,vk in ((1,0x79),(2,0x70+int(self.key[1:])-1)):
                if not user.RegisterHotKey(None,ident,0x4000,vk):
                    raise RuntimeError(f'{"F10" if ident==1 else self.key} is already in use. Choose another advance key or close the conflicting app.')
                registered.append(ident)
            self.ready.set()
            while user.GetMessageW(ctypes.byref(msg),None,0,0)>0:
                if msg.message==0x0312:
                    (self.stop if msg.wParam==1 else self.advance)()
        except Exception as exc:self.error=str(exc)
        finally:
            self.ready.set()
            for ident in registered:user.UnregisterHotKey(None,ident)

    def close(self):
        if self.thread_id:
            ctypes.WinDLL('user32',use_last_error=True).PostThreadMessageW(self.thread_id,0x0012,0,0)
        self.thread.join(timeout=2)
