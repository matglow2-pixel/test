"""Offline map data, validated personal coordinates, and cached overlay drawing."""
from __future__ import annotations
import csv
import json
import math
import os
import time
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
REF_W, REF_H = 570, 1029
MAP_BOTTOM = 938  # Keep terrain above the current bottom navigation visible.
COLORS = {'gems': (244, 91, 208), 'common': (164, 244, 117),
          'rare': (65, 196, 255), 'epic': (255, 173, 42)}
TIERS = tuple(COLORS)
SIGHTING_COLOR = (103, 239, 211)

def user_dir():
    base = os.environ.get('LOCALAPPDATA') if os.name == 'nt' else os.environ.get('XDG_CACHE_HOME')
    return Path(base or Path.home() / '.cache') / 'LoongLens'

def load_coordinates(path):
    """Reject malformed imports as a whole; never silently accept bad locations."""
    result = {tier: [] for tier in TIERS}
    seen = set()
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        if not {'tier', 'x', 'y'}.issubset(reader.fieldnames or []):
            raise ValueError('CSV needs tier,x,y,label columns (label is optional).')
        for line, row in enumerate(reader, 2):
            if not any(row.values()):
                continue
            try:
                tier = row['tier'].strip().lower()
                x, y = float(row['x']), float(row['y'])
                if tier not in TIERS or not all(math.isfinite(v) and 0 <= v < 280 for v in (x, y)):
                    raise ValueError()
            except (ValueError, TypeError, KeyError):
                raise ValueError(f'Invalid coordinate on line {line}; use gems/common/rare/epic and x,y from 0 to 279.') from None
            key = tier, x, y
            if key not in seen:
                result[tier].append({'x': x, 'y': y, 'label': (row.get('label') or '').strip()})
                seen.add(key)
    return result

class ResourceStore:
    def __init__(self, custom_path=None):
        self.data = json.loads((ROOT / 'loong_haven_map_data.json').read_text('utf-8'))
        self.ingredients = json.loads((ROOT / 'loong_haven_ingredients.json').read_text('utf-8'))
        self.custom = {tier: [] for tier in TIERS}
        if custom_path and Path(custom_path).exists():
            self.custom = load_coordinates(custom_path)
        self.points = {}
        self.areas = {}
        for tier in TIERS:
            rows = ([item['position'] for item in self.data['gems']] if tier == 'gems'
                    else self.ingredients[tier]['points'])
            # Deduplicate personal coordinates against bundled data as well.
            coordinates = sorted({(float(p['x']) + .5, float(p['y']) + .5)
                                  for p in rows + self.custom[tier]})
            self.points[tier] = np.asarray(coordinates, dtype=np.float64).reshape(-1, 2)
            self.areas[tier] = []
            if tier in ('common', 'rare'):
                for area in self.ingredients[tier]['areas']:
                    contours = [np.asarray(c, dtype=np.float64) + .5 for c in area['outlines']]
                    self.areas[tier].append((area['name'], contours))

class Renderer:
    """Vectorized projection, reusable marker sprites, and stationary-frame cache."""
    def __init__(self, store):
        self.store = store
        self.key = None
        self.cached = None
        self.sprites = {}
        self.draws = 0
        self.fonts = {}

    def invalidate(self):
        self.key = None

    def render(self, size, pose, layers, marker_size=5, opacity=.85, fill=True, pickup_markers=(), now=None, sighting_markers=()):
        w, h = size
        now=time.time() if now is None else now
        reminders=[]
        if layers.get('gems'):
            for pickup in pickup_markers:
                # Keep a 'Check' hint for ten minutes after expiry, then restore
                # normal map dots. The permanent history remains available.
                if now<pickup.check_at+600:
                    reminders.append(('pickup',pickup,pickup.label(now)))
            for sighting in sighting_markers:
                if sighting.can_mark(now):
                    reminders.append(('sighting',sighting,sighting.label(now)))
        # Subpixel motion below half a display pixel does not warrant a repaint.
        key = (size, round(pose.scale, 5), round(pose.tx * w / REF_W * 2),
               round(pose.ty * h / REF_H * 2), tuple(bool(layers.get(t)) for t in TIERS),
               marker_size, round(opacity, 2), fill,
               tuple((kind,p.id,p.marker_x,p.marker_y,label) for kind,p,label in reminders))
        if key == self.key:
            return self.cached[0], self.cached[1], False
        self.draws += 1
        image = Image.new('RGBA', size)
        pen = ImageDraw.Draw(image)
        counts = {t: 0 for t in TIERS}
        ratio = np.array([w / REF_W, h / REF_H])
        mul = np.array([pose.scale, -pose.scale]) * ratio
        shift = np.array([pose.tx, pose.ty]) * ratio
        for tier in ('common', 'rare'):
            if not layers.get(tier):
                continue
            color = COLORS[tier]
            for name, contours in self.store.areas[tier]:
                visible = False
                for contour in contours:
                    pts = contour * mul + shift
                    if len(pts) < 3 or (pts[:, 0].max() < 14 * ratio[0]
                         or pts[:, 0].min() > 550 * ratio[0]
                         or pts[:, 1].max() < 36 * ratio[1]
                         or pts[:, 1].min() > MAP_BOTTOM * ratio[1]):
                        continue
                    xy = list(map(tuple, pts))
                    if fill:
                        pen.polygon(xy, fill=(*color, round(25 * opacity)))
                    pen.line(xy + xy[:1], fill=(*color, round(220 * opacity)),
                             width=max(2, round(2 * min(ratio))))
                    visible = True
                counts[tier] += int(visible)
        for tier in TIERS:
            if not layers.get(tier):
                continue
            # Cull every point in one NumPy operation before drawing.
            projected = self.store.points[tier] * np.array([pose.scale, -pose.scale]) + [pose.tx, pose.ty]
            x, y = projected.T
            visible = ((x > 14) & (x < 550) & (y > 36) & (y < MAP_BOTTOM)
                       & ~((x > 420) & (y < 233)) & ~((x > 519) & (y > 788)))
            radius = max(3, round(marker_size * min(ratio)))
            sprite_key = (tier, radius, round(opacity, 2))
            if sprite_key not in self.sprites:
                extent = radius + 3
                sprite = Image.new('RGBA', (extent * 2 + 1, extent * 2 + 1))
                draw = ImageDraw.Draw(sprite)
                draw.ellipse((1, 1, extent * 2 - 1, extent * 2 - 1),
                             fill=(9, 13, 22, round(190 * opacity)))
                draw.ellipse((3, 3, extent * 2 - 3, extent * 2 - 3),
                             fill=(*COLORS[tier], round(255 * opacity)),
                             outline=(255, 255, 255, round(245 * opacity)), width=1)
                self.sprites[sprite_key] = sprite
            sprite = self.sprites[sprite_key]
            offset = sprite.width // 2
            for px, py in projected[visible] * ratio:
                image.alpha_composite(sprite, (round(px) - offset, round(py) - offset))
            counts[tier] += int(visible.sum())
        # Reminders are attached to coordinates, so they follow map panning.
        extra_timer_points = set()
        for kind,pickup,label in reminders:
            mx,my=pose.project(pickup.marker_x+.5,pickup.marker_y+.5)
            if not(14<mx<550 and 36<my<MAP_BOTTOM) or (mx>420 and my<233) or (mx>519 and my>788):
                continue
            px,py=np.array([mx,my])*ratio
            radius=max(3,round(marker_size*min(ratio)))
            waiting=pickup.remaining(now)>0
            ring=SIGHTING_COLOR if kind=='sighting' else (104,184,255) if waiting else (255,203,91)
            pen.ellipse((px-radius-2,py-radius-2,px+radius+2,py+radius+2),
                        fill=(21,35,54,round(235*opacity)),outline=(*ring,round(255*opacity)),width=2)
            pen.ellipse((px-2,py-2,px+2,py+2),fill=(*ring,round(255*opacity)))
            font_size=max(10,round(12*min(ratio)))
            if font_size not in self.fonts:
                for name in ('segoeui.ttf','DejaVuSans.ttf'):
                    try:
                        self.fonts[font_size]=ImageFont.truetype(name,font_size)
                        break
                    except OSError:
                        pass
                else:
                    self.fonts[font_size]=ImageFont.load_default()
            font=self.fonts[font_size]
            left,top,right,bottom=pen.textbbox((0,0),label,font=font)
            tw,th=right-left,bottom-top
            bx=max(14*ratio[0],min(px-tw/2-4,550*ratio[0]-tw-8))
            by=max(36*ratio[1],py-radius-th-12)
            pen.rounded_rectangle((bx,by,bx+tw+8,by+th+6),radius=3,
                                  fill=(10,16,25,round(220*opacity)))
            pen.text((bx+4-left,by+3-top),label,font=font,fill=(*ring,round(255*opacity)))
            known=self.store.points['gems']
            point=np.array([pickup.marker_x+.5,pickup.marker_y+.5])
            position=(pickup.marker_x,pickup.marker_y)
            if position not in extra_timer_points and (not len(known) or not np.any(np.linalg.norm(known-point,axis=1)<1e-6)):
                counts['gems']+=1
                extra_timer_points.add(position)
        # Fixed controls and chrome never receive markers, outlines, or fills.
        for bounds in [(0, 0, w - 1, 35 * ratio[1]),
                       (421 * ratio[0], 35 * ratio[1], w - 1, 233 * ratio[1]),
                       (0, MAP_BOTTOM * ratio[1], w - 1, h - 1),
                       (519 * ratio[0], 788 * ratio[1], w - 1, MAP_BOTTOM * ratio[1]),
                       (0, 0, 13 * ratio[0], h - 1),
                       (550 * ratio[0], 0, w - 1, h - 1)]:
            pen.rectangle(bounds, fill=(0, 0, 0, 0))
        self.key = key
        self.cached = (image, counts)
        return image, counts, True
