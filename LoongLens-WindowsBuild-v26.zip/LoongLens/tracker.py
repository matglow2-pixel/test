"""Latest-frame-only screenshot tracking, separate from the Windows UI."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
import logging
import threading
import time
import cv2
import numpy as np
from resources import REF_W, REF_H
from vision import Calibrator, MotionTracker, TitleDetector, Session, reconcile

LOG = logging.getLogger('loonglens')

class VisualWorker:
    def __init__(self, find_window, cache_dir, fps=30):
        self.find_window = find_window
        self.fps = fps
        self.lock = threading.Lock()
        self.snapshot = dict(open=False, match=None, rect=None, state='Preparing atlas index…',
                             info='First launch builds a local cache', fps=0., scan_ms=0.)
        self.stop_event = threading.Event()
        self.scan_event = threading.Event()
        self.pause_event = threading.Event()
        self.session = Session()
        self.motion = MotionTracker()
        self.title = TitleDetector()
        self.calibrator = Calibrator(cache_dir)
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='LoongLens-recognition')
        self.future = self.ticket = None
        self.pose = None
        self.last_scan = 0.
        self.anchor_time = 0.
        self.hidden_frames = 0
        self.thread = None
        self.scan_ms = 0.
        self.metrics_started = time.perf_counter()
        self.metrics_frames = 0
        self.actual_fps = 0.
        self.last_error = None
        self.last_capture = None

    def get_diagnostics(self):
        with self.lock:
            if self.last_capture is None:
                return None
            frame, details = self.last_capture
            return frame.copy(), details.copy()

    def record_capture(self, frame, rect, title_score):
        with self.lock:
            self.last_capture = (frame, dict(rect=list(rect),title_score=round(title_score,4),
                                 state=self.snapshot['state'],scale=self.pose.scale if self.pose else None,
                                 source=self.pose.source if self.pose else None,
                                 tx=self.pose.tx if self.pose else None,ty=self.pose.ty if self.pose else None,
                                 fit_error=self.pose.error if self.pose else None,
                                 age_reference=time.perf_counter()))

    def publish(self, **values):
        with self.lock:
            self.snapshot.update(values)

    def get(self):
        with self.lock:
            return self.snapshot.copy()

    def pause(self, paused):
        if paused:
            self.pause_event.set()
            self.publish(open=False, match=None, state='Paused', info='Resume to follow the map')
        else:
            self.pause_event.clear()
            self.scan_event.set()

    def request_scan(self):
        self.scan_event.set()

    def start(self):
        self.thread = threading.Thread(target=self.run, name='LoongLens-capture', daemon=True)
        self.thread.start()

    def _hide(self, state, info, rect=None):
        self.session.update(False, rect)
        self.pose = None
        self.motion.reset()
        self.hidden_frames = 0
        self.publish(open=False, match=None, rect=rect, state=state, info=info)

    def _search(self, frame, prior):
        start = time.perf_counter()
        return self.calibrator.locate(frame, prior), (time.perf_counter() - start) * 1000

    def run(self):
        import mss
        # Recognition infrastructure is warmed once, not once per map opening.
        self.future = self.pool.submit(self.calibrator.index.prepare)
        try:
            with mss.mss() as capture:
                while not self.stop_event.is_set():
                    start = time.perf_counter()
                    try:
                        self.step(capture, start)
                        self.last_error = None
                    except Exception as exc:
                        if str(exc) != self.last_error:
                            LOG.exception('Capture/tracking failed')
                            self.last_error = str(exc)
                        self._hide('Capture interrupted', str(exc)[:140])
                        self.stop_event.wait(.25)
                    self.metrics_frames += 1
                    elapsed = time.perf_counter() - self.metrics_started
                    if elapsed >= 1.:
                        self.actual_fps = self.metrics_frames / elapsed
                        self.metrics_started = time.perf_counter()
                        self.metrics_frames = 0
                    interval = 1. / self.fps if self.session.active else .10
                    if self.pause_event.is_set():
                        interval = .25
                    self.stop_event.wait(max(.001, interval - (time.perf_counter() - start)))
        except Exception as exc:
            LOG.exception('Screenshot backend failed')
            self._hide('Screenshot backend unavailable', str(exc)[:140])

    def step(self, capture, now):
        if self.pause_event.is_set():
            self._hide('Paused', 'Resume to follow the map')
            return
        rect = self.find_window()
        if rect is None:
            self._hide('Waiting for BlueStacks', 'Bring the BlueStacks map window to the foreground')
            return
        x, y, w, h = rect
        if self.session.rect != rect:
            self.session.update(False, rect)
            self.pose = None
            self.motion.reset()
        pixels = np.asarray(capture.grab(dict(left=x, top=y, width=w, height=h)))
        frame = cv2.resize(pixels[:, :, :3], (REF_W, REF_H), interpolation=cv2.INTER_AREA)
        title_score=self.title.score(frame)
        self.record_capture(frame,rect,title_score)
        if title_score < .64:
            # Publish hidden immediately; no stale dots while the title disappears.
            self._hide('Map closed', 'Open Loong Haven at normal zoom', rect)
            self.record_capture(frame,rect,title_score)
            return
        if not self.session.active:
            self.scan_event.set()
        self.session.update(True, rect)
        if self.pose is not None:
            updated = self.motion.update(frame, self.pose)
            if updated is None:
                self.pose = None
                self.motion.prime(frame)
                self.scan_event.set()
            else:
                self.pose = updated
        else:
            self.motion.prime(frame)
        if self.future is not None and self.future.done():
            completed, ticket = self.future, self.ticket
            self.future = self.ticket = None
            try:
                result = completed.result()
                if ticket is not None and self.session.accepts(ticket, now):
                    detected, self.scan_ms = result
                    detected = reconcile(ticket, frame, detected)
                    if detected is not None:
                        self.pose = detected
                        self.anchor_time = now
                        self.motion.prime(frame)
            except Exception as exc:
                LOG.exception('Atlas recognition failed')
                self.publish(info=f'Atlas error: {str(exc)[:100]}')
        # Refresh absolute position less often while tracking; limit accumulated drift.
        if self.pose is not None and now - self.anchor_time > 6.:
            self.pose = None
            self.scan_event.set()
        gap = .20 if self.pose is None else 1.8
        if self.future is None and (self.scan_event.is_set() or now - self.last_scan >= gap):
            self.scan_event.clear()
            self.last_scan = now
            self.ticket = self.session.ticket(frame, now)
            self.future = self.pool.submit(self._search, self.ticket.frame,
                                          self.pose.scale if self.pose else None)
        self.publish(open=True, match=self.pose, rect=rect, fps=self.actual_fps,
                     scan_ms=self.scan_ms,
                     state='Following map' if self.pose else 'Finding map position…',
                     info=(f'{self.pose.scale:.2f} px/tile · {self.pose.source}'
                           if self.pose else 'Markers stay hidden until the map is aligned'))
        self.record_capture(frame,rect,title_score)

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2.)
        self.pool.shutdown(wait=False, cancel_futures=True)
