"""Detached Windows entry point with one app instance and visible startup errors."""
from pathlib import Path
import os
import traceback

TITLE = 'Loong Lens'


def run():
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    handle = kernel.CreateMutexW(None, False, 'Local\\LoongLensUnified-v5')
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    existing = ctypes.get_last_error() == 183  # ERROR_ALREADY_EXISTS
    try:
        if existing:
            user = ctypes.WinDLL('user32', use_last_error=True)
            user.FindWindowW.argtypes = (wintypes.LPCWSTR, wintypes.LPCWSTR)
            user.FindWindowW.restype = wintypes.HWND
            user.ShowWindow.argtypes = (wintypes.HWND, ctypes.c_int)
            user.SetForegroundWindow.argtypes = (wintypes.HWND,)
            window = user.FindWindowW(None, TITLE)
            if window:
                user.ShowWindow(window, 9)
                user.SetForegroundWindow(window)
            return
        from loong_lens import main
        main()
    finally:
        kernel.CloseHandle(handle)


if __name__ == '__main__':
    try:
        run()
    except Exception as exc:
        folder = Path(os.environ.get('LOCALAPPDATA') or Path.home() / '.cache') / 'LoongLens'
        detail = traceback.format_exc()
        try:
            folder.mkdir(parents=True, exist_ok=True)
            (folder / 'startup-error.log').write_text(detail, encoding='utf-8')
            detail = f'Error details: {folder / "startup-error.log"}'
        except OSError:
            detail = 'Could not save an error log.'
        import tkinter as tk
        from tkinter import messagebox
        root = tk._default_root
        if root is None:
            root = tk.Tk()
            root.withdraw()
        messagebox.showerror('Loong Lens could not start', f'{exc}\n\n{detail}', parent=root)
        root.destroy()
