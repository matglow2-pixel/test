"""Check the three-page layout at supported sizes with no game input."""
from pathlib import Path
import contextlib
import os
import sys
import tempfile
import types
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import tkinter as tk
from tkinter import ttk
from PIL import ImageGrab,Image,ImageTk
import cv2
from smoke_backend import install
install()
sys.modules['winsound']=types.SimpleNamespace(Beep=lambda *a:None,MessageBeep=lambda *a:None,MB_ICONEXCLAMATION=48)
sys.modules['mss']=types.SimpleNamespace(mss=lambda:contextlib.nullcontext(None))
(ROOT/'artifacts').mkdir(exist_ok=True)
folder=Path(tempfile.mkdtemp(prefix='layout-ui-',dir=ROOT/'artifacts'))
os.environ['XDG_CACHE_HOME']=str(folder)
import gem_watch_panel,patrol_live_panel,loong_lens
panels={}
for name,cls in [('watch',gem_watch_panel.WatchPanel),('live',patrol_live_panel.LivePatrolPanel)]:
    init=cls.__init__
    def remember(panel,*args,_init=init,_name=name,**kwargs):
        _init(panel,*args,**kwargs);panels[_name]=panel
    cls.__init__=remember

def descendants(widget):
    for child in widget.winfo_children():
        yield child
        yield from descendants(child)

original=tk.Tk.__init__;errors=[];done=[]
def start(root,*args,**kwargs):
    original(root,*args,**kwargs)
    def failed(kind,value,trace):
        import traceback
        errors.append(''.join(traceback.format_exception(kind,value,trace)));root.destroy()
    root.report_callback_exception=failed
    def check():
        notebook=next(w for w in descendants(root) if isinstance(w,ttk.Notebook))
        assert [notebook.tab(t,'text') for t in notebook.tabs()]==['Map overlay','Gem Watch','Gem Sniping']
        assert panels['live'].keys is not None and not panels['live'].busy
        assert not panels['live'].runner.running
        assert not any(isinstance(w,ttk.Checkbutton) and w.cget('text')=='Enable live clicking' for w in descendants(root))
        panel=panels['live']
        panel.events.put(dict(kind='view_timing',total_seconds=12.4,map_seconds=11.2,inspect_seconds=1.2,skipped=False));panel.drain()
        assert 'Inspect 1.2s' in panel.performance.get()
        recent=tuple(dict(number=n,elapsed=seconds,gems=0) for n,seconds in ((4,461),(3,456),(2,451)))
        panel.events.put(dict(kind='pass_complete',passes=4,stats=recent[0],recent_passes=recent));panel.drain()
        assert panel.pass_text.get()=='Passes completed: 4\nLast 3 runs: #4 7:41 · #3 7:36 · #2 7:31'
        for size in ['540x820','560x860','700x950']:
            root.geometry(size+'+20+20')
            for i,tab in enumerate(notebook.tabs()):
                notebook.select(tab);root.update();time.sleep(.12);root.update()
                page=root.nametowidget(tab)
                for w in descendants(page):
                    if isinstance(w,(ttk.Button,ttk.Checkbutton,ttk.Scale,ttk.Label,ttk.Combobox)) and w.winfo_ismapped():
                        box=(w.winfo_rootx(),w.winfo_rooty(),w.winfo_width(),w.winfo_height())
                        assert box[0]>=root.winfo_rootx(), (size,w,box)
                        assert box[0]+box[2]<=root.winfo_rootx()+root.winfo_width(),(size,w,box)
                        assert box[1]+box[3]<=root.winfo_rooty()+root.winfo_height(),(size,w,box)
                        assert w.winfo_height()>=w.winfo_reqheight(),(size,str(w.cget('text')),box,w.winfo_reqheight())
                if size=='560x860':
                    photo=ROOT.parent/'gem-examples/GemsPictures/IMG_1401.png'
                    if photo.exists():
                        frame=cv2.imread(str(photo));panels['live'].show_frame(frame)
                        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));image.thumbnail((440,260))
                        panels['watch'].preview_photo=ImageTk.PhotoImage(image)
                        panels['watch'].preview.configure(image=panels['watch'].preview_photo,text='')
                    root.update();time.sleep(.12);root.update()
                    ImageGrab.grab(xdisplay=os.environ['DISPLAY'],bbox=(root.winfo_rootx(),root.winfo_rooty(),root.winfo_rootx()+root.winfo_width(),root.winfo_rooty()+root.winfo_height())).save(folder/f'tab-{i}.png')
        panels['live'].history_button.invoke()
        assert panels['watch'].sighting_controls.window.winfo_exists()
        panels['watch'].sighting_controls.window.destroy()
        panels['live'].show_settings()
        settings=next(w for w in root.winfo_children() if isinstance(w,tk.Toplevel) and w.title()=='Gem Sniping settings')
        settings.destroy()
        panel=panels['live']
        panel.routes.save_copy('UI route',panel.runner.views);panel.refresh_routes()
        panel=panels['live'];panel.show_route_editor();root.update()
        assert panel.editing and panel.editor is not None
        panel.start();assert not panel.runner.running
        editor=panel.editor;editor.select(11);editor.add_view();editor.nudge(0,-1)
        selected=editor.views[12];editor.save();root.update()
        assert not panel.editing and len(panel.runner.views)==77
        assert panel.progress.cget('maximum')==77
        assert '0 / 77 views' in panel.count.get() and '0 / 83' in panel.count.get()
        assert panel.runner.views[12]==selected and not panel.runner.checked
        assert panel.pass_text.get()=='' and panel.stats_text.get()=='Time spent: 0:00\nGems found: 0'
        from patrol_route import load_camera_adjustments
        assert load_camera_adjustments(panel.base_views,panel.route_path)==panel.runner.views
        panel.show_route_editor();root.update()
        panel.editor.reset_all();panel.editor.save();root.update()
        assert len(panel.runner.views)==76 and panel.progress.cget('maximum')==76
        done.append(True)
        next(w for w in descendants(root) if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
    root.after(700,check);root.after(15000,root.destroy)
tk.Tk.__init__=start
old=sys.platform;sys.platform='win32'
try:loong_lens.main([])
finally:sys.platform=old;tk.Tk.__init__=original
assert done and not errors,errors
print('Three-tab layout, ready controls, shared History and editor save/reset with dynamic 77/83 totals passed.')
print(folder)
