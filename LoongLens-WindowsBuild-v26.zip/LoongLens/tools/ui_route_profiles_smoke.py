"""Exercise route dropdowns and Save as in real Tk without gameplay input."""
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import tkinter as tk
from tkinter import messagebox
from resources import ResourceStore
from patrol_route import load_fixed_route
from route_profiles import RouteProfiles
from route_editor import RouteEditor
from ui_theme import apply_theme


def main():
    root=tk.Tk();root.withdraw();apply_theme(root)
    base=load_fixed_route(ResourceStore().data)
    with tempfile.TemporaryDirectory(prefix='loonglens-routes-') as folder:
        profiles=RouteProfiles(base,folder)
        busy=profiles.save_copy('Busy zones',base[1:]);profiles.activate('default')
        selected=[];saved=[]
        def choose(name):
            ident=next(ident for ident,label in profiles.items() if label==name)
            views=profiles.activate(ident);selected.append((name,views));return views
        def copy(views):
            profiles.save_copy('Busy copy',views);saved.append(views)
            return 'Busy copy',views
        editor=RouteEditor(root,base,base,lambda views:profiles.save(profiles.active,views),
            route_choices=lambda:[name for _,name in profiles.items()],active_route='Default',
            on_route_change=choose,on_save_copy=copy)
        editor.window.geometry('820x620');root.update()
        assert tuple(editor.route_box.cget('values'))==('Default','Busy zones')
        editor.route_choice.set('Busy zones');editor.change_route();root.update()
        assert len(editor.views)==75 and profiles.active==busy and selected[-1][0]=='Busy zones'
        editor.nudge(.25,0)
        original=messagebox.askyesno
        try:
            messagebox.askyesno=lambda *a,**kw:False
            editor.route_choice.set('Default');editor.change_route()
            assert editor.route_choice.get()=='Busy zones' and editor.dirty
            messagebox.askyesno=lambda *a,**kw:True
            editor.route_choice.set('Default');editor.change_route()
            assert tuple(editor.views)==base and not editor.dirty
        finally:messagebox.askyesno=original
        editor.remove_selected();editor.save_route_copy();root.update()
        assert editor.route_choice.get()=='Busy copy' and not editor.dirty
        assert len(editor.views)==75 and profiles.load('default')==base
        assert 'Busy copy' in editor.route_box.cget('values')
        for button in (editor.remove_button,editor.undo_button,editor.restore_button):
            assert button.winfo_height()>=button.winfo_reqheight()
            assert button.winfo_rooty()+button.winfo_height()<=editor.window.winfo_rooty()+editor.window.winfo_height()
        editor.close();root.update()
        restarted=RouteProfiles(base,folder)
        assert restarted.name(restarted.active)=='Busy copy' and restarted.load(restarted.active)==saved[-1]
    root.destroy()
    print('Editor Run route dropdown, Save as, unsaved-edit protection, Default preservation and restart persistence passed.')


if __name__=='__main__':main()
