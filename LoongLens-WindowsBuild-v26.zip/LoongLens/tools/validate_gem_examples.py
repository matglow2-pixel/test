"""Validate gem detection against annotated user examples kept outside the release.

Usage: python tools/validate_gem_examples.py /path/to/extracted/GemsPictures
"""
from pathlib import Path
import argparse
import json
import statistics
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import cv2
import numpy as np
from gem_detector import GemDetector

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder',type=Path)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'artifacts/gem-validation.json')
    args=parser.parse_args()
    cv2.setNumThreads(2)
    detector=GemDetector()
    examples=json.loads((Path(__file__).with_name('gem_examples.json')).read_text('utf-8'))['examples']
    report=[]
    for row in examples:
        image=cv2.imread(str(args.folder/row['file']))
        if image is None:raise FileNotFoundError(row['file'])
        started=time.perf_counter()
        # Reference images have different cropping/UI layouts; scan every pixel.
        # The live HUD exclusion path is tested separately.
        detections=detector.detect(image,exclude_hud=False)
        elapsed=(time.perf_counter()-started)*1000
        centers=np.array([d.center for d in detections],float).reshape(-1,2)*(570/image.shape[1])
        unmatched=list(range(len(centers)))
        matched=0
        for center in row['centers']:
            nearest=min(unmatched,key=lambda i:np.linalg.norm(centers[i]-center)) if unmatched else None
            if nearest is not None and np.linalg.norm(centers[nearest]-center)<12:
                unmatched.remove(nearest);matched+=1
        passed=matched==len(row['centers']) and not unmatched
        result=dict(file=row['file'],training=row['training'],expected=len(row['centers']),
                    detected=len(detections),matched=matched,extra=len(unmatched),passed=passed,
                    scan_ms=round(elapsed,2),scores=[round(d.score,4) for d in detections])
        report.append(result)
        print(f"{'PASS' if passed else 'FAIL'} {row['file']}: {matched}/{len(row['centers'])} piles, {len(unmatched)} extra",flush=True)
    heldout=[r for r in report if not r['training'] and r['expected']]
    summary=dict(positive_images=sum(r['expected']>0 for r in report),
                 held_out_positive_images=len(heldout),held_out_positive_images_passed=sum(r['passed'] for r in heldout),
                 total_expected_piles=sum(r['expected'] for r in report),total_matched_piles=sum(r['matched'] for r in report),
                 extra_detections=sum(r['extra'] for r in report),
                 negative_image_results=[r for r in report if not r['expected']],
                 median_scan_ms=round(statistics.median(r['scan_ms'] for r in report),2),
                 limitations='Small supplied screenshot set; no independent negative set, live session, occlusion or Windows capture validation.',
                 results=report)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(summary,indent=2),encoding='utf-8')
    if not all(r['passed'] for r in report):raise SystemExit(1)
    print(f"All {len(report)} screenshots passed. {len(heldout)} held-out positive images; {summary['total_matched_piles']} total gem piles; no extra detections.")

if __name__=='__main__':main()
