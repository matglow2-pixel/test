"""Reproducible recognition/render microbenchmarks using the uploaded atlas."""
from pathlib import Path
import json
import statistics
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cv2
import numpy as np
from resources import ROOT, ResourceStore, Renderer, TIERS
from vision import AtlasIndex, MotionTracker
from sxs_atlas_tracker import align_atlas
from pose import Match

def measure(fn, repeats=10):
    fn()
    samples = []
    for _ in range(repeats):
        start = time.perf_counter()
        fn()
        samples.append((time.perf_counter() - start) * 1000)
    return {'median_ms': round(statistics.median(samples), 3),
            'p95_ms': round(float(np.percentile(samples, 95)), 3), 'repeats': repeats}

def main():
    cv2.setNumThreads(2)
    output = ROOT / 'artifacts'
    output.mkdir(exist_ok=True)
    atlas = cv2.imread(str(ROOT / 'loong_haven_default_atlas.png'))
    index = AtlasIndex(output / 'benchmark-cache')
    start = time.perf_counter()
    index.prepare()
    prepare_ms = (time.perf_counter() - start) * 1000
    results = {'scope': 'Offline synthetic atlas crops; not live-game or Windows display latency.',
               'opencv_threads': 2, 'index_prepare_ms': round(prepare_ms, 3), 'recognition': []}
    for x,y in [(900,1300), (1600,1500), (2000,1700)]:
        frame = atlas[y:y+1029,x:x+570].copy()
        # Check correct alignment before claiming a timing result.
        for fn in (align_atlas, index.locate):
            found = fn(frame)
            assert found is not None and abs(found.tx+x) < 4 and abs(found.ty-(279*12.45-y)) < 4
        old = measure(lambda: align_atlas(frame), 6)
        new = measure(lambda: index.locate(frame), 12)
        results['recognition'].append({'viewport': [x,y], 'original': old, 'indexed': new,
                                      'speedup': round(old['median_ms']/new['median_ms'], 2)})
    store = ResourceStore()
    renderer = Renderer(store)
    layers = dict.fromkeys(TIERS, True)
    pose = Match(12.45, -1650, 2250, 20, .1, [])
    def redraw():
        renderer.invalidate()
        return renderer.render((570,1029), pose, layers)
    results['full_render'] = measure(redraw, 60)
    results['stationary_cached_render'] = measure(lambda: renderer.render((570,1029),pose,layers), 1000)
    frame = atlas[1300:2329,900:1470].copy()
    flow = MotionTracker(); flow.prime(frame)
    results['stationary_optical_flow'] = measure(lambda: flow.update(frame,pose), 60)
    results['windows_upload'] = 'Not measured: requires a Windows machine.'
    path = output / 'benchmark.json'
    path.write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps(results, indent=2))

if __name__ == '__main__':
    main()
