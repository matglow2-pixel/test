"""Validate minimap labels against the supplied photos, without redistributing them."""
from pathlib import Path
import argparse
import json
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from gem_detector import load_image
from location_ocr import Location, LocationReader, ROOT

EXPECTED = {
    'IMG_1401.png': ('Ironpeak',31,186),
    'IMG_1409.png': ('Crystalheart Lake',192,218),
    'IMG_1423.png': ('Vale of Light',231,129),
    'IMG_1424.png': ('Demonbind Tower',144,67),
    'IMG_1427.png': ('Dying Sun',110,45),
    'IMG_1430.png': ('Demonbind Tower',145,67),
    'IMG_1440.png': ('Fairy Greens',207,82),
    'IMG_1442.png': ('Gleam Vault',129,242),
    'IMG_4267.png': ("Loong's Perch",157,172),
    'MyLocationNoGems.png': ('Demonbind Tower',158,67),
    'Screenshot_20260811_215817_Sword_x_Staff.jpg': ('Glacial Hollow',198,240),
    'Screenshot_20260812_094823_Sword_x_Staff.jpg': ('Loong Haven XII',84,167),
    'Screenshot_20260812_125601_Sword_x_Staff.jpg': ('Hush Yard',193,83),
    'Screenshot_20260812_160855_Sword_x_Staff.jpg': ('Celestship',140,248),
    'Screenshot_20260812_175907_Sword_x_Staff.jpg': ('Withered Ravine',104,55),
    'Screenshot_20260812_192953_Sword_x_Staff.jpg': ('Crystalheart Lake',195,219),
    'Screenshot_20260813_122733_Sword_x_Staff.jpg': ('Twilight Shoal',51,94),
    'Screenshot_20260813_125327_Sword_x_Staff.jpg': ('Emerald Corner',245,103),
    'Screenshot_20260816_224005_Sword_x_Staff.jpg': ('Streamside',128,106),
}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder',type=Path)
    args=parser.parse_args()
    reader=LocationReader()
    rows=[]
    for name, expected in EXPECTED.items():
        start=time.perf_counter()
        actual=reader.read(load_image(args.folder/name))
        valid=actual==Location(*expected)
        rows.append(dict(file=name,expected=expected,actual=None if actual is None else actual.__dict__,
                         passed=valid,ms=round((time.perf_counter()-start)*1000)))
        print(f'{"PASS" if valid else "FAIL"}: {name} — {actual}',flush=True)
    folder=ROOT/'artifacts';folder.mkdir(exist_ok=True)
    (folder/'location-validation.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    count=sum(row['passed'] for row in rows)
    print(f'{count}/{len(rows)} supplied minimap labels matched the visual annotations.')
    if count!=len(rows):raise SystemExit(1)


if __name__=='__main__':main()
