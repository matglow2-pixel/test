"""Exercise real Tk/history/map-renderer wiring with a simulated game backend."""
from pathlib import Path
import contextlib
import os
import sys
import tempfile
import time
import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import tkinter as tk
from tkinter import ttk
from pose import Match
from resources import SIGHTING_COLOR
from smoke_backend import install, MapWorker, Overlay
import loong_lens

folder = Path(tempfile.mkdtemp(prefix='sighting-timer-ui-', dir=ROOT/'artifacts'))
os.environ['XDG_CACHE_HOME'] = str(folder)
install()
sys.modules['winsound'] = types.SimpleNamespace(Beep=lambda *a:None, MessageBeep=lambda *a:None, MB_ICONEXCLAMATION=48)
sys.modules['mss'] = types.SimpleNamespace(mss=lambda:contextlib.nullcontext(None))
import gem_watch_panel
real_time = time.time
start = real_time()
state = {'now':start, 'image':None, 'pose':Match(12.45,250-100.5*12.45,460+100.5*12.45,20,0,[])}
time.time = lambda:state['now']
MapWorker.get = lambda worker:dict(open=True,match=state['pose'],rect=(0,0,570,1029),state='Map aligned',info='Simulated map',fps=45.,scan_ms=0.)
Overlay.show_image = lambda overlay,rect,image:state.update(image=image.copy())
Overlay.hide = lambda overlay:state.update(image=None)
panels = []
original_panel_init = gem_watch_panel.WatchPanel.__init__
def remember_panel(panel,*args,**kwargs):
    original_panel_init(panel,*args,**kwargs)
    panels.append(panel)
gem_watch_panel.WatchPanel.__init__ = remember_panel

def descendants(widget):
    result=[]
    for child in widget.winfo_children():
        result.append(child);result.extend(descendants(child))
    return result

def teal_at(position):
    return state['image'] is not None and state['image'].getpixel(position)[:3]==SIGHTING_COLOR

original_root_init = tk.Tk.__init__
errors=[]
finished=[]

def root_init(root,*args,**kwargs):
    original_root_init(root,*args,**kwargs)
    def failed(kind,value,trace):
        import traceback
        errors.append(''.join(traceback.format_exception(kind,value,trace)))
        root.destroy()
    root.report_callback_exception=failed
    pending=dict(event_id='timer-ui',seen_at=start,screen_x=10,screen_y=20,score=.95,test_mode=False,capture_status='pending')
    def queue(event):
        panel=panels[0]
        with panel.worker.lock:panel.worker.sightings.append(event)
        panel.flush_sightings()
    def begin():
        queue(pending)
        root.after(80,confirm_pending)
    def confirm_pending():
        assert not teal_at((250,460))
        state['now']=start+5
        queue(dict(pending,capture_status='ready',zone='Loong Haven III',game_x=100,game_y=100,captured_at=start+5))
        root.after(80,confirmed)
    def confirmed():
        assert teal_at((250,460))
        assert panels[0].sighting_history.active_markers()[0].label(state['now'])=='29:55'
        state['now']=start+600
        controls=panels[0].sighting_controls
        controls.show()
        key=controls.tree.get_children()[0]
        controls.tree.selection_set(key)
        controls.edit_location()
        editor=controls.edit_window
        fields=[w for w in descendants(editor) if isinstance(w,ttk.Entry)]
        for field,value in zip(fields,('Loong Haven V','102','100')):
            field.delete(0,'end');field.insert(0,value)
        next(w for w in descendants(editor) if isinstance(w,ttk.Button) and w.cget('text')=='Save location').invoke()
        root.after(80,edited)
    def edited():
        assert teal_at((275,460)) and not teal_at((250,460))
        row=panels[0].sighting_history.active_markers()[0]
        assert row.seen_at==start and row.label(state['now'])=='20:00'
        pose=state['pose']
        state['pose']=Match(pose.scale,pose.tx+75,pose.ty+20,20,0,[])
        root.after(80,panned)
    def panned():
        assert teal_at((350,480))
        checkbox=next(w for w in descendants(root) if isinstance(w,ttk.Checkbutton) and w.cget('text')=='Sighting timers (30 min)')
        checkbox.invoke()
        root.after(80,disabled)
    def disabled():
        assert not teal_at((350,480))
        checkbox=next(w for w in descendants(root) if isinstance(w,ttk.Checkbutton) and w.cget('text')=='Sighting timers (30 min)')
        checkbox.invoke()
        root.after(80,reenabled)
    def reenabled():
        assert teal_at((350,480))
        state['now']=start+1800
        root.after(80,expired)
    def expired():
        assert not teal_at((350,480))
        panel=panels[0]
        assert len(panel.sighting_history.list())==1 and not panel.sighting_history.active_markers()
        panel.sighting_history.edit_location(1,'Loong Haven IX',78,48)
        assert not panel.sighting_history.active_markers()
        controls=panel.sighting_controls
        controls.tree.selection_set('1')
        controls.remove()
        assert not panel.sighting_history.list()
        controls.window.destroy()
        finished.append(True)
        next(w for w in descendants(root) if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
    root.after(300,begin)
    root.after(10000,root.destroy)

tk.Tk.__init__=root_init
sys.platform='win32'
try:
    loong_lens.main(argv=[])
finally:
    time.time=real_time
assert finished and not errors,(finished,errors)
print('Sighting map UI passed: pending/confirmed capture metadata, 29:55 from original time, edited coordinates moving the dot at 20:00, pan, timer toggle, expiry, deletion and unchanged spotting time.')
