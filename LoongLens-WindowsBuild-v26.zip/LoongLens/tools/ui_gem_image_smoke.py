"""Real detector/alert/UI picture-mode smoke check on Linux with mock Windows audio.

The live desktop backend is mocked; image loading, detection, confirmation,
panel updates and sound requests use the actual application implementations.
"""
import os
from pathlib import Path
import sys
import types
import traceback
import time
from datetime import datetime, time as day_time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from tkinter import ttk,filedialog
import cv2
import numpy as np
from PIL import Image
from mss.linux import MSS
from gem_detector import ROOT
import gem_watch
from smoke_backend import install
from sighting_history import SightingHistory

OUT=ROOT/'artifacts'
OUT.mkdir(exist_ok=True)
os.environ['XDG_CACHE_HOME']=str(OUT/'image-test-ui-settings')
history_path=OUT/'image-test-ui-settings/LoongLens/sightings.sqlite3'
if history_path.exists():history_path.unlink()
positive=Path(os.environ.get('GEM_WATCH_TEST_POSITIVE',OUT/'picture-mode-positive.png'))
negative=Path(os.environ.get('GEM_WATCH_TEST_NEGATIVE',OUT/'picture-mode-negative.png'))
def badge(image, zone, x, y):
    cv2.rectangle(image,(332,228),(554,291),(55,60,50),-1)
    cv2.putText(image,zone,(346,253),cv2.FONT_HERSHEY_SIMPLEX,.55,(240,240,240),1,cv2.LINE_AA)
    cv2.putText(image,f'({x},{y})',(369,279),cv2.FONT_HERSHEY_SIMPLEX,.55,(240,240,240),1,cv2.LINE_AA)
    return image

if not os.environ.get('GEM_WATCH_TEST_POSITIVE'):
    frame=np.full((1029,570,3),(95,145,105),np.uint8)
    sprite=cv2.imread(str(ROOT/'gem_templates/gem_0.png'))
    frame[440:440+sprite.shape[0],280:280+sprite.shape[1]]=sprite
    cv2.imwrite(str(positive),badge(frame,'Loong Haven I',100,100))
if not os.environ.get('GEM_WATCH_TEST_NEGATIVE'):
    cv2.imwrite(str(negative),np.full((1029,570,3),(95,145,105),np.uint8))

live_state={'started':None}
initial_live=badge(cv2.imread(str(positive)).copy(),'Loong Haven I',100,100)
arrived_live=badge(initial_live.copy(),'Loong Haven III',193,121)

class Capture:
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def grab(self,*args):
        return arrived_live if live_state['started'] is not None and time.monotonic()-live_state['started']>=3 else initial_live

sys.modules['mss']=types.SimpleNamespace(mss=Capture)
install(find_visible=lambda:(123,(0,0,570,1029)))
sounds=[]
opened=[]
os.startfile=lambda path:opened.append(path)
sys.modules['winsound']=types.SimpleNamespace(Beep=lambda *args:sounds.append(args),MessageBeep=lambda *args:None,MB_ICONEXCLAMATION=48)
files=iter([str(positive),str(negative)])
filedialog.askopenfilename=lambda **kwargs:next(files)
original=tk.Tk.__init__
errors=[]
finished=[]

def descendants(root):
    result=[]
    for w in root.winfo_children():result.append(w);result.extend(descendants(w))
    return result

def start(self,*args,**kwargs):
    original(self,*args,**kwargs)
    def callback_error(*args):
        errors.append(args);traceback.print_exception(*args)
    self.report_callback_exception=callback_error
    def buttons():return {w.cget('text'):w for w in descendants(self) if isinstance(w,ttk.Button)}
    def label_values():
        return [str(self.getvar(w.cget('textvariable'))) for w in descendants(self)
                if isinstance(w,ttk.Label) and w.cget('textvariable')]
    def load_positive():
        buttons()['Test image'].invoke()
        assert 'Watch game' in buttons()
        self.after(3000,positive_check)
    def positive_check():
        database=SightingHistory(history_path)
        rows=database.list(include_tests=True)
        database.close()
        if not rows or rows[0].capture_status=='pending':
            self.after(350,positive_check)
            return
        labels=label_values()
        assert any('IMAGE TEST: GEM DETECTED' in text for text in labels),labels
        assert len(sounds)==3,sounds
        buttons()['History'].invoke()
        history=next(w for w in descendants(self) if isinstance(w,tk.Toplevel) and w.title()=='Gem sighting history')
        tree=next(w for w in descendants(history) if isinstance(w,ttk.Treeview))
        assert not tree.get_children(), 'Image tests must be excluded from live history initially'
        next(w for w in descendants(history) if isinstance(w,ttk.Checkbutton) and w.cget('text')=='Include image tests').invoke()
        assert len(tree.get_children())==1
        values=tree.item(tree.get_children()[0],'values')
        assert values[1]=='Image test · Open screenshot'
        assert values[0].endswith(rows[0].spotted[-14:])
        assert tree.heading('time','text')=='Spotted'
        if not os.environ.get('GEM_WATCH_TEST_POSITIVE'):
            assert values[0].startswith('Loong Haven I (100,100) '),values
        history.update_idletasks()
        box=tree.bbox(tree.get_children()[0],'source')
        tree.event_generate('<Button-1>',x=box[0]+12,y=box[1]+8)
        tree.event_generate('<ButtonRelease-1>',x=box[0]+12,y=box[1]+8)
        assert opened and opened[-1]==rows[0].screenshot_path
        history.destroy()
        self.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            cap=screen.grab(dict(left=self.winfo_rootx(),top=self.winfo_rooty(),width=self.winfo_width(),height=self.winfo_height()))
            Image.frombytes('RGB',cap.size,cap.rgb).save(OUT/'image-test-panel-preview.png')
        buttons()['Test image'].invoke()
        self.after(2200,negative_check)
    def negative_check():
        labels=label_values()
        assert any('IMAGE TEST · no gems detected' in text for text in labels),labels
        assert not any('IMAGE TEST: GEM DETECTED' in text for text in labels),labels
        assert len(sounds)==3,'Negative photo unexpectedly sounded an alert'
        live_state['started']=time.monotonic()
        buttons()['Watch game'].invoke()
        notebook=next(w for w in descendants(self) if isinstance(w,ttk.Notebook))
        notebook.select(notebook.tabs()[0])  # Live watching continues on the Map tab.
        self.after(2500,game_check)
    def game_check():
        labels=label_values()
        assert any('GEM DETECTED at ' in text and 'IMAGE TEST' not in text for text in labels),labels
        database=SightingHistory(history_path)
        assert len(database.list())==1 and len(database.list(include_tests=True))==2
        assert database.list()[0].capture_status=='pending' and not database.list()[0].screenshot_path
        database.close()
        assert len(sounds)==6, sounds
        self.after(6000,finish)
    def finish():
        database=SightingHistory(history_path)
        live=database.list()[0]
        if live.capture_status=='pending':
            database.close()
            self.after(350,finish)
            return
        assert live.spotted.startswith('Loong Haven III (193,121) '),live
        assert live.captured_at-live.seen_at>=5 and live.captured_at-live.seen_at<7
        assert np.array_equal(cv2.imread(live.screenshot_path),arrived_live)
        assert database.pending_count()==0
        database.close()
        buttons()['History'].invoke()
        history=next(w for w in descendants(self) if isinstance(w,tk.Toplevel) and w.title()=='Gem sighting history')
        tree=next(w for w in descendants(history) if isinstance(w,ttk.Treeview))
        live_key=next(key for key in tree.get_children() if str(tree.item(key,'values')[1]).startswith('Live game'))
        history.update_idletasks()
        footer=next(w for w in descendants(history) if isinstance(w,ttk.Button) and w.cget('text')=='Open screenshot')
        assert footer.winfo_rooty()+footer.winfo_height()<=history.winfo_rooty()+history.winfo_height()
        box=tree.bbox(live_key,'source')
        tree.event_generate('<Button-1>',x=box[0]+12,y=box[1]+8)
        tree.event_generate('<ButtonRelease-1>',x=box[0]+12,y=box[1]+8)
        assert opened[-1]==live.screenshot_path and len(opened)==2
        history_buttons={w.cget('text'):w for w in descendants(history) if isinstance(w,ttk.Button)}
        assert 'Export history CSV' not in history_buttons and 'Retake screenshot' not in history_buttons
        tree.selection_set(live_key)
        history_buttons['Edit location'].invoke()
        editor=next(w for w in descendants(history) if isinstance(w,tk.Toplevel) and w.title()=='Edit sighting location')
        fields=[w for w in descendants(editor) if isinstance(w,ttk.Entry)]
        assert len(fields)==3,'Only zone, X and Y should be editable'
        save=next(w for w in descendants(editor) if isinstance(w,ttk.Button) and w.cget('text')=='Save location')
        fields[0].delete(0,'end')
        save.invoke()
        assert editor.winfo_exists(),'Blank zone should not save'
        for field,value in zip(fields,('Loong Haven IX','78','48')):
            field.delete(0,'end');field.insert(0,value)
        save.invoke()
        assert not editor.winfo_exists()
        database=SightingHistory(history_path)
        corrected=database.get(live.id)
        assert (corrected.zone,corrected.game_x,corrected.game_y)==('Loong Haven IX',78,48)
        assert corrected.seen_at==live.seen_at and corrected.captured_at==live.captured_at
        assert corrected.screenshot_path==live.screenshot_path
        assert corrected.spotted.endswith(live.spotted[-14:])
        yesterday=datetime.combine(datetime.now().date(),day_time.min).timestamp()-1
        database.record([dict(event_id='older-history',seen_at=yesterday,screen_x=1,screen_y=2,score=.9,test_mode=False)])
        old_key=str(next(row.id for row in database.list() if row.event_id=='older-history'))
        database.close()
        radios={w.cget('text'):w for w in descendants(history) if isinstance(w,ttk.Radiobutton)}
        assert radios['Today only'].instate(['selected'])
        assert old_key not in tree.get_children()
        radios['Show all'].invoke()
        assert old_key in tree.get_children() and len(tree.get_children())==3
        radios['Today only'].invoke()
        assert old_key not in tree.get_children() and len(tree.get_children())==2
        assert tree.item(live_key,'values')[0]==corrected.spotted
        history.geometry('660x360')
        history.update_idletasks()
        for button in history_buttons.values():
            assert button.winfo_ismapped()
            assert button.winfo_rooty()+button.winfo_height()<=history.winfo_rooty()+history.winfo_height()
        history.geometry('880x480')
        history.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            cap=screen.grab(dict(left=history.winfo_rootx(),top=history.winfo_rooty(),width=history.winfo_width(),height=history.winfo_height()))
            Image.frombytes('RGB',cap.size,cap.rgb).save(OUT/'sighting-history-preview.png')
        history.destroy()
        assert not errors,errors
        finished.append(True)
        buttons()['Exit'].invoke()
        restarted=SightingHistory(history_path)
        assert len(restarted.list())==2 and len(restarted.list(include_tests=True))==3
        assert restarted.get(live.id)==corrected and Path(restarted.get(live.id).screenshot_path).is_file()
        restarted.close()
        print('Unified UI passed: real detection/OCR and capture, exact location/date format, matching Source links, edit validation, preserved spotting/capture timestamps and screenshot, Today/Show all filters, minimum-window layout, CSV button removal and restart persistence.')
    self.after(300,load_positive)
    self.after(35000,self.destroy)

tk.Tk.__init__=start
sys.platform='win32';sys.argv=['gem_watch.py']
gem_watch.main()
assert finished and not errors,(finished,errors)
