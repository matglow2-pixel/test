"""Draw the bundled fixed route as an exact-coordinate SVG data diagram."""
from pathlib import Path
import base64,json,math,html,csv,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from patrol_route import map_clickable
route=json.loads((ROOT/'gem_sniping_route.json').read_text('utf-8'));stops=route['stops']
S=12.45;OX=70;OY=350;W=3626;H=4030

def xy(s):return OX+s['x']*S,OY+(279-s['y'])*S

def visible(a,b):
    x=285+(b['x']-a['x'])*S;y=530-(b['y']-a['y'])*S
    return map_clickable((x,y))

svg=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
'<rect width="100%" height="100%" fill="#0e1622"/>',
'<g font-family="DejaVu Sans,sans-serif" fill="#eef6ff">',
'<text x="70" y="85" font-size="46" font-weight="bold">GEM SNIPING · FIXED 76-CHECK PATH</text>',
'<text x="70" y="143" font-size="29" fill="#aec5d9">Emerald Corner first · same remaining order every pass · 83 spawn spots</text>',
'<text x="70" y="195" font-size="27" fill="#ffd792">REMOVED: 26 Forsaken Lotus Pond · 51 Jadetoad Isle · 72 Frosted Plain</text>',
'<text x="70" y="243" font-size="25">Original map numbers retained. Extra B/R camera clicks removed; use a held mouse drag only when needed.</text>',
'<circle cx="90" cy="300" r="18" fill="#162a3d" stroke="#c2fff6" stroke-width="3"/><text x="90" y="307" text-anchor="middle" font-size="20" font-weight="bold">8</text>',
'<text x="125" y="309" font-size="24">Camera check</text>',
'<circle cx="490" cy="300" r="7" fill="#ff79dc"/><text x="515" y="309" font-size="24">Included gem spawn</text>',
'<path d="M 1020 300 h 90" stroke="#ffc477" stroke-width="5" stroke-dasharray="12 9"/><text x="1130" y="309" font-size="24">Likely map drag (D)</text>',
'<path d="M 1690 300 h 90" stroke="#baa6ff" stroke-width="5" stroke-dasharray="12 9"/><text x="1800" y="309" font-size="24">Loop return to 1</text></g>']
blob=base64.b64encode((ROOT/'loong_haven_default_atlas.png').read_bytes()).decode()
svg.append(f'<image x="{OX}" y="{OY}" width="3486" height="3486" xlink:href="data:image/png;base64,{blob}"/>')
svg.append(f'<rect x="{OX}" y="{OY}" width="3486" height="3486" fill="#07101a" opacity=".12"/>')
gap=0
for a,b in zip(stops,stops[1:]):
    x,y=xy(a);u,v=xy(b);drag=not visible(a,b)
    color='#ffc477' if drag else '#72dfd1';dash=' stroke-dasharray="13 9"' if drag else ''
    svg.append(f'<path d="M{x} {y} L{u} {v}" fill="none" stroke="#081522" stroke-width="12" opacity=".75"/>')
    svg.append(f'<path d="M{x} {y} L{u} {v}" fill="none" stroke="{color}" stroke-width="6" opacity=".9"{dash}/>')
    mx,my=(x+u)/2,(y+v)/2;angle=math.degrees(math.atan2(v-y,u-x))
    svg.append(f'<path d="M-9 -7 L9 0 L-9 7 Z" transform="translate({mx},{my}) rotate({angle})" fill="{color}" stroke="#081522" stroke-width="2"/>')
    if drag:
        gap+=1;svg.append(f'<text x="{mx+14}" y="{my-14}" font-family="DejaVu Sans" font-size="22" font-weight="bold" fill="#ffc477" stroke="#07111c" stroke-width="6" paint-order="stroke">D{gap}</text>')
x,y=xy(stops[-1]);u,v=xy(stops[0])
svg.append(f'<path d="M{x} {y} L{u} {v}" fill="none" stroke="#baa6ff" stroke-width="5" stroke-dasharray="12 10"/><text x="{(x+u)/2+20}" y="{(y+v)/2}" font-family="DejaVu Sans" font-size="24" fill="#baa6ff" stroke="#07111c" stroke-width="5" paint-order="stroke">77 → 1</text>')
for s in stops:
    for a,b in s['spawn_spots']:
        x=OX+(a+.5)*S;y=OY+(279-b-.5)*S
        svg.append(f'<circle cx="{x}" cy="{y}" r="7" fill="#ff79dc" stroke="#201323" stroke-width="2"/>')
labels=[list(xy(s)) for s in stops]
for _ in range(40):
    for i in range(len(labels)):
        for j in range(i):
            dx=labels[i][0]-labels[j][0];dy=labels[i][1]-labels[j][1];d=math.hypot(dx,dy)
            if d<60:
                ux,uy=(dx/d,dy/d) if d else (1.,0.);shift=(60-d)/2
                labels[i][0]+=ux*shift;labels[i][1]+=uy*shift;labels[j][0]-=ux*shift;labels[j][1]-=uy*shift
for s,(x,y) in zip(stops,labels):
    px,py=xy(s)
    if math.hypot(x-px,y-py)>5:svg.append(f'<path d="M{px} {py} L{x} {y}" stroke="white" stroke-width="3"/>')
    fill='#174b3c' if s['number']==1 else '#162a3d';stroke='#8dffc6' if s['number']==1 else '#dcfff9'
    title=html.escape(f"Route #{s['number']}{s.get('part','')}: {s['zone']} — camera ({s['x']},{s['y']}) — {s['spawn_spots']}")
    svg.append(f'<g><title>{title}</title><circle cx="{x}" cy="{y}" r="23" fill="{fill}" stroke="#07111c" stroke-width="8"/><circle cx="{x}" cy="{y}" r="23" fill="{fill}" stroke="{stroke}" stroke-width="3"/><text x="{x}" y="{y+9}" text-anchor="middle" font-family="DejaVu Sans" font-size="26" font-weight="bold" fill="white">{s["number"]}{s.get("part", "")}</text></g>')
x,y=xy(stops[0]);svg.append(f'<text x="{x-170}" y="{y+77}" font-family="DejaVu Sans" font-size="30" font-weight="bold" fill="#8dffc6" stroke="#07111c" stroke-width="7" paint-order="stroke">START · EMERALD CORNER</text>')
svg.extend(['<g font-family="DejaVu Sans" fill="#c2d0df" font-size="24">',
'<text x="70" y="3895">Snipe checks this path once. Loop Sniping repeats it. F10 or a confirmed gem stops input.</text>',
'<text x="70" y="3940">Every destination is fixed in map coordinates. Actual input uses fresh screenshot alignment after each recenter/drag.</text>',
'<text x="70" y="3985">D labels predict gaps from default-zoom geometry. Live centering/locks determine whether a drag is needed.</text></g></svg>'])
(ROOT/'GemSniping-Fixed-Route.svg').write_text(''.join(svg))
with (ROOT/'GemSniping-Fixed-Route.csv').open('w',newline='') as f:
    w=csv.writer(f,lineterminator="\n");w.writerow(['Processed check','Original route number','Zone','Camera X','Camera Y','Spawn coordinates'])
    for n,s in enumerate(stops,1):w.writerow([n,str(s['number'])+s.get('part',''),s['zone'],s['x'],s['y'],'; '.join(f'{x},{y}' for x,y in s['spawn_spots'])])
print('Drawn',len(stops),'checks;',gap,'nominal drag transitions; IDs 26,51,72 omitted.')
