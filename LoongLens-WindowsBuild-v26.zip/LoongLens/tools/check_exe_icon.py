"""Verify the Windows GUI executable embeds every image in the supplied ICO."""
from pathlib import Path
import argparse
import hashlib
import struct

import pefile


def check(executable, icon):
    raw = Path(icon).read_bytes()
    count = struct.unpack_from('<H', raw, 4)[0]
    expected = set()
    for index in range(count):
        length, offset = struct.unpack_from('<II', raw, 6+index*16+8)
        expected.add(hashlib.sha256(raw[offset:offset+length]).hexdigest())
    binary = pefile.PE(str(executable))
    assert binary.FILE_HEADER.Machine == 0x8664, 'Expected 64-bit Windows executable'
    assert binary.OPTIONAL_HEADER.Subsystem == 2, 'Expected GUI executable without a console'
    embedded = set()
    groups = 0
    for resource in binary.DIRECTORY_ENTRY_RESOURCE.entries:
        if resource.id == 14:
            groups += len(resource.directory.entries)
        if resource.id != 3:
            continue
        for name in resource.directory.entries:
            for language in name.directory.entries:
                data = language.data.struct
                payload = binary.get_data(data.OffsetToData, data.Size)
                embedded.add(hashlib.sha256(payload).hexdigest())
    assert groups and expected <= embedded, 'The executable is missing the supplied icon images'
    print(f'Verified Windows x64 GUI EXE: all {count} supplied ICO images embedded; no console subsystem.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('icon', type=Path)
    args = parser.parse_args()
    check(args.executable, args.icon)
