"""Exercise the real editor canvas and persistence, without sending game input."""
import sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from PIL import ImageGrab
from resources import ResourceStore
from patrol_route import load_fixed_route,load_camera_adjustments,save_camera_adjustments
from route_editor import RouteEditor
from ui_theme import apply_theme


def main():
    root=tk.Tk();root.withdraw();apply_theme(root)
    route=load_fixed_route(ResourceStore().data)
    with tempfile.TemporaryDirectory(prefix='route-editor-') as directory:
        path=Path(directory)/'camera-route-adjustments.json';saved=[];closed=[]
        def save(views):save_camera_adjustments(route,views,path);saved.append(views)
        editor=RouteEditor(root,route,route,save,lambda:closed.append(True));root.update()
        index=next(i for i,v in enumerate(route) if v.route_label=='12')
        editor.select(index);editor.zoom_selected();root.update()
        x,y=editor.point(route[index].x,route[index].y)
        x-=editor.canvas.canvasx(0);y-=editor.canvas.canvasy(0)
        editor.canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y));root.update()
        editor.canvas.event_generate('<B1-Motion>',x=round(x),y=round(y+20));root.update()
        editor.canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y+20));root.update()
        adjusted=editor.views[index]
        assert adjusted.y<route[index].y-2 and adjusted.cells==route[index].cells
        assert editor.dragging is False
        assert 'outside' in editor.info.get()
        editor.add_view();root.update()
        assert len(editor.views)==77 and editor.views[index+1].route_label=='12+1'
        editor.nudge(.25,-.5);editor.add_view();root.update()
        assert [v.route_label for v in editor.views[index:index+4]]==['12','12+1','12+2','13']
        assert editor.remove_button.instate(['!disabled'])
        editor.remove_extra();assert len(editor.views)==77
        editor.select(index);assert editor.remove_button.instate(['!disabled'])
        editor.select(index+1);editor.add_view();root.update()
        extras=tuple(editor.views[index+1:index+3])
        editor.window.geometry('1100x820+0+0');root.update()
        ImageGrab.grab().save(Path(tempfile.gettempdir())/'loong-route-editor-v26.png')
        editor.save();root.update();assert saved and closed and path.exists()
        loaded=load_camera_adjustments(route,path);assert loaded[index]==adjusted
        assert loaded[index+1:index+3]==extras
        second=RouteEditor(root,route,loaded,save);root.update();second.select(index)
        second.reset_selected();assert second.views[index]==route[index]
        second.reset_all();second.save();root.update()
        assert load_camera_adjustments(route,path)==route
        third=RouteEditor(root,route,route,save);root.update()
        third.nudge(.25,0);third.dirty=False;third.close();root.update()
        assert load_camera_adjustments(route,path)==route
        fourth=RouteEditor(root,route,route,save);root.update();fourth.select(index)
        fourth.window.geometry('820x620');root.update()
        for button in (fourth.remove_button,fourth.undo_button,fourth.restore_button):
            assert button.winfo_height()>=button.winfo_reqheight()
            assert button.winfo_rooty()+button.winfo_height()<=fourth.window.winfo_rooty()+fourth.window.winfo_height()
        fourth.remove_selected();root.update()
        assert len(fourth.views)==75 and not any(v.route_label=='12' for v in fourth.views)
        assert '4 omitted' in fourth.total.get()
        fourth.undo_remove();assert tuple(fourth.views)==route
        fourth.remove_selected();fourth.save();root.update()
        reduced=load_camera_adjustments(route,path)
        assert len(reduced)==75 and not any(v.route_label=='12' for v in reduced)
        fifth=RouteEditor(root,route,reduced,save);root.update()
        fifth.restore_originals();fifth.save();root.update()
        assert load_camera_adjustments(route,path)==route
        last=RouteEditor(root,route,(route[0],),save);root.update()
        assert last.remove_button.instate(['disabled'])
        last.remove_selected();assert len(last.views)==1
        last.add_view();assert len(last.views)==2
        last.remove_selected();last.undo_remove();assert len(last.views)==2
        last.dirty=False;last.close();root.update()
    root.destroy();print('Map editor: add, remove originals/extras, undo, reduced-route save/reload, restore, one-point route and minimum-size controls passed.')


if __name__=='__main__':main()
