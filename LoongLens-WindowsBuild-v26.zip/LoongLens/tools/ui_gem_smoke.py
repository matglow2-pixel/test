"""Linux virtual-display smoke check for the Gem Watch panel (mock Win32 backend)."""
import os
from pathlib import Path
import sys
import types
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from tkinter import ttk
import cv2
import numpy as np
from PIL import Image
from mss.linux import MSS
from gem_detector import Detection
import gem_watch_worker
import gem_watch
from smoke_backend import install

OUT = Path(__file__).resolve().parents[1]/'artifacts'
OUT.mkdir(exist_ok=True)
os.environ['XDG_CACHE_HOME'] = str(OUT/'gem-ui-settings')
path = os.environ.get('GEM_WATCH_TEST_IMAGE')
FRAME = cv2.imread(path) if path else np.full((1029,570,3),(95,145,105),np.uint8)
assert FRAME is not None

class Worker:
    def __init__(self,*args,**kwargs):self.paused=True;self.region=None;self.sent=False
    def configure(self,paused=None,region=None,**kwargs):
        if paused is not None:self.paused=paused
        if kwargs.get('reset'):self.region=region
    def start(self):pass
    def close(self):pass
    def get(self):
        return dict(state='Paused' if self.paused else 'Watching · no gems detected',
                    frame=FRAME,detections=[],scan_ms=40.,rect=(0,0,FRAME.shape[1],FRAME.shape[0]))
    def drain_alerts(self):return []
    def drain_sightings(self):return []

gem_watch_worker.WatchWorker = Worker
install()
sounds = []
sys.modules['winsound'] = types.SimpleNamespace(Beep=lambda *args:sounds.append(args),MessageBeep=lambda *args:None,MB_ICONEXCLAMATION=48)
original = tk.Tk.__init__
errors = []

def descendants(root):
    result=[]
    for w in root.winfo_children():result.append(w);result.extend(descendants(w))
    return result

def start(self,*args,**kwargs):
    original(self,*args,**kwargs)
    def callback_error(*args):
        errors.append(args)
        traceback.print_exception(*args)
    self.report_callback_exception = callback_error
    def interact():
        ws=descendants(self)
        buttons={w.cget('text'):w for w in ws if isinstance(w,ttk.Button)}
        buttons['Start watching'].invoke()
        assert buttons['Start watching'].cget('text')=='Pause'
        buttons['Test sound'].invoke()
        buttons['Select scan area'].invoke()
        win=next(w for w in self.winfo_children() if isinstance(w,tk.Toplevel))
        win.update()
        canvas=next(w for w in descendants(win) if isinstance(w,tk.Canvas))
        canvas.event_generate('<Button-1>',x=30,y=160)
        canvas.event_generate('<B1-Motion>',x=400,y=650)
        canvas.event_generate('<ButtonRelease-1>',x=400,y=650)
        next(w for w in descendants(win) if isinstance(w,ttk.Button) and w.cget('text')=='Save area').invoke()
        buttons['History'].invoke()
        history = next(w for w in self.winfo_children() if isinstance(w,tk.Toplevel) and w.title() == 'Gem sighting history')
        history.destroy()
        self.after(400,screenshot)
    def screenshot():
        self.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            capture=screen.grab(dict(left=self.winfo_rootx(),top=self.winfo_rooty(),width=self.winfo_width(),height=self.winfo_height()))
            Image.frombytes('RGB',capture.size,capture.rgb).save(OUT/'gem-panel-preview.png')
        ws=descendants(self)
        footer=next(w for w in ws if isinstance(w,ttk.Label) and str(w.cget('text')).startswith('Pink boxes mark'))
        assert footer.winfo_rooty()+footer.winfo_height()<=self.winfo_rooty()+self.winfo_height(), 'Footer exceeds initial panel height'
        assert not errors,errors
        assert sounds,'Test sound did not call the sound backend'
        settings=OUT/'gem-ui-settings/LoongLens/gemwatch-settings.json'
        assert settings.exists()
        next(w for w in ws if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
        print('Gem Watch Tk smoke passed: start/pause, sound backend, area selection, saved preferences, layout, exit.')
    self.after(300,interact)
    self.after(6000,self.destroy)

tk.Tk.__init__ = start
sys.platform='win32';sys.argv=['gem_watch.py']
gem_watch.main()
if errors:raise RuntimeError(errors)
