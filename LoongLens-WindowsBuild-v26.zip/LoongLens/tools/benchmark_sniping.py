"""Profile the full fixed route using real atlas pixels and simulated desktop input.

The existing independent route test verifies every selected camera coordinate.
This measures recognition work and simulated waits, not live BlueStacks speed.
Use --app-root to compare an extracted older release in a separate process.
"""
import argparse
import json
from pathlib import Path
import sys
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app-root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=args.app_root.resolve()
    sys.path[:0]=[str(root),str(root/'tests')]
    import cv2
    cv2.setNumThreads(2)
    import vision
    from patrol_live import LivePatrol
    from patrol_route import load_fixed_route
    from resources import ResourceStore
    from test_fixed_route import test_complete_fixed_route_uses_recentered_atlas_screenshots_and_no_transit_camera_clicks
    result=dict(scope='Full 76-view atlas route; simulated input, loading and detector. Not live Windows/BlueStacks speed.',
                captures=0,relative_matches=0,absolute_matches=0)
    original_run=LivePatrol.run
    original_track=vision.track_map_pan
    def track(*a,**kw):
        result['relative_matches']+=1
        return original_track(*a,**kw)
    vision.track_map_pan=track
    def run(engine,backend,*a,**kw):
        capture=backend.capture;locate=engine.locator.locate
        def screenshot():result['captures']+=1;return capture()
        def absolute(frame):result['absolute_matches']+=1;return locate(frame)
        backend.capture=screenshot;engine.locator.locate=absolute
        started=time.perf_counter()
        value=original_run(engine,backend,*a,**kw)
        result.update(cpu_wall_seconds=round(time.perf_counter()-started,3),
                      simulated_elapsed_seconds=round(backend.now,3),
                      views_checked=len(engine.checked),
                      drags=sum(event[0]=='drag' for event in backend.inputs))
        return value
    LivePatrol.run=run
    route=load_fixed_route(ResourceStore().data)
    test_complete_fixed_route_uses_recentered_atlas_screenshots_and_no_transit_camera_clicks(route)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
