"""Personal camera framing cannot alter the fixed route or original spawn data."""
from dataclasses import replace
import json
import pytest
from resources import ResourceStore
from patrol_route import load_fixed_route,load_camera_adjustments,save_camera_adjustments,apply_camera_adjustments,camera_warnings


@pytest.fixture
def route():return load_fixed_route(ResourceStore().data)


def test_camera_drag_save_reload_preserves_order_cells_and_split_identities(route,tmp_path):
    path=tmp_path/'camera-route-adjustments.json';edited=list(route)
    for i,v in enumerate(edited):
        if v.route_label in ('12','40b'):edited[i]=replace(v,x=v.x-.25,y=v.y-1.25)
    save_camera_adjustments(route,edited,path)
    reloaded=load_camera_adjustments(route,path)
    assert reloaded==tuple(edited)
    assert [(v.route_label,v.cells) for v in reloaded]==[(v.route_label,v.cells) for v in route]
    assert set(json.loads(path.read_text())['targets'])=={'12','40b'}
    assert not path.with_suffix('.json.tmp').exists()
    save_camera_adjustments(route,route,path)
    assert load_camera_adjustments(route,path)==route


@pytest.mark.parametrize('point',[[float('nan'),2],[1,float('inf')],[-1,3],[1,280],[True,3],['1',2],[1],None])
def test_invalid_saved_position_is_rejected_as_a_whole(route,point):
    with pytest.raises(ValueError):apply_camera_adjustments(route,{'version':1,'targets':{'12':point}})


def test_removed_or_unknown_points_cannot_be_added(route):
    for label in ('26','51','72','40','400'):
        with pytest.raises(ValueError):apply_camera_adjustments(route,{'version':1,'targets':{label:[1,2]}})


def test_changed_spawn_or_order_cannot_be_saved(route,tmp_path):
    changed=(replace(route[0],cells=frozenset({(0,0)})),)+route[1:]
    for edited in (changed,tuple(reversed(route))):
        with pytest.raises(ValueError):save_camera_adjustments(route,edited,tmp_path/'route.json')
    assert not (tmp_path/'route.json').exists()


def test_manual_framing_can_show_offset_ground_with_warning_without_changing_spawns(route):
    changed=apply_camera_adjustments(route,{'version':1,'targets':{'12':[159.5,63.5],'44':[70,211]}})
    tower=next(v for v in changed if v.route_label=='12')
    assert len(tower.cells)==4 and camera_warnings(tower)
    assert any('portal' in warning for v in changed if v.route_label=='44' for warning in camera_warnings(v))


def test_missing_adjustments_use_defaults_and_corrupt_file_is_not_overwritten(route,tmp_path):
    path=tmp_path/'camera-route-adjustments.json';assert load_camera_adjustments(route,path)==route
    path.write_text('{broken')
    with pytest.raises(ValueError):load_camera_adjustments(route,path)
    assert path.read_text()=='{broken'
