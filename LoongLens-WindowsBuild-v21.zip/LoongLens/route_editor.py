"""Full-map camera target editor. Editing never sends game input."""
from dataclasses import replace
import math
import tkinter as tk
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
from resources import ROOT
from camera_patrol import PatrolSettings
from patrol_route import camera_warnings,clear_view_bounds
from ui_theme import BG,CARD,TEXT,ACCENT,MUTED


class RouteEditor:
    def __init__(self,parent,base,views,on_save,on_close=lambda:None):
        self.base=tuple(base);self.views=list(views);self.on_save=on_save;self.on_close=on_close
        self.selected=0;self.dragging=False;self.dirty=False;self.scale=.18
        self.window=tk.Toplevel(parent);self.window.title('Loong Lens · Edit camera route')
        width=min(1100,self.window.winfo_screenwidth()-60);height=min(820,self.window.winfo_screenheight()-80)
        self.window.geometry(f'{width}x{height}');self.window.minsize(820,620)
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.source=Image.open(ROOT/'loong_haven_default_atlas.png').convert('RGB')
        bar=ttk.Frame(self.window,padding=10);bar.pack(fill='x')
        ttk.Label(bar,text='Drag camera targets · pink dots are the original spawn locations',font=('Segoe UI',11,'bold')).pack(side='left')
        ttk.Button(bar,text='Save & reset checks',style='Primary.TButton',command=self.save).pack(side='right')
        body=ttk.Frame(self.window,padding=(10,0,10,10));body.pack(fill='both',expand=True)
        sidebar=ttk.Frame(body,width=270);sidebar.pack(side='right',fill='y',padx=(12,0));sidebar.pack_propagate(False)
        ttk.Label(sidebar,text='CAMERA TARGETS').pack(anchor='w')
        listing=ttk.Frame(sidebar);listing.pack(fill='both',expand=True,pady=6)
        self.listbox=tk.Listbox(listing,bg=CARD,fg=TEXT,selectbackground='#35516b',exportselection=False,highlightthickness=0)
        scroll=ttk.Scrollbar(listing,command=self.listbox.yview);scroll.pack(side='right',fill='y')
        self.listbox.configure(yscrollcommand=scroll.set);self.listbox.pack(fill='both',expand=True)
        for v in self.views:self.listbox.insert('end',f'#{v.route_label} · {v.near_zone}')
        self.listbox.bind('<<ListboxSelect>>',self.select_list)
        fields=ttk.Frame(sidebar);fields.pack(fill='x')
        self.x=tk.StringVar();self.y=tk.StringVar()
        for name,value in (('X',self.x),('Y',self.y)):
            ttk.Label(fields,text=name).pack(side='left');ttk.Entry(fields,textvariable=value,width=7).pack(side='left',padx=(4,8))
        ttk.Button(sidebar,text='Apply coordinates',command=self.apply_fields).pack(fill='x',pady=6)
        ttk.Button(sidebar,text='Zoom to selected',command=self.zoom_selected).pack(fill='x')
        ttk.Button(sidebar,text='Reset selected point',command=self.reset_selected).pack(fill='x',pady=6)
        ttk.Button(sidebar,text='Reset all points',command=self.reset_all).pack(fill='x')
        self.info=tk.StringVar();ttk.Label(sidebar,textvariable=self.info,wraplength=258,style='Muted.TLabel').pack(fill='x',pady=10)
        ttk.Label(sidebar,text='Solid box: camera view\nDashed box: suggested clear area\nWheel / + −: zoom · drag empty map: pan\nArrow keys: nudge selected camera\nOrder and spawn dots stay unchanged.\nA single view cannot cover every possible 10-tile spawn offset.',wraplength=258,style='Muted.TLabel').pack(fill='x')
        area=ttk.Frame(body);area.pack(fill='both',expand=True)
        zoom=ttk.Frame(area);zoom.pack(fill='x',pady=(0,5))
        ttk.Button(zoom,text='Whole map',command=self.fit).pack(side='left')
        ttk.Button(zoom,text='+',command=lambda:self.zoom(1.4)).pack(side='left',padx=5)
        ttk.Button(zoom,text='-',command=lambda:self.zoom(1/1.4)).pack(side='left')
        self.canvas=tk.Canvas(area,bg=BG,highlightthickness=0);self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<ButtonPress-1>',self.press);self.canvas.bind('<B1-Motion>',self.motion)
        self.canvas.bind('<ButtonRelease-1>',lambda e:setattr(self,'dragging',False))
        self.canvas.bind('<MouseWheel>',lambda e:self.zoom(1.25 if e.delta>0 else .8,e.x,e.y))
        self.canvas.bind('<Button-4>',lambda e:self.zoom(1.25,e.x,e.y))
        self.canvas.bind('<Button-5>',lambda e:self.zoom(.8,e.x,e.y))
        for key,dx,dy in (('Left',-.25,0),('Right',.25,0),('Up',0,.25),('Down',0,-.25)):
            self.canvas.bind('<'+key+'>',lambda e,a=dx,b=dy:self.nudge(a,b))
        self.window.update_idletasks();self.fit();self.select(0)

    def point(self,x,y):return x*12.45*self.scale,(279-y)*12.45*self.scale
    def world(self,x,y):return x/(12.45*self.scale),279-y/(12.45*self.scale)

    def draw(self):
        c=self.canvas;c.delete('all')
        size=round(3486*self.scale)
        if getattr(self,'image_size',None)!=size:
            self.photo=ImageTk.PhotoImage(self.source.resize((size,size),Image.Resampling.LANCZOS));self.image_size=size
        c.create_image(0,0,image=self.photo,anchor='nw');c.configure(scrollregion=(0,0,size,size))
        path=[coord for v in self.views for coord in self.point(v.x,v.y)]
        c.create_line(*path,fill=ACCENT,width=2,arrow='last')
        for v in self.views:
            for x,y in v.cells:
                px,py=self.point(x+.5,y+.5);c.create_oval(px-3,py-3,px+3,py+3,fill='#ff79dc',outline='#311b37')
        view=self.views[self.selected]
        for bounds,color,dash in ((view.bounds(PatrolSettings()),'#ffffff',None),(clear_view_bounds(view),'#ffd27b',(5,3))):
            l,b,r,t=bounds;coords=(*self.point(l,t),*self.point(r,b))
            c.create_rectangle(*coords,outline=color,width=2,dash=dash or ())
        for i,v in enumerate(self.views):
            x,y=self.point(v.x,v.y);color='#ffcf76' if i==self.selected else ACCENT
            c.create_oval(x-7,y-7,x+7,y+7,fill=BG,outline=color,width=2)
            c.create_text(x+9,y-10,text=v.route_label,anchor='w',fill=color,font=('Segoe UI',10,'bold'))

    def fit(self):
        self.scale=max(.1,min(self.canvas.winfo_width(),self.canvas.winfo_height())/3486)
        self.draw();self.canvas.xview_moveto(0);self.canvas.yview_moveto(0)

    def zoom(self,factor,x=None,y=None):
        x=self.canvas.winfo_width()/2 if x is None else x;y=self.canvas.winfo_height()/2 if y is None else y
        wx,wy=self.world(self.canvas.canvasx(x),self.canvas.canvasy(y))
        self.scale=min(1.6,max(.1,self.scale*factor));self.draw();px,py=self.point(wx,wy)
        size=round(3486*self.scale)
        self.canvas.xview_moveto((px-x)/size);self.canvas.yview_moveto((py-y)/size)

    def zoom_selected(self):
        self.scale=max(self.scale,.65);self.draw()
        px,py=self.point(self.views[self.selected].x,self.views[self.selected].y);size=round(3486*self.scale)
        self.canvas.xview_moveto((px-self.canvas.winfo_width()/2)/size)
        self.canvas.yview_moveto((py-self.canvas.winfo_height()/2)/size)

    def select(self,index):
        self.selected=index;self.listbox.selection_clear(0,'end');self.listbox.selection_set(index);self.listbox.see(index)
        v=self.views[index];self.x.set(f'{v.x:.2f}');self.y.set(f'{v.y:.2f}')
        warnings=camera_warnings(v)
        self.info.set(f'#{v.route_label} · {v.near_zone}\nCamera ({v.x:.2f}, {v.y:.2f})\n'+('\n'.join(warnings) if warnings else 'Recorded centres fit the suggested clear area.'))
        self.draw()

    def select_list(self,event=None):
        if self.listbox.curselection():self.select(self.listbox.curselection()[0])

    def press(self,event):
        self.canvas.focus_set();x,y=self.canvas.canvasx(event.x),self.canvas.canvasy(event.y)
        distances=[math.dist((x,y),self.point(v.x,v.y)) for v in self.views]
        nearest=self.selected if distances[self.selected]<=12 else min(range(len(distances)),key=distances.__getitem__)
        if distances[nearest]<=12:self.select(nearest);self.dragging=True
        else:self.dragging=False;self.canvas.scan_mark(event.x,event.y)

    def motion(self,event):
        if not self.dragging:self.canvas.scan_dragto(event.x,event.y,gain=1);return
        x,y=self.world(self.canvas.canvasx(event.x),self.canvas.canvasy(event.y));self.move_to(x,y)

    def move_to(self,x,y):
        self.views[self.selected]=replace(self.views[self.selected],x=round(min(279.99,max(0.,x)),2),y=round(min(279.99,max(0.,y)),2))
        self.dirty=True;self.select(self.selected)

    def nudge(self,x,y):
        v=self.views[self.selected];self.move_to(v.x+x,v.y+y);return 'break'

    def apply_fields(self):
        try:
            x,y=float(self.x.get()),float(self.y.get())
            if not all(math.isfinite(a) and 0<=a<280 for a in (x,y)):raise ValueError()
        except ValueError:messagebox.showerror('Invalid coordinates','Use coordinates from 0 to 279.99.',parent=self.window);return
        self.move_to(x,y)

    def reset_selected(self):
        self.views[self.selected]=self.base[self.selected];self.dirty=True;self.select(self.selected)

    def reset_all(self):
        self.views=list(self.base);self.dirty=True;self.select(self.selected)

    def save(self):
        try:self.on_save(tuple(self.views))
        except (OSError,ValueError) as exc:messagebox.showerror('Could not save',str(exc),parent=self.window);return
        self.dirty=False;self.close()

    def close(self):
        if self.dirty and not messagebox.askyesno('Discard adjustments?','Close without saving your camera adjustments?',parent=self.window):return
        self.source.close();self.window.destroy();self.on_close()
