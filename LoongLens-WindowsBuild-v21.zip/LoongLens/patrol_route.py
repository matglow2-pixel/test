"""The approved fixed camera order; removed numbers retain their old map IDs."""
import json
import math
from dataclasses import replace
from pathlib import Path
from camera_patrol import Viewpoint, PatrolSettings, camera_click_clear


def clear_view_bounds(view,settings=None):
    """Spawn centres need context above the chat and below the upper HUD.

    World Y increases upwards. These bounds reserve four tiles at the bottom
    and 2.5 at the top of the full 12.1-tile camera rectangle, plus side padding.
    They cover the listed centres, not every possible ten-tile spawn offset.
    """
    left,bottom,right,top=view.bounds(settings or PatrolSettings())
    return left+.6,bottom+4.,right-.6,top-2.5


def load_fixed_route(data):
    route=json.loads((Path(__file__).resolve().parent/'gem_sniping_route.json').read_text('utf-8'))
    known={(int(s['position']['x']),int(s['position']['y'])) for s in data['gems']}
    excluded={tuple(c) for s in route['excluded'] for c in s['spawn_spots']}
    result=[];seen=set();numbers=[];settings=PatrolSettings()
    for s in route['stops']:
        cells=frozenset(tuple(c) for c in s['spawn_spots'])
        x,y=s['x'],s['y'];number=s['number']
        if not cells or not cells<=known or cells & (seen|excluded):
            raise ValueError('Fixed camera route has missing, duplicate or excluded spawns.')
        if not (math.isfinite(x) and math.isfinite(y) and 0<=x<280 and 0<=y<280 and camera_click_clear(x,y)):
            raise ValueError('Fixed camera route has an invalid camera target.')
        view=Viewpoint(x,y,s['zone'],cells,route_number=number,route_part=s.get('part',''))
        left,bottom,right,top=clear_view_bounds(view,settings)
        if not all(left-1e-6<=cx+.5<=right+1e-6 and bottom-1e-6<=cy+.5<=top+1e-6 for cx,cy in cells):
            raise ValueError('A spawn falls outside the clear gameplay area of its fixed view.')
        result.append(view);seen.update(cells);numbers.append(number)
    expected=[n for n in range(1,78) if n not in (26,51,72) for _ in range(2 if n in (40,64) else 1)]
    parts=[v.route_part for v in result]
    expected_parts=[part for n in range(1,78) if n not in (26,51,72) for part in (('a','b') if n in (40,64) else ('',))]
    if numbers!=expected or parts!=expected_parts or seen!=known-excluded:
        raise ValueError('The fixed camera path must preserve its approved order and exclusions.')
    return tuple(result)


def route_pan_delta(point,limit):
    """Pull an offscreen target toward the middle in one bounded held drag.

    Merely exposing its edge can leave too little terrain for registration and
    require several tiny drags. Endpoints stay in the clear central map area.
    """
    x,y=point
    tx,ty=285.,500.
    dx,dy=tx-x,ty-y
    factor=max(1.,math.hypot(dx,dy)/limit)
    return dx/factor,dy/factor


def apply_camera_adjustments(views,document):
    """Only camera positions are editable; identity, order and spawns stay fixed."""
    if not isinstance(document,dict) or document.get('version')!=1 or not isinstance(document.get('targets'),dict):
        raise ValueError('Camera adjustments have an unsupported format.')
    targets=document['targets'];known={v.route_label for v in views}
    if not targets.keys()<=known:raise ValueError('Camera adjustments refer to an unknown route point.')
    result=[]
    for view in views:
        if view.route_label not in targets:result.append(view);continue
        point=targets[view.route_label]
        if not isinstance(point,list) or len(point)!=2 or any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not 0<=x<280 for x in point):
            raise ValueError('Camera positions must be finite coordinates from 0 to 279.99.')
        result.append(replace(view,x=float(point[0]),y=float(point[1])))
    return tuple(result)


def load_camera_adjustments(views,path):
    path=Path(path)
    if not path.exists():return tuple(views)
    return apply_camera_adjustments(views,json.loads(path.read_text('utf-8')))


def save_camera_adjustments(base,views,path):
    if [(v.route_label,v.cells) for v in base]!=[(v.route_label,v.cells) for v in views]:
        raise ValueError('Editing camera positions must preserve route order and spawn locations.')
    document={'version':1,'targets':{v.route_label:[v.x,v.y] for original,v in zip(base,views) if (original.x,original.y)!=(v.x,v.y)}}
    apply_camera_adjustments(base,document)
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(document,indent=2)+'\n','utf-8');temporary.replace(path)


def camera_warnings(view):
    warnings=[]
    if not camera_click_clear(view.x,view.y):warnings.append('Camera target overlaps a known portal.')
    left,bottom,right,top=clear_view_bounds(view)
    outside=sum(not(left-1e-6<=x+.5<=right+1e-6 and bottom-1e-6<=y+.5<=top+1e-6) for x,y in view.cells)
    if outside:warnings.append(f'{outside} recorded spawn centre(s) are outside the suggested clear area.')
    return warnings
