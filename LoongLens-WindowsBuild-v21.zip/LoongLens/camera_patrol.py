"""Group camera checks over playable terrain; no desktop input APIs."""
from __future__ import annotations
from dataclasses import dataclass
import math
from functools import lru_cache
import base64
import json
from pathlib import Path
import numpy as np

MAP_SIZE = 280
# Loong Haven IV's portal icon intercepts camera clicks around this position.
# Keep the gem's original location; only move the camera selection point.
CAMERA_CLICK_EXCLUSIONS = ((184.,138.,2.5),(70.,211.,2.5))


def camera_click_clear(x,y):
    return all((x-px)**2+(y-py)**2 >= radius**2
               for px,py,radius in CAMERA_CLICK_EXCLUSIONS)



@dataclass(frozen=True)
class Spawn:
    x: float
    y: float
    zone: str


@dataclass(frozen=True)
class PatrolSettings:
    # About 83 x 151 map pixels in the supplied white rectangle / 12.45.
    view_width: float = 6.7
    view_height: float = 12.1

    def __post_init__(self):
        values = (self.view_width, self.view_height)
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Use finite numbers for the camera settings.')
        if not (2 <= self.view_width <= 40 and 2 <= self.view_height <= 60):
            raise ValueError('View width must be 2–40 tiles; height must be 2–60.')


@dataclass(frozen=True)
class Viewpoint:
    x: float
    y: float
    near_zone: str
    cells: frozenset[tuple[int, int]]
    route_number: int | None = None
    route_part: str = ''

    @property
    def route_label(self):
        return f'{self.route_number}{self.route_part}'

    def bounds(self, settings):
        w, h = settings.view_width/2, settings.view_height/2
        return self.x-w, self.y-h, self.x+w, self.y+h


@dataclass(frozen=True)
class PatrolPlan:
    spawns: tuple[Spawn, ...]
    settings: PatrolSettings
    views: tuple[Viewpoint, ...]
    cells: frozenset[tuple[int, int]]


def load_spawns(data):
    return tuple(Spawn(float(row['position']['x'])+.5,
                       float(row['position']['y'])+.5,
                       row.get('regionName', 'Loong Haven')) for row in data['gems'])


@lru_cache(maxsize=1)
def playable_ground():
    data = json.loads((Path(__file__).resolve().parent/'loong_haven_terrain.json').read_text('utf-8'))
    raw = np.frombuffer(base64.b64decode(data['ground']), np.uint8).reshape(data['height'],data['width'])
    # All 86 supplied spawns are on category 0: the light, playable terrain.
    return raw == 0


def build_plan(spawns, settings=None, ground=None):
    settings = settings or PatrolSettings()
    spawns = tuple(spawns)
    if len(spawns)>2000:
        raise ValueError('The camera planner supports up to 2,000 gem locations.')
    for spawn in spawns:
        if not (math.isfinite(spawn.x) and math.isfinite(spawn.y)
                and 0 <= spawn.x < MAP_SIZE and 0 <= spawn.y < MAP_SIZE):
            raise ValueError('Spawn coordinates must be inside the Loong Haven map.')
    if not spawns:
        return PatrolPlan(spawns, settings, (), frozenset())
    ground = playable_ground() if ground is None else np.asarray(ground, dtype=bool)
    if ground.shape != (MAP_SIZE,MAP_SIZE):
        raise ValueError('Playable terrain must use the 280 by 280 world grid.')
    points = np.array([(s.x,s.y) for s in spawns])
    half = np.array([settings.view_width/2, settings.view_height/2])
    # Keep every covered dot away from the screen edge; do not chain clusters
    # whose end points cannot actually fit into the same camera rectangle.
    usable = half - min(.6, min(half)/3)
    offsets = np.array([(x,y) for x in np.arange(-usable[0],usable[0]+.01,max(.5,settings.view_width/20))
                        for y in np.arange(-usable[1],usable[1]+.01,max(.5,settings.view_height/30))] + [(0.,0.)])
    # Sample the whole footprint, not merely whether its centre is walkable.
    footprint = np.array([(x,y) for x in np.arange(-half[0]+.25,half[0],max(.5,settings.view_width/30))
                          for y in np.arange(-half[1]+.25,half[1],max(.5,settings.view_height/40))])
    # Compare all anchors before assigning a group, so a neighbouring pair
    # cannot steal one of the four tightly packed Demonbind Tower dots.
    remaining = set(range(len(spawns)))
    grouped = []
    while remaining:
        ids = sorted(remaining)
        best_count = -1
        for anchor in ids:
            # Keep only this anchor's neighbours; avoid a cubic world-sized
            # candidate tensor when camera settings use a wider footprint.
            local = [i for i in ids if (np.abs(points[i]-points[anchor])<=2*usable+1e-7).all()]
            candidates = np.clip(points[anchor]+offsets,[.5,.5],[MAP_SIZE-.5,MAP_SIZE-.5])
            covers = (np.abs(candidates[:,None,:]-points[local])<=usable+1e-7).all(axis=2)
            tiles = np.floor(candidates).astype(int)
            counts = covers.sum(axis=1)
            counts[~ground[tiles[:,1],tiles[:,0]]] = -1
            for px,py,radius in CAMERA_CLICK_EXCLUSIONS:
                counts[((candidates-[px,py])**2).sum(axis=1)<radius**2] = -1
            if counts.max()>best_count:
                best_count = int(counts.max())
                best = (candidates,covers,counts,local)
        if best_count<1:
            raise ValueError('A spawn has no playable camera centre inside its view.')
        candidates,covers,counts,ids = best
        possible = np.flatnonzero(counts == best_count)
        scored = []
        for k in possible:
            center = candidates[k]
            members = [ids[j] for j in np.flatnonzero(covers[k])]
            middle = (points[members].min(axis=0)+points[members].max(axis=0))/2
            samples = center+footprint
            valid = ((samples>=0)&(samples<MAP_SIZE)).all(axis=1)
            tiles = np.floor(samples[valid]).astype(int)
            area = int(ground[tiles[:,1],tiles[:,0]].sum())
            cx,cy = np.floor(center).astype(int)
            distance = float(np.sum((center-middle)**2))
            # Trade wasted border area against moving away from the group's
            # middle. Never shift so far that a covered dot leaves the view.
            score = (bool(ground[cy,cx]), area - 5*distance, -distance)
            scored.append((score,k,members))
        _,k,members = max(scored,key=lambda row:row[0])
        center = candidates[k]
        near = min(members,key=lambda i:float(np.sum((points[i]-center)**2)))
        cells = frozenset((math.floor(spawns[i].x),math.floor(spawns[i].y)) for i in members)
        grouped.append((min(members), Viewpoint(float(center[0]),float(center[1]),spawns[near].zone,cells)))
        remaining.difference_update(members)
    # Keep dataset order between groups; this is not a character travel route.
    views = tuple(view for _,view in sorted(grouped,key=lambda item:item[0]))
    cells = frozenset(cell for view in views for cell in view.cells)
    return PatrolPlan(spawns, settings, tuple(views), cells)


def approach_click(gem_center, frame_shape, settings=None):
    """One tile strictly left or right of the gem; never above or below.

    The game resolves the nearest reachable destination. If neither horizontal
    side avoids the HUD, return None rather than clicking another control.
    """
    settings = settings or PatrolSettings()
    h,w = frame_shape[:2]
    gx,gy = gem_center[0]*570/w,gem_center[1]*1029/h
    tile_width = 570/settings.view_width
    # Move inward: right of a left-half gem, left of a right-half gem.
    direction=1 if gx<285 else -1
    for dx in (direction*tile_width,-direction*tile_width):
        px,py=gx+dx,gy
        if not (40<px<520 and 280<py<760):continue
        if px>420 and py<470:continue
        return float(px),float(py)
    return None
