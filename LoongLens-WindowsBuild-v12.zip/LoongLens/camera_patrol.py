"""Offline camera coverage and map-input simulation. No desktop input APIs."""
from __future__ import annotations
from dataclasses import dataclass
import math

MAP_SIZE = 280


@dataclass(frozen=True)
class Spawn:
    x: float
    y: float
    zone: str


@dataclass(frozen=True)
class PatrolSettings:
    # About 83 x 151 map pixels in the supplied white rectangle / 12.45.
    view_width: float = 6.7
    view_height: float = 12.1
    variation: float = 10.
    inset: float = .5
    inspect_seconds: float = 5.

    def __post_init__(self):
        values = (self.view_width, self.view_height, self.variation,
                  self.inset, self.inspect_seconds)
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Use finite numbers for the preview settings.')
        if not (2 <= self.view_width <= 40 and 2 <= self.view_height <= 60):
            raise ValueError('View width must be 2–40 tiles; height must be 2–60.')
        if not (0 <= self.variation <= 20 and 0 <= self.inset <= 3):
            raise ValueError('Spawn variation must be 0–20 tiles; edge inset 0–3.')
        if min(self.view_width, self.view_height) - 2*self.inset < 1:
            raise ValueError('Leave at least one usable tile inside each view.')
        if not 1 <= self.inspect_seconds <= 30:
            raise ValueError('Inspection time must be 1–30 seconds.')


@dataclass(frozen=True)
class Viewpoint:
    x: float
    y: float
    near_zone: str
    cells: frozenset[tuple[int, int]]

    def bounds(self, settings, usable=False):
        margin = settings.inset if usable else 0.
        w, h = settings.view_width/2-margin, settings.view_height/2-margin
        return self.x-w, self.y-h, self.x+w, self.y+h


@dataclass(frozen=True)
class PatrolPlan:
    spawns: tuple[Spawn, ...]
    settings: PatrolSettings
    views: tuple[Viewpoint, ...]
    cells: frozenset[tuple[int, int]]
    route_distance: float

    @property
    def inspection_seconds(self):
        # Loading, map opening and dragging add time and are deliberately excluded.
        return len(self.views) * self.settings.inspect_seconds


def load_spawns(data):
    return tuple(Spawn(float(row['position']['x'])+.5,
                       float(row['position']['y'])+.5,
                       row.get('regionName', 'Loong Haven')) for row in data['gems'])


def target_cells(spawns, radius):
    """Every map tile touched by a radius disk, including partial edge tiles.

    Covering whole cells avoids gaps between sampled spawn positions. No terrain
    mask is applied: the screenshots do not establish where a gem cannot spawn.
    """
    cells = set()
    for spawn in spawns:
        if not (math.isfinite(spawn.x) and math.isfinite(spawn.y)
                and 0 <= spawn.x < MAP_SIZE and 0 <= spawn.y < MAP_SIZE):
            raise ValueError('Spawn coordinates must be inside the Loong Haven map.')
        for x in range(max(0, math.floor(spawn.x-radius)), min(MAP_SIZE, math.floor(spawn.x+radius)+1)):
            for y in range(max(0, math.floor(spawn.y-radius)), min(MAP_SIZE, math.floor(spawn.y+radius)+1)):
                dx = max(x-spawn.x, spawn.x-(x+1), 0)
                dy = max(y-spawn.y, spawn.y-(y+1), 0)
                if dx*dx+dy*dy <= radius*radius + 1e-9:
                    cells.add((x, y))
    return frozenset(cells)


def _distance(a, b):
    return math.hypot(a.x-b.x, a.y-b.y)


def _order_views(views):
    """Deterministic nearest-neighbour path, shortened with bounded 2-opt passes."""
    remaining = list(views)
    if not remaining:
        return ()
    current = min(remaining, key=lambda v: (v.y, v.x))
    route = [current]
    remaining.remove(current)
    while remaining:
        current = min(remaining, key=lambda v: (_distance(current, v), v.y, v.x))
        route.append(current)
        remaining.remove(current)
    for _ in range(2):
        changed = False
        for i in range(1, len(route)-2):
            for j in range(i+1, min(i+70, len(route)-1)):
                old = _distance(route[i-1], route[i])+_distance(route[j], route[j+1])
                new = _distance(route[i-1], route[j])+_distance(route[i], route[j+1])
                if new+1e-8 < old:
                    route[i:j+1] = reversed(route[i:j+1])
                    changed = True
        if not changed:
            break
    return tuple(route)


def build_plan(spawns, settings=None):
    settings = settings or PatrolSettings()
    spawns = tuple(spawns)
    cells = target_cells(spawns, settings.variation)
    if not cells:
        return PatrolPlan(spawns, settings, (), cells, 0.)
    width = math.floor(settings.view_width - 2*settings.inset + 1e-9)
    height = math.floor(settings.view_height - 2*settings.inset + 1e-9)
    # Try all tile-aligned offsets of a non-overlapping covering lattice.
    # This bounds planning work and guarantees coverage, without claiming an
    # optimal set cover. A view may cover parts of several spawn disks.
    best, best_key = None, None
    def offsets(size):
        return range(size) if size <= 12 else sorted({round(i*(size-1)/11) for i in range(12)})
    for ox in offsets(width):
        for oy in offsets(height):
            blocks = {}
            for x, y in cells:
                key = (x-ox)//width, (y-oy)//height
                blocks.setdefault(key, set()).add((x, y))
            score = len(blocks), ox, oy
            if best_key is None or score < best_key:
                best, best_key = blocks, score
    if len(best)>2000:
        raise ValueError('That geometry needs more than 2,000 camera views. Increase the view size or reduce spawn variation.')
    views = []
    for key in sorted(best):
        group = best[key]
        x = (min(p[0] for p in group)+max(p[0] for p in group)+1)/2
        y = (min(p[1] for p in group)+max(p[1] for p in group)+1)/2
        nearest = min(spawns, key=lambda s: math.hypot(s.x-x, s.y-y))
        views.append(Viewpoint(x, y, nearest.zone, frozenset(group)))
    ordered = _order_views(views)
    distance = sum(_distance(a,b) for a,b in zip(ordered, ordered[1:]))
    return PatrolPlan(spawns, settings, ordered, cells, distance)


@dataclass(frozen=True)
class MapStep:
    action: str
    center: tuple[float, float]
    start: tuple[float, float] | None = None
    end: tuple[float, float] | None = None


def simulate_map_steps(center, target, scale=12.45):
    """Plan reference-client drags and a click; never dispatch real inputs.

    Map drags start in clear central terrain and stay away from the legend,
    zoom bar and bottom navigation. Actual dragging and camera edge clamping
    still need live calibration in a later version.
    """
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('Map scale must be positive.')
    if not all(math.isfinite(v) and 0 <= v <= MAP_SIZE for v in (*center, *target)):
        raise ValueError('Map centers must be finite coordinates inside the map.')
    x, y = center
    dx, dy = (x-target[0])*scale, (target[1]-y)*scale
    count = max(1, math.ceil(max(abs(dx)/200, abs(dy)/280)))
    steps = [MapStep('Open map', (x,y))]
    if abs(dx)+abs(dy) > 1e-7:
        sx, sy = dx/count, dy/count
        for _ in range(count):
            x -= sx/scale
            y += sy/scale
            steps.append(MapStep('Pan map', (x,y), (285.,500.), (285.+sx,500.+sy)))
    steps.extend([MapStep('Select view', target, (285.,500.), (285.,500.)),
                  MapStep('Close map', target), MapStep('Inspect scene', target)])
    return tuple(steps)
