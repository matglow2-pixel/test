"""Optional screenshot-only camera patrol preview; isolated from live Gem Watch."""
from __future__ import annotations
import math
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageDraw, ImageTk
from camera_patrol import PatrolSettings, build_plan, load_spawns, simulate_map_steps
from resources import ROOT

TEAL = '#67efd3'
PINK = '#f45bd0'


class PatrolPanel:
    def __init__(self, parent, data):
        self.parent = parent
        self.root = parent.winfo_toplevel()
        self.spawns = load_spawns(data)
        self.settings = PatrolSettings()
        self.plan = None
        self.enabled = tk.BooleanVar(value=False)
        self.hotkey = tk.StringVar(value='F8')
        self.summary = tk.StringVar(value='Enable the preview to calculate camera views.')
        self.location = tk.StringVar(value='No view selected')
        self.status = tk.StringVar(value='Preview disabled. Gem Watch and the overlay work normally.')
        self.note = tk.StringVar(value='No gameplay screenshot loaded.')
        self.index = -1
        self.map_center = (160.,140.)
        self.step = None
        self.running = False
        self.auto = False
        self.closed = False
        self.after_id = None
        self.poll_id = None
        self.generation = 0
        self.result_queue = queue.Queue()
        self.atlas = self.atlas_small = None
        self.detail = None
        self.scene = None
        self.scene_boxes = ()
        self.detector = None
        self.bindings = []
        self._build()
        for key in ('F6','F7','F8','F9','F10'):
            sequence = '<'+key+'>'
            binding = self.root.bind(sequence, lambda event,k=key:self._key(k), add='+')
            self.bindings.append((sequence,binding))
        self.bindings.append(('<Escape>', self.root.bind('<Escape>', self._escape, add='+')))
        self.parent.bind('<Destroy>', self._destroyed, add='+')

    def _build(self):
        body = ttk.Frame(self.parent,padding=(18,14))
        body.pack(fill='both',expand=True)
        ttk.Label(body,text='CAMERA PATROL',font=('Segoe UI',20,'bold')).pack(anchor='w')
        ttk.Label(body,text='Screenshot simulation • no BlueStacks input',style='Muted.TLabel').pack(anchor='w',pady=(0,8))
        ttk.Checkbutton(body,text='Enable patrol preview',variable=self.enabled,command=self.toggle).pack(anchor='w')
        row = ttk.Frame(body);row.pack(fill='x')
        ttk.Label(row,text='Advance key').pack(side='left')
        ttk.Combobox(row,values=('F6','F7','F8','F9','F10'),textvariable=self.hotkey,
                     state='readonly',width=5).pack(side='left',padx=8)
        self.settings_button = ttk.Button(row,text='Coverage settings',command=self.show_settings)
        self.settings_button.pack(side='right')
        ttk.Label(body,textvariable=self.summary,wraplength=440,style='Muted.TLabel').pack(anchor='w',pady=(8,5))
        self.canvas = tk.Canvas(body,height=320,bg='#0d1219',highlightthickness=0)
        self.canvas.pack(fill='both',expand=True,pady=4)
        self.canvas.bind('<Configure>',lambda event:self.draw())
        self.canvas.bind('<Button-1>',self.pick_view)
        ttk.Label(body,textvariable=self.location,wraplength=440,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(5,2))
        ttk.Label(body,textvariable=self.status,wraplength=440,style='Muted.TLabel').pack(anchor='w',pady=(0,6))
        row=ttk.Frame(body);row.pack(fill='x')
        self.play_button=ttk.Button(row,text='Play preview',command=self.play)
        self.play_button.pack(side='left')
        self.next_button=ttk.Button(row,text='Next view',command=self.next_view)
        self.next_button.pack(side='left',padx=6)
        ttk.Button(row,text='Stop (Esc)',command=self.stop).pack(side='left')
        ttk.Button(row,text='Reset',command=self.reset).pack(side='right')
        row=ttk.Frame(body);row.pack(fill='x',pady=6)
        self.detail_button=ttk.Button(row,text='Open screenshot preview',command=self.show_detail)
        self.detail_button.pack(side='left')
        ttk.Label(body,text='Click the map to preview a nearby view. Keys work with this tab focused.\nPink: spawns. White: camera view. Teal: usable area. No live input.',
                  style='Muted.TLabel',font=('Segoe UI',9),wraplength=440).pack(anchor='w')
        self._buttons()

    def _buttons(self, busy=False):
        ready = self.enabled.get() and self.plan is not None and not busy
        for button in (self.play_button,self.next_button,self.detail_button):
            button.configure(state='normal' if ready else 'disabled')
        self.settings_button.configure(state='disabled' if busy else 'normal')

    def toggle(self):
        self.stop(silent=True)
        self.generation += 1
        if not self.enabled.get():
            self.status.set('Preview disabled. Gem Watch and the overlay work normally.')
            self._buttons();self.draw();return
        if self.plan is None:
            self.rebuild()
        else:
            self.status.set('Ready. Next view simulates one camera selection.')
            self._buttons();self.draw()

    def rebuild(self):
        self.stop(silent=True)
        self.generation += 1
        generation = self.generation
        settings = self.settings
        self.plan = None
        self.index = -1
        self.summary.set('Calculating coverage for all 86 known spawn locations…')
        self._buttons(busy=True)
        def calculate():
            try:
                plan=build_plan(self.spawns,settings)
                self.result_queue.put((generation,plan,None))
            except Exception as exc:
                self.result_queue.put((generation,None,str(exc)))
        threading.Thread(target=calculate,daemon=True,name='patrol-preview-plan').start()
        if self.poll_id is None:
            self.poll_id=self.root.after(50,self._poll)

    def _poll(self):
        self.poll_id=None
        if self.closed:return
        found=False
        while True:
            try:generation,plan,error=self.result_queue.get_nowait()
            except queue.Empty:break
            if generation != self.generation:continue
            found=True
            if error:
                self.summary.set(error);self._buttons();continue
            self.plan=plan
            minutes=plan.inspection_seconds/60
            self.summary.set(f'{len(plan.spawns)} spawn points • {len(plan.views)} camera views • ±{self.settings.variation:g} tiles\n'
                             f'{minutes:.1f} min inspection only; loading and panning add time.')
            self.status.set('Ready. Next view simulates one camera selection.')
            self._buttons();self.draw()
        if not found and self.enabled.get() and self.plan is None:
            self.poll_id=self.root.after(50,self._poll)
        else:
            self._buttons()

    def _active(self):
        if not self.enabled.get():return False
        focus=self.root.focus_get()
        if focus is None:return False
        if self.detail is not None and self.detail.winfo_exists():
            if focus.winfo_toplevel()==self.detail:return True
        if focus.winfo_toplevel()!=self.root:return False
        notebook=self.parent.master
        return str(notebook.select())==str(self.parent)

    def _key(self,key):
        if key==self.hotkey.get() and self._active():
            self.next_view();return 'break'

    def _escape(self,event=None):
        if self._active():
            self.stop();return 'break'

    def _load_atlas(self):
        if self.atlas is None:
            with Image.open(ROOT/'loong_haven_default_atlas.png') as source:
                self.atlas=source.convert('RGB')
            self.atlas_small=self.atlas.copy()
            self.atlas_small.thumbnail((900,900),Image.Resampling.LANCZOS)

    def draw(self):
        if self.closed:return
        canvas=self.canvas
        canvas.delete('all')
        w,h=max(1,canvas.winfo_width()),max(1,canvas.winfo_height())
        if not self.enabled.get() or self.plan is None:
            canvas.create_text(w/2,h/2,text='Enable preview to see the camera route',fill='#95a5bc',width=max(100,w-30))
            return
        self._load_atlas()
        side=max(1,min(w-8,h-8))
        image=self.atlas_small.resize((side,side),Image.Resampling.LANCZOS)
        self.overview_photo=ImageTk.PhotoImage(image)
        ox,oy=(w-side)/2,(h-side)/2
        canvas.create_image(ox,oy,image=self.overview_photo,anchor='nw')
        scale=side/280
        def p(x,y):return ox+x*scale,oy+(279-y)*scale
        # Visited route only, so hundreds of future segments do not obscure terrain.
        visited=self.plan.views[:max(0,self.index+1)]
        if len(visited)>1:
            points=[v for view in visited for v in p(view.x,view.y)]
            canvas.create_line(*points,fill='#67a59a',width=1)
        for spawn in self.spawns:
            x,y=p(spawn.x,spawn.y)
            canvas.create_oval(x-2,y-2,x+2,y+2,fill=PINK,outline='')
        if 0 <= self.index < len(self.plan.views):
            view=self.plan.views[self.index]
            for usable,color in ((False,'#ffffff'),(True,TEAL)):
                left,bottom,right,top=view.bounds(self.settings,usable)
                canvas.create_rectangle(*p(left,top),*p(right,bottom),outline=color,width=1)
            x,y=p(view.x,view.y)
            canvas.create_oval(x-3,y-3,x+3,y+3,fill=TEAL,outline='#101620')
        self.draw_detail()

    def show_settings(self):
        if hasattr(self,'settings_window') and self.settings_window is not None and self.settings_window.winfo_exists():
            self.settings_window.lift();return
        window=self.settings_window=tk.Toplevel(self.root)
        window.title('Patrol coverage settings');window.transient(self.root)
        body=ttk.Frame(window,padding=20);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Screenshot measurements are provisional.',font=('Segoe UI',11,'bold')).grid(row=0,column=0,columnspan=2,sticky='w')
        ttk.Label(body,text='White rectangle ≈83×151 map pixels at default zoom.\nA 12.45 pixel/tile map gives ≈6.7×12.1 tiles per view.',style='Muted.TLabel').grid(row=1,column=0,columnspan=2,sticky='w',pady=8)
        fields={}
        labels=(('view_width','Camera width (tiles)'),('view_height','Camera height (tiles)'),
                ('variation','Spawn variation radius (tiles)'),('inset','Reserved edge margin (tiles)'),
                ('inspect_seconds','Inspection time (seconds)'))
        for row,(name,label) in enumerate(labels,2):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=5)
            entry=ttk.Entry(body,width=10);entry.insert(0,str(getattr(self.settings,name)))
            entry.grid(row=row,column=1,padx=(15,0));fields[name]=entry
        ttk.Label(body,text='Variation 0 checks marked tiles only. Default 10 covers a\n10-tile disk around every spawn. HUD/chat and camera edge\nbehaviour still require calibration; this is a coverage model.',style='Muted.TLabel').grid(row=7,column=0,columnspan=2,sticky='w',pady=10)
        error=tk.StringVar()
        ttk.Label(body,textvariable=error,wraplength=400).grid(row=8,column=0,columnspan=2,sticky='w')
        def apply():
            try:settings=PatrolSettings(**{name:float(field.get()) for name,field in fields.items()})
            except ValueError as exc:error.set(str(exc));return
            self.settings=settings;window.destroy()
            if self.enabled.get():self.rebuild()
            else:self.plan=None
        ttk.Button(body,text='Apply settings',command=apply).grid(row=9,column=0,sticky='w',pady=(8,0))
        ttk.Button(body,text='Cancel',command=window.destroy).grid(row=9,column=1,sticky='e',pady=(8,0))

    def pick_view(self,event):
        if not self.enabled.get() or self.plan is None:return
        w,h=self.canvas.winfo_width(),self.canvas.winfo_height()
        side=max(1,min(w-8,h-8));ox,oy=(w-side)/2,(h-side)/2
        if not (ox<=event.x<=ox+side and oy<=event.y<=oy+side):return
        x,y=(event.x-ox)*280/side,279-(event.y-oy)*280/side
        index=min(range(len(self.plan.views)),key=lambda i:math.hypot(self.plan.views[i].x-x,self.plan.views[i].y-y))
        self.stop(silent=True);self.index=index-1
        self.next_view()

    def play(self):
        if not self.enabled.get() or self.plan is None:return
        self.auto=True
        if not self.running:self.next_view(auto=True)

    def next_view(self,auto=False):
        if self.running or not self.enabled.get() or self.plan is None:return
        if not auto:self.auto=False
        if self.index+1 >= len(self.plan.views):
            self.auto=False;self.status.set('Preview complete. Reset to start again.');return
        self.index+=1
        view=self.plan.views[self.index]
        self.location.set(f'View {self.index+1}/{len(self.plan.views)} • center ({view.x:g},{view.y:g})\nNear {view.near_zone} — camera area, not an exact gem tile')
        self.steps=simulate_map_steps(self.map_center,(view.x,view.y))
        self.step_index=0;self.running=True
        self._advance_step()

    def _advance_step(self):
        self.after_id=None
        if self.closed or not self.running or not self.enabled.get():return
        if self.step_index>=len(self.steps):
            self.running=False
            self.status.set('Inspection preview finished. Advance when ready.')
            if self.auto:self.next_view(auto=True)
            return
        self.step=self.steps[self.step_index];self.step_index+=1
        self.map_center=self.step.center
        text=self.step.action
        if self.step.action=='Pan map':
            a,b=self.step.start,self.step.end
            text+=f' • simulated drag ({a[0]:.0f},{a[1]:.0f}) → ({b[0]:.0f},{b[1]:.0f})'
        elif self.step.action=='Inspect scene':
            text+=f' • {self.settings.inspect_seconds:g}s • no live capture'
            if self.scene_boxes:
                self.auto=False
                text+=' • photo has candidates: autoplay paused'
        self.status.set(text)
        self.draw()
        delay=round(self.settings.inspect_seconds*1000) if self.step.action=='Inspect scene' else 300
        self.after_id=self.root.after(delay,self._advance_step)

    def stop(self,silent=False):
        if self.after_id is not None:
            self.root.after_cancel(self.after_id);self.after_id=None
        self.running=False;self.auto=False
        if not silent:self.status.set('Preview stopped. No game inputs were sent.')

    def reset(self):
        self.stop(silent=True)
        self.index=-1;self.map_center=(160.,140.);self.step=None
        self.location.set('No view selected')
        self.status.set('Ready. Next view simulates one camera selection.' if self.enabled.get() else 'Preview disabled.')
        self.draw()

    def show_detail(self):
        if not self.enabled.get() or self.plan is None:return
        if self.detail is not None and self.detail.winfo_exists():self.detail.lift();return
        self.detail=tk.Toplevel(self.root)
        self.detail.title('Camera Patrol · screenshot simulation')
        self.detail.geometry('1020x780');self.detail.minsize(850,650)
        for key in ('F6','F7','F8','F9','F10'):
            self.detail.bind('<'+key+'>',lambda event,k=key:self._key(k))
        self.detail.bind('<Escape>',self._escape)
        body=ttk.Frame(self.detail,padding=14);body.pack(fill='both',expand=True)
        ttk.Label(body,text='SCREENSHOT SIMULATION',font=('Segoe UI',16,'bold')).pack(anchor='w')
        ttk.Label(body,textvariable=self.location).pack(anchor='w',pady=4)
        row=ttk.Frame(body);row.pack(fill='both',expand=True)
        left=ttk.Frame(row);left.pack(side='left',fill='both',expand=True)
        right=ttk.Frame(row);right.pack(side='left',fill='both',expand=True,padx=(14,0))
        ttk.Label(left,text='Map screenshot • proposed pan / click').pack(anchor='w')
        ttk.Label(right,text='Optional gameplay screenshot • detector test').pack(anchor='w')
        self.map_canvas=tk.Canvas(left,bg='#0d1219',highlightthickness=0)
        self.map_canvas.pack(fill='both',expand=True)
        self.scene_canvas=tk.Canvas(right,bg='#0d1219',highlightthickness=0)
        self.scene_canvas.pack(fill='both',expand=True)
        self.map_canvas.bind('<Configure>',lambda event:self.draw_detail())
        self.scene_canvas.bind('<Configure>',lambda event:self.draw_scene())
        ttk.Label(right,textvariable=self.note,wraplength=390,style='Muted.TLabel').pack(anchor='w',pady=4)
        ttk.Button(right,text='Load gameplay screenshot',command=self.load_scene).pack(anchor='w')
        ttk.Label(body,textvariable=self.status,wraplength=960).pack(anchor='w',pady=(8,4))
        row=ttk.Frame(body);row.pack(fill='x')
        ttk.Button(row,text='Next view',command=self.next_view).pack(side='left')
        ttk.Button(row,text='Stop (Esc)',command=self.stop).pack(side='left',padx=8)
        ttk.Button(row,text='Close preview',command=self.detail.destroy).pack(side='right')
        ttk.Label(body,text='Uses the bundled atlas stitched from map screenshots. No remote gameplay is generated.\nLoaded photos are tested independently; they do not create history entries or confirm coverage.',style='Muted.TLabel').pack(anchor='w',pady=(8,0))
        self.draw_detail();self.draw_scene()

    def draw_detail(self):
        if self.detail is None or not self.detail.winfo_exists():return
        self._load_atlas()
        # Consistent with the existing overlay's x+, y-up atlas transform.
        x,y=self.map_center;scale=12.45
        cx,cy=x*scale,(279-y)*scale
        image=self.atlas.crop((round(cx-285),round(cy-500),round(cx+285),round(cy+529)))
        pen=ImageDraw.Draw(image)
        if self.index>=0 and self.plan is not None:
            view=self.plan.views[self.index]
            px,py=(view.x-x)*scale+285,-(view.y-y)*scale+500
            left,top=px-self.settings.view_width*scale/2,py-self.settings.view_height*scale/2
            right,bottom=px+self.settings.view_width*scale/2,py+self.settings.view_height*scale/2
            pen.rectangle((left,top,right,bottom),outline='white',width=3)
            pen.ellipse((px-6,py-6,px+6,py+6),fill=TEAL,outline='black')
        if self.step is not None and self.step.action=='Pan map':
            a,b=self.step.start,self.step.end
            pen.line((*a,*b),fill='#ffcd72',width=5)
            pen.ellipse((b[0]-7,b[1]-7,b[0]+7,b[1]+7),fill='#ffcd72')
        pen.rectangle((0,0,569,45),fill='#101620')
        pen.text((14,14),'SIMULATED MAP / NO LIVE INPUT',fill='white')
        self._draw_fitted(self.map_canvas,image,'map_photo')
        self.draw_scene()

    def load_scene(self):
        path=filedialog.askopenfilename(parent=self.detail,title='Test a gameplay screenshot',filetypes=[('Images','*.png *.jpg *.jpeg *.bmp *.webp'),('All files','*.*')])
        if not path:return
        try:
            from gem_detector import GemDetector,load_image
            import cv2
            bgr=load_image(path)
            if self.detector is None:self.detector=GemDetector()
            boxes=self.detector.detect(bgr,exclude_hud=False)
            self.scene=Image.fromarray(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB))
            self.scene_boxes=boxes
            self.note.set(f'{len(boxes)} gem candidate(s) in this photo. No history saved.\nPhoto is independent of the selected map viewpoint.')
            self.draw_scene()
        except (OSError,ValueError) as exc:
            messagebox.showerror('Screenshot test failed',str(exc),parent=self.detail)

    def draw_scene(self):
        if self.detail is None or not self.detail.winfo_exists():return
        if self.scene is None:
            c=self.scene_canvas;c.delete('all')
            c.create_text(max(1,c.winfo_width())/2,max(1,c.winfo_height())/2,
                          text='Load a real gameplay screenshot\nto test the existing gem detector.\n\nThe atlas cannot show actual gem spawns.',
                          fill='#95a5bc',justify='center',width=max(120,c.winfo_width()-30))
            return
        image=self.scene.copy();pen=ImageDraw.Draw(image)
        for box in self.scene_boxes:
            pen.rectangle((box.x,box.y,box.x+box.width,box.y+box.height),outline=PINK,width=3)
        self._draw_fitted(self.scene_canvas,image,'scene_photo')

    def _draw_fitted(self,canvas,image,attribute):
        w,h=max(1,canvas.winfo_width()),max(1,canvas.winfo_height())
        image.thumbnail((w,h),Image.Resampling.LANCZOS)
        photo=ImageTk.PhotoImage(image);setattr(self,attribute,photo)
        canvas.delete('all');canvas.create_image(w/2,h/2,image=photo)

    def _destroyed(self,event):
        if event.widget==self.parent:self.close()

    def close(self):
        if self.closed:return
        self.stop(silent=True);self.closed=True;self.generation+=1
        if self.poll_id is not None:self.root.after_cancel(self.poll_id);self.poll_id=None
        for sequence,binding in self.bindings:
            self.root.unbind(sequence,binding)
        for window in (self.detail,getattr(self,'settings_window',None)):
            if window is not None and window.winfo_exists():window.destroy()
