import json
import math
from pathlib import Path
import pytest
from camera_patrol import (Spawn, PatrolSettings, build_plan, load_spawns,
                           target_cells, simulate_map_steps)


@pytest.fixture(scope='module')
def real_plan():
    data=json.loads((Path(__file__).parents[1]/'loong_haven_map_data.json').read_text())
    return build_plan(load_spawns(data))


def test_all_86_spawn_disks_covered_by_whole_tiles(real_plan):
    assert len(real_plan.spawns)==86
    covered=set()
    for view in real_plan.views:
        left,bottom,right,top=view.bounds(real_plan.settings,usable=True)
        for x,y in view.cells:
            assert left-1e-8<=x and x+1<=right+1e-8
            assert bottom-1e-8<=y and y+1<=top+1e-8
        covered.update(view.cells)
    assert covered==real_plan.cells
    # No overlapping spawn disk or route ordering silently discards coverage.
    for spawn in real_plan.spawns:
        for degrees in range(0,360,9):
            angle=math.radians(degrees)
            x,y=spawn.x+9.999*math.cos(angle),spawn.y+9.999*math.sin(angle)
            if 0<=x<280 and 0<=y<280:
                assert (math.floor(x),math.floor(y)) in covered


def test_inspection_estimate_excludes_unmeasured_loading(real_plan):
    assert real_plan.inspection_seconds==len(real_plan.views)*5
    assert real_plan.route_distance>0
    assert len(real_plan.views)>86  # This measured camera is small vs a 10-tile disk.


def test_impractically_small_view_rejected_before_route_search(real_plan):
    with pytest.raises(ValueError,match='2,000'):
        build_plan(real_plan.spawns,PatrolSettings(view_width=2,view_height=2))


def test_zero_spread_is_explicitly_only_marked_tiles(real_plan):
    exact=build_plan(real_plan.spawns,PatrolSettings(variation=0))
    assert len(exact.cells)==86
    assert len(exact.views)<len(real_plan.views)


def test_partial_edge_tiles_are_included_not_just_centers():
    cells=target_cells((Spawn(10.5,10.5,'A'),),1.)
    assert (9,9) in cells  # Disk reaches a corner even though its center is outside.
    assert (8,10) not in cells


def test_shared_spawn_disks_deduplicate_and_map_edges_stay_bounded():
    spawn=Spawn(.5,279.5,'edge')
    a=build_plan((spawn,))
    b=build_plan((spawn,spawn))
    assert a.cells==b.cells and a.views==b.views
    assert all(0<=x<280 and 0<=y<280 for x,y in a.cells)


def test_route_is_deterministic_and_handles_no_spawns():
    spawns=(Spawn(10.5,20.5,'A'),Spawn(12.5,21.5,'B'),Spawn(100.5,110.5,'C'))
    assert build_plan(spawns)==build_plan(spawns)
    assert build_plan(()).views==()
    assert build_plan(()).inspection_seconds==0


@pytest.mark.parametrize('values',[
    {'view_width':float('nan')},{'view_height':float('inf')},
    {'variation':-1},{'variation':21},{'inspect_seconds':0},
    {'view_width':2,'inset':1},{'view_height':61},
])
def test_bad_geometry_rejected(values):
    with pytest.raises(ValueError):PatrolSettings(**values)


def test_whole_map_pan_converges_with_safe_drag_endpoints():
    start,target=(260.,5.),(10.,270.)
    steps=simulate_map_steps(start,target)
    assert steps[0].action=='Open map'
    assert [s.action for s in steps[-3:]]==['Select view','Close map','Inspect scene']
    previous=start
    drags=[s for s in steps if s.action=='Pan map']
    assert len(drags)>1
    for step in drags:
        a,b=step.start,step.end
        assert 14<b[0]<519 and 233<b[1]<788
        dx,dy=b[0]-a[0],b[1]-a[1]
        assert step.center==pytest.approx((previous[0]-dx/12.45,previous[1]+dy/12.45))
        previous=step.center
    assert previous==pytest.approx(target)
    assert steps[-1].center==target
    assert steps[-3].start==(285.,500.)


def test_same_view_does_not_pan_or_walk_character():
    steps=simulate_map_steps((100.,100.),(100.,100.))
    assert [s.action for s in steps]==['Open map','Select view','Close map','Inspect scene']
    with pytest.raises(ValueError):simulate_map_steps((0,0),(float('nan'),10))


@pytest.mark.parametrize('target',[(0.,0.),(280.,0.),(0.,280.),(280.,280.)])
def test_drag_endpoints_avoid_legend_and_zoom_bar_in_every_direction(target):
    for step in simulate_map_steps((140.,140.),target):
        if step.action=='Pan map':
            x,y=step.end
            assert 14<x<519 and 233<y<788
