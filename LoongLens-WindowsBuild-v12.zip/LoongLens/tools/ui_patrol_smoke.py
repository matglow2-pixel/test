"""Exercise the real combined app's offline patrol with simulated Windows APIs."""
from pathlib import Path
import contextlib
import json
import os
import sys
import tempfile
import time
import types

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import tkinter as tk
from tkinter import ttk
from PIL import ImageGrab
from smoke_backend import install
install()
sys.modules['winsound']=types.SimpleNamespace(Beep=lambda *a:None,MessageBeep=lambda *a:None,MB_ICONEXCLAMATION=48)
sys.modules['mss']=types.SimpleNamespace(mss=lambda:contextlib.nullcontext(None))
folder=Path(tempfile.mkdtemp(prefix='patrol-ui-',dir=ROOT/'artifacts'))
os.environ['XDG_CACHE_HOME']=str(folder)
import patrol_panel
import loong_lens
from camera_patrol import PatrolSettings

panels=[]
original_panel_init=patrol_panel.PatrolPanel.__init__
def panel_init(panel,*args,**kwargs):
    original_panel_init(panel,*args,**kwargs);panels.append(panel)
patrol_panel.PatrolPanel.__init__=panel_init
original_root_init=tk.Tk.__init__
errors=[];done=[]
def root_init(root,*args,**kwargs):
    original_root_init(root,*args,**kwargs)
    def failed(kind,value,trace):
        import traceback
        errors.append(''.join(traceback.format_exception(kind,value,trace)));root.destroy()
    root.report_callback_exception=failed
    def begin():
        p=panels[0]
        assert not p.enabled.get() and p.plan is None
        p.settings=PatrolSettings(inspect_seconds=1)
        p.enabled.set(True);p.toggle()
        root.after(50,ready)
    def ready():
        p=panels[0]
        if p.plan is None:root.after(50,ready);return
        assert len(p.plan.views)==658
        assert not p.running and p.index==-1
        root.geometry('490x780');root.update_idletasks()
        for button in (p.play_button,p.next_button,p.detail_button):
            assert button.winfo_rooty()+button.winfo_height()<=root.winfo_rooty()+root.winfo_height()
        assert p.canvas.winfo_height()>=200
        root.geometry('500x820')
        p.show_detail()
        root.after(100,hotkeys)
    def hotkeys():
        p=panels[0]
        p.detail.focus_force()
        p.detail.event_generate('<F8>')
        root.after(50,stop)
    def stop():
        p=panels[0]
        assert p.running and p.index==0
        p.detail.event_generate('<Escape>')
        assert not p.running and p.after_id is None
        p.auto=True
        p.next_view(auto=True)
        p.stop()
        assert not p.auto and not p.running
        p.reset()
        # Jump directly to a northern view, without stepping through 658 views.
        p.index=min(range(len(p.plan.views)),key=lambda i:abs(p.plan.views[i].y-220))-1
        p.next_view();p.stop()
        # Use an actual supplied gameplay screenshot and the unmodified detector.
        from tkinter import filedialog
        example=ROOT.parent/'gem-examples/GemsPictures/IMG_1401.png'
        original=filedialog.askopenfilename
        filedialog.askopenfilename=lambda **kw:str(example)
        try:p.load_scene()
        finally:filedialog.askopenfilename=original
        assert len(p.scene_boxes)>=1
        # Static-photo candidates pause autoplay, without creating sighting rows.
        view=p.plan.views[p.index]
        p.steps=(types.SimpleNamespace(action='Inspect scene',center=(view.x,view.y)),)
        p.step_index=0;p.running=True;p.auto=True;p._advance_step()
        assert not p.auto
        p.stop()
        p.status.set('Simulation verified • preview stopped • no live input')
        root.after(200,capture)
    def capture():
        p=panels[0]
        mocked_platform=sys.platform
        sys.platform=old_platform
        try:ImageGrab.grab().save(folder/'patrol-preview.png')
        finally:sys.platform=mocked_platform
        db=folder/'LoongLens/sightings.sqlite3'
        import sqlite3
        with sqlite3.connect(db) as con:
            assert con.execute('SELECT COUNT(*) FROM sightings').fetchone()[0]==0
        # Disable cancels the next callback and blocks keys/advancement.
        p.play();p.enabled.set(False);p.toggle()
        before=p.index;p.next_view();assert p.index==before and not p.running
        assert p.after_id is None
        # Delayed planning result cannot reactivate a disabled preview.
        p.plan=None;p.enabled.set(True);p.rebuild()
        p.enabled.set(False);p.toggle()
        root.after(1800,disabled)
    def disabled():
        p=panels[0]
        assert p.plan is None and not p.enabled.get() and p.poll_id is None
        done.append(True)
        widgets=[]
        def visit(w):
            for c in w.winfo_children():widgets.append(c);visit(c)
        visit(root)
        next(w for w in widgets if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
    root.after(300,begin)
    root.after(25000,root.destroy)
tk.Tk.__init__=root_init
old_platform=sys.platform;sys.platform='win32'
try:loong_lens.main(['--tab','patrol'])
finally:
    sys.platform=old_platform
    tk.Tk.__init__=original_root_init
    patrol_panel.PatrolPanel.__init__=original_panel_init
if errors or not done:raise RuntimeError(f'Patrol GUI check failed: {errors}')
print('Patrol GUI passed: disabled startup, coverage, detail image, F8, Esc, photo detection, no history, disable during planning, exit.')
print(folder/'patrol-preview.png')
