"""Saved route identity, reduced totals and screenshot-guided fixed-order input."""
import contextlib
from dataclasses import replace
import json
import math
from types import SimpleNamespace
import threading
import cv2
import numpy as np
import pytest
from camera_patrol import Viewpoint
from patrol_live import LivePatrol,LiveRunner,LiveSettings
from patrol_route import load_fixed_route,route_pan_delta
from resources import ROOT,ResourceStore
from pose import Match
from test_live_patrol import setup


@pytest.fixture(scope='module')
def route():return load_fixed_route(ResourceStore().data)


def test_saved_path_preserves_original_numbers_and_removes_exactly_the_requested_three(route):
    assert len(route)==74 and sum(len(v.cells) for v in route)==83
    assert [v.route_number for v in route]==[n for n in range(1,78) if n not in (26,51,72)]
    assert route[0].near_zone=='Emerald Corner'
    assert not ({(49,34),(121,163),(205,186)} & set().union(*(v.cells for v in route)))
    assert route[24].route_number==25 and route[25].route_number==27
    assert route[48].route_number==50 and route[49].route_number==52
    assert route[68].route_number==71 and route[69].route_number==73
    assert len(ResourceStore().data['gems'])==86  # Exclusions affect sniping, not history/overlay data.


def test_fixed_order_does_not_choose_the_nearest_or_first_visible_remaining_point():
    engine,backend,events=setup()
    views=(Viewpoint(130.5,100.5,'First',frozenset({(130,100)}),1),
           Viewpoint(100.5,100.5,'Second',frozenset({(100,100)}),2))
    fixed=LivePatrol(views,engine.settings,engine.cancel,events.append,detector=engine.detector,
        locator=engine.locator,title=engine.title,clock=engine.clock)
    fixed.run(backend)
    assert [e['view'].route_number for e in events if e['kind']=='view']==[1,2]
    assert fixed.checked=={0,1} and any(i[0]=='drag' for i in backend.inputs)


@pytest.mark.parametrize('point',[(520,500),(10,500),(450,200),(280,100),(280,830)])
def test_gap_drag_reveals_target_with_shortest_clear_map_motion(point):
    delta=route_pan_delta(point,300)
    x,y=point[0]+delta[0],point[1]+delta[1]
    assert math.hypot(*delta)<=300.001
    assert 32<=x<=510 and 150<=y<=800 and not(x>=420 and y<=250)
    assert math.hypot(*delta)<math.dist(point,(285,500))


def test_long_gap_drag_is_bounded_and_held_endpoints_avoid_controls():
    dx,dy=route_pan_delta((1100,-800),300)
    assert math.hypot(dx,dy)==pytest.approx(300)
    for x,y in [(285-dx/2,500-dy/2),(285+dx/2,500+dy/2)]:
        assert 130<=x<=440 and 345<=y<=655


def test_fixed_route_repeats_identical_order_and_can_resume_without_restarting_at_one():
    engine,backend,events=setup()
    views=tuple(replace(v,route_number=i+1) for i,v in enumerate(engine.views))
    def emit(event):
        events.append(event)
        if event['kind']=='pass_complete' and event['passes']==2:runner.stop()
    runner=LiveRunner(views,lambda cancel:contextlib.nullcontext(backend),emit,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title;backend.cancel=runner.cancel
    assert runner.start(LiveSettings(),auto=False);runner.thread.join(5)
    assert runner.checked=={0}
    assert runner.start(LiveSettings(),repeat=True);runner.thread.join(5)
    assert not runner.running and runner.passes==2
    assert [e['view'].route_number for e in events if e['kind']=='view']==[1,2,1,2]


def test_complete_fixed_route_uses_recentered_atlas_screenshots_and_no_transit_camera_clicks(route):
    cv2.setNumThreads(2)
    atlas=cv2.imread(str(ROOT/'loong_haven_default_atlas.png'))
    class Backend:
        def __init__(self):
            self.center=(route[0].x,route[0].y);self.camera=self.center
            self.open=True;self.now=0.;self.visits=[];self.inputs=[];self.cache={}
            self.target=(123,(0,0,570,1029))
        def wait(self,t):self.now+=t
        def focus(self):pass
        def pose(self):return Match(12.45,285-self.center[0]*12.45,530+self.center[1]*12.45,20,0,[])
        def capture(self):
            if not self.open:return np.zeros((1029,570,3),np.uint8)
            key=tuple(self.center)
            if key not in self.cache:
                p=self.pose()
                f=cv2.warpAffine(atlas,np.float32([[1,0,p.tx],[0,1,p.ty-279*12.45]]),(570,1029))
                f[0,0]=255;self.cache[key]=f
            return self.cache[key]
        def click(self,p):
            self.inputs.append(('click',p))
            if not self.open:
                assert p==(480.,170.);self.open=True;self.center=self.camera;return
            if p==(64.,980.):self.open=False;return
            expected=route[len(self.visits)]
            known=self.pose();world=((p[0]-known.tx)/known.scale,(known.ty-p[1])/known.scale)
            assert math.dist(world,(expected.x,expected.y))<.4,(expected.route_number,world)
            assert 32<=p[0]<=510 and 150<=p[1]<=800 and not(p[0]>=420 and p[1]<=250)
            self.visits.append(expected.route_number);self.camera=(expected.x,expected.y)
        def drag(self,a,b):
            self.inputs.append(('drag',a,b));self.wait(.4)
            assert math.dist(a,b)<=300.01
            for x,y in (a,b):assert 130<=x<=440 and 345<=y<=655
            self.center=(self.center[0]-(b[0]-a[0])/12.45,self.center[1]+(b[1]-a[1])/12.45)
    backend=Backend();events=[]
    engine=LivePatrol(route,LiveSettings(),threading.Event(),events.append,
        detector=SimpleNamespace(detect=lambda *a,**kw:[]),
        locator=SimpleNamespace(locate=lambda f:backend.pose()),
        title=SimpleNamespace(score=lambda f:float(f[0,0,0]>0)),clock=lambda:backend.now)
    engine.run(backend)
    assert backend.visits==[v.route_number for v in route]
    assert len(engine.checked)==74
    # Exactly one camera selection per check; no B/R/removed-dot selections.
    assert sum(i[0]=='click' for i in backend.inputs)==74*3-1
    assert 0<sum(i[0]=='drag' for i in backend.inputs)<30
    assert engine.navigation.get('relative_updates',0)>0
    assert not any(e['kind']=='found' for e in events)


def test_pass_totals_finish_at_74_and_timer_stays_frozen(route):
    engine,backend,events=setup()
    runner=LiveRunner(route,lambda cancel:contextlib.nullcontext(backend),events.append,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title;backend.cancel=runner.cancel
    # Resume a pass at 73/74. The independent full-atlas test covers the whole
    # route; this case isolates the completion threshold and clock anchor.
    runner.checked.update(range(73));backend.center=(route[-1].x,route[-1].y)
    runner.stats.start();backend.clock.now+=100
    assert runner.start(LiveSettings());runner.thread.join(5)
    if runner.running:runner.stop();runner.thread.join(3)
    assert len(runner.checked)==74 and runner.passes==1, events[-1]
    assert [e['view'].route_number for e in events if e['kind']=='view']==[77]
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=60
    assert elapsed>=100 and runner.stats.snapshot()['elapsed']==elapsed
    assert not runner.start(LiveSettings())


def test_fixed_route_centre_in_locked_shading_is_skipped_without_substitute_click():
    engine,backend,events=setup()
    view=Viewpoint(100.5,100.5,'Fixed',frozenset({(102,100)}),1)
    original=backend.capture
    def capture():
        f=original()
        if backend.open:f[470:535,250:320]=(44,47,46)
        return f
    backend.capture=capture
    fixed=LivePatrol((view,),engine.settings,engine.cancel,events.append,detector=engine.detector,
        locator=engine.locator,title=engine.title,clock=engine.clock)
    fixed.run(backend)
    assert fixed.checked==fixed.skipped=={0} and not backend.inputs


def test_map_recentring_again_before_fixed_click_stops_without_input():
    engine,backend,events=setup()
    fixed=LivePatrol((replace(engine.views[0],route_number=1),),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    original=backend.capture;move=[False]
    def capture():
        f=original()
        if move[0]:f[250:800,30:515]=200
        return f
    backend.capture=capture
    def emit(event):
        events.append(event)
        if event['kind']=='status' and event['message'].startswith('Clicking'):move[0]=True
    fixed.emit=emit
    with pytest.raises(RuntimeError,match='map moved'):fixed.run(backend)
    assert not backend.inputs and not fixed.checked
