# Verification — Loong Lens v20

The app targets Windows 10 (2004+) / Windows 11 and BlueStacks at Loong Haven's default zoom. Linux checks use the pinned Python 3.12 environment and simulated desktop delivery. No live game input is sent by these checks.

## Fixed route and excluded totals

The bundled route follows the approved diagram's original order, beginning at Emerald Corner. Original route IDs 26 (Forsaken Lotus Pond), 51 (Jadetoad Isle) and 72 (Frosted Plain) are absent. The route has exactly 74 checks and 83 unique original spawn spots. All remaining camera targets retain their original coordinates and edge margins, including Loong Haven IV portal avoidance. IDs are not renumbered; the progress maximum is 74.

Route tests require this exact order even when a later target is closer or already visible, consistent repeated passes, resume from the first unfinished check, complete totals at 74, and a frozen completed-pass timer. The normal map overlay's original 86-location dataset and personal history are retained.

A full-route simulation renders actual atlas pixels, simulates map automatic recentering on reopening, uses real overlapping-screenshot registration and checks every camera click against an independent ground-truth viewport transform. It requires all 74 checks in order, exactly one camera selection per check, no selections at excluded points, fewer than 30 map drags and no B/R camera selections. Initial/global poses are supplied by the simulated backend; this is not a proof that absolute atlas recognition works at every viewpoint.

## Faster mouse dragging and alignment

Native drag sequence checks require one mouse-down held throughout movement, final movement to the requested endpoint, a stationary 0.18-second hold, and guaranteed mouse-up on cancellation. The motion now uses 4–12 waits of 0.02 seconds instead of 18 waits of 0.03 seconds. Input guard tests cover foreground loss, moved/resized windows, covered points and F10 cancellation.

Fixed-route drags minimise the shift needed to bring the next target into a clear clickable map area. Endpoints are centred around a safe map region. The initial pan is capped at 120 reference pixels until movement is measured; verified dense terrain can use up to 300 pixels, sparse terrain 140, and overshoot reduces later motion. Alignment requires fresh stable screenshots. Existing bounded reverse recovery retains progress and never clicks a target without recognition.

A reopened map uses its last selected camera to estimate overlap movement rather than assuming the previous map pose persists. Fixed-route absolute refreshes occur after at most six accepted relative alignments; failure to recognise overlap falls back to absolute recognition. A thread-local cache reuses source landmarks only when the exact reference image is immutable and its known pose matches. Destination screenshots are always processed freshly. A regression test checks one source extraction against two independently recognised destination images.

## Existing behavior

Coverage retains gem confirmation over three sightings and 0.8 seconds, a bounded late-candidate extension, the 20-second history/screenshot cooldown, the 30-second sound cooldown, screenshot-before-one-tile horizontal approach, optional five-second photo hold, and stopping on a find at the last view without restarting a loop. Pass timing continues through incomplete pauses/finds/errors and completes only at the reduced pass total.

Real Tk checks verify Map overlay, Gem Watch and Gem Sniping, Snipe/Loop Sniping/Stop controls, ready hotkeys without automatic startup input, the shared History window, settings, responsive layout, and the 74-check panel. Screenshot-driven checks exercise the actual detector, writer and SQLite history with simulated mouse delivery. Edited history coordinates must still move a map dot without resetting its 30-minute anchor.

## Windows release checks

The build workflow runs the full tests, builds the windowed one-file EXE, compares its embedded white badge against the supplied ICO, validates frozen atlas/OCR resources and opens the native GUI. The GUI check requires the exact fixed route, 74-check progress maximum, history editor/date filters, correct transparent window icon and clean shutdown. The native input check exercises guarded clicks/drags/hotkeys and capture exclusion on the app's own test window, not BlueStacks. Passing reports accompany the release downloads.

## Limits

The route order and world-coordinate destinations are fixed. Raw desktop pixel sequences can differ with map recentering, clamping and emulator size; input is based on the verified current map pose. Real game inertia, loading times, additional portal/icon interactions, account-specific locked regions and total pass speed still need BlueStacks validation. The updated map's dashed links predict likely drags from default-zoom geometry; they are not recorded live actions. Faster real-world completion is not guaranteed by a simulated route.
