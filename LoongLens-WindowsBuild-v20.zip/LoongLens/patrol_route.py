"""The approved fixed camera order; removed numbers retain their old map IDs."""
import json
import math
from pathlib import Path
from camera_patrol import Viewpoint, PatrolSettings, camera_click_clear


def load_fixed_route(data):
    route=json.loads((Path(__file__).resolve().parent/'gem_sniping_route.json').read_text('utf-8'))
    known={(int(s['position']['x']),int(s['position']['y'])) for s in data['gems']}
    excluded={tuple(c) for s in route['excluded'] for c in s['spawn_spots']}
    result=[];seen=set();numbers=[];settings=PatrolSettings()
    for s in route['stops']:
        cells=frozenset(tuple(c) for c in s['spawn_spots'])
        x,y=s['x'],s['y'];number=s['number']
        if not cells or not cells<=known or cells & (seen|excluded):
            raise ValueError('Fixed camera route has missing, duplicate or excluded spawns.')
        if not (math.isfinite(x) and math.isfinite(y) and 0<=x<280 and 0<=y<280 and camera_click_clear(x,y)):
            raise ValueError('Fixed camera route has an invalid camera target.')
        view=Viewpoint(x,y,s['zone'],cells,route_number=number)
        left,bottom,right,top=view.bounds(settings)
        if not all(left+.59<=cx+.5<=right-.59 and bottom+.59<=cy+.5<=top-.59 for cx,cy in cells):
            raise ValueError('A spawn falls outside its fixed camera view.')
        result.append(view);seen.update(cells);numbers.append(number)
    if numbers!=[n for n in range(1,78) if n not in (26,51,72)] or seen!=known-excluded:
        raise ValueError('The fixed camera path must preserve its approved order and exclusions.')
    return tuple(result)


def route_pan_delta(point,limit):
    """Shortest bounded drag into a clear part of the clickable map.

    Two rectangles form the available map area around the upper-right legend.
    Stop once the next target is visible; closing/reopening will recenter it.
    """
    x,y=point
    candidates=[(min(max(x,52.),398.),min(max(y,170.),770.)),
                (min(max(x,52.),490.),min(max(y,270.),770.))]
    tx,ty=min(candidates,key=lambda p:math.hypot(p[0]-x,p[1]-y))
    dx,dy=tx-x,ty-y
    factor=max(1.,math.hypot(dx,dy)/limit)
    return dx/factor,dy/factor
