"""Screenshot-guided live patrol loop; input and clock are injectable for tests."""
from __future__ import annotations
from dataclasses import dataclass,replace
import math
import threading
import time
import uuid
import cv2
from gem_detector import GemDetector,AlertGate
from patrol_windows import PatrolStopped

LEGACY_MAP_OPEN = (515.,830.)
MINIMAP_OPEN = (480.,170.)
LIVE_SETTINGS_VERSION = 3


@dataclass(frozen=True)
class LiveSettings:
    map_open: tuple = MINIMAP_OPEN
    map_close: tuple = (64.,980.)
    settle_seconds: float = .5
    inspect_seconds: float = 1.2
    threshold: float = .77
    mask_hud: bool = False
    approach_gem: bool = True

    def __post_init__(self):
        for x,y in (self.map_open,self.map_close):
            if not (math.isfinite(x) and math.isfinite(y) and 0<=x<570 and 0<=y<1029):
                raise ValueError('Choose map buttons inside the BlueStacks screenshot.')
        if not (math.isfinite(self.settle_seconds) and .2<=self.settle_seconds<=10
                and math.isfinite(self.inspect_seconds) and 1.2<=self.inspect_seconds<=10
                and .5<=self.threshold<=.99):raise ValueError('Invalid patrol timing or detector settings.')


def load_live_config(config):
    """Upgrade old defaults while preserving custom calibration and timings."""
    values=dict(config['settings'])
    migrated=(config.get('version',1)==1 and tuple(values.get('map_open',MINIMAP_OPEN))==LEGACY_MAP_OPEN)
    if migrated:values['map_open']=MINIMAP_OPEN
    if config.get('version',1)<3 and values.get('settle_seconds',.8)==.8 and values.get('inspect_seconds',1.5)==1.5:
        values.update(settle_seconds=.5,inspect_seconds=1.2)
    settings=LiveSettings(**values)
    key=config.get('key','F8')
    return settings,key if key in ('F6','F7','F8','F9') else 'F8',migrated


def clickable(point):
    x,y=point
    return 32<=x<=510 and 150<=y<=800 and not (x>=420 and y<=250)


def character_anchor(frame):
    """Read the white marker inside the camera rectangle (reference pixels).

    The user centres this rectangle on their character before a new pass.
    Restrict candidates to a camera-sized white outline so terrain labels,
    map icons, the zoom handle and other round UI controls cannot be anchors.
    """
    import numpy as np
    normal=cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)
    hsv=cv2.cvtColor(normal,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,np.array((0,0,185)),np.array((179,75,255)))
    mask[:150]=0;mask[870:]=0;mask[:,:24]=0;mask[:,520:]=0;mask[:250,420:]=0
    # Small gaps from labels or compression should not break the outline.
    outline=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    contours,_=cv2.findContours(outline,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    rectangles=[]
    for contour in contours:
        x,y,w,h=cv2.boundingRect(contour)
        if not (65<=w<=105 and 125<=h<=180 and .43<=w/h<=.68):continue
        edges=(outline[y:y+3,x:x+w].mean(),outline[y+h-3:y+h,x:x+w].mean(),
               outline[y:y+h,x:x+3].mean(),outline[y:y+h,x+w-3:x+w].mean())
        if min(edges)<95:continue
        center=(x+w/2,y+h/2)
        dots=[]
        inner=mask[y+8:y+h-8,x+8:x+w-8]
        parts,_=cv2.findContours(inner,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        for part in parts:
            px,py,dw,dh=cv2.boundingRect(part);area=cv2.contourArea(part)
            if not (4<=dw<=15 and 4<=dh<=15 and .65<=dw/dh<=1.5 and area>=8):continue
            dot=(x+8+px+dw/2,y+8+py+dh/2)
            if math.dist(dot,center)<=24:dots.append(dot)
        rectangles.append((bool(dots),-abs(w-83)-abs(h-151),dots[0] if dots else center))
    return max(rectangles,key=lambda item:item[:2])[2] if rectangles else None


def locked_at(frame,point,scale):
    """Recognise the dark desaturated locked-zone shading at a known spawn.

    Do not infer locks from names, the character level, or the atlas: locks
    belong to this player's current map. Ignore text/icons using a tile patch.
    """
    x,y=map(round,point);radius=max(8,round(scale*1.15))
    h,w=frame.shape[:2]
    if not (radius<=x<w-radius and radius<=y<h-radius):return False
    hsv=cv2.cvtColor(frame[y-radius:y+radius+1,x-radius:x+radius+1],cv2.COLOR_BGR2HSV)
    dark=(hsv[:,:,2]>18)&(hsv[:,:,2]<96)&(hsv[:,:,1]<80)
    return float(dark.mean())>=.68


def accessible_view(view,frame,pose):
    """Exclude locked member spots, preserving the unlocked ones in one view."""
    from camera_patrol import PatrolSettings,playable_ground,camera_click_clear
    unlocked=frozenset(cell for cell in view.cells if not locked_at(frame,pose.project(cell[0]+.5,cell[1]+.5),pose.scale))
    if not unlocked:return None
    if camera_click_clear(view.x,view.y) and not locked_at(frame,pose.project(view.x,view.y),pose.scale):
        return replace(view,cells=unlocked)
    # A group straddling a locked boundary must be centred on its open side.
    import numpy as np
    settings=PatrolSettings();half=np.array([settings.view_width/2-.6,settings.view_height/2-.6])
    points=np.array([(x+.5,y+.5) for x,y in unlocked]);low=(points-half).max(axis=0);high=(points+half).min(axis=0)
    ground=playable_ground();candidates=[]
    for x in np.arange(low[0],high[0]+.001,.25):
        for y in np.arange(low[1],high[1]+.001,.25):
            point=pose.project(x,y)
            if 0<=x<280 and 0<=y<280 and ground[int(y),int(x)] and camera_click_clear(x,y) and clickable(point) and not locked_at(frame,point,pose.scale):
                candidates.append((math.hypot(x-view.x,y-view.y),x,y))
    if not candidates:raise RuntimeError('This view crosses a locked boundary; no open camera target was visible. Patrol stopped.')
    _,x,y=min(candidates)
    return replace(view,x=x,y=y,cells=unlocked)


class MapAlignmentLost(RuntimeError):
    pass


class LivePatrol:
    def __init__(self,views,settings,cancel,emit,checked=None,cooldown=None,
                 detector=None,locator=None,title=None,clock=time.perf_counter,wall=time.time,skipped=None,navigation=None):
        self.views=tuple(views);self.settings=settings;self.cancel=cancel;self.emit=emit
        self.fixed_route=bool(self.views) and all(v.route_number is not None for v in self.views)
        self.reopen_reference=None
        self.checked=checked if checked is not None else set()
        self.cooldown=cooldown if cooldown is not None else {'last':-float('inf')}
        self.detector=detector or GemDetector(threshold=settings.threshold)
        self.locator=locator;self.title=title;self.clock=clock;self.wall=wall
        self.navigation=navigation if navigation is not None else {}
        self.map_reference=self.navigation.get('reference')
        self.pan_scale=self.navigation.get('pan_scale',1.)
        self.skipped=skipped if skipped is not None else set()

    def send(self,kind,**data):self.emit(dict(kind=kind,**data))
    def check(self):
        if self.cancel.is_set():raise PatrolStopped('Stopped.')

    @staticmethod
    def normal(frame):return cv2.resize(frame,(570,1029),interpolation=cv2.INTER_AREA)

    def is_map(self,frame):return self.title.score(self.normal(frame))>=.64

    def map_frame(self,backend):
        deadline=self.clock()+6
        while self.clock()<deadline:
            self.check();frame=backend.capture()
            if self.is_map(frame):return frame
            backend.wait(.2)
        raise RuntimeError('The large map did not open. Set Open map to the minimap in Sniping settings; patrol stopped.')

    def open_map(self,backend):
        frame=backend.capture()
        if self.is_map(frame):return frame
        self.send('status',message='Reopening the large map…')
        backend.click(self.settings.map_open)
        selected=self.navigation.get('selected_camera')
        if selected is not None and self.map_reference is not None:
            before,known,_=self.map_reference
            sx,sy=known.project(*selected)
            self.reopen_reference=(before,known,(285.-sx,530.-sy))
        # One opener click only. Do not proceed or click other controls until
        # the actual map title appears; alignment follows on fresh screenshots.
        return self.map_frame(backend)

    def align(self,backend,reference=None,timeout=7.,recovery=False):
        deadline=self.clock()+timeout
        previous=None
        reference=reference or self.map_reference
        refresh=not self.fixed_route or self.navigation.get('relative_updates',0)>=5
        while self.clock()<deadline:
            self.check();frame=self.map_frame(backend)
            normal=self.normal(frame)
            pose=None
            if reference is not None:
                from vision import track_map_pan
                before,known,delta=reference
                pose=track_map_pan(before,normal,known,delta,recovery=recovery)
                if pose is None and reference is self.reopen_reference:
                    # Map edges can clamp recentering, and some reopenings
                    # retain the old view. Verify that unchanged terrain too.
                    pose=track_map_pan(before,normal,known,(0.,0.))
            absolute_used=False
            if pose is not None and refresh and reference is not None and math.hypot(*reference[2])>1 and hasattr(self.locator,'index'):
                # Refresh against absolute atlas landmarks when available so
                # many relative pans do not accumulate small registration errors.
                absolute=self.locator.index.locate(normal)
                if absolute is None:absolute=self.locator.index.locate(normal,wide=True)
                if absolute is not None and math.hypot(absolute.tx-pose.tx,absolute.ty-pose.ty)<10:
                    pose=absolute;absolute_used=True
            if pose is None:
                pose=self.locator.locate(normal);absolute_used=pose is not None
            self.check()
            if pose is not None and previous is not None and (
                    abs(pose.scale-previous.scale)<.03 and abs(pose.tx-previous.tx)<3 and abs(pose.ty-previous.ty)<3):
                normal.setflags(write=False)
                self.map_reference=(normal,pose,(0.,0.))
                self.navigation['reference']=self.map_reference
                self.navigation['relative_updates']=0 if absolute_used else self.navigation.get('relative_updates',0)+1
                return frame,pose
            previous=pose
            backend.wait(.15)
        raise MapAlignmentLost('Could not align Loong Haven. Use default zoom and keep map terrain visible.')

    def recover_pan(self,backend):
        pending=self.navigation.get('pending')
        if pending is None or self.navigation.get('recovery_exhausted'):
            raise MapAlignmentLost('Could not align the map. Drag it back to recognisable terrain, then resume; checked locations are kept.')
        before,known,delta=pending
        length=math.hypot(*delta)
        if length<1:raise MapAlignmentLost('Could not recover an unmoving map; checked locations are kept.')
        # Only undo our own last pan, in small steps, while the large map is
        # visibly open. Never click a guessed gem position during recovery.
        reverse=tuple(-v/length*min(70.,length) for v in delta)
        for attempt in range(6):
            self.check();self.map_frame(backend)
            self.send('status',message=f'Recovering map alignment — small reverse pan {attempt+1}/6…')
            self.check();backend.drag((285.,500.),(285+reverse[0],500+reverse[1]))
            backend.wait(.25)
            try:
                frame,pose=self.align(backend,(before,known,delta),timeout=1.5,recovery=True)
            except MapAlignmentLost:
                continue
            self.navigation.pop('pending',None);self.navigation.pop('recovery_exhausted',None)
            self.pan_scale=max(.25,self.pan_scale*.5)
            self.navigation['pan_scale']=self.pan_scale
            self.navigation['pan_verified']=False
            self.send('status',message='Map recovered. Continuing with smaller pans; progress kept.')
            return frame,pose
        self.navigation['recovery_exhausted']=True
        raise MapAlignmentLost('Map recovery could not find enough terrain. Drag back onto the map and resume; checked locations are kept.')

    def pan(self,backend,frame,pose,delta):
        before=self.normal(frame)
        before.setflags(write=False)
        self.navigation['pending']=(before,pose,delta)
        start=(285-delta[0]/2,500-delta[1]/2) if self.fixed_route else (285.,500.)
        self.check();backend.drag(start,(start[0]+delta[0],start[1]+delta[1]))
        backend.wait(.10 if self.fixed_route else .25)
        try:
            current,updated=self.align(backend,(before,pose,delta),timeout=3.)
        except MapAlignmentLost:
            return self.recover_pan(backend)
        actual=math.hypot(updated.tx-pose.tx,updated.ty-pose.ty)
        requested=math.hypot(*delta)
        if actual>requested*1.35:
            self.pan_scale=max(.25,self.pan_scale*requested/actual)
            self.navigation['pan_scale']=self.pan_scale
            self.navigation['pan_verified']=False
        elif requested>20 and actual>requested*.5:
            self.navigation['pan_verified']=True
        self.navigation.pop('pending',None);self.navigation.pop('recovery_exhausted',None)
        return current,updated

    def inspect(self,backend):
        gate=AlertGate(cooldown=0)
        started=self.clock();scans=0
        deadline=started+self.settings.inspect_seconds
        while True:
            self.check();frame=backend.capture()
            if self.is_map(frame):raise RuntimeError('The map did not close. Set its Back button in Sniping settings.')
            boxes=self.detector.detect(frame,exclude_hud=self.settings.mask_hud)
            self.check();gate.update(boxes,self.clock());scans+=1
            self.send('frame',frame=frame,detections=boxes)
            if gate.new_sightings:return gate.new_sightings[0],frame
            # A candidate appearing near the end gets time to meet the existing
            # three-hit / 0.8-second confirmation rule. Empty views stay short;
            # a false positive cannot extend inspection indefinitely.
            if boxes:
                deadline=max(deadline,min(started+self.settings.inspect_seconds+1.,self.clock()+.85))
            if self.clock()>=deadline and scans>=3:break
            if self.clock()-started>8:raise RuntimeError('Screenshot detection is too slow to complete this view.')
            backend.wait(.2)
        return None,None

    def run(self,backend,auto=True):
        self.check()
        if self.locator is None:
            from vision import Calibrator,TitleDetector
            from resources import user_dir
            self.send('status',message='Preparing map recognition…')
            self.locator=Calibrator(user_dir(),wide=True);self.title=TitleDetector()
        if hasattr(self.locator,'index') and not self.locator.index.ready:
            self.send('status',message='Preparing map recognition cache…')
            self.locator.index.prepare()
            self.check()
        self.send('status',message='Starting… F10 stops at any time.')
        backend.wait(.5);backend.focus()
        while len(self.checked)<len(self.views):
            self.check();self.open_map(backend)
            pending=self.navigation.get('pending')
            try:
                frame,pose=self.align(backend,pending or self.reopen_reference,timeout=3. if pending else 7.)
                self.reopen_reference=None
                self.navigation.pop('pending',None);self.navigation.pop('recovery_exhausted',None)
            except MapAlignmentLost:
                frame,pose=self.recover_pan(backend)
            remaining=[i for i in range(len(self.views)) if i not in self.checked]
            if not remaining:break
            visible=[i for i in remaining if clickable(pose.project(self.views[i].x,self.views[i].y))]
            center=((285-pose.tx)/pose.scale,(pose.ty-500)/pose.scale)
            if self.fixed_route:
                index=remaining[0]
            elif not self.checked:
                anchor=character_anchor(frame)
                if anchor is not None:
                    origin=((anchor[0]-pose.tx)/pose.scale,(pose.ty-anchor[1])/pose.scale)
                else:
                    origin=center
                    self.send('status',message='Character rectangle not readable; starting nearest the visible map centre.')
                # Rank the actual spawn spots, rather than shifted camera
                # centres, so a border/portal offset cannot change the choice.
                index=min(remaining,key=lambda i:min(math.hypot(x+.5-origin[0],y+.5-origin[1])
                    for x,y in self.views[i].cells))
                index=self.navigation.pop('repeat_start',index)
                self.navigation.setdefault('pass_start',index)
            else:
                index=(visible[0] if visible else min(remaining,key=lambda i:
                    math.hypot(self.views[i].x-center[0],self.views[i].y-center[1])))
            view=self.views[index]
            self.send('view',index=index,view=view,checked=len(self.checked))
            stalled=0;previous=None
            for attempt in range(257):
                self.check();point=pose.project(view.x,view.y)
                if clickable(point):break
                if attempt==256:raise RuntimeError('Could not bring this dot into view. Patrol stopped.')
                distance=math.hypot(point[0]-285,point[1]-500)
                stalled=stalled+1 if previous is not None and distance>=previous-3 else 0
                if stalled>=3:raise RuntimeError('Map panning is not moving toward the dot. Patrol stopped.')
                previous=distance
                dx,dy=285-point[0],500-point[1]
                self.send('status',message='Dragging to reveal the next route check…' if self.fixed_route else 'Panning to reveal the next gem dot…')
                from terrain_alignment import classify_screen
                known_ground=classify_screen(self.normal(frame))
                sparse=(known_ground[150:850,24:510]!=0).mean()<.35
                if self.fixed_route:
                    from patrol_route import route_pan_delta
                    limit=(140. if sparse else 300.) if self.navigation.get('pan_verified') else 120.
                    delta=route_pan_delta(point,limit*self.pan_scale)
                else:
                    limit=(70. if sparse else 120.)*self.pan_scale
                    factor=max(1,math.hypot(dx,dy)/limit)
                    delta=(dx/factor,dy/factor)
                frame,pose=self.pan(backend,frame,pose,delta)
            if self.fixed_route and locked_at(self.normal(frame),pose.project(view.x,view.y),pose.scale):
                available=None  # Keep the saved target; never substitute a different camera centre.
            else:
                available=accessible_view(view,self.normal(frame),pose)
            if available is None:
                self.checked.add(index);self.skipped.add(index)
                self.send('checked',index=index,count=len(self.checked),skipped=len(self.skipped))
                self.send('status',message=f'Skipped locked area: {view.near_zone}')
                if not auto:return 'Locked gem location skipped. Press the advance hotkey for another.'
                continue
            view=available;point=pose.project(view.x,view.y)
            if not clickable(point):raise RuntimeError('The accessible camera target moved outside the clickable map; stopped.')
            # Recognition came from this fresh screenshot; guard input again.
            self.check();self.send('status',message=f'Clicking {view.near_zone} ({math.floor(view.x)},{math.floor(view.y)})')
            fresh=backend.capture()
            if not self.is_map(fresh):raise RuntimeError('The map changed before the dot click. Patrol stopped.')
            if self.fixed_route:
                from vision import patrol_map_mask
                import numpy as np
                difference=cv2.absdiff(self.normal(frame),self.normal(fresh)).max(axis=2)
                terrain=patrol_map_mask(difference.shape)!=0
                if np.mean(difference[terrain]>28)>.06:
                    raise RuntimeError('The map moved before the fixed route click. Stopped; resume when the map has settled.')
            backend.click(point);backend.wait(.2)
            self.navigation['selected_camera']=(view.x,view.y)
            if self.is_map(backend.capture()):backend.click(self.settings.map_close)
            deadline=self.clock()+5
            while self.is_map(backend.capture()):
                if self.clock()>deadline:raise RuntimeError('The map did not close. Calibrate its Back button.')
                backend.wait(.2)
            backend.wait(self.settings.settle_seconds)
            self.send('status',message='Inspecting the visible scene…')
            found,frame=self.inspect(backend)
            self.checked.add(index);self.send('checked',index=index,count=len(self.checked))
            if found is not None:
                now=self.clock();event=None
                if now-self.cooldown['last']>=20:
                    self.cooldown['last']=now
                    event=dict(event_id='patrol:'+uuid.uuid4().hex,seen_at=self.wall(),screen_x=found.center[0],
                        screen_y=found.center[1],score=found.score,test_mode=False,capture_status='pending',
                        zone=view.near_zone,game_x=math.floor(view.x),game_y=math.floor(view.y),
                        capture_note='Camera view: selected spawn area, not the gem tile.',
                        camera_location=dict(zone=view.near_zone,x=math.floor(view.x),y=math.floor(view.y)))
                sound=now-self.cooldown.get('sound',-float('inf'))>=30
                if sound:self.cooldown['sound']=now
                self.send('found',event=event,view=view,sound=sound)
                if self.settings.approach_gem:
                    from camera_patrol import approach_click
                    point=approach_click(found.center,frame.shape)
                    if event is not None:
                        event=dict(event,capture_note=event['capture_note']+' Photo saved before the movement click.')
                        self.send('capture',event=event,frame=frame.copy(),captured_at=self.wall())
                    self.check()
                    if point is None:
                        return 'Gem found. No nearby click away from interface controls was available; stopped for manual movement.'
                    # Capture guards cover focus/resize/obstruction, and a fresh
                    # visual check avoids sending a move into a changed scene.
                    fresh=backend.capture()
                    if self.is_map(fresh):return 'Gem found. Map reopened; movement cancelled.'
                    current=self.detector.detect(fresh,exclude_hud=self.settings.mask_hud)
                    if not any(math.dist(box.center,found.center)<max(30,found.width*2) for box in current):
                        return 'Gem found. Scene changed before movement; stopped without clicking.'
                    self.check();backend.click(point)
                    self.send('approached',point=point)
                    return 'Gem found. Clicked beside the gem once; patrol stopped. Collect it manually.'
                if event is not None:
                    try:
                        backend.wait(5);fresh=backend.capture()
                        if self.is_map(fresh):raise RuntimeError('The map was opened before capture.')
                        self.send('capture',event=event,frame=fresh,captured_at=self.wall())
                    except Exception as exc:
                        self.send('sighting',event=dict(event,capture_status='cancelled',
                            capture_note=event['capture_note']+' Screenshot unavailable: '+str(exc)))
                return 'Gem found. Patrol stopped; collect it manually.'
            if not auto:return 'One location checked. Press the advance hotkey for another.'
        return f'Pass complete: {len(self.checked)-len(self.skipped)} camera views checked, {len(self.skipped)} locked views skipped. Reset checks to scan again.'


class PatrolRunStats:
    """Elapsed wall time and confirmed finds until every view is processed."""
    def __init__(self,clock=time.perf_counter):
        self.clock=clock;self.lock=threading.Lock()
        self.elapsed=0.;self.started=None;self.gems=0

    def start(self):
        with self.lock:
            if self.started is None:self.started=self.clock()

    def complete(self):
        with self.lock:
            if self.started is not None:
                self.elapsed+=max(0.,self.clock()-self.started);self.started=None

    def found(self):
        with self.lock:self.gems+=1

    def reset(self):
        with self.lock:self.elapsed=0.;self.started=None;self.gems=0

    def snapshot(self):
        with self.lock:
            elapsed=self.elapsed+(max(0.,self.clock()-self.started) if self.started is not None else 0.)
            return dict(elapsed=elapsed,gems=self.gems)

    def text(self):
        values=self.snapshot();minutes,seconds=divmod(int(values['elapsed']),60)
        return f"Time spent: {minutes}:{seconds:02d}\nGems found: {values['gems']}"


class LiveRunner:
    def __init__(self,views,backend_factory,emit,clock=time.perf_counter):
        self.views=views;self.backend_factory=backend_factory;self.emit=emit
        self.cancel=threading.Event();self.thread=None;self.checked=set();self.skipped=set();self.cooldown={'last':-float('inf')}
        self.detector=None;self.locator=None;self.title=None
        self.stats=PatrolRunStats(clock)
        self.navigation={}
        self.passes=0;self.last_pass=None
    @property
    def running(self):return self.thread is not None and self.thread.is_alive()
    def stop(self):self.cancel.set()
    def start(self,settings,auto=True,repeat=False):
        if self.running or not self.views:return False
        if len(self.checked)>=len(self.views):
            if not repeat:return False
            self.checked.clear();self.skipped.clear();self.stats.reset()
            if 'pass_start' in self.navigation:self.navigation['repeat_start']=self.navigation['pass_start']
        self.cancel.clear()
        self.stats.start()
        found=False
        def report(event):
            nonlocal found
            if event['kind']=='found':self.stats.found();found=True
            self.emit(event)
        def work():
            message='Stopped.'
            try:
                if self.cancel.is_set():raise PatrolStopped('Stopped.')
                if self.detector is None:self.detector=GemDetector(threshold=settings.threshold)
                self.detector.threshold=settings.threshold
                if self.cancel.is_set():raise PatrolStopped('Stopped.')
                if self.locator is None:
                    from vision import Calibrator,TitleDetector
                    from resources import user_dir
                    self.locator=Calibrator(user_dir(),wide=True);self.title=TitleDetector()
                with self.backend_factory(self.cancel) as backend:
                    while True:
                        patrol=LivePatrol(self.views,settings,self.cancel,report,self.checked,self.cooldown,
                            self.detector,self.locator,self.title,clock=self.stats.clock,skipped=self.skipped,navigation=self.navigation)
                        patrol.check();message=patrol.run(backend,auto)
                        complete=len(self.checked)>=len(self.views)
                        if complete:
                            self.stats.complete();self.passes+=1;self.last_pass=self.stats.snapshot()
                            self.emit(dict(kind='pass_complete',passes=self.passes,stats=self.last_pass))
                        # A find on the final view must stop even though the
                        # pass is also complete. Errors/F10 never restart.
                        if not repeat or not complete or found:break
                        patrol.check();backend.wait(.2);patrol.check()
                        self.checked.clear();self.skipped.clear();self.stats.reset();self.stats.start()
                        if 'pass_start' in self.navigation:self.navigation['repeat_start']=self.navigation['pass_start']
                        self.emit(dict(kind='pass_started',passes=self.passes))
            except Exception as exc:message=str(exc)
            finally:
                if len(self.checked)>=len(self.views):self.stats.complete()
                self.emit(dict(kind='finished',message=message,stats=self.stats.snapshot()))
        self.thread=threading.Thread(target=work,daemon=True,name='LoongLens-live-patrol');self.thread.start()
        return True
