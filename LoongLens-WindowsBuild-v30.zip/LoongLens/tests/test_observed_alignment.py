"""Reuse measured map poses while retaining fresh-frame and movement checks."""
from types import SimpleNamespace
import cv2
import numpy as np
import pytest
import vision
from patrol_windows import PatrolStopped
from pose import Match
from test_live_patrol import setup
from test_sniping_speed import atlas_frame


def prepare():
    engine,backend,events=setup();frame=atlas_frame()
    frame.setflags(write=False)
    pose=Match(12.45,-900.,2173.55,20,0,[])
    engine.title=SimpleNamespace(score=lambda f:1.)
    return engine,backend,frame,pose


def test_unchanged_trusted_reference_still_uses_two_fresh_observations(monkeypatch):
    engine,backend,frame,pose=prepare();captures=[]
    backend.capture=lambda:captures.append(True) or frame.copy()
    monkeypatch.setattr(vision,'track_map_pan',lambda *a,**kw:pytest.fail('Unchanged terrain was re-matched'))
    engine.locator=SimpleNamespace(locate=lambda f:pytest.fail('Unchanged terrain was located again'))
    _,found=engine.align(backend,(frame,pose,(0,0)))
    assert found is pose and len(captures)==2 and backend.clock.now>=.15


def test_post_release_frame_confirms_an_older_measured_held_frame(monkeypatch):
    engine,backend,frame,pose=prepare();captures=[]
    observed=backend.clock.now;backend.wait(.22)
    backend.capture=lambda:captures.append(True) or frame.copy()
    monkeypatch.setattr(vision,'track_map_pan',lambda *a,**kw:pytest.fail('The measured map was re-matched'))
    _,found=engine.align(backend,(frame,pose,(0,0)),observed_at=observed)
    assert found is pose and len(captures)==1 and backend.clock.now==pytest.approx(.22)


@pytest.mark.parametrize('age',[0.,.1,-.1])
def test_recent_or_future_timestamp_cannot_replace_a_settled_observation(age):
    engine,backend,frame,pose=prepare();captures=[]
    backend.capture=lambda:captures.append(True) or frame.copy()
    engine.align(backend,(frame,pose,(0,0)),observed_at=backend.clock.now-age)
    assert len(captures)==2 and backend.clock.now>=.15


def test_predicted_movement_cannot_be_used_as_an_observed_pose():
    engine,backend,frame,pose=prepare();captures=[];backend.wait(.22)
    backend.capture=lambda:captures.append(True) or frame.copy()
    engine.align(backend,(frame,pose,(120,0)),observed_at=0.)
    assert len(captures)==2


def test_release_movement_requires_new_recognition_and_stable_confirmation(monkeypatch):
    engine,backend,before,pose=prepare();after=np.roll(before,30,axis=1)
    frames=iter([after,after]);captures=[];matches=[];backend.wait(.22)
    moved=Match(pose.scale,pose.tx+30,pose.ty,20,0,[])
    backend.capture=lambda:captures.append(True) or next(frames).copy()
    def track(*args,**kwargs):matches.append(True);return moved
    monkeypatch.setattr(vision,'track_map_pan',track)
    _,found=engine.align(backend,(before,pose,(0,0)),observed_at=0.)
    assert found is moved and len(captures)==2 and len(matches)==1
    assert backend.clock.now>=.37


def test_flat_reference_cannot_confirm_a_measured_pose_without_recognition(monkeypatch):
    engine,backend,frame,pose=prepare();flat=np.zeros_like(frame);calls=[];captures=[]
    backend.wait(.22);backend.capture=lambda:captures.append(True) or flat.copy()
    monkeypatch.setattr(vision,'track_map_pan',lambda *a,**kw:calls.append(True) or pose)
    engine.align(backend,(flat,pose,(0,0)),observed_at=0.)
    assert calls and captures


def test_cancel_before_the_post_release_capture_stops_without_input():
    engine,backend,frame,pose=prepare();backend.wait(.22);engine.cancel.set()
    backend.capture=lambda:pytest.fail('Capture after cancellation')
    with pytest.raises(PatrolStopped):engine.align(backend,(frame,pose,(0,0)),observed_at=0.)
    assert not backend.inputs


def test_periodic_absolute_refresh_is_retained_for_unchanged_map():
    engine,backend,frame,pose=prepare();refresh=[]
    engine.fixed_route=True;engine.navigation['relative_updates']=5
    engine.locator=SimpleNamespace(index=SimpleNamespace(locate=lambda *a,**kw:refresh.append(True) or pose))
    backend.capture=lambda:frame.copy()
    engine.align(backend,(frame,pose,(120,0)))
    assert refresh and engine.navigation['relative_updates']==0


@pytest.mark.parametrize('processing,expected',[(.04,.15),(.25,.25)])
def test_recognition_time_counts_toward_the_observation_interval(processing,expected):
    engine,backend,frame,pose=prepare();captures=[]
    backend.capture=lambda:captures.append(backend.clock.now) or frame.copy()
    def recognize(frame):backend.clock.now+=processing;return pose
    engine.locator=SimpleNamespace(locate=recognize)
    engine.align(backend)
    assert len(captures)==2 and captures[1]-captures[0]>=.15
    assert backend.clock.now==pytest.approx(expected)
