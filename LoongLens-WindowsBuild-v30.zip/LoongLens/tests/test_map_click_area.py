"""Visible edge dots must be clicked without dragging onto excluded controls."""
import math
import pytest
from camera_patrol import Viewpoint
from patrol_route import map_clickable
from patrol_live import LivePatrol
from test_live_patrol import setup


SAFE_POINTS=((20,110),(400,110),(20,500),(470,300),(470,590),(470,850),(20,910),(400,910),(470,900),
             (530,300),(530,590),(490,300),(490,590),(20,920),(400,920),(20,60),(210,95),(5,500),(555,150))


@pytest.mark.parametrize('point',SAFE_POINTS)
def test_user_outlined_surface_is_clickable(point):
    assert map_clickable(point)


@pytest.mark.parametrize('point',[(450,150),(540,220),(530,700),(515,910),(450,960),(100,75),(-5,300),(570,500),(20,940),(15,20),
                                  (float('nan'),500),(300,float('inf'))])
def test_legend_zoom_tabs_chrome_and_outside_are_excluded(point):
    assert not map_clickable(point)


@pytest.mark.parametrize('point',SAFE_POINTS)
def test_visible_edge_dot_is_selected_directly_without_any_map_drag(point):
    engine,backend,events=setup()
    # Independently place the target at the requested reference pixel using
    # the backend's known world transform; the map is already open and stable.
    x=100+(point[0]-285)/12.45;y=100+(500-point[1])/12.45
    view=Viewpoint(x,y,'Visible edge',frozenset({(math.floor(x),math.floor(y))}),1)
    patrol=LivePatrol((view,),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    patrol.run(backend)
    assert patrol.checked=={0}
    assert not any(action[0]=='drag' for action in backend.inputs)
    assert backend.inputs[0][0]=='click' and backend.inputs[0][1]==pytest.approx(point)


@pytest.mark.parametrize('point',[(450,150),(530,700),(450,960),(495,910),(100,75),(190,90)])
def test_target_over_a_control_is_dragged_to_map_surface_before_selection(point):
    engine,backend,events=setup()
    x=100+(point[0]-285)/12.45;y=100+(500-point[1])/12.45
    view=Viewpoint(x,y,'Behind control',frozenset({(math.floor(x),math.floor(y))}),1)
    patrol=LivePatrol((view,),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    patrol.run(backend)
    assert patrol.checked=={0} and backend.inputs[0][0]=='drag'
    first_click=next(action for action in backend.inputs if action[0]=='click')
    assert map_clickable(first_click[1]) and first_click[1]!=pytest.approx(point)


@pytest.mark.parametrize('angle',range(0,360,30))
def test_character_portrait_bubble_and_glowing_border_are_excluded(angle):
    # The shown portrait/glow lies inside the marked zoom/portrait box.
    point=(526+34*math.cos(math.radians(angle)),759+34*math.sin(math.radians(angle)))
    assert not map_clickable(point)


@pytest.mark.parametrize('point',[(28,60),(100,70),(185,90),(190,95)])
def test_upper_left_loong_haven_title_is_excluded(point):
    assert not map_clickable(point)


def test_target_behind_portrait_bubble_is_revealed_before_clicking():
    engine,backend,events=setup();bubble=(526,759)
    x=100+(bubble[0]-285)/12.45;y=100+(500-bubble[1])/12.45
    view=Viewpoint(x,y,'Behind portrait',frozenset({(math.floor(x),math.floor(y))}),1)
    patrol=LivePatrol((view,),engine.settings,engine.cancel,events.append,
        detector=engine.detector,locator=engine.locator,title=engine.title,clock=engine.clock)
    patrol.run(backend)
    first=next(action[1] for action in backend.inputs if action[0]=='click')
    assert map_clickable(first) and math.dist(first,bubble)>34
    assert backend.inputs[0][0]=='drag'


@pytest.mark.parametrize('point',[(27,75),(192,75),(100,53),(100,99),
                                  (421,150),(555,150),(500,57),(500,232),
                                  (489,800),(530,640),(530,924),
                                  (552,960),(300,928)])
def test_pixel_immediately_outside_a_red_box_is_available_without_padding(point):
    assert map_clickable(point)


@pytest.mark.parametrize('point',[(28,75),(191,75),(100,54),(100,98),
                                  (422,150),(554,150),(500,58),(500,231),
                                  (490,800),(530,641),(530,923),
                                  (3,960),(551,960),(300,929)])
def test_pixels_on_red_boxes_are_excluded(point):
    assert not map_clickable(point)
