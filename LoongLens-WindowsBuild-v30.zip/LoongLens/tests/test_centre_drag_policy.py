"""Centre-start strokes, input-hold failures and recovery without blind reversals."""
import math
import pytest
from camera_patrol import Viewpoint
from patrol_live import MapAlignmentLost
from patrol_route import DRAG_CENTER,route_drag_step,route_point_visible
from test_live_patrol import setup
from test_held_pan import native_backend


@pytest.mark.parametrize('angle',range(0,360,15))
def test_stroke_reaches_the_exact_first_control_or_viewport_edge(angle):
    direction=(math.cos(math.radians(angle)),math.sin(math.radians(angle)))
    cursor=DRAG_CENTER
    for _ in range(10):
        end=route_drag_step(cursor,direction)
        if end is None:break
        count=max(1,math.ceil(math.dist(cursor,end)))
        assert all(route_point_visible((cursor[0]+(end[0]-cursor[0])*i/count,
                                        cursor[1]+(end[1]-cursor[1])*i/count))
                   for i in range(count+1))
        cursor=end
    else:pytest.fail('Stroke did not stop at an edge')
    assert route_point_visible(cursor)
    assert not route_point_visible((cursor[0]+direction[0],cursor[1]+direction[1]))


@pytest.mark.parametrize('previous,target',[
    ((107.75,179.55),Viewpoint(131.5,141.5,'Reed Marsh',frozenset({(131,141)}),52)),
    ((139.75,247.55),Viewpoint(163.25,235.05,'Mount Jade',frozenset({(165,237)}),66)),
])
def test_xiv_and_last_celestship_transitions_use_one_fast_centre_stroke(previous,target):
    engine,backend,events=setup()
    engine.views=(target,);engine.fixed_route=True;backend.center=previous
    engine.run(backend)
    strokes=[action for action in backend.inputs if action[0]=='drag']
    assert len(strokes)==1
    assert strokes[0][1]==DRAG_CENTER
    assert strokes[0][2][0]<DRAG_CENTER[0] and strokes[0][2][1]<DRAG_CENTER[1]
    assert engine.checked=={0} and not backend.held
    assert [e['view'].route_number for e in events if e['kind']=='view']==[target.route_number]
    assert not any('reverse' in e.get('message','') for e in events)


def test_fixed_route_recognition_failure_never_sends_the_old_six_reverse_drags():
    engine,backend,events=setup();engine.fixed_route=True
    frame=backend.capture();pose=engine.locator.locate(frame)
    engine.navigation['pending']=(frame,pose,(20.,0.));engine.checked.add(0)
    def failed(*args,**kwargs):raise MapAlignmentLost('Controlled recognition failure')
    engine.align=failed
    with pytest.raises(MapAlignmentLost,match='without reverse dragging'):
        engine.recover_pan(backend)
    assert not backend.inputs and engine.checked=={0}
    assert engine.navigation['recovery_exhausted']


def test_fixed_route_recovery_can_continue_after_fresh_in_place_recognition():
    engine,backend,events=setup();engine.fixed_route=True
    frame=backend.capture();pose=engine.locator.locate(frame)
    engine.navigation['pending']=(frame,pose,(20.,0.))
    result=engine.recover_pan(backend)
    assert result[1]==pose and not backend.inputs
    assert 'pending' not in engine.navigation


def test_windows_rejects_a_missing_mouse_hold_before_moving():
    backend,actions=native_backend();backend.api.left_down=lambda:False
    with pytest.raises(RuntimeError,match='hold was released'):
        with backend.hold_drag(DRAG_CENTER):backend.drag_held_to((200,400))
    assert [a for a in actions if a[0]=='move']==[('move',DRAG_CENTER)]
    assert actions[-1]==('button',4) and not backend.down


def test_windows_stops_mid_stroke_if_the_mouse_button_is_released():
    backend,actions=native_backend();state={'held':True}
    backend.api.left_down=lambda:state['held']
    move=backend.move
    with pytest.raises(RuntimeError,match='hold was released'):
        with backend.hold_drag(DRAG_CENTER):
            def lost_hold(point):move(point);state['held']=False
            backend.move=lost_hold
            backend.drag_held_to((200,400))
    assert len([a for a in actions if a[0]=='move'])==2
    assert actions[-1]==('button',4) and not backend.down
