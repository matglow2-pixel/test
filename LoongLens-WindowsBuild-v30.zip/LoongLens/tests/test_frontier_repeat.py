"""A tiny second-visit shift must not trigger a pan through open right terrain."""
from contextlib import contextmanager
import math
from camera_patrol import Viewpoint
from test_live_patrol import setup


def test_frontier_vault_second_visit_does_not_pan_at_the_removed_strip():
    engine,backend,events=setup()
    view=Viewpoint(52.5,209.5,'Frontier Vault',frozenset({(52,209)}),43)
    engine.views=(view,);engine.fixed_route=True
    original=backend.hold_drag;state={}
    @contextmanager
    def hold(start):
        state.update(start=start,actual=(0.,0.))
        with original(start):yield
    backend.hold_drag=hold
    def move(end):
        start=state['start'];delta=(end[0]-start[0],end[1]-start[1])
        # Model the game's gesture threshold: tiny movement is still a tap.
        actual=delta if math.hypot(*delta)>=8 else (0.,0.)
        change=(actual[0]-state['actual'][0],actual[1]-state['actual'][1])
        backend.center=(backend.center[0]-change[0]/12.45,backend.center[1]+change[1]/12.45)
        backend.cursor=end;state['actual']=actual
    backend.drag_held_to=move
    for px in (479.,481.):
        engine.checked.clear();backend.open=True
        backend.center=(view.x-(px-285)/12.45,view.y)
        engine.run(backend)
        assert engine.checked=={0}
    assert not any(action[0]=='drag' for action in backend.inputs)
    assert [event['view'].route_number for event in events if event['kind']=='view']==[43,43]
