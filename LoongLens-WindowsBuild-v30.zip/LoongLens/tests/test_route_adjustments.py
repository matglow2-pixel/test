"""Personal camera framing cannot alter the fixed route or original spawn data."""
from dataclasses import replace
import json
import pytest
from resources import ResourceStore
from patrol_route import load_fixed_route,load_camera_adjustments,save_camera_adjustments,apply_camera_adjustments,camera_warnings,add_camera_view


@pytest.fixture
def route():return load_fixed_route(ResourceStore().data)


def test_camera_drag_save_reload_preserves_order_cells_and_split_identities(route,tmp_path):
    path=tmp_path/'camera-route-adjustments.json';edited=list(route)
    for i,v in enumerate(edited):
        if v.route_label in ('12','40b'):edited[i]=replace(v,x=v.x-.25,y=v.y-1.25)
    save_camera_adjustments(route,edited,path)
    reloaded=load_camera_adjustments(route,path)
    assert reloaded==tuple(edited)
    assert [(v.route_label,v.cells) for v in reloaded]==[(v.route_label,v.cells) for v in route]
    assert set(json.loads(path.read_text())['targets'])=={'12','40b'}
    assert not path.with_suffix('.json.tmp').exists()
    save_camera_adjustments(route,route,path)
    assert load_camera_adjustments(route,path)==route


@pytest.mark.parametrize('point',[[float('nan'),2],[1,float('inf')],[-1,3],[1,280],[True,3],['1',2],[1],None])
def test_invalid_saved_position_is_rejected_as_a_whole(route,point):
    with pytest.raises(ValueError):apply_camera_adjustments(route,{'version':1,'targets':{'12':point}})


def test_removed_or_unknown_points_cannot_be_added(route):
    for label in ('26','51','72','40','400'):
        with pytest.raises(ValueError):apply_camera_adjustments(route,{'version':1,'targets':{label:[1,2]}})


def test_changed_spawn_or_order_cannot_be_saved(route,tmp_path):
    changed=(replace(route[0],cells=frozenset({(0,0)})),)+route[1:]
    for edited in (changed,tuple(reversed(route))):
        with pytest.raises(ValueError):save_camera_adjustments(route,edited,tmp_path/'route.json')
    assert not (tmp_path/'route.json').exists()


def test_manual_framing_can_show_offset_ground_with_warning_without_changing_spawns(route):
    changed=apply_camera_adjustments(route,{'version':1,'targets':{'12':[159.5,63.5],'44':[70,211]}})
    tower=next(v for v in changed if v.route_label=='12')
    assert len(tower.cells)==4 and camera_warnings(tower)
    assert not any('portal' in warning for v in changed if v.route_label=='44' for warning in camera_warnings(v))


def test_missing_adjustments_use_defaults_and_corrupt_file_is_not_overwritten(route,tmp_path):
    path=tmp_path/'camera-route-adjustments.json';assert load_camera_adjustments(route,path)==route
    path.write_text('{broken')
    with pytest.raises(ValueError):load_camera_adjustments(route,path)
    assert path.read_text()=='{broken'


def test_multiple_extras_insert_directly_after_selection_and_survive_restart(route,tmp_path):
    index=next(i for i,v in enumerate(route) if v.route_label=='12')
    edited=add_camera_view(route,index)
    first=edited[index+1]
    assert first.route_label=='12+1' and first.route_parent=='12'
    assert first.x==route[index].x+1 and first.y==route[index].y
    edited=add_camera_view(edited,index+1)  # Insert after the extra itself.
    edited=add_camera_view(edited,index)  # Insert before the previous extras.
    assert [v.route_label for v in edited[index:index+5]]==['12','12+3','12+1','12+2','13']
    edited=list(edited);edited[index+2]=replace(edited[index+2],y=65.)
    path=tmp_path/'route.json';save_camera_adjustments(route,edited,path)
    assert load_camera_adjustments(route,path)==tuple(edited)
    assert len(edited)==79 and len(set().union(*(v.cells for v in edited)))==83
    assert [v for v in edited if not v.route_parent]==list(route)


def test_extra_after_split_view_retains_its_unique_parent_and_removal_reanchors_followers(route,tmp_path):
    index=next(i for i,v in enumerate(route) if v.route_label=='40b')
    edited=add_camera_view(route,index);edited=add_camera_view(edited,index+1)
    assert [v.route_label for v in edited[index:index+4]]==['40b','40b+1','40b+2','41']
    edited=edited[:index+1]+edited[index+2:]  # Remove the first extra, keep its following sibling.
    path=tmp_path/'route.json';save_camera_adjustments(route,edited,path)
    assert load_camera_adjustments(route,path)==edited
    assert edited[index+1].cells==route[index].cells


@pytest.mark.parametrize('changes',[
    {'id':'12'}, {'id':'26+1','parent':'26'}, {'id':'12+0'},
    {'after':'missing'}, {'after':'13'}, {'x':float('nan')}, {'parent':'40'},
])
def test_invalid_extra_views_cannot_replace_originals_or_break_group_order(route,changes):
    extra=dict(id='12+1',parent='12',after='12',x=160.,y=68.);extra.update(changes)
    with pytest.raises(ValueError):apply_camera_adjustments(route,{'version':2,'targets':{},'extras':[extra]})


def test_duplicate_extra_ids_and_edited_extra_spawns_are_rejected(route,tmp_path):
    extra=dict(id='12+1',parent='12',after='12',x=160.,y=68.)
    with pytest.raises(ValueError):apply_camera_adjustments(route,{'version':2,'targets':{},'extras':[extra,extra]})
    edited=list(add_camera_view(route,11));edited[12]=replace(edited[12],cells=frozenset({(0,0)}))
    with pytest.raises(ValueError):save_camera_adjustments(route,edited,tmp_path/'route.json')


def test_v21_positions_migrate_when_extra_views_are_saved(route,tmp_path):
    loaded=apply_camera_adjustments(route,{'version':1,'targets':{'12':[159.5,66.]}})
    edited=add_camera_view(loaded,11);path=tmp_path/'route.json'
    save_camera_adjustments(route,edited,path)
    assert json.loads(path.read_text())['version']==2
    assert load_camera_adjustments(route,path)==edited
    assert edited[11].y==66.


def test_live_sniping_inspects_nearby_extra_before_next_original_without_any_drag():
    from patrol_live import LivePatrol
    from test_live_patrol import setup
    engine,backend,events=setup()
    base=(replace(engine.views[0],route_number=1),replace(engine.views[1],route_number=2))
    views=add_camera_view(base,0)
    fixed=LivePatrol(views,engine.settings,engine.cancel,events.append,detector=engine.detector,
        locator=engine.locator,title=engine.title,clock=engine.clock)
    fixed.run(backend)
    assert [e['view'].route_label for e in events if e['kind']=='view']==['1','1+1','2']
    assert fixed.checked=={0,1,2}
    assert not any(action[0]=='drag' for action in backend.inputs)


def test_loop_sniping_repeats_extras_in_saved_order_and_completes_the_larger_total():
    import contextlib
    from patrol_live import LiveRunner,LiveSettings
    from test_live_patrol import setup
    engine,backend,events=setup()
    base=tuple(replace(v,route_number=i+1) for i,v in enumerate(engine.views))
    views=add_camera_view(base,0)
    def emit(event):
        events.append(event)
        if event['kind']=='pass_complete' and event['passes']==2:runner.stop()
    runner=LiveRunner(views,lambda cancel:contextlib.nullcontext(backend),emit,clock=engine.clock)
    runner.detector=engine.detector;runner.locator=engine.locator;runner.title=engine.title;backend.cancel=runner.cancel
    assert runner.start(LiveSettings(),repeat=True);runner.thread.join(5)
    assert not runner.running and runner.passes==2 and runner.checked=={0,1,2}
    assert [e['view'].route_label for e in events if e['kind']=='view']==['1','1+1','2']*2
    elapsed=runner.stats.snapshot()['elapsed'];backend.clock.now+=20
    assert runner.stats.snapshot()['elapsed']==elapsed+20
