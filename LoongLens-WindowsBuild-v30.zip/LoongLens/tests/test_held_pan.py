"""Held map movement, early stopping, input cleanup and the user's map boundary."""
from contextlib import contextmanager
from dataclasses import replace
from types import SimpleNamespace
import math
import threading
import pytest
from camera_patrol import Viewpoint
from patrol_live import LivePatrol,LiveSettings,MapAlignmentLost
from patrol_windows import WindowsBackend,PatrolStopped
from patrol_route import (route_point_visible,route_reveal_delta,route_drag_start,
                          route_drag_step,DRAG_BOUNDS,DRAG_CENTER)
from test_live_patrol import setup


@pytest.mark.parametrize('delta',[(0,-100),(0,100),(-100,0),(100,0),
                                   (-100,-100),(100,100),(100,-100),(-100,100)])
def test_all_drag_directions_start_at_centre_and_avoid_controls(delta):
    start=route_drag_start(delta)
    assert start==DRAG_CENTER
    assert route_point_visible(start)
    end=route_drag_step(start,delta)
    assert route_point_visible(end)
    assert math.dist(start,end)<=240.001


@pytest.mark.parametrize('point',[(650,500),(-100,500),(450,180),(280,1060),(280,-100)])
def test_reveal_direction_is_opposite_the_target_relative_to_centre(point):
    dx,dy=route_reveal_delta(point)
    target=(point[0]+dx,point[1]+dy)
    assert route_point_visible(target)
    assert target==pytest.approx(DRAG_CENTER)


@pytest.mark.parametrize('point',[(480,180),(530,800),(64,980),(285,960),(5,20)])
def test_controls_and_edges_are_not_revealed_targets(point):
    assert not route_point_visible(point)


@pytest.mark.parametrize('point',[(480,850),(412,110),(10,918),(400,918)])
def test_no_extra_padding_is_added_inside_the_marked_boundary(point):
    assert route_point_visible(point)


def native_backend():
    backend=WindowsBackend.__new__(WindowsBackend)
    backend.down=False;backend.cancel=threading.Event();actions=[]
    backend.api=SimpleNamespace(left_down=lambda:True,mouse=lambda flag:actions.append(('button',flag)))
    backend.move=lambda point:actions.append(('move',point))
    backend.guard=lambda:None
    backend.wait=lambda seconds:actions.append(('wait',seconds))
    return backend,actions


def test_one_press_across_multiple_moves_and_stationary_release():
    backend,actions=native_backend()
    with backend.hold_drag((285,900)):
        backend.drag_held_to((285,780))
        backend.drag_held_to((285,660))
        assert [a for a in actions if a[0]=='button']==[('button',2)]
    assert [a for a in actions if a[0]=='button']==[('button',2),('button',4)]
    assert actions[-2:]==[('wait',.18),('button',4)]
    assert not backend.down


@pytest.mark.parametrize('failure',['cancel','covered','focus','resize'])
def test_held_failures_release_without_an_extra_move(failure):
    backend=WindowsBackend.__new__(WindowsBackend)
    backend.down=False;backend.cancel=threading.Event();actions=[]
    backend.target=(123,(0,0,570,1029));state={'failure':None}
    def bounds(hwnd,pointer):
        r=pointer._obj;r.left=0;r.top=0;r.right=571 if state['failure']=='resize' else 570;r.bottom=1029
        return True
    user=SimpleNamespace(GetWindowRect=bounds,
        GetForegroundWindow=lambda:999 if state['failure']=='focus' else 123,
        GetAncestor=lambda hwnd,kind:hwnd,
        SetCursorPos=lambda *p:actions.append(('move',p)) or True)
    backend.api=SimpleNamespace(user=user,left_down=lambda:True,mouse=lambda flag:actions.append(('button',flag)))
    backend.visible_at=lambda *p:state['failure']!='covered'
    backend.wait=lambda seconds:None
    with pytest.raises(RuntimeError):
        with backend.hold_drag((285,900)):
            backend.drag_held_to((285,780))
            before=len(actions);state['failure']=failure
            if failure=='cancel':backend.cancel.set()
            backend.drag_held_to((285,660))
    assert actions[before:]==[('button',4)]
    assert actions[-1]==('button',4)
    assert not backend.down


@pytest.mark.parametrize('start',[(480,180),(526,730),(120,75)])
def test_invalid_held_start_sends_no_input(start):
    backend,actions=native_backend()
    with pytest.raises(ValueError):
        with backend.hold_drag(start):pass
    assert actions==[]


def test_path_crossing_legend_is_rejected_before_any_movement():
    backend,actions=native_backend()
    with pytest.raises(ValueError):
        with backend.hold_drag((390,120)):
            before=len(actions)
            backend.drag_held_to((460,300))
    assert actions[before:]==[('button',4)]


def fixed_engine(x,y):
    engine,backend,events=setup()
    view=Viewpoint(x,y,'Target',frozenset({(int(x),int(y))}),1)
    engine.views=(view,);engine.fixed_route=True
    return engine,backend,events,view


def test_single_hold_spans_multiple_screenshots_and_stops_at_first_visible_frame():
    engine,backend,events,view=fixed_engine(100,40)
    moves=[];screens=[];capture=backend.capture;move=backend.drag_held_to
    def screenshot():
        frame=capture()
        if getattr(backend,'held',False):screens.append((len(moves),engine.locator.locate(frame).project(view.x,view.y)))
        return frame
    def drag(end):
        moves.append(end);return move(end)
    backend.capture=screenshot;backend.drag_held_to=drag
    engine.run(backend)
    strokes=[a for a in backend.inputs if a[0]=='drag']
    assert len(strokes)==1 and len(moves)>=2
    assert strokes[0][1]==DRAG_CENTER
    assert strokes[0][2][1]<strokes[0][1][1]  # Reveal lower map by dragging up.
    assert route_point_visible(screens[-1][1])
    assert all(not route_point_visible(point) for _,point in screens[:-1])
    assert screens[-1][0]==len(moves)  # No movement after the first visible frame.
    assert not backend.held and engine.checked=={0}


def test_first_visible_target_is_not_pulled_to_center():
    engine,backend,events,view=fixed_engine(126,100)
    engine.run(backend)
    strokes=[a for a in backend.inputs if a[0]=='drag']
    assert len(strokes)==1
    point=engine.locator.locate(backend.capture()).project(view.x,view.y)
    assert route_point_visible(point) and point[0]>DRAG_CENTER[0]
    assert strokes[0][1]==DRAG_CENTER


def test_map_loss_during_hold_releases_and_never_clicks():
    engine,backend,events,view=fixed_engine(100,40)
    capture=backend.capture
    def screenshot():
        frame=capture()
        if getattr(backend,'held',False):frame[0,0]=0
        return frame
    backend.capture=screenshot
    with pytest.raises(RuntimeError,match='large map changed'):engine.run(backend)
    assert not backend.held and not engine.checked
    assert not any(a[0]=='click' for a in backend.inputs)


def test_cancel_during_held_recognition_releases_and_never_clicks():
    engine,backend,events,view=fixed_engine(100,40)
    locate=engine.locator.locate
    def locate_and_cancel(frame):
        if getattr(backend,'held',False):engine.cancel.set()
        return locate(frame)
    engine.locator.locate=locate_and_cancel
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert not backend.held and not engine.checked
    assert not any(a[0]=='click' for a in backend.inputs)


def test_clamped_map_stops_without_clicking_or_holding_button():
    engine,backend,events,view=fixed_engine(100,40);backend.stuck=True
    with pytest.raises(RuntimeError,match='not moving'):engine.run(backend)
    assert not backend.held and not engine.checked
    assert not any(a[0]=='click' for a in backend.inputs)


def test_window_edge_reanchors_only_after_releasing():
    engine,backend,events,view=fixed_engine(100,-100)
    # Exercise the panning stage directly; the artificial target is outside
    # the game's grid solely to force a stroke longer than the window height.
    frame=backend.capture();pose=engine.locator.locate(frame)
    first,pose=engine.pan_held(backend,frame,pose,view)
    assert not backend.held
    assert len([a for a in backend.inputs if a[0]=='drag'])==1
    assert not route_point_visible(pose.project(view.x,view.y))
    second,pose=engine.pan_held(backend,first,pose,view)
    assert not backend.held
    assert len([a for a in backend.inputs if a[0]=='drag'])==2


def test_release_movement_is_measured_again_before_the_target_click():
    engine,backend,events,view=fixed_engine(126,100)
    original_hold=backend.hold_drag;original_click=backend.click;shifted=[];clicked=[];before_release=[]
    @contextmanager
    def hold(start):
        with original_hold(start):yield
        if not shifted:
            before_release.append(engine.locator.locate(backend.capture()).project(view.x,view.y))
            backend.center=(backend.center[0]+30/12.45,backend.center[1]);shifted.append(True)
    def click(point):
        if backend.open and point!=engine.settings.map_close:
            expected=engine.locator.locate(backend.capture()).project(view.x,view.y)
            assert point==tuple(round(value) for value in expected)
            clicked.append(point)
        original_click(point)
    backend.hold_drag=hold;backend.click=click
    engine.run(backend)
    assert shifted and len(clicked)==1
    assert clicked[0]==(round(before_release[0][0]-30),round(before_release[0][1]))


def test_lost_intermediate_recognition_releases_before_realigning_and_continuing():
    engine,backend,events,view=fixed_engine(100,40)
    locate=engine.locator.locate;failed=[]
    def locate_once_missing(frame):
        if getattr(backend,'held',False) and not failed:
            failed.append(True);return None
        return locate(frame)
    engine.locator.locate=locate_once_missing
    engine.run(backend)
    assert failed and engine.checked=={0} and not backend.held
    assert len([a for a in backend.inputs if a[0]=='drag'])==2
