# v27 — continuous held map panning

Gem Sniping now keeps the mouse button held while moving the map and checking
fresh screenshots for the next fixed-route location. It stops movement at the
first confirmed frame where that target is safely clickable, rather than
continuing toward the map centre.

- Start near the opposite edge to leave room for the intended map movement.
  Revealing a lower location starts the mouse low and drags the map upward.
- Measure progress after movements of at most 120 reference pixels, keeping
  the same button hold across those screenshot/recognition checks.
- Keep drag starts, cursor paths and target clicks within the user-marked map
  outline, excluding the top/title, legend, entire right-hand strip and bottom
  Back/region controls. An additional inset protects against edge clicks.
- Stop the cursor, hold it stationary for 0.18 seconds, then release. Confirm
  the settled map again before clicking the next location.
- At the window edge, release safely before re-anchoring for another stroke.
  Recovery may also use separate strokes; a hold cannot extend past the window.
- Release on F10, focus loss, resizing, obstruction, capture/recognition errors
  or an unexpected map closure. Never click an unconfirmed target.

Default and named routes, removals, history, settings, inspection waits and
gem confirmation are retained from v26. This remains Windows mouse input and
desktop screenshot capture. Keep BlueStacks visible, uncovered and focused.

The Windows validation exercises actual held input and F10 release on the
application's own test window. The full-route atlas benchmark uses simulated
input, loading and empty detection; its results are not live BlueStacks times.

Close the previous app, extract the complete folder and run its LoongLens.exe.
Personal data stays in %LOCALAPPDATA%\LoongLens. The full 7z includes the EXE,
source, assets, models, launchers, tests, tools and validation reports.
