# v29 — four exact control exclusions, no padding

Map panning and location selection now exclude only the four user-marked boxes:
the Loong Haven title, legend, zoom/portrait area and bottom controls. The rest
of the map content is available, including the right-side terrain between the
legend and zoom slider. The old broad polygon and right strip are removed.
There is no added padding around the boxes.

Movement stops when the target's input pixel is available. Drag starts and
intermediate cursor positions use the same four-box geometry. Reveal movements
choose the nearest available pixel, rather than aiming at the old inner region.
Window chrome and areas outside the captured game surface are not map content.

A controlled Frontier Vault regression reproduces v28's reported stop on the
second visit: a two-pixel viewport shift sends the target into the old right
strip and provokes an ineffective tiny drag. v29 selects both visits directly.
A two-pass atlas test also repeats the complete default route while preserving
navigation between passes. These checks do not establish the exact state of
the user's live game when the original stop occurred.

Fast held movement, stationary release, fresh-frame checks, F10, saved routes,
point removal, gem detection and inspection settings are retained.

Close the old app, extract the full folder and run its LoongLens.exe. Settings,
routes, screenshots and history remain in %LOCALAPPDATA%\LoongLens.
