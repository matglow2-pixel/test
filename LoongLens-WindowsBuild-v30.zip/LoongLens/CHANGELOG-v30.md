# v30 — centre-start map dragging and portal restriction removed

Every fixed-route stroke starts at reference pixel (285,530), near the map
centre. Direction is centre minus the next target's measured screen position.
For a target below and to the right, the mouse moves quickly up and left.
The button stays held between movement and screenshot checks. A stroke keeps
its initial direction, checks at most every 240 reference pixels, and stops
at the first verified frame with the target available. It does not need
per-location measurements or a fixed desktop window size.

Cursor paths use the four exact marked title, legend, zoom/portrait and bottom
control exclusions. Their coordinates are unchanged from v29. No padding is
added. The cursor stops at the first excluded pixel or viewport edge. A longer
transition releases at rest and starts another hold from the centre.

The 0.18-second stationary release pause and fresh position verification remain.
Windows button state is checked before held movement. If the button has been
released, input stops before another cursor movement. This detects a lost
Windows hold; it cannot prove how BlueStacks handles a delivered gesture.

Fixed-route alignment recovery no longer sends the old blind reverse sweeps.
It attempts fresh recognition in place, then stops with checked locations kept
if it cannot establish the position. Legacy automatic-planner recovery is
unchanged; the Gem Sniping saved-route path uses the fixed-route policy.

All known-portal coordinate filtering, the runtime stop and editor portal
warning are removed from application code. This includes the rebuilt EXE.
Hide portal icons in the game's map filter as requested. The default route
coordinates, route exclusions, saved profiles, point removal, detector and
inspection settings are retained. Removed points are not runtime lock checks.

The app header shows v30, including when run from the rebuilt EXE. Start and
drag diagnostics are recorded locally in the existing loonglens.log.

Exit the old app completely, extract the full folder and run its LoongLens.exe.
Python edits affect RUN_LOONG_LENS.bat, while the EXE contains its own code.
The launcher activates an existing instance, so exit it before switching.
Settings, routes and history remain in %LOCALAPPDATA%\LoongLens.

Windows checks cover the frozen GUI, icon, resources, held input and F10 on the
app's own test window. Route tests and timings use simulated map delivery and
atlas screenshots. They do not establish live BlueStacks timing or reproduce
the exact state of the user's intermittent Celestship/XIV failure.
