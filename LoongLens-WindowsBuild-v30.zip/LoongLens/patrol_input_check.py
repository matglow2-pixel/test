"""Verify real Windows clicks/drags/hotkeys on our own test window, never the game."""
import queue
import threading
import tkinter as tk
import ctypes
from ctypes import wintypes
from patrol_windows import WindowsBackend,GlobalPatrolKeys,PatrolStopped


def check_native_input():
    root=tk.Tk();root.title('Loong Lens native input test');root.geometry('600x650+60+40')
    tk.Label(root,text='Testing mouse input on this window only').pack()
    canvas=tk.Canvas(root,bg='#253449');canvas.pack(fill='both',expand=True)
    counts={'press':0,'release':0,'motion':0}
    def count(name):counts[name]+=1
    root.bind('<ButtonPress-1>',lambda event:count('press'))
    root.bind('<ButtonRelease-1>',lambda event:count('release'))
    root.bind('<B1-Motion>',lambda event:count('motion'))
    result=queue.Queue();completed=[];overlay=None
    def start():
        nonlocal overlay
        user=ctypes.WinDLL('user32',use_last_error=True)
        user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];user.GetAncestor.restype=wintypes.HWND
        user.GetWindowRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
        hwnd=user.GetAncestor(root.winfo_id(),2);r=wintypes.RECT()
        assert user.GetWindowRect(hwnd,ctypes.byref(r))
        target=(int(hwnd),(r.left,r.top,r.right-r.left,r.bottom-r.top))
        from win_overlay import PixelAlphaOverlay
        from PIL import Image,ImageDraw
        overlay=PixelAlphaOverlay()
        image=Image.new('RGBA',(target[1][2],target[1][3]))
        ImageDraw.Draw(image).rectangle((50,100,450,550),fill=(255,0,255,220))
        overlay.show_image(target[1],image)
        assert overlay.excluded_from_capture,'Overlay must be excluded from patrol screenshots'
        def work():
            cancel=threading.Event();advance=threading.Event();stopped=threading.Event();keys=None
            try:
                def stop():cancel.set();stopped.set()
                keys=GlobalPatrolKeys(advance.set,stop)
                with WindowsBackend(cancel,find=lambda:target) as backend:
                    assert ctypes.sizeof(backend.api.Input)==40,'Expected x64 INPUT layout'
                    backend.focus()
                    import numpy as np
                    frame=backend.capture()
                    magenta=(frame[:,:,0]>200)&(frame[:,:,1]<50)&(frame[:,:,2]>200)
                    assert np.count_nonzero(magenta)<20,'Visible overlay leaked into screenshot'
                    backend.click((100,300));backend.drag((180,400),(350,500))
                    backend.wait(.1);before=dict(counts)
                    with backend.hold_drag((450,850)):
                        backend.drag_held_to((390,700));backend.capture()
                        backend.drag_held_to((330,550));backend.capture()
                        backend.wait(.1)
                        assert counts['press']==before['press']+1,'Held drag pressed more than once'
                        assert counts['release']==before['release'],'Held drag released between checks'
                    backend.wait(.1)
                    assert counts['release']==before['release']+1,'Held drag did not release once'
                    backend.api.key(0x77);backend.api.key(0x77,up=True)  # F8
                    assert advance.wait(2),'Global advance hotkey did not fire'
                    try:
                        with backend.hold_drag((300,700)):
                            backend.drag_held_to((300,600))
                            backend.api.key(0x79);backend.api.key(0x79,up=True)  # F10
                            assert stopped.wait(2),'Global emergency stop did not fire'
                            backend.wait(.01)
                    except PatrolStopped:pass
                    else:raise AssertionError('F10 did not interrupt the held drag')
                    assert not backend.down,'F10 left the mouse button held'
                    assert not (backend.api.user.GetAsyncKeyState(0x01)&0x8000),'Windows still reports the mouse button down'
                result.put(None)
            except Exception as exc:result.put(str(exc))
            finally:
                if keys is not None:keys.close()
        threading.Thread(target=work,daemon=True).start()
    def poll():
        try:error=result.get_nowait()
        except queue.Empty:root.after(100,poll);return
        completed.append((error,dict(counts)))
        if overlay is not None:overlay.close()
        root.destroy()
    root.after(400,start);root.after(500,poll);root.after(20000,root.destroy)
    root.mainloop()
    assert completed,'Native input test timed out'
    error,counts=completed[0]
    assert error is None,error
    assert counts['press']>=2 and counts['release']>=2 and counts['motion']>=3,counts
    return counts
