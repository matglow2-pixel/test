"""Exercise device selection, image geometry, cancellation and panel integration."""
from dataclasses import asdict
import json
import subprocess
import threading
from types import SimpleNamespace

import cv2
import numpy as np
import pytest

import patrol_adb
from patrol_adb import AdbBackend, InputSettings
from patrol_windows import PatrolStopped


def png(width=570, height=1029, color=(17, 93, 201)):
    frame = np.full((height, width, 3), color, np.uint8)
    return cv2.imencode('.png', frame)[1].tobytes()


class Device:
    def __init__(self, monkeypatch, settings=None):
        self.commands = []
        self.image = png()
        self.package = 'com.example.game'
        self.output = None
        self.error = b''
        self.code = 0
        self.on_input = None
        self.cancel = threading.Event()
        device = self
        monkeypatch.setattr(patrol_adb, 'find_adb', lambda path: 'chosen-adb.exe')

        class Process:
            def __init__(self, command, **kwargs):
                assert 'shell' not in kwargs
                device.commands.append(command)
                self.returncode = None
                if command[-1] == 'get-state':
                    self.output = b'device\n'
                elif command[-2:] == ['screencap', '-p']:
                    self.output = device.image() if callable(device.image) else device.image
                elif command[-2:] == ['dumpsys', 'window']:
                    self.output = f'mCurrentFocus=Window{{abc u0 {device.package}/.MainActivity}}'.encode()
                else:
                    self.output = b'connected'
                    if 'touchscreen' in command and device.on_input is not None:
                        device.on_input(command[command.index('touchscreen')+1:])

            def communicate(self, timeout=None):
                self.returncode = device.code
                return device.output if device.output is not None else self.output, device.error

            def poll(self): return self.returncode
            def kill(self): self.returncode = -9

        monkeypatch.setattr(patrol_adb.subprocess, 'Popen', Process)
        self.backend = AdbBackend(self.cancel, settings or InputSettings(mode='ADB'))
        self.backend.__enter__()

    def connect(self):
        self.backend.focus()
        return self.backend


def test_old_config_defaults_to_mouse_and_adb_profile_round_trips():
    assert InputSettings.load({}).mode == 'Mouse'
    settings = InputSettings(mode='ADB', adb_path='C:/Program Files/BlueStacks_nxt/HD-Adb.exe',
                             serial='127.0.0.1:5565', content_rect=(0, 35, 550, 1020))
    restored = InputSettings.load(json.loads(json.dumps({'input': asdict(settings)})))
    assert restored == settings


@pytest.mark.parametrize('values', [dict(mode='Other'), dict(serial=''), dict(serial='-d'),
                                    dict(serial='device; bad'), dict(content_rect=(0, 0, 571, 1029)),
                                    dict(content_rect=(4, 0, 4, 1029)), dict(content_rect=(0., 0, 570, 1029)),
                                    dict(content_rect=(0, 0, 5, 10))])
def test_bad_input_profile_is_rejected(values):
    with pytest.raises(ValueError): InputSettings(**values)


def test_exact_selected_instance_gets_taps_and_swipes_without_windows_mouse(monkeypatch):
    device = Device(monkeypatch)
    backend = device.connect()
    backend.click((285, 500))
    backend.drag((285, 500), (345, 600))
    commands = device.commands
    assert commands[0] == ['chosen-adb.exe', 'connect', '127.0.0.1:5555']
    assert all(cmd[1:3] == ['-s', '127.0.0.1:5555'] for cmd in commands[1:])
    assert ['chosen-adb.exe', '-s', '127.0.0.1:5555', 'shell', 'input', 'touchscreen', 'tap', '285', '500'] in commands
    swipe = next(cmd for cmd in commands if 'swipe' in cmd)
    assert swipe[-5:-1] == ['285', '500', '345', '600']
    assert 350 <= int(swipe[-1]) <= 850
    assert not any('keyevent' in cmd or 'kill-server' in cmd for cmd in commands)


def test_usb_serial_does_not_auto_connect_or_choose_another_device(monkeypatch):
    device = Device(monkeypatch, InputSettings(mode='ADB', serial='emulator-5554'))
    device.connect()
    assert all(cmd[1:3] == ['-s', 'emulator-5554'] for cmd in device.commands)


def test_png_capture_keeps_bgr_and_maps_calibrated_reference_to_android(monkeypatch):
    options = InputSettings(mode='ADB', content_rect=(10, 40, 550, 1000))
    device = Device(monkeypatch, options)
    device.image = png(1080, 1920)
    backend = device.connect()
    frame = backend.capture()
    assert frame.shape == (2058, 1140, 3)
    assert tuple(frame[80, 20]) == (17, 93, 201)
    assert not frame[:80].any() and not frame[:, :20].any()
    assert backend.point((280, 520)) == (540, 960)
    assert backend.point((549.99, 999.99)) == (1079, 1919)
    for point in [(9, 40), (550, 50), (20, 1000), (float('nan'), 50)]:
        with pytest.raises(ValueError): backend.click(point)
    assert not any('tap' in cmd for cmd in device.commands)


def test_native_capture_detail_and_gem_centres_survive_padding(monkeypatch):
    from camera_patrol import gem_click
    options = InputSettings(mode='ADB', content_rect=(10, 40, 550, 1000))
    device = Device(monkeypatch, options)
    image = np.zeros((1920, 1080, 3), np.uint8)
    image[900, 500] = (255, 42, 99)
    device.image = cv2.imencode('.png', image)[1].tobytes()
    backend = device.connect()
    frame = backend.capture()
    assert tuple(frame[980, 520]) == (255, 42, 99)
    point = gem_click((520, 980), frame.shape)
    assert point is not None
    assert backend.point(point) == (500, 900)


@pytest.mark.parametrize('payload', [b'', b'error: offline', b'\x89PNG\r\n\x1a\nbroken'], ids=['empty', 'offline', 'truncated'])
def test_broken_capture_stops_before_input(monkeypatch, payload):
    device = Device(monkeypatch)
    device.image = payload
    with pytest.raises(RuntimeError, match='screenshot|PNG'): device.connect()
    assert not any('input' in cmd for cmd in device.commands)


def test_display_changes_and_android_app_switch_block_input(monkeypatch):
    device = Device(monkeypatch)
    backend = device.connect()
    device.package = 'com.other.app'
    with pytest.raises(RuntimeError, match='app changed'): backend.click((200, 400))
    device.package = 'com.example.game'
    device.image = png(1140, 2058)
    with pytest.raises(RuntimeError, match='resolution changed'): backend.drag((200, 400), (220, 430))
    assert not any('input' in cmd for cmd in device.commands)


def test_repeat_pass_does_not_retarget_another_android_app(monkeypatch):
    device = Device(monkeypatch)
    backend = device.connect()
    device.package = 'com.other.game'
    with pytest.raises(RuntimeError, match='app changed'): backend.focus()
    assert backend.package == 'com.example.game'
    assert not any('input' in cmd for cmd in device.commands)


@pytest.mark.parametrize('image', [png(1029, 570), png(800, 1200)], ids=['landscape', 'wrong-aspect'])
def test_wrong_orientation_or_geometry_is_rejected(monkeypatch, image):
    device = Device(monkeypatch)
    device.image = image
    with pytest.raises(RuntimeError, match='portrait|aspect ratio'): device.connect()


@pytest.mark.parametrize('package', ['com.android.launcher3', 'com.bluestacks.launcher', 'com.android.settings'])
def test_starting_on_home_or_settings_is_rejected(monkeypatch, package):
    device = Device(monkeypatch)
    device.package = package
    with pytest.raises(RuntimeError, match='Open the game'): device.connect()


def test_device_error_and_stop_never_fall_back_to_mouse(monkeypatch):
    device = Device(monkeypatch)
    backend = device.connect()
    device.code = 1
    device.error = b'device offline'
    with pytest.raises(RuntimeError, match='offline'): backend.click((200, 400))
    device.cancel.set()
    count = len(device.commands)
    with pytest.raises(PatrolStopped): backend.click((200, 400))
    assert len(device.commands) == count


def test_f10_interrupts_pending_adb_command_and_reaps_process(monkeypatch):
    cancel = threading.Event()
    calls = []
    class Pending:
        returncode = None
        def __init__(self, *args, **kwargs): pass
        def communicate(self, timeout=None):
            calls.append(timeout)
            if timeout is not None:
                cancel.set()
                raise subprocess.TimeoutExpired('adb', timeout)
            return b'', b''
        def poll(self): return self.returncode
        def kill(self): calls.append('kill'); self.returncode = -9
    monkeypatch.setattr(patrol_adb.subprocess, 'Popen', Pending)
    backend = AdbBackend(cancel)
    backend.executable = 'adb'
    with pytest.raises(PatrolStopped): backend.command('get-state')
    assert calls == [.05, 'kill', None]


def test_timeout_kills_pending_adb_without_retries(monkeypatch):
    device = Device(monkeypatch)
    ticks = iter([0, 11])
    monkeypatch.setattr(patrol_adb.time, 'monotonic', lambda: next(ticks))
    with pytest.raises(RuntimeError, match='timed out'): device.backend.command('get-state')
    assert len(device.commands) == 1


def test_connection_preview_is_read_only(monkeypatch):
    device = Device(monkeypatch)
    frame = AdbBackend.peek(InputSettings(mode='ADB'))
    assert frame.shape == (1029, 570, 3)
    assert not any('input' in cmd for cmd in device.commands)


def test_panel_backend_selection_and_saved_input_leave_existing_live_settings_intact(monkeypatch, tmp_path):
    from patrol_live_panel import LivePatrolPanel
    from patrol_live import LiveSettings, load_live_config
    import patrol_live_panel
    panel = object.__new__(LivePatrolPanel)
    panel.settings = LiveSettings(map_open=(480, 170), inspect_seconds=2.4)
    panel.input_settings = InputSettings(mode='ADB', serial='127.0.0.1:5575')
    panel.input_error = None
    panel.key = SimpleNamespace(get=lambda: 'F9')
    panel.path = tmp_path / 'settings.json'
    panel.save_config()
    saved = json.loads(panel.path.read_text())
    assert InputSettings.load(saved).serial == '127.0.0.1:5575'
    assert load_live_config(saved)[0].inspect_seconds == 2.4
    backend = panel.make_backend(threading.Event())
    assert isinstance(backend, AdbBackend) and backend.settings == panel.input_settings
    sentinel = object()
    monkeypatch.setattr(patrol_live_panel, 'WindowsBackend', lambda cancel: sentinel)
    panel.input_settings = InputSettings()
    assert panel.make_backend(threading.Event()) is sentinel


def test_malformed_saved_adb_profile_is_preserved_until_repaired(tmp_path):
    from patrol_live_panel import LivePatrolPanel
    from patrol_live import LiveSettings
    panel = object.__new__(LivePatrolPanel)
    panel.settings = LiveSettings()
    panel.input_settings = InputSettings()
    panel.input_error = 'Invalid ADB profile'
    panel.key = SimpleNamespace(get=lambda: 'F8')
    panel.path = tmp_path / 'settings.json'
    panel.path.write_text(json.dumps({'input': {'mode': 'ADB', 'serial': 'bad!'}}))
    panel.save_config()
    assert json.loads(panel.path.read_text())['input'] == {'mode': 'ADB', 'serial': 'bad!'}


@pytest.mark.parametrize('positive', [False, True])
def test_route_loop_uses_adb_screenshots_and_device_input_through_gem_stop(monkeypatch, positive):
    from patrol_live import LiveSettings
    from test_live_patrol import setup
    engine, game, events = setup(positive=positive)
    engine.settings = LiveSettings(approach_gem=True)
    device = Device(monkeypatch)
    device.image = lambda: cv2.imencode('.png', game.capture())[1].tobytes()
    def gesture(args):
        if args[0] == 'tap': game.click(tuple(map(int, args[1:])))
        else: game.drag(tuple(map(int, args[1:3])), tuple(map(int, args[3:5])))
    device.on_input = gesture
    backend = device.backend
    backend.cancel = engine.cancel
    backend.wait = game.wait
    message = engine.run(backend)
    assert engine.checked == ({0} if positive else {0, 1})
    if positive:
        assert 'Clicked the gem once' in message
        assert game.inputs[-1][1] == (200, 400)
        assert len(game.inputs) == 3
        assert any(e['kind'] == 'capture' for e in events)
    else:
        assert not any(e['kind'] == 'found' for e in events)
        assert [x[2] for x in game.inputs] == [True, True, False, True, True]


@pytest.mark.parametrize('state', [
    '  mCurrentFocus=Window{abc u0 com.example.game/.MainActivity}\n',
    '  mCurrentFocus = Window{abc u0 com.example.game/org.cocos2dx.cpp.AppActivity}\r\n',
    'mFocusedWindow: Window{abc u0 com.example.game/.Game}\n',
])
def test_android_window_focus_formats(state):
    assert AdbBackend.active_package(state, ('mCurrentFocus', 'mFocusedWindow')) == (True, 'com.example.game')


@pytest.mark.parametrize('field', ['topResumedActivity', 'mResumedActivity'])
def test_android_activity_manager_formats(field):
    state = f'    {field}=ActivityRecord{{abc u0 com.example.game/.MainActivity t12}}\n'
    assert AdbBackend.active_package(state, ('topResumedActivity', 'mResumedActivity')) == (True, 'com.example.game')


@pytest.mark.parametrize('state', [
    'mCurrentFocus=null\nmFocusedWindow=Window{old u0 com.old.game/.Old}\n',
    'mCurrentFocus=Window{unreadable}\n',
    'mCurrentFocus=Window{abc u0 com.one.game/.Main}\nmCurrentFocus=Window{def u0 com.other.game/.Main}\n',
])
def test_null_unreadable_or_ambiguous_focus_is_not_replaced_by_stale_app(state):
    assert AdbBackend.active_package(state, ('mCurrentFocus', 'mFocusedWindow')) == (True, None)


def test_unfocused_window_listing_does_not_identify_active_app():
    state = 'Window #0 Window{abc u0 com.example.game/.MainActivity}\n'
    assert AdbBackend.active_package(state, ('mCurrentFocus',)) == (False, None)


def test_android_11_full_window_dump_and_activity_fallback(monkeypatch):
    device = Device(monkeypatch)
    backend = device.backend
    commands = []
    def command(*args):
        commands.append(args)
        if args == ('shell', 'dumpsys', 'window'):
            return b'WINDOW MANAGER WINDOWS\nWindow #0 Window{abc u0 com.stale.app/.Old}\n'
        assert args == ('shell', 'dumpsys', 'activity', 'activities')
        return b'  topResumedActivity=ActivityRecord{abc u0 com.example.game/.Main t42}\n'
    monkeypatch.setattr(backend, 'command', command)
    assert backend.foreground_package() == 'com.example.game'
    assert len(commands) == 2


def test_unknown_focus_still_stops_without_touch_or_stale_fallback(monkeypatch):
    device = Device(monkeypatch)
    backend = device.backend
    commands = []
    def command(*args):
        commands.append(args)
        return b'mCurrentFocus=null\n'
    monkeypatch.setattr(backend, 'command', command)
    with pytest.raises(RuntimeError, match='cannot identify'): backend.foreground_package()
    assert commands == [('shell', 'dumpsys', 'window')]


@pytest.mark.parametrize('package', ['com.android.permissioncontroller', 'com.google.android.permissioncontroller'])
def test_permission_dialog_does_not_become_the_game(monkeypatch, package):
    device = Device(monkeypatch)
    device.package = package
    with pytest.raises(RuntimeError, match='Open the game'): device.connect()
    assert not any('input' in cmd for cmd in device.commands)
