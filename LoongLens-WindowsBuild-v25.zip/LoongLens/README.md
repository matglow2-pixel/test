# Loong Lens

A Windows 10 (2004+) / Windows 11 companion for Sword x Staff in BlueStacks. Use Loong Haven's default map zoom.

## Start

Close the previous app and run **LoongLens.exe**. Python and separate icon files are not needed. The portable download contains the EXE and this guide; the full package also includes source, assets and development checks.

The EXE keeps the white gem badge in Explorer. Its window and taskbar use the original transparent gem artwork. Settings, history and screenshots remain in `%LOCALAPPDATA%\LoongLens` when upgrading.

## Map overlay

Open the large Loong Haven map with BlueStacks visible. Pink dots mark 86 possible gem locations; Ingredients groups the bean, bamboo and crab layers. Pause, Re-align and appearance controls affect only the overlay.

Recent sightings appear as teal dots with a 30-minute countdown from their original spotting time. Editing coordinates moves the dot without restarting its timer. Expired dots disappear; history stays saved. Manual pickups have their own Mark collected, Pickup history and timer controls.

## Gem Watch

Press **Start watching** for visible-gameplay detection. Confirmed gems trigger an optional sound and a history entry. A fresh screenshot and the character's minimap location are saved five seconds later. History/screenshots have a 20-second cooldown; sounds have a 30-second cooldown.

**History** opens the shared sighting log. Edit location changes only the zone and X,Y, preserving the original date, time and screenshot. Today only / Show all filter the log. Click Source or Open screenshot to view a saved picture. Test image and Test sound help check detection and alerts.

Detection uses full-resolution captures. The small live view displays the latest inspected screenshot and pink candidate boxes; it is a monitor, not the detector's input resolution. Covered or minimized gameplay cannot be inspected.

## Gem Sniping

### ADB input (v25, live BlueStacks validation pending)

**ADB focus compatibility fix:** reads the complete Android WindowManager dump
instead of the window-list-only view, which can omit current focus on Android
11. When the focus field is absent, it checks ActivityTaskManager's top-resumed
activity. Null, unreadable or conflicting focus still stops input; permission
dialogs are not accepted as the game. If the connection preview still cannot
identify the app, confirm that the configured ADB port belongs to the exact
BlueStacks instance running the game. No desktop-mouse fallback is used.

**Sniping settings → Input method → ADB** sends screenshots, taps and swipes through the selected Android device. It does not move the PC cursor, send Windows keys or bring BlueStacks to the foreground. Mouse mode remains the default for existing settings. Only Gem Sniping uses ADB; the Map overlay and ordinary Gem Watch continue using the visible Windows desktop.

1. Close the old Loong Lens app. For this source package, launch `RUN_LOONG_LENS.bat` with 64-bit Python 3.12 installed; it prepares its own dependencies. Alternatively build the Windows EXE as described under Development. An older EXE will not contain this change.
2. Enable **Android Debug Bridge** under BlueStacks **Settings → Advanced**. Use the port shown for the instance running your game. In Sniping settings choose **ADB**, enter that exact address (for example `127.0.0.1:5555`), and optionally choose the ADB executable. The app looks for `BlueStacks_nxt/HD-Adb.exe` under Program Files and then `adb` on PATH. You can use Google's Android SDK platform-tools instead. No ADB binary is downloaded or bundled with this package.
3. Open the game in portrait orientation. With BlueStacks visible for this one-time calibration, press **Pick game area**. Click the top-left and bottom-right of the Android display inside the BlueStacks window, excluding Windows title bar, side toolbar and emulator bottom controls. This preserves the existing 570×1029 reference geometry used by map recognition and HUD guards. If Android navigation bars are included in the device screenshot, include their corresponding image area. Recalibrate after changing the emulator layout or resolution.
4. Use **Test connection / preview**. This reads device screenshots without sending game input. Check that the game is placed correctly; use **Pick on screenshot** for the minimap and large-map Back button if needed. Save settings. ADB uses the selected address only; it does not auto-select among connected devices. Non-loopback serials must already be connected via your ADB installation.
5. Start a single **Snipe** pass first. Switch to another desktop app and confirm that map opening, camera checks, screenshots and the final gem tap work correctly. Then try **Loop Sniping**. Keep BlueStacks running and the game active inside Android; some BlueStacks configurations stop rendering when minimized. Covering the desktop window does not cover ADB screenshots.

Route order, saved camera adjustments, extra views, detector confirmation, screenshot/history cooldowns, cumulative timing and repeat/resume behavior are shared with mouse mode. Connection errors never switch to mouse input. Changing input settings clears cached map alignment while retaining processed checks; use Reset checks for a fresh pass. A detected Android app change, invalid screenshot, landscape orientation or resolution change stops input.

F10 prevents subsequent commands and interrupts a waiting local ADB process. A gesture already delivered to Android can finish; swipe durations are bounded to 350–850 ms. Android swipes do not provide the mouse backend's stationary endpoint hold, so inertia, pan speed, screenshot latency and live detector performance need testing on your instance. The current fast 1.2-second inspection interval may need increasing in Sniping settings if ADB capture is slow.

Linux validation covers simulated ADB responses and the real Tk settings flow. It does not establish live BlueStacks compatibility, background/minimized rendering, Android input permission or Windows executable behavior.

ADB captures retain native image detail for gem detection and screenshot history, padded into the existing reference layout. The route's alignment stage still normalizes its own frames to 570×1029. No Windows desktop pixels are used in ADB mode.

### Route and controls

This replaces the former Live patrol tab. The separate Patrol preview tab and its simulation controls have been removed; screenshot-based engine and UI checks remain in the development tools.

1. Open Loong Haven's map at default zoom. The fixed route always begins at **Emerald Corner (#1)**, so start there to minimise setup movement. Keep BlueStacks uncovered and move Loong Lens aside.
2. Press **Snipe** or **F8** to check the remaining route once. **Loop Sniping** repeats complete passes until a gem is found or **F10** stops it. Live controls are ready at launch; opening the app alone sends no input. Choose another Snipe key if a hotkey is already in use.
3. The saved path keeps the original diagram's order and numbers, with **#26 Forsaken Lotus Pond, #51 Jadetoad Isle and #72 Frosted Plain removed**. They are never inspected or included in completion totals. There are now **76 camera checks / 83 spawn spots**. The original IDs keep their gaps. Wide vertical groups #40 and #64 are split into a/b checks so a spawn near the rectangle edge is not counted as clearly inspected.
4. Each check selects the next fixed camera destination, closes the map and inspects gameplay. Reopening normally recentres on the selected camera. The next destination is clicked directly when visible. The clickable surface follows the user-marked map outline: it reaches near the left edge, below the title and down to the lower map edge, with cutouts for the upper-right legend and lower-right zoom controls. Visible targets anywhere inside that surface are selected directly. If it is outside that surface, a held-button drag reveals it; the earlier B/R intermediate camera selections are not used. The fixed order is not replaced by nearest-dot selection.
5. Every click targets the saved map coordinate using fresh screenshot alignment. The actual mouse pixels and corrective drag length depend on the current map position, recentering, edge clamping and emulator size. Unconfirmed alignment stops input. Resuming keeps the first unfinished check; Reset checks returns to #1. Each completed loop returns to the same start and order.

The full package includes **GemSniping-Fixed-Route.png**, a zoomable SVG and a CSV listing all 76 checks. The data used by the app is **gem_sniping_route.json**. Pink spawn locations on the normal map overlay remain the original 86-location dataset; these exclusions apply to Gem Sniping. Existing history entries are kept.

**Edit route** opens the full Loong Haven map and stops sniping input. Select a numbered camera target to see its white camera rectangle and dashed suggested clear area, then drag it or enter X/Y. Pink dots remain the original spawn locations. Use the wheel or +/− to zoom, drag empty map to pan, and use Zoom to selected for fine changes; arrow keys nudge by 0.25 tile. Reset point restores a selected original point to its default position; for an extra it restores the position at which you opened or added it. Reset route to defaults removes extras and restores the bundled camera positions. **Add view after selected** inserts a separate camera target one tile beside the chosen point and selects it for adjustment. It runs immediately after that point, including when you add after another extra. Extra labels such as #12+1 keep the original map numbers intact. Drag the extra to cover the ground you want; **Remove extra** deletes only an added view. Added views do not add spawn coordinates or change the excluded locations. **Save & reset checks** stores your camera positions and extra views locally, clears pass progress/timing and uses those positions on future launches and repeated passes. Closing without saving keeps the current route. The original route order, removed points and spawn coordinates stay unchanged; extras keep their saved order between the originals. Existing v21 camera adjustments load automatically. Warnings identify known portal overlap or recorded centres outside the suggested clear area; manual adjustments can intentionally show ground beside the listed dots. Sniping stops before selecting a target that overlaps a known portal, so move that target before running. One camera view cannot guarantee coverage of every possible 10-tile spawn offset.

Default startup is 0.5 seconds, scene loading is 0.5 seconds, and empty-view inspection is 1.2 seconds. A late gem candidate receives up to one extra second for the unchanged three-sighting / 0.8-second confirmation. Custom waits and map-button calibration are preserved. Increase the loading/check waits in **Sniping settings** if the game renders slowly.

Map dragging now shortens mouse motion according to distance while keeping the button held throughout. It retains a stationary 0.18-second endpoint hold before release to limit flinging. Offscreen drags pull farther toward the centre instead of barely revealing an edge. Visually verified dense-map pans can grow to 420 reference pixels, with smaller limits on sparse or overshooting terrain. Each drag is measured from settled screenshots; immutable source landmarks are reused to reduce repeated work. Reopened-map overlap uses the previous selected camera, with periodic absolute atlas refreshes. A bounded recovery attempt retains checked locations; focus loss, coverage, resizing, stalled movement or an unrecoverable map stops input.

Other dark locked groups are still skipped from the current screenshot without changing the order of remaining targets. Camera targets avoid the known Loong Haven IV and Crowcry Plain portals; Crowcry clicks farther left. Demonbind Tower is shifted lower and horizontally centred to show more ground above the chat. After a confirmed find, the enabled click action selects the gem once and stops.

On a confirmed gem, the default action captures its screenshot, confirms the gem again in a fresh frame, clicks the gem itself once, then stops. The click uses the latest detected centre with no tile offset. It avoids HUD buttons and cancels if the scene changes or F10 is pressed. Disable **On gem: click the gem itself once, then stop** in Sniping settings to retain the five-second photo hold instead. The legacy saved click setting is preserved; no further collection/dialog clicks are sent. A sniping history location identifies the selected camera area, not the character's minimap position or exact gem tile. Saving retains its 20-second cooldown across repeat passes.

**Time spent: 7:41** is cumulative during a Loop Sniping session. It does not reset on each pass, on a find, on F10, or when resuming; the wall clock continues through pauses until you explicitly reset checks. **Last 3 runs** shows the three most recent completed pass durations separately, newest first, such as #4 7:41 · #3 7:36 · #2 7:31. An incomplete pass does not replace a completed time. Gems found also stays cumulative. **Reset checks** clears total time, finds, pass history and progress; saving edits with **Save & reset checks** does the same. A standalone Snipe pass still freezes its timer after all saved views (including extra views and locked skips) are processed. History beside Sniping settings opens the shared log and stops mouse actions while the incomplete-pass clock continues. These runtime totals are not saved across closing the application.

The overlay stays visible during sniping. Normal Gem Watch pauses to avoid duplicate captures and remains paused afterward until resumed manually. Existing history, screenshots and both icons are preserved.

## Files and privacy

The app uses ordinary desktop screenshots and Windows mouse input. It does not read game memory, inject DLLs or modify game files. Screenshots are saved locally and are not uploaded by the app.

Personal data is in `%LOCALAPPDATA%\LoongLens`: `settings.json`, `gemwatch-settings.json`, `patrol-live-settings.json`, `camera-route-adjustments.json`, `pickups.sqlite3`, `sightings.sqlite3` and `screenshots/`. Existing personal coordinates from earlier versions remain supported. Diagnostics use `loonglens.log`; Save debug writes the last map frame and alignment details to this same folder.

Do not delete that folder when updating. Old build archives, user data, caches, development screenshots and obsolete preview code are excluded from the new packages.

## Development

Use Python 3.12 and the pinned `requirements.txt`. Windows source launchers open the same combined app; RUN_GEM_WATCH selects its Gem Watch tab. The one-file EXE is built with PyInstaller 6.16.0 and has no console window.

```
python -m pip install -r requirements.txt pytest==8.4.2
python -m pytest -q
python loong_lens.py --self-check
# Windows build:
python -m pip install pyinstaller==6.16.0
python tools/build_windows_exe.py
```

`--tab map`, `--tab watch` and `--tab live` select a startup page. Tests use simulated desktop input and real atlas/detector fixtures; the Windows workflow additionally checks the frozen app, icons and native input against its own test window. These checks do not measure a live BlueStacks pass. See VALIDATION.md for the current verification scope. OCR model notices and licences are included in `ocr_models`.
