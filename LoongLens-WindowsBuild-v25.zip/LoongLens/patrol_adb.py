"""Device-only screenshots and gestures; never captures or controls the PC desktop."""
from __future__ import annotations

from dataclasses import dataclass
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time

import cv2
import numpy as np

from patrol_windows import PatrolStopped


@dataclass(frozen=True)
class InputSettings:
    mode: str = 'Mouse'
    adb_path: str = ''
    serial: str = '127.0.0.1:5555'
    # Android content bounds within the existing Windows reference screenshot.
    # Padding preserves title recognition, HUD masks and the route's geometry.
    content_rect: tuple = (0, 0, 570, 1029)

    def __post_init__(self):
        if self.mode not in ('Mouse', 'ADB'):
            raise ValueError('Choose Mouse or ADB input.')
        if not isinstance(self.adb_path, str) or not isinstance(self.serial, str):
            raise ValueError('ADB path and device must be text.')
        if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,160}', self.serial) or self.serial.startswith('-'):
            raise ValueError('Enter one exact ADB device serial, such as 127.0.0.1:5555.')
        if len(self.content_rect) != 4 or any(type(v) is not int for v in self.content_rect):
            raise ValueError('Game area must be four integer coordinates: left,top,right,bottom.')
        left, top, right, bottom = self.content_rect
        if not (0 <= left < right <= 570 and 0 <= top < bottom <= 1029):
            raise ValueError('Game area must fit inside the 570×1029 reference screenshot.')
        if right-left < 285 or bottom-top < 500:
            raise ValueError('Pick the whole Android display; the game area must cover most of the reference screenshot.')
        object.__setattr__(self, 'content_rect', tuple(self.content_rect))

    @classmethod
    def load(cls, config):
        return cls(**config.get('input', {}))


def find_adb(configured=''):
    """Reuse BlueStacks' executable or the user's installed platform tools."""
    if configured:
        path = Path(configured).expanduser()
        resolved = str(path) if path.is_file() else shutil.which(configured)
        if resolved:
            return resolved
        raise RuntimeError('ADB executable not found. Select HD-Adb.exe from BlueStacks or adb.exe from Android platform-tools.')
    for name in ('ProgramFiles', 'ProgramFiles(x86)'):
        base = os.environ.get(name)
        if base:
            path = Path(base) / 'BlueStacks_nxt' / 'HD-Adb.exe'
            if path.is_file():
                return str(path)
    resolved = shutil.which('adb') or shutil.which('HD-Adb.exe')
    if not resolved:
        raise RuntimeError('ADB not found. Set the ADB executable in Sniping settings.')
    return resolved


class AdbBackend:
    def __init__(self, cancel, settings=None):
        self.cancel = cancel
        self.settings = settings or InputSettings(mode='ADB')
        self.executable = None
        self.size = None
        self.package = None

    def __enter__(self):
        self.executable = find_adb(self.settings.adb_path)
        return self

    def __exit__(self, *args):
        # ADB server and emulator are shared with the user; leave both running.
        pass

    def check(self):
        if self.cancel.is_set():
            raise PatrolStopped('Stopped. An already delivered Android gesture may finish (under one second).')

    def wait(self, seconds):
        if self.cancel.wait(seconds):
            self.check()

    def command(self, *args, targeted=True, timeout=10):
        self.check()
        command = [self.executable]
        if targeted:
            command += ['-s', self.settings.serial]
        command += list(args)
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       creationflags=flags)
        except OSError as exc:
            raise RuntimeError(f'Could not start ADB: {exc}') from exc
        deadline = time.monotonic() + timeout
        try:
            while True:
                self.check()
                if time.monotonic() >= deadline:
                    raise RuntimeError('ADB timed out. Check the device connection and keep BlueStacks running.')
                try:
                    output, error = process.communicate(timeout=.05)
                    break
                except subprocess.TimeoutExpired:
                    continue
            self.check()
            if process.returncode:
                detail = error.decode('utf-8', errors='replace').strip()[:400]
                raise RuntimeError(f'ADB failed for {self.settings.serial}: {detail or "command rejected"}')
            return output
        finally:
            if process.poll() is None:
                process.kill()
            process.communicate()

    def foreground_package(self):
        state = self.command('shell', 'dumpsys', 'window', 'windows').decode('utf-8', errors='replace')
        # Android 7/9/11 used by BlueStacks expose the foreground window here.
        match = re.search(r'mCurrentFocus=Window\{[^\n}]*\s([A-Za-z0-9_.]+)/[^\s}]+', state)
        if not match:
            raise RuntimeError('ADB cannot identify the active Android app. Open the game, dismiss dialogs, and retry.')
        return match.group(1)

    def focus(self):
        """Connect the selected instance without bringing its desktop window forward."""
        self.check()
        # Only an explicitly selected loopback endpoint is auto-connected.
        # Other serials must already appear in adb devices; never pick one implicitly.
        if re.fullmatch(r'(?:127\.0\.0\.1|localhost):[0-9]{1,5}', self.settings.serial):
            self.command('connect', self.settings.serial, targeted=False)
        if self.command('get-state').strip() != b'device':
            raise RuntimeError('Selected ADB device is not ready. Enable Android Debug Bridge in BlueStacks settings.')
        package = self.foreground_package()
        if self.package is not None and package != self.package:
            raise RuntimeError('The active Android app changed; ADB sniping stopped.')
        if any(word in package.lower() for word in ('launcher', 'systemui')) or package == 'com.android.settings':
            raise RuntimeError('Open the game in BlueStacks before starting ADB sniping.')
        self.package = package
        self.capture()

    def capture(self):
        payload = self.command('exec-out', 'screencap', '-p')
        if not payload.startswith(b'\x89PNG\r\n\x1a\n'):
            raise RuntimeError('ADB did not return a PNG screenshot. Check the selected BlueStacks instance.')
        frame = cv2.imdecode(np.frombuffer(payload, np.uint8), cv2.IMREAD_COLOR)
        if frame is None:
            raise RuntimeError('ADB screenshot could not be decoded.')
        height, width = frame.shape[:2]
        if width >= height:
            raise RuntimeError('ADB sniping requires the existing portrait game layout. Restore portrait orientation.')
        size = (width, height)
        if self.size is not None and size != self.size:
            raise RuntimeError('Android display resolution changed. Stop, check calibration, and restart sniping.')
        self.size = size
        left, top, right, bottom = self.settings.content_rect
        if abs((right-left)/(bottom-top) / (width/height) - 1) > .08:
            raise RuntimeError('ADB game area has a different aspect ratio. Calibrate the game area in Sniping settings.')
        # Preserve native capture detail for GemDetector. Only the patrol's
        # alignment code downsizes to its canonical reference dimensions.
        scale = width / (right-left)
        reference = np.zeros((round(1029*scale), round(570*scale), 3), np.uint8)
        x1, y1, x2, y2 = (round(v*scale) for v in (left, top, right, bottom))
        reference[y1:y2, x1:x2] = cv2.resize(frame, (x2-x1, y2-y1), interpolation=cv2.INTER_AREA)
        return reference

    def guard(self):
        self.check()
        if self.package is None or self.size is None:
            raise RuntimeError('Connect and preview the ADB device before sending input.')
        if self.foreground_package() != self.package:
            raise RuntimeError('The active Android app changed; ADB sniping stopped.')
        # Detect rotations/resolution changes before sending coordinates.
        self.capture()

    def point(self, reference):
        x, y = reference
        left, top, right, bottom = self.settings.content_rect
        if not (math.isfinite(x) and math.isfinite(y) and left <= x < right and top <= y < bottom):
            raise ValueError('ADB input point is outside the calibrated Android game area.')
        if self.size is None:
            raise RuntimeError('ADB screenshot dimensions are unavailable.')
        width, height = self.size
        return min(width-1, round((x-left)*width/(right-left))), min(height-1, round((y-top)*height/(bottom-top)))

    def click(self, reference):
        self.guard()
        x, y = self.point(reference)
        self.command('shell', 'input', 'touchscreen', 'tap', str(x), str(y))

    def drag(self, start, end):
        self.guard()
        x1, y1 = self.point(start)
        x2, y2 = self.point(end)
        # One bounded Android gesture avoids a stuck touch on disconnect/F10.
        # Android swipe has no stationary endpoint hold; visual pan recovery
        # remains responsible for inertia and overshoot.
        duration = max(350, min(850, round(math.dist(start, end)*2)))
        self.command('shell', 'input', 'touchscreen', 'swipe', str(x1), str(y1), str(x2), str(y2), str(duration))

    @classmethod
    def peek(cls, settings):
        """Read-only connection preview; sends no taps, swipes or focus requests."""
        with cls(threading.Event(), settings) as backend:
            backend.focus()
            return backend.capture()
