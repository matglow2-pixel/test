"""Package the built EXE in a standards-compatible RAR 4 archive (store method)."""
from pathlib import Path
import argparse
import struct
import zlib


def header(kind, flags, body=b''):
    data = struct.pack('<BHH', kind, flags, 7 + len(body)) + body
    return struct.pack('<H', zlib.crc32(data) & 0xffff) + data


def package(executable, output):
    executable, output = Path(executable), Path(output)
    if output.suffix.lower() != '.rar':
        raise ValueError('Use a .rar output filename.')
    if executable.suffix.lower() != '.exe' or not executable.is_file():
        raise ValueError('Build the Windows EXE before packaging.')
    size = executable.stat().st_size
    if size >= 2**32:
        raise ValueError('This RAR packager supports EXEs smaller than 4 GiB.')
    name = executable.name.encode('ascii')
    crc = 0
    with executable.open('rb') as source:
        if source.read(2) != b'MZ':
            raise ValueError('The input does not have a Windows executable signature.')
        source.seek(0)
        while chunk := source.read(1024*1024):
            crc = zlib.crc32(chunk, crc)
    # RAR 4 file header: packed/unpacked size, Windows host, CRC, DOS date,
    # minimum unpack version 2.0, store method, filename length and attributes.
    body = struct.pack('<IIBIIBBHI', size, size, 2, crc, (40 << 25) | (1 << 21) | (1 << 16),
                       20, 0x30, len(name), 0x20) + name
    temporary = output.with_suffix(output.suffix + '.tmp')
    try:
        with temporary.open('wb') as archive, executable.open('rb') as source:
            archive.write(b'Rar!\x1a\x07\x00')
            archive.write(header(0x73, 0, b'\x00'*6))
            archive.write(header(0x74, 0x8000, body))
            while chunk := source.read(1024*1024):
                archive.write(chunk)
            archive.write(header(0x7b, 0))
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    package(args.executable, args.output)
