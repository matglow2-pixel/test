"""Real Tk ADB settings/calibration smoke test with simulated device screenshots.

Run with DISPLAY pointing at an X server on Linux. Sends no device/desktop input.
"""
from pathlib import Path
import json
import os
import sys
import tempfile
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ['XDG_CACHE_HOME'] = tempfile.mkdtemp(prefix='adb-ui-')
(Path(os.environ['XDG_CACHE_HOME']) / 'LoongLens').mkdir()

import numpy as np
import tkinter as tk
from tkinter import ttk
import patrol_live_panel
from patrol_adb import AdbBackend, InputSettings
from resources import ResourceStore
from ui_theme import apply_theme


class Keys:
    def __init__(self, *args, **kwargs): pass
    def close(self): pass


def widgets(parent):
    for child in parent.winfo_children():
        yield child
        yield from widgets(child)


def button(parent, label):
    return next(w for w in widgets(parent) if isinstance(w, ttk.Button) and w.cget('text') == label)


def wait_for(root, predicate):
    deadline = time.monotonic() + 3
    while not predicate():
        assert time.monotonic() < deadline, 'UI action timed out'
        root.update()
        time.sleep(.01)


def main():
    patrol_live_panel.GlobalPatrolKeys = Keys
    frame = np.full((1029, 570, 3), (40, 90, 140), np.uint8)
    patrol_live_panel.WindowsBackend = SimpleNamespace(peek=lambda: frame.copy())
    previews = []
    original_peek = AdbBackend.peek
    AdbBackend.peek = classmethod(lambda cls, options: previews.append(options) or frame.copy())
    root = tk.Tk()
    errors = []
    root.report_callback_exception = lambda kind, value, tb: errors.append(str(value))
    root.geometry('700x950')
    apply_theme(root)
    host = ttk.Frame(root)
    host.pack(fill='both', expand=True)
    watch = SimpleNamespace(flush_sightings=lambda: None)
    panel = patrol_live_panel.LivePatrolPanel(host, ResourceStore().data, watch)
    try:
        assert panel.input_settings.mode == 'Mouse'
        panel.show_settings()
        win = next(w for w in root.winfo_children() if isinstance(w, tk.Toplevel))
        root.update()
        combos = [w for w in widgets(win) if isinstance(w, ttk.Combobox)]
        next(w for w in combos if tuple(w.cget('values')) == ('Mouse', 'ADB')).set('ADB')
        entries = [w for w in widgets(win) if isinstance(w, ttk.Entry) and not isinstance(w, ttk.Combobox)]
        # Existing map-button and timing fields precede the three ADB fields.
        entries[-2].delete(0, 'end'); entries[-2].insert(0, '127.0.0.1:5575')
        button(win, 'Test connection / preview').invoke()
        wait_for(root, lambda: bool(previews) and any(isinstance(w, tk.Toplevel) for w in win.winfo_children()))
        assert previews[-1].mode == 'ADB' and previews[-1].serial == '127.0.0.1:5575'
        preview = next(w for w in win.winfo_children() if isinstance(w, tk.Toplevel))
        preview.destroy()
        button(win, 'Pick game area').invoke()
        picker = next(w for w in win.winfo_children() if isinstance(w, tk.Toplevel))
        root.update()
        canvas = next(w for w in picker.winfo_children() if isinstance(w, tk.Canvas))
        canvas.event_generate('<Button-1>', x=8, y=28)
        canvas.event_generate('<Button-1>', x=400, y=700)
        root.update()
        assert entries[-1].get() != '0,0,570,1029'
        # Use an exact profile for the persistence checks.
        entries[-1].delete(0, 'end'); entries[-1].insert(0, '10,40,550,1000')
        button(win, 'Save settings').invoke()
        root.update()
        assert panel.input_settings == InputSettings(mode='ADB', serial='127.0.0.1:5575', content_rect=(10, 40, 550, 1000))
        saved = json.loads(panel.path.read_text())
        assert InputSettings.load(saved) == panel.input_settings
        assert isinstance(panel.make_backend(panel.runner.cancel), AdbBackend)
        assert not errors, errors
        print('ADB settings UI passed: selection, async preview, game-area picker, save/reload and backend routing.')
    finally:
        panel.close()
        root.destroy()
        AdbBackend.peek = original_peek


if __name__ == '__main__':
    main()
