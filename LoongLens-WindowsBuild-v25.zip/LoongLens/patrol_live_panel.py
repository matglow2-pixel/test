"""User-controlled real BlueStacks input and patrol status/history integration."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import json
import queue
import threading
import tkinter as tk
from tkinter import ttk,messagebox
from pathlib import Path
import cv2
from PIL import Image,ImageDraw,ImageTk
from patrol_route import load_fixed_route,load_camera_adjustments,save_camera_adjustments
from patrol_live import LiveSettings,LiveRunner,load_live_config,LIVE_SETTINGS_VERSION
from patrol_windows import WindowsBackend,GlobalPatrolKeys
from patrol_adb import AdbBackend,InputSettings
from sighting_capture import SightingCapture
from resources import user_dir


class LivePatrolPanel:
    def __init__(self,parent,data,watch,on_active=lambda active:None):
        self.parent=parent;self.root=parent.winfo_toplevel();self.watch=watch;self.on_active=on_active
        self.key=tk.StringVar(value='F8')
        self.status=tk.StringVar(value='Preparing live controls…')
        self.location=tk.StringVar(value='Fixed path starts at Emerald Corner. Route #26, #51 and #72 are excluded.')
        self.count=tk.StringVar(value='Preparing grouped camera checks…')
        self.pass_text=tk.StringVar(value='')
        self.stats_text=tk.StringVar(value='Time spent: 0:00\nGems found: 0')
        self.events=queue.Queue();self.keys=None;self.closed=False;self.busy=False
        self.job=None;self.photo=None;self.futures=[];self.editing=False;self.editor=None
        self.path=user_dir()/'patrol-live-settings.json'
        self.input_settings=InputSettings();self.input_error=None
        try:
            config=json.loads(self.path.read_text('utf-8'))
            self.settings,key,migrated=load_live_config(config)
            self.key.set(key)
            if migrated:self.status.set('Updated Open map to the top-right minimap.')
        except (OSError,ValueError,KeyError,TypeError):self.settings=LiveSettings()
        try:
            if self.path.exists():self.input_settings=InputSettings.load(json.loads(self.path.read_text('utf-8')))
        except (OSError,ValueError,KeyError,TypeError) as exc:
            self.input_error=f'Check input settings before sniping: {exc}'
        self.base_views=load_fixed_route(data);self.route_path=user_dir()/'camera-route-adjustments.json'
        warning=None
        try:views=load_camera_adjustments(self.base_views,self.route_path)
        except (OSError,ValueError,TypeError) as exc:
            views=self.base_views;warning=f'Using default camera targets: {exc}'
        self.runner=LiveRunner(views,self.make_backend,self.events.put)
        self.update_count()
        # Patrol captures already have their map location and bypass player OCR.
        self.capture_store=SightingCapture(user_dir(),reader=object())
        self.save_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='Patrol-screenshot')
        self.build_ui();self.bind_keys();self.job=self.root.after(100,self.poll)
        if warning:self.status.set(warning)
        if self.input_error:self.status.set(self.input_error)

    def make_backend(self,cancel):
        if self.input_settings.mode=='ADB':return AdbBackend(cancel,self.input_settings)
        return WindowsBackend(cancel)

    def build_ui(self):
        from ui_theme import FONT, heading, card, row, CARD, MUTED
        body=ttk.Frame(self.parent,padding=(20,18));body.pack(fill='both',expand=True)
        heading(body, 'Gem Sniping', 'Check known gem spots without moving your character.')
        controls=card(body, 'SNIPING CONTROLS')
        line=row(controls)
        ttk.Label(line,text='Ready when you are',style='Card.TLabel').pack(side='left')
        ttk.Button(line,text='Edit route',command=self.show_route_editor,padding=(10,5)).pack(side='left',padx=10)
        ttk.Label(line,text='F10 · emergency stop',style='CardTitle.TLabel').pack(side='right')
        line=row(controls)
        ttk.Label(line,text='Snipe key',style='CardMuted.TLabel').pack(side='left')
        box=ttk.Combobox(line,textvariable=self.key,values=('F6','F7','F8','F9'),state='readonly',width=5)
        box.pack(side='left',padx=8);box.bind('<<ComboboxSelected>>',self.change_key)
        ttk.Button(line,text='Sniping settings',command=self.show_settings,padding=(10,7)).pack(side='right')
        self.history_button=ttk.Button(line,text='History',command=self.show_history,padding=(10,7))
        self.history_button.pack(side='right',padx=(0,6))
        status=card(body)
        ttk.Label(status,textvariable=self.status,style='Status.TLabel',wraplength=450).pack(anchor='w')
        ttk.Label(status,textvariable=self.location,style='CardMuted.TLabel',wraplength=450).pack(anchor='w',pady=(5,7))
        ttk.Label(status,textvariable=self.count,style='CardMuted.TLabel').pack(anchor='w')
        ttk.Separator(status).pack(fill='x',pady=9)
        ttk.Label(status,textvariable=self.stats_text,style='Stats.TLabel').pack(anchor='w')
        ttk.Label(status,textvariable=self.pass_text,style='CardMuted.TLabel',wraplength=450).pack(anchor='w')
        self.progress=ttk.Progressbar(status,maximum=len(self.runner.views))
        self.progress.pack(fill='x',pady=(9,0))
        actions=ttk.Frame(body);actions.pack(fill='x',pady=(0,10))
        self.snipe=ttk.Button(actions,text='Snipe',style='Primary.TButton',command=lambda:self.start(False));self.snipe.pack(side='left')
        self.repeat=ttk.Button(actions,text='Loop Sniping',command=lambda:self.start(True));self.repeat.pack(side='left',padx=6)
        ttk.Button(actions,text='Stop (F10)',style='Stop.TButton',command=self.stop).pack(side='left')
        ttk.Button(actions,text='Reset checks',command=self.reset).pack(side='right')
        footer=ttk.Frame(body)
        footer.pack(side='bottom',fill='x',pady=(10,0))
        ttk.Label(footer,text='Snipe checks once. Loop Sniping repeats until a gem or F10.\nMouse mode needs a visible, focused BlueStacks window.\nADB mode frees your mouse. Choose input in Sniping settings.',
                  style='Muted.TLabel',font=(FONT,9),wraplength=470).pack(anchor='w')
        viewport=tk.Frame(body,bg=CARD,height=220)
        viewport.pack(fill='both',expand=True);viewport.pack_propagate(False)
        self.preview=tk.Label(viewport,bg=CARD,fg=MUTED,text='Your latest camera check will appear here.')
        self.preview.pack(fill='both',expand=True)
        self.update_count();self.buttons()

    def show_history(self):
        if self.busy:self.runner.stop()
        self.watch.flush_sightings()
        self.watch.sighting_controls.show()

    def show_route_editor(self):
        if self.editor is not None:self.editor.window.lift();return
        if self.editing:return
        self.editing=True;self.runner.stop();self.buttons()
        def open_when_stopped():
            if self.closed:return
            if self.runner.running:self.root.after(50,open_when_stopped);return
            self.drain()
            from route_editor import RouteEditor
            def close():
                self.editor=None;self.editing=False;self.buttons()
            def save(views):
                save_camera_adjustments(self.base_views,views,self.route_path)
                self.runner.views=views;self.runner.navigation.clear();self.reset()
                self.status.set('Camera targets saved. Checks reset; the next pass uses your adjusted route.')
            self.editor=RouteEditor(self.root,self.base_views,self.runner.views,save,close)
        open_when_stopped()

    def buttons(self):
        ready=self.keys is not None and not self.busy and not self.editing
        for button in (self.snipe,self.repeat):button.configure(state='normal' if ready else 'disabled')

    def bind_keys(self):
        self.stop(silent=True)
        if self.keys is not None:self.keys.close();self.keys=None
        try:
            self.keys=GlobalPatrolKeys(lambda:self.events.put(dict(kind='advance')),
                self.emergency,key=self.key.get())
            self.status.set(f'Ready. {self.key.get()} starts the fixed path; F10 stops.')
        except Exception as exc:
            self.status.set(str(exc))
            messagebox.showerror('Live controls unavailable',str(exc),parent=self.root)
        self.buttons();self.save_config()

    def change_key(self,event=None):
        self.bind_keys()

    def emergency(self):
        self.runner.stop()  # Called directly on the hotkey thread, without Tk delay.
        self.events.put(dict(kind='panic'))

    def start(self,repeat=False):
        if self.keys is None or self.busy or self.editing:return
        if self.input_error:self.status.set(self.input_error);return
        if not repeat and len(self.runner.checked)>=len(self.runner.views):
            self.status.set('Pass complete. Use Reset checks to start a new timed pass.');return
        with self.watch.worker.lock:
            self.runner.cooldown['last']=max(self.runner.cooldown['last'],self.watch.worker.last_live_sighting)
            self.runner.cooldown['sound']=max(self.runner.cooldown.get('sound',-float('inf')),self.watch.worker.gate.last_alert)
        settings=LiveSettings(self.settings.map_open,self.settings.map_close,
            self.settings.settle_seconds,self.settings.inspect_seconds,
            {'Conservative':.84,'Balanced':.77,'Sensitive':.70}[self.watch.mode.get()],self.watch.mask_hud.get(),self.settings.approach_gem)
        self.watch.suspend_for_patrol()
        self.on_active(True);self.busy=True;self.buttons()
        if not self.runner.start(settings,auto=True,repeat=repeat):
            self.busy=False;self.watch.patrol_busy=False;self.on_active(False);self.buttons()

    def stop(self,silent=False):
        self.runner.stop()
        if not silent:self.status.set('Stop requested. A delivered ADB gesture may take under a second to finish.' if self.input_settings.mode=='ADB' else 'Stop requested. Mouse input is being released.')

    def reset(self):
        if self.busy:
            self.status.set('Stop patrol before resetting its checked locations.');return
        if not self.runner.reset_checks():
            self.status.set('Wait for sniping to stop before resetting checks.');return
        self.pass_text.set('');self.stats_text.set(self.runner.stats.text());self.update_count()
        self.status.set('Checks reset.')

    def update_count(self):
        views=self.runner.views
        checked=self.runner.checked.copy()
        covered=set().union(*(views[i].cells for i in checked)) if checked else set()
        total=set().union(*(view.cells for view in views))
        if hasattr(self,'progress'):self.progress.configure(value=len(checked),maximum=len(views))
        self.count.set(f'Processed: {len(self.runner.checked)} / {len(views)} views · Locked skips: {len(self.runner.skipped)}\nSpawn spots processed: {len(covered)} / {len(total)}')

    def show_frame(self,frame,boxes=()):
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));pen=ImageDraw.Draw(image)
        for box in boxes:pen.rectangle((box.x,box.y,box.x+box.width,box.y+box.height),outline='#f45bd0',width=3)
        image.thumbnail((440,max(80,min(240,self.preview.winfo_height()-8))));self.photo=ImageTk.PhotoImage(image)
        self.preview.configure(image=self.photo,text='')

    def drain(self):
        while True:
            try:event=self.events.get_nowait()
            except queue.Empty:break
            kind=event['kind']
            if kind=='advance':
                if not self.closed:self.start(False)
            elif kind=='panic':self.status.set('F10 emergency stop.')
            elif kind=='status':self.status.set(event['message'])
            elif kind=='view':
                view=event['view']
                self.location.set(f'{"Route #"+view.route_label+" · " if view.route_number else ""}{view.near_zone} ({int(view.x)},{int(view.y)}) • {len(view.cells)} spawn spot(s) in this view')
            elif kind=='frame':self.show_frame(event['frame'],event['detections'])
            elif kind=='checked':self.update_count()
            elif kind=='pass_complete':
                times=[]
                for run in event['recent_passes']:
                    minutes,seconds=divmod(int(run['elapsed']),60)
                    times.append(f"#{run['number']} {minutes}:{seconds:02d}")
                self.pass_text.set(f"Passes completed: {event['passes']}\nLast 3 runs: "+' · '.join(times));self.update_count()
            elif kind=='pass_started':self.update_count()
            elif kind=='found':
                self.status.set('GEM FOUND — saving the scene, then clicking the gem once…' if self.settings.approach_gem else 'GEM FOUND — holding this view for its screenshot…')
                self.watch.last_alert.set('GEM DETECTED · camera patrol stopped')
                if self.watch.sound.get() and event.get('sound',True):self.watch.play_sound()
                if event['event'] is not None:
                    self.watch.pending_sightings.append(event['event'])
                    with self.watch.worker.lock:self.watch.worker.last_live_sighting=self.runner.cooldown['last']
                else:self.status.set('Gem found — stopped. History is within the 20-second cooldown.')
            elif kind=='capture':
                captured_at=event.get('captured_at',__import__('time').time())
                self.futures.append((self.save_pool.submit(self.capture_store.save,event['event'],event['frame'],captured_at),event['event']))
            elif kind=='sighting':self.watch.pending_sightings.append(event['event'])
            elif kind=='finished':
                self.busy=False;self.on_active(False);self.buttons()
                self.watch.patrol_busy=False
                self.status.set(event['message'])
        waiting=[]
        for future,event in self.futures:
            if not future.done():waiting.append((future,event));continue
            try:self.watch.pending_sightings.append(future.result())
            except Exception as exc:self.watch.pending_sightings.append(self.capture_store.unavailable(event,str(exc),'save_error'))
        self.futures=waiting
        self.watch.flush_sightings()

    def poll(self):
        self.job=None
        if self.closed:return
        try:
            self.drain()
            self.stats_text.set(self.runner.stats.text())
        except Exception:
            import logging
            self.runner.stop();logging.exception('Live patrol panel update failed')
            self.status.set('Patrol stopped after a display error; see loonglens.log.')
        self.job=self.root.after(100,self.poll)

    def save_config(self):
        try:
            tmp=self.path.with_suffix('.tmp')
            # Preserve an invalid input profile until the user explicitly repairs it.
            config=dict(version=LIVE_SETTINGS_VERSION,settings=asdict(self.settings),key=self.key.get(),input=asdict(self.input_settings))
            if self.input_error and self.path.exists():
                config['input']=json.loads(self.path.read_text('utf-8')).get('input',{})
            tmp.write_text(json.dumps(config,indent=2),'utf-8')
            tmp.replace(self.path)
        except (OSError,ValueError,TypeError):
            import logging
            logging.exception('Could not save patrol settings')

    def show_settings(self):
        if self.busy:
            self.status.set('Stop patrol before changing its settings.');return
        win=tk.Toplevel(self.root);win.title('Gem Sniping settings');win.transient(self.root)
        body=ttk.Frame(win,padding=18);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Map button positions in the 570×1029 reference screenshot.',font=('Segoe UI',10,'bold')).grid(row=0,column=0,columnspan=3,sticky='w')
        ttk.Label(body,text='Open map: click the round minimap in the top-right during gameplay.\nFor Back: manually open the large map first, then pick its Back button.',style='Muted.TLabel').grid(row=1,column=0,columnspan=3,sticky='w',pady=8)
        fields={}
        for row,name,label in ((2,'map_open','Open map (minimap)'),(3,'map_close','Map Back button')):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=6)
            field=ttk.Entry(body,width=15);field.insert(0,','.join(str(v) for v in getattr(self.settings,name)))
            field.grid(row=row,column=1,padx=8);fields[name]=field
            ttk.Button(body,text='Pick on screenshot',command=lambda f=field:self.pick_button(win,f)).grid(row=row,column=2)
        for row,name,label in ((4,'settle_seconds','Scene loading wait (seconds)'),(5,'inspect_seconds','Empty-view check (seconds)')):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=6)
            field=ttk.Entry(body,width=15);field.insert(0,str(getattr(self.settings,name)));field.grid(row=row,column=1,padx=8);fields[name]=field
        approach=tk.BooleanVar(value=self.settings.approach_gem)
        ttk.Checkbutton(body,text='On gem: click the gem itself once, then stop',variable=approach).grid(row=6,column=0,columnspan=3,sticky='w')
        mode=tk.StringVar(value=self.input_settings.mode)
        ttk.Label(body,text='Input method').grid(row=7,column=0,sticky='w')
        ttk.Combobox(body,textvariable=mode,values=('Mouse','ADB'),state='readonly',width=12).grid(row=7,column=1,sticky='w',padx=8)
        inputs={}
        for row,name,label,value in ((8,'adb_path','ADB executable (blank = auto)',self.input_settings.adb_path),
                                     (9,'serial','ADB device / loopback address',self.input_settings.serial),
                                     (10,'content_rect','Game area: left,top,right,bottom',','.join(map(str,self.input_settings.content_rect)))):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky='w',pady=4)
            field=ttk.Entry(body,width=32);field.insert(0,value);field.grid(row=row,column=1,columnspan=2,sticky='ew',padx=8);inputs[name]=field
        error=tk.StringVar();ttk.Label(body,textvariable=error,wraplength=560).grid(row=13,column=0,columnspan=3,sticky='w')
        def read_input():
            return InputSettings(mode=mode.get(),adb_path=inputs['adb_path'].get().strip(),serial=inputs['serial'].get().strip(),
                                 content_rect=tuple(int(v.strip()) for v in inputs['content_rect'].get().split(',')))
        # Screenshot calibration must use the selected, unsaved backend too.
        win.read_input=read_input
        def preview():
            try:options=read_input()
            except (ValueError,TypeError) as exc:error.set(str(exc));return
            error.set('Reading screenshot…')
            def show(frame):
                error.set('Screenshot received. Check game area and map-button calibration before sniping.')
                self.show_capture_picker(win,frame,None)
            self.read_screenshot(win,options,show,lambda exc:error.set(str(exc)))
        ttk.Button(body,text='Test connection / preview',command=preview).grid(row=11,column=0,columnspan=2,sticky='w',pady=6)
        ttk.Button(body,text='Pick game area',command=lambda:self.pick_game_area(win,inputs['content_rect'])).grid(row=11,column=2,sticky='e')
        ttk.Label(body,text='Enable Android Debug Bridge in BlueStacks Settings → Advanced. Use its exact port.\nPick game area once from the visible BlueStacks window: Android image only, excluding\nWindows title bar, side toolbar and bottom controls. Then preview and pick map buttons.\nADB mode needs the game running/rendering; minimizing may pause some BlueStacks setups.',
                  wraplength=560,style='Muted.TLabel').grid(row=12,column=0,columnspan=3,sticky='w',pady=6)
        def apply():
            if self.busy or self.runner.running:error.set('Stop sniping before saving settings.');return
            try:
                points={name:tuple(float(v.strip()) for v in fields[name].get().split(',')) for name in ('map_open','map_close')}
                settings=LiveSettings(**points,settle_seconds=float(fields['settle_seconds'].get()),inspect_seconds=float(fields['inspect_seconds'].get()),approach_gem=approach.get())
                options=read_input()
            except (TypeError,ValueError) as exc:error.set(str(exc));return
            if options!=self.input_settings:self.runner.navigation.clear()
            self.settings=settings;self.input_settings=options;self.input_error=None
            self.status.set(f'{options.mode} input selected. '+('Your desktop mouse is free; keep the Android game running.' if options.mode=='ADB' else 'BlueStacks must stay visible and focused.'))
            self.save_config();win.destroy()
        ttk.Button(body,text='Save settings',command=apply).grid(row=14,column=0,sticky='w',pady=10)
        ttk.Button(body,text='Cancel',command=win.destroy).grid(row=14,column=2,sticky='e')

    def read_screenshot(self,parent,options,done,failed):
        # ADB discovery/capture must not block Tk or the stop button.
        result=queue.Queue()
        def work():
            try:result.put((True,AdbBackend.peek(options) if options.mode=='ADB' else WindowsBackend.peek()))
            except Exception as exc:result.put((False,exc))
        threading.Thread(target=work,daemon=True,name='ADB-preview').start()
        def poll():
            if self.closed or not parent.winfo_exists():return
            try:success,value=result.get_nowait()
            except queue.Empty:self.root.after(50,poll);return
            (done if success else failed)(value)
        poll()

    def pick_button(self,parent,field):
        try:options=parent.read_input()
        except Exception as exc:messagebox.showerror('Capture unavailable',str(exc),parent=parent);return
        self.read_screenshot(parent,options,lambda frame:self.show_capture_picker(parent,frame,field),
                             lambda exc:messagebox.showerror('Capture unavailable',str(exc),parent=parent))

    def show_capture_picker(self,parent,frame,field):
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));image.thumbnail((500,760))
        picker=tk.Toplevel(parent);picker.title('Click the button in this screenshot' if field is not None else 'Connection preview — no game input sent')
        photo=ImageTk.PhotoImage(image)
        canvas=tk.Canvas(picker,width=image.width,height=image.height,highlightthickness=0)
        canvas.pack();canvas.create_image(0,0,image=photo,anchor='nw');canvas.photo=photo
        def select(event):
            field.delete(0,'end');field.insert(0,f'{event.x*570/image.width:.1f},{event.y*1029/image.height:.1f}');picker.destroy()
        if field is not None:canvas.bind('<Button-1>',select)

    def pick_game_area(self,parent,field):
        # Calibration reads the visible window only; it never sends game input.
        try:frame=WindowsBackend.peek()
        except Exception as exc:messagebox.showerror('Show BlueStacks for calibration',str(exc),parent=parent);return
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));image.thumbnail((500,760))
        picker=tk.Toplevel(parent);picker.title('Pick Android image top-left, then bottom-right (exclude emulator chrome)')
        photo=ImageTk.PhotoImage(image);points=[]
        canvas=tk.Canvas(picker,width=image.width,height=image.height,highlightthickness=0)
        canvas.pack();canvas.create_image(0,0,image=photo,anchor='nw');canvas.photo=photo
        def select(event):
            points.append((round(event.x*570/image.width),round(event.y*1029/image.height)))
            if len(points)==1:canvas.create_oval(event.x-4,event.y-4,event.x+4,event.y+4,outline='#ff79dc',width=2);return
            left,top=points[0];right,bottom=points[1]
            try:InputSettings(content_rect=(left,top,right,bottom))
            except ValueError as exc:points.clear();messagebox.showerror('Invalid game area',str(exc),parent=picker);return
            field.delete(0,'end');field.insert(0,f'{left},{top},{right},{bottom}');picker.destroy()
        canvas.bind('<Button-1>',select)

    def close(self):
        if self.closed:return
        self.closed=True;self.runner.stop()
        if self.job is not None:self.root.after_cancel(self.job);self.job=None
        if self.keys is not None:self.keys.close();self.keys=None
        if self.runner.thread is not None:self.runner.thread.join(timeout=3)
        self.drain();self.save_pool.shutdown(wait=True);self.drain()
        self.capture_store.close();self.save_config()
