"""Gem Spy controls and histories, using Gem Sniper's route and preferences."""
from dataclasses import replace
from datetime import datetime
from pathlib import Path
import os
import queue
import tkinter as tk
from tkinter import ttk,messagebox
from resources import user_dir
from spy_history import SpyHistory
from spy_runner import SpyRunner


def stamp(value):return datetime.fromtimestamp(value).strftime('%d/%m/%y %H:%M:%S') if value is not None else 'Unknown'


def window_label(row):
    return f"{stamp(row['last_empty'])} – {stamp(row['first_seen'])}" if row['last_empty'] is not None else 'Already present at first observation'


class SpyHistoryWindow:
    def __init__(self,root,history,services):
        self.root=root;self.history=history;self.services=services;self.window=None;self.job=None;self.rows={}

    def show(self,page='Sightings'):
        if self.window is not None and self.window.winfo_exists():
            self.notebook.select(self.pages[page]);self.window.lift();self.refresh();return
        self.window=win=tk.Toplevel(self.root);win.title('Gem Spy history');win.geometry('1160x560');win.minsize(780,400)
        win.transient(self.root);win.protocol('WM_DELETE_WINDOW',self.close)
        body=ttk.Frame(win,padding=14);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Gem Spy history',style='Heading.TLabel').pack(anchor='w')
        ttk.Label(body,text='One encounter per continuing gem. Times use your PC clock; appearance windows are observation bounds.',wraplength=1080).pack(anchor='w',pady=(4,10))
        self.notebook=ttk.Notebook(body);self.notebook.pack(fill='both',expand=True);self.pages={};self.tables={}
        definitions={
            'Sightings':[('location','Location / camera view',205),('first','First seen',145),('empty','Last empty',145),
                         ('window','Appearance window',300),('last','Last seen',145),('missing','First missing',145),
                         ('runs','Runs seen',75),('photo','Screenshot',120)],
            'Hourly':[('date','Date',110),('hour','Hour',140),('timezone','UTC offset',100),('gems','New gems seen',130),('checks','Checks',90)],
            'Timing patterns':[('location','Location / camera view',220),('candidate','Candidate minute(s) of hour',350),
                               ('support','Supporting windows',160),('appearances','Appearances',100),('gap','Median observed gap',180)],
            'Check log':[('time','Checked at',150),('run','Run',65),('location','Location',220),('outcome','Result',90),('reason','Note',520)]}
        for name,columns in definitions.items():
            page_frame=ttk.Frame(self.notebook,padding=8);self.pages[name]=page_frame;self.notebook.add(page_frame,text=name)
            table=ttk.Treeview(page_frame,columns=[c[0] for c in columns],show='headings',selectmode='browse')
            for key,label,width in columns:table.heading(key,text=label);table.column(key,width=width,minwidth=55,stretch=False)
            y=ttk.Scrollbar(page_frame,orient='vertical',command=table.yview)
            x=ttk.Scrollbar(page_frame,orient='horizontal',command=table.xview)
            table.configure(yscrollcommand=y.set,xscrollcommand=x.set)
            page_frame.rowconfigure(0,weight=1);page_frame.columnconfigure(0,weight=1)
            table.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew')
            self.tables[name]=table
        self.tables['Sightings'].bind('<Double-1>',lambda _:self.open_photo())
        footer=ttk.Frame(body);footer.pack(fill='x',pady=(8,0))
        ttk.Button(footer,text='Open screenshot',command=self.open_photo).pack(side='left')
        ttk.Button(footer,text='Standard history',command=self.services.sighting_controls.show).pack(side='left',padx=8)
        ttk.Button(footer,text='Close',command=self.close).pack(side='right')
        self.note=tk.StringVar(win);ttk.Label(body,textvariable=self.note,wraplength=1080).pack(anchor='w',pady=(6,0))
        self.notebook.select(self.pages[page]);self.refresh();self.job=self.root.after(2000,self.tick)

    @staticmethod
    def fill(table,rows):
        selected=table.selection();wanted={str(key) for key,_ in rows};existing=set(table.get_children())
        for key in existing-wanted:table.delete(key)
        for index,(key,values) in enumerate(rows):
            key=str(key)
            if key in existing:table.item(key,values=values)
            else:table.insert('',index,iid=key,values=values)
            table.move(key,'',index)
        if selected and selected[0] in wanted:table.selection_set(selected[0])

    def refresh(self):
        if self.window is None:return
        rows=self.history.encounters();self.rows={r['id']:r for r in rows}
        self.fill(self.tables['Sightings'],[(r['id'],(
            f"#{r['point']} · {r['zone']} ({r['camera_x']:g},{r['camera_y']:g})",stamp(r['first_seen']),stamp(r['last_empty']),
            window_label(r),stamp(r['last_seen']),stamp(r['first_missing']),r['runs'],
            'Open screenshot' if r['screenshot_path'] else r['capture_status'])) for r in rows])
        hours=[]
        for r in self.history.hours():
            a=datetime.fromtimestamp(r['hour_start']).astimezone();b=datetime.fromtimestamp(r['hour_start']+3600).astimezone()
            offset=a.strftime('%z') if a.utcoffset()==b.utcoffset() else a.strftime('%z')+' → '+b.strftime('%z')
            hours.append((r['hour_key'],(a.strftime('%d/%m/%Y'),a.strftime('%H:%M')+'–'+b.strftime('%H:%M'),offset,r['gems'],r['checks'])))
        self.fill(self.tables['Hourly'],hours)
        self.fill(self.tables['Timing patterns'],[(i,(f"#{r['point']} · {r['zone']}",r['candidate'],r['support'],r['appearances'],
            f"{r['gap_minutes']:.1f} min" if r['gap_minutes'] is not None else 'Learning')) for i,r in enumerate(self.history.patterns())])
        self.fill(self.tables['Check log'],[(r['id'],(stamp(r['checked_at']),r['run'],f"#{r['point']} · {r['zone']}",r['outcome'],r['reason'])) for r in self.history.visits()])
        self.note.set('Hourly counts use first confirmed sightings, not estimated spawn times. Repeated sightings add no new count.\n'
                      'Timing candidates need repeated windows; observed gaps can include missed appearances. Check log shows the latest 1,000 visits.')

    def tick(self):
        self.job=None
        if self.window is not None:self.refresh();self.job=self.root.after(2000,self.tick)

    def open_photo(self):
        selected=self.tables['Sightings'].selection();row=self.rows.get(selected[0]) if selected else None
        if row and row['screenshot_path'] and Path(row['screenshot_path']).is_file():os.startfile(row['screenshot_path'])
        elif self.window is not None:messagebox.showinfo('Screenshot','Select a sighting with a saved screenshot.',parent=self.window)

    def close(self):
        if self.job is not None:self.root.after_cancel(self.job);self.job=None
        if self.window is not None:self.window.destroy();self.window=None


class SpyPanel:
    def __init__(self,parent,sniper,services,on_active=lambda active:None):
        self.root=parent.winfo_toplevel();self.parent=parent;self.sniper=sniper;self.services=services;self.on_active=on_active
        self.events=queue.Queue();self.runner=SpyRunner(user_dir(),self.events.put)
        self.history=SpyHistory(user_dir()/'sightings.sqlite3');self.history_window=SpyHistoryWindow(self.root,self.history,services)
        self.status=tk.StringVar(value='Ready — uses the route and settings selected in Gem Sniper.')
        self.location=tk.StringVar();self.stats=tk.StringVar();self.progress_text=tk.StringVar();self.photo=None
        self.closed=False;self.job=None;self.map_refresh=0.;self.sniper.spy_stop=self.runner.stop
        self.build_ui();self.poll()

    def build_ui(self):
        from ui_theme import heading,card,row,CARD,MUTED,FONT
        body=ttk.Frame(self.parent,padding=(20,18));body.pack(fill='both',expand=True)
        heading(body,'Gem Spy','Observe, record and continue. Your character stays where it is.')
        controls=card(body,'SPY CONTROLS');line=row(controls)
        self.start_button=ttk.Button(line,text='Start / Resume',style='Primary.TButton',command=self.start);self.start_button.pack(side='left')
        self.stop_button=ttk.Button(line,text='Stop (F10)',style='Stop.TButton',command=self.stop);self.stop_button.pack(side='left',padx=6)
        line=row(controls)
        ttk.Button(line,text='Spy history',command=lambda:self.history_window.show('Sightings')).pack(side='left')
        ttk.Button(line,text='Hourly history',command=lambda:self.history_window.show('Hourly')).pack(side='left',padx=6)
        ttk.Label(controls,textvariable=self.location,style='CardMuted.TLabel',wraplength=450).pack(anchor='w',pady=(8,0))
        state=card(body)
        ttk.Label(state,textvariable=self.status,style='Status.TLabel',wraplength=450).pack(anchor='w')
        ttk.Label(state,textvariable=self.progress_text,style='CardMuted.TLabel',wraplength=450).pack(anchor='w',pady=8)
        ttk.Label(state,textvariable=self.stats,style='Stats.TLabel').pack(anchor='w',pady=(0,8))
        self.progress=ttk.Progressbar(state);self.progress.pack(fill='x')
        footer=ttk.Frame(body);footer.pack(side='bottom',fill='x',pady=(10,0))
        ttk.Label(footer,text='New gems get one history entry and screenshot. Existing gems are tracked across runs.\n'
                  'Automatic recovery keeps progress. Stop / F10 always stays stopped.',style='Muted.TLabel',font=(FONT,9),wraplength=470).pack(anchor='w')
        viewport=tk.Frame(body,bg=CARD,height=230);viewport.pack(fill='both',expand=True);viewport.pack_propagate(False)
        from gem_heatmap_panel import HeatmapPreview
        self.map_preview=HeatmapPreview(viewport,self.root,self.services.sighting_history,user_dir())

    def start(self):
        if self.runner.running:return
        if self.sniper.keys is None:
            self.status.set('The global stop key is unavailable. Resolve hotkey setup in Gem Sniper first.');return
        if self.sniper.busy or self.sniper.editing or self.sniper.switching or not self.services.acquire('spy'):
            self.status.set('Stop Gem Sniper and close its route editor before starting Gem Spy.');return
        settings=replace(self.sniper.settings,threshold=self.services.threshold,mask_hud=self.services.mask_hud.get(),approach_gem=False)
        if not self.runner.start(self.sniper.runner.views,settings):self.services.release('spy');return
        self.status.set('Starting Gem Spy… F10 stops.');self.on_active(True);self.sniper.buttons()

    def stop(self):
        self.runner.stop();self.status.set('Stop requested — saving Spy progress.');self.on_active(False)

    def drain(self):
        while True:
            try:event=self.events.get_nowait()
            except queue.Empty:break
            kind=event['kind']
            if kind=='status':self.status.set(event['message'])
            elif kind=='view':
                view=event['view'];self.status.set(f'Run {self.runner.run_number} · Checking #{view.route_label} {view.near_zone}')
            elif kind=='spy_observed':
                if event['new']:
                    self.status.set(f"{event['new']} new gem(s) recorded — continuing")
                    self.services.play_sound()
                elif event['outcome']=='present':self.status.set('Gem still present — already recorded')
                elif event['outcome']=='unclear':self.status.set('Check unclear — not counted as empty')
            elif kind=='spy_finished':
                self.services.release('spy');self.status.set(event['message']);self.on_active(False);self.sniper.buttons()
            elif kind=='spy_history_changed':self.services.sighting_controls.refresh()
            elif kind=='frame':pass  # The panel now displays the map; original photos are still saved by Spy.


    def poll(self):
        self.job=None
        if self.closed:return
        self.drain()
        import time
        if time.monotonic()>=self.map_refresh:
            self.map_preview.refresh();self.map_refresh=time.monotonic()+2
        values=self.runner.snapshot();minutes,seconds=divmod(int(values['elapsed']),60)
        self.stats.set(f"Time spent: {minutes//60}:{minutes%60:02d}:{seconds:02d}\nGems found: {values['gems']}")
        self.progress_text.set(f"Run {values['run']} · Processed: {values['processed']} / {values['total']} locations")
        self.progress.configure(maximum=max(1,values['total']),value=values['processed'])
        self.location.set('Uses Gem Sniper route: '+self.sniper.route_name.get())
        self.start_button.configure(state='disabled' if self.runner.running or self.services.owner is not None or self.sniper.editing else 'normal')
        self.job=self.root.after(150,self.poll)

    def close(self):
        if self.closed:return
        self.closed=True;self.runner.stop()
        if self.job is not None:self.root.after_cancel(self.job);self.job=None
        if self.runner.thread is not None:self.runner.thread.join(timeout=5)
        self.map_preview.close();self.history_window.close();self.history.close();self.services.release('spy')
