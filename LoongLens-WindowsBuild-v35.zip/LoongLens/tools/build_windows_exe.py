"""Build one Windows EXE with the user's icon, CPU OCR and map resources embedded."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    if sys.platform != 'win32':
        raise SystemExit('Build on Windows with 64-bit Python 3.12.')
    assets = [
        'LoongLens-WhiteIcon.ico', 'LoongLens-Original-Optimized.ico',
        'launch_app.pyw', 'atlas_metadata.json', 'gem_sniping_route.json',
        'loong_haven_default_atlas.png', 'loong_title_template.png',
        'loong_haven_map_data.json', 'loong_haven_ingredients.json',
        'loong_haven_terrain.json',
        'gem_templates', 'ocr_models',
    ]
    command = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile',
               '--windowed', '--noupx', '--name', 'LoongLens',
               '--icon', str(ROOT/'LoongLens-WhiteIcon.ico'),
               '--collect-all', 'onnxruntime', '--collect-all', 'tzdata']
    for asset in assets:
        path = ROOT/asset
        if not path.exists():
            raise SystemExit(f'Missing asset: {path}')
        destination = asset if path.is_dir() else '.'
        command.extend(['--add-data', f'{path}:{destination}'])
    command.append(str(ROOT/'desktop_entry.py'))
    subprocess.run(command, cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
