"""Native Tk + real Spy/detector/storage; camera delivery uses a simulated backend."""
from datetime import datetime
from PIL import Image
import json
import logging
import os
from pathlib import Path
import sys
import tempfile
import traceback
import tkinter as tk
from tkinter import ttk
import cv2

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from test_spy_runner import SceneBackend
from test_live_patrol import Clock,Locator
from gem_detector import GemDetector
import loong_lens,patrol_live_panel,spy_panel


def main():
    if sys.platform!='win32':raise SystemExit('Run this native UI check on Windows.')
    temporary=tempfile.TemporaryDirectory(prefix='loonglens-spy-ui-')
    original_local=os.environ.get('LOCALAPPDATA');os.environ['LOCALAPPDATA']=temporary.name
    original=tk.Tk;panels={};errors=[];completed=[];state={}
    original_sniper=patrol_live_panel.LivePatrolPanel.__init__
    original_spy=spy_panel.SpyPanel.__init__
    def sniper(panel,*a,**kw):original_sniper(panel,*a,**kw);panels['sniper']=panel
    def spy(panel,*a,**kw):original_spy(panel,*a,**kw);panels['spy']=panel
    patrol_live_panel.LivePatrolPanel.__init__=sniper;spy_panel.SpyPanel.__init__=spy

    def descendants(widget):
        return [item for child in widget.winfo_children() for item in (child,*descendants(child))]

    class Window(original):
        def exit_app(self):
            button=next((w for w in descendants(self) if isinstance(w,ttk.Button) and w.cget('text')=='Exit'),None)
            if button is None:self.destroy()
            else:button.invoke()
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            def failed(kind,value,trace):
                error=''.join(traceback.format_exception(kind,value,trace));errors.append(error);print(error,flush=True);self.exit_app()
            self.report_callback_exception=failed
            self.after(1800,self.begin);self.after(120000,self.destroy)
        def begin(self):
            sniper=panels['sniper'];spy=panels['spy'];services=sniper.services;services.sound.set(False)
            notebook=next(w for w in descendants(self) if isinstance(w,ttk.Notebook))
            assert [notebook.tab(t,'text') for t in notebook.tabs()]==['Map Tweaker','Gem Sniper','Gem Spy']
            assert 'gem_watch_panel' not in sys.modules,'Removed tab is still being instantiated/imported'
            assert sniper.seen_text.get()=='0/5'
            import time
            sniper.events.put(dict(kind='found',event=None,seen_id='patrol:header-ui',seen_at=time.time(),sound=False))
            sniper.drain()
            old_mode=services.mode.get()
            sniper.show_settings();self.update_idletasks()
            settings=next(w for w in self.winfo_children() if isinstance(w,tk.Toplevel) and w.title()=='Gem Sniper settings')
            next(w for w in descendants(settings) if isinstance(w,ttk.Combobox)).set('Sensitive')
            next(w for w in descendants(settings) if isinstance(w,ttk.Button) and w.cget('text')=='Cancel').invoke()
            assert services.mode.get()==old_mode,'Cancel changed shared detection preferences'
            sniper.show_settings();self.update_idletasks()
            settings=next(w for w in self.winfo_children() if isinstance(w,tk.Toplevel) and w.title()=='Gem Sniper settings')
            next(w for w in descendants(settings) if isinstance(w,ttk.Combobox)).set('Sensitive')
            next(w for w in descendants(settings) if isinstance(w,ttk.Button) and w.cget('text')=='Save settings').invoke()
            assert services.mode.get()=='Sensitive'
            views=tuple(sniper.base_views[:2])
            sniper.routes.save_copy('Spy UI route',views);sniper.apply_route(views)
            clock=Clock();backend=SceneBackend(views,clock,fail_index=1);backend.cancel=spy.runner.cancel
            image=cv2.imread(str(ROOT/'gem_templates/gem_0.png'));h,w=image.shape[:2]
            backend.frame[400:400+h,240:240+w]=image
            runner=spy.runner;runner.backend_factory=lambda cancel:backend;runner.clock=clock
            runner.wall=lambda:datetime(2026,10,18,8).timestamp()+clock.now
            runner.detector=GemDetector();runner.locator=Locator(backend)
            from types import SimpleNamespace
            runner.title=SimpleNamespace(score=lambda f:float(f[0,0,0]))
            def wait(seconds):
                if runner.cancel.is_set():return True
                clock.now+=seconds;return runner.cancel.is_set()
            runner.retry_wait=wait
            emit=runner.emit
            def report(event):
                emit(event)
                if event['kind']=='spy_pass_complete' and event['run']>=2:runner.stop()
            runner.emit=report
            state.update(backend=backend,runner=runner,notebook=notebook)
            spy.start_button.invoke()
            assert services.owner=='spy' and sniper.route_box.instate(['disabled']) and sniper.edit_button.instate(['disabled'])
            notebook.select(notebook.tabs()[2]);self.after(100,self.first_done)
        def first_done(self):
            spy=panels['spy'];sniper=panels['sniper'];runner=state['runner'];backend=state['backend']
            if runner.running:self.after(100,self.first_done);return
            spy.drain();self.update_idletasks()
            assert sniper.services.owner is None and runner.snapshot()['gems']==2
            assert sniper.seen_text.get()=='1/5','Sniper counter did not update or counted Spy observations'
            assert runner.detector.threshold==.70,'Spy did not use Sniper detection preferences'
            assert backend.selections==[0,1,1,0,1],backend.selections
            assert any(row['outcome']=='unclear' for row in spy.history.visits())
            assert len(spy.history.encounters())==2
            assert len(list((Path(temporary.name)/'LoongLens/screenshots').glob('*.png')))==2
            standard=sniper.services.sighting_history.list()
            assert len(standard)==2 and all(row.source=='Gem Spy' and row.screenshot_path for row in standard)
            if not state.get('heatmap_started'):
                assert not any('Your latest Spy observation' in str(w.cget('text')) for w in descendants(spy.parent) if isinstance(w,tk.Label))
                preview=spy.map_preview;preview.refresh()
                assert preview.snapshot.total==2 and preview.snapshot.mapped==2
                assert preview.base.size==(3486,3486)
                preview.preview.event_generate('<Button-1>');self.update_idletasks()
                assert preview.window is not None and preview.window.title()=='Gem sightings heatmap'
                viewer=preview.viewer;initial=viewer.zoom
                preview.zoom_in.invoke();self.update_idletasks();assert viewer.zoom>initial
                viewer.canvas.focus_force();self.update()
                zoom=viewer.zoom;viewer.canvas.event_generate('<MouseWheel>',delta=120,x=180,y=180)
                self.update_idletasks();assert viewer.zoom>zoom
                viewer.zoom_at(100);self.update_idletasks();viewer.render()
                assert viewer.zoom==8. and viewer.photo.width()<=viewer.canvas.winfo_width()+32
                assert viewer.photo.height()<=viewer.canvas.winfo_height()+32
                viewer.canvas.xview_moveto(.4);viewer.canvas.yview_moveto(.4);self.update_idletasks();viewer.render()
                assert viewer.canvas.canvasx(0)>0 and viewer.canvas.canvasy(0)>0
                viewer.fit();self.update_idletasks();assert viewer.fitted
                preview.show_heat.set(False);preview.toggle_heat()
                assert preview.heat_image().tobytes()==preview.base.tobytes()
                preview.show_heat.set(True);preview.toggle_heat()
                exported=Path(temporary.name)/'heatmap-export.png';preview.heat_image().save(exported)
                with Image.open(exported) as picture:assert picture.size==(3486,3486)
                parts=[]
                with Image.open(ROOT/'loong_haven_default_atlas.png') as source:
                    for i,(top,bottom) in enumerate(((0,1550),(1050,2600),(2050,3486))):
                        path=Path(temporary.name)/f'map-part-{i}.png';source.crop((0,top,3486,bottom)).save(path);parts.append(path)
                state['heatmap_started']=True;preview.begin_import(parts)
                self.after(100,self.first_done);return
            if spy.map_preview.future is not None:self.after(100,self.first_done);return
            assert spy.map_preview.metadata['source_count']==3
            assert abs(spy.map_preview.base.width-3486)<8
            from heatmap_map_import import load_map
            saved,meta=load_map(Path(temporary.name)/'LoongLens')
            assert meta['source_count']==3 and saved.size==spy.map_preview.base.size
            from route_editor import RouteEditor
            editor=RouteEditor(self,tuple(sniper.base_views[:2]),tuple(sniper.base_views[:2]),lambda views:None)
            assert editor.map_metadata['source_count']==3 and editor.source.size==saved.size
            x,y=editor.world(*editor.point(241,107));assert abs(x-241)<.001 and abs(y-107)<.001
            editor.window.destroy();spy.map_preview.close_window()
            spy.history_window.show('Sightings');self.update_idletasks()
            assert len(spy.history_window.tables['Sightings'].get_children())==2
            spy.history_window.show('Hourly');self.update_idletasks()
            table=spy.history_window.tables['Hourly']
            assert sum(int(table.item(k,'values')[3]) for k in table.get_children())==2
            spy.history_window.close()
            # F10 while automatically retrying must cancel, not create another
            # worker or reset encounters/timing.
            state['elapsed']=runner.snapshot()['elapsed'];backend.always_fail=True
            emit=spy.events.put
            def report(event):
                emit(event)
                if event['kind']=='status' and event['message'].startswith('Recovering'):sniper.emergency()
            runner.emit=report
            spy.start_button.configure(state='normal');spy.start_button.invoke();self.after(100,self.second_done)
        def second_done(self):
            spy=panels['spy'];sniper=panels['sniper'];runner=state['runner']
            if runner.running:self.after(100,self.second_done);return
            spy.drain();sniper.drain()
            assert runner.cancel.is_set() and sniper.services.owner is None
            assert runner.snapshot()['gems']==2 and runner.snapshot()['elapsed']>=state['elapsed']
            assert len(spy.history.encounters())==2
            completed.append(dict(passed=True,version=35,unique_gems=2,screenshots=2,
                                  passes=2,recovery_kept_progress=True,f10_stays_stopped=True,
                                  heatmap_all_history=True,heatmap_zoom_pan=True,heatmap_viewport_bounded=True,
                                  heatmap_three_part_import=True,heatmap_saved_map_reloaded=True,route_editor_uses_imported_map=True))
            next(w for w in descendants(self) if isinstance(w,ttk.Button) and w.cget('text')=='Exit').invoke()
    tk.Tk=Window
    try:loong_lens.main([],default_tab='spy')
    finally:
        tk.Tk=original;patrol_live_panel.LivePatrolPanel.__init__=original_sniper;spy_panel.SpyPanel.__init__=original_spy
        # Windows cannot remove the isolated directory while its FileHandler
        # owns loonglens.log, even after the app and SQLite stores are closed.
        logging.shutdown()
        if original_local is None:os.environ.pop('LOCALAPPDATA',None)
        else:os.environ['LOCALAPPDATA']=original_local
        temporary.cleanup()
    assert completed and not errors,errors
    (ROOT/'spy-ui-check.json').write_text(json.dumps(completed[0],indent=2)+'\n','utf-8')
    print('Native Spy UI: selected Sniper route, real detector, two passes, no duplicates, both histories, map zoom/pan, three-part import/reload, route-editor display, recovery and F10 passed.')


if __name__=='__main__':main()
