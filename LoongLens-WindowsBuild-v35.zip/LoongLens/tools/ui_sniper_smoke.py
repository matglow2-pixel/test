"""Native Windows UI + real detector/storage; game delivery and waits are simulated."""
from dataclasses import replace
import json
import logging
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import time
import traceback
import tkinter as tk
import cv2

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import loong_lens,patrol_live_panel
from gem_detector import GemDetector
from test_spy_runner import SceneBackend
from test_live_patrol import Clock,Locator
from types import SimpleNamespace


def main():
    if sys.platform!='win32':raise SystemExit('Run this native UI check on Windows.')
    resume=len(sys.argv)>1 and sys.argv[1]=='--resume'
    temporary=SimpleNamespace(name=sys.argv[2],cleanup=lambda:None) if resume else tempfile.TemporaryDirectory(prefix='loonglens-sniper-ui-')
    previous_local=os.environ.get('LOCALAPPDATA');os.environ['LOCALAPPDATA']=temporary.name
    original_tk=tk.Tk;original_init=patrol_live_panel.LivePatrolPanel.__init__
    panels={};errors=[];results=[json.loads((ROOT/'sniper-ui-check.json').read_text())] if resume else []
    state={'missed_id':sys.argv[3]} if resume else {};phase=[1 if resume else 0]
    def remember(panel,*a,**kw):original_init(panel,*a,**kw);panels['sniper']=panel
    patrol_live_panel.LivePatrolPanel.__init__=remember

    class Window(original_tk):
        def exit_app(self):
            from tkinter import ttk
            def descendants(widget):
                return [item for child in widget.winfo_children() for item in (child,*descendants(child))]
            button=next((w for w in descendants(self) if isinstance(w,ttk.Button) and w.cget('text')=='Exit'),None)
            if button is None:self.destroy()
            else:button.invoke()
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            def failed(kind,value,trace):errors.append(''.join(traceback.format_exception(kind,value,trace)));self.exit_app()
            self.report_callback_exception=failed
            self.after(1800,self.begin);self.after(60000,self.exit_app)
        def begin(self):
            panel=panels['sniper'];panel.services.sound.set(False)
            now=time.time()
            if phase[0]==0:
                assert panel.seen_text.get()=='0/5' and not panel.endless.get()
                for i in range(4):panel.services.sighting_history.mark_sniper_seen(f'patrol:earlier-{i}',now-60)
            else:
                assert panel.seen_text.get()=='4/5' and panel.endless.get() and panel.runner.endless.is_set()
                panel.show_daily_gems();self.update_idletasks()
                daily=panel.daily_gems;key=state['missed_id']
                assert not daily.rows[key]['obtained']
                daily.tree.selection_set(key);daily.select();daily.check.invoke()
                assert daily.rows[key]['obtained'] and panel.seen_text.get()=='5/5'
                daily.window.destroy()
            views=(replace(panel.base_views[0],x=241.,y=107.),)
            panel.apply_route(views)
            clock=Clock();backend=SceneBackend(views,clock)
            backend.cancel=panel.runner.cancel
            capture=backend.capture
            def dim_camera_frame():
                frame=capture()
                if backend.open:frame[frame==255]=175
                return frame
            backend.capture=dim_camera_frame
            image=cv2.imread(str(ROOT/'gem_templates/gem_0.png'));h,w=image.shape[:2]
            backend.frame[400:400+h,240:240+w]=image
            runner=panel.runner;runner.backend_factory=lambda cancel:backend
            runner.stats.clock=clock;runner.pass_stats.clock=clock;runner.wall=lambda:now+clock.now
            runner.detector=GemDetector();runner.locator=Locator(backend)
            runner.title=SimpleNamespace(score=lambda f:float(f[0,0,0]))
            recorded=[];emit=runner.emit
            def report(event):
                recorded.append(event);emit(event)
                if phase[0]==1 and event['kind']=='gem_clicked' and runner.stats.snapshot()['gems']==2:
                    panel.emergency()
            runner.emit=report
            clicks=[];click=backend.click
            def record(point):clicks.append((point,clock.now,backend.open));click(point)
            backend.click=record
            state.update(clock=clock,backend=backend,events=recorded,clicks=clicks)
            panel.snipe.invoke()
            assert panel.services.owner=='sniper'
            self.after(100,self.done)
        def done(self):
            panel=panels['sniper'];runner=panel.runner
            if runner.running:self.after(100,self.done);return
            panel.drain()
            if panel.futures:self.after(100,self.done);return
            panel.services.flush_sightings();panel.seen_refresh=0
            panel.seen_text.set(f'{panel.services.sighting_history.sniper_seen()}/5')
            events=state['events'];clicks=state['clicks'];backend=state['backend']
            if phase[0]==1:
                assert panel.services.owner is None and panel.seen_text.get()=='7/5',dict(owner=panel.services.owner,counter=panel.seen_text.get(),status=panel.status.get(),stats=runner.stats.snapshot(),events=[(e['kind'],e.get('message')) for e in events if e['kind'] in ('status','found','gem_clicked','returned_home','finished')])
                assert runner.cancel.is_set() and not runner.running
                assert sum(e['kind']=='gem_clicked' for e in events)==2
                assert sum(e['kind']=='returned_home' for e in events)==1
                assert sum(e['kind']=='pass_started' for e in events)==1
                panel.endless_button.invoke()
                assert not panel.endless.get() and not runner.endless.is_set()
                count=len(clicks);panel.snipe.invoke()
                assert len(clicks)==count and panel.services.owner is None and '5/5' in panel.status.get()
                results[0].update(restart_restored_obtained_choice=True,restart_restored_endless_preference=True,
                    endless_continued_beyond_five=True,f10_stayed_stopped_in_endless=True,
                    disabling_endless_restored_quota=True,daily_count_after_endless=7)
                self.exit_app();return
            assert panel.services.owner is None and panel.seen_text.get()=='5/5' 
            assert '5/5' in panel.status.get() and 'Returned' in panel.status.get(),panel.status.get()
            assert sum(e['kind']=='gem_clicked' for e in events)==1
            assert sum(e['kind']=='returned_home' for e in events)==1
            assert not any(e['kind']=='pass_started' for e in events)
            clicked=next(e['point'] for e in events if e['kind']=='gem_clicked')
            stamp=next(t for p,t,opened in clicks if p==clicked and not opened)
            reopened=next(t for p,t,opened in clicks if p==panel.settings.map_open and t>stamp)
            assert reopened-stamp>=20
            assert clicks[-1][0]==(285.,530.) and not clicks[-1][2]
            assert backend.selected_world==(241.,107.)
            assert backend.selections==[0,0],backend.selections
            assert len(panel.services.sighting_history.list())==1
            assert len(list((Path(temporary.name)/'LoongLens/screenshots').glob('*.png')))==1
            panel.reset()
            assert panel.services.sighting_history.sniper_seen()==5
            count=len(clicks);panel.snipe.invoke()
            assert panel.services.owner is None and len(clicks)==count and '5/5' in panel.status.get()
            results.append(dict(passed=True,version=35,collection_seconds=20,return_world=[241,107],
                                daily_count=5,stopped_at_goal=True,source_screenshot_saved=True,
                                dim_camera_selected_once_per_visit=True,
                                reset_kept_daily_counter=True,scope='Native Tk and detector; simulated game input and waits'))
            panel.show_daily_gems();self.update_idletasks()
            daily=panel.daily_gems
            assert len(daily.rows)==5 and all(r['obtained'] for r in daily.rows.values())
            key=next(k for k,r in daily.rows.items() if r['screenshot_path'])
            original=daily.rows[key]['screenshot_path'];daily.tree.selection_set(key);daily.select()
            assert daily.check.instate(['!disabled']) and daily.obtained.get()
            daily.check.invoke()
            assert panel.seen_text.get()=='4/5' and not daily.rows[key]['obtained']
            assert Path(original).is_file() and len(panel.services.sighting_history.list())==1
            daily.check.invoke()
            assert panel.seen_text.get()=='5/5'
            daily.tree.event_generate('<space>');self.update()
            # Direct handler also covers cases where Tk focus is on the button.
            if daily.rows[key]['obtained']:daily.toggle_selected()
            assert panel.seen_text.get()=='4/5' and not daily.rows[key]['obtained']
            state['missed_id']=key;daily.window.destroy()
            panel.endless_button.invoke()
            assert panel.endless.get() and runner.endless.is_set()
            self.exit_app()
    tk.Tk=Window
    try:
        loong_lens.main([],default_tab='live')
        if not resume:
            assert results and not errors,errors
            (ROOT/'sniper-ui-check.json').write_text(json.dumps(results[0]),'utf-8')
            subprocess.run([sys.executable,str(Path(__file__).resolve()),'--resume',temporary.name,state['missed_id']],check=True,cwd=ROOT)
            results[0]=json.loads((ROOT/'sniper-ui-check.json').read_text())
    finally:
        tk.Tk=original_tk;patrol_live_panel.LivePatrolPanel.__init__=original_init
        logging.shutdown()
        if previous_local is None:os.environ.pop('LOCALAPPDATA',None)
        else:os.environ['LOCALAPPDATA']=previous_local
        temporary.cleanup()
    assert results and results[0].get('restart_restored_obtained_choice') and results[0].get('endless_continued_beyond_five') and not errors,errors
    (ROOT/'sniper-ui-check.json').write_text(json.dumps(results[0],indent=2)+'\n','utf-8')
    print('Native Sniper UI: daily checkbox, screenshot retention, app restart, saved endless preference, beyond-five loop, F10 and normal quota restoration passed.')


if __name__=='__main__':main()
