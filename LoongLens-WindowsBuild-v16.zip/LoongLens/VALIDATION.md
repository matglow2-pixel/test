# Validation of this source release

Tests were run in the Linux development environment with Python 3.12, OpenCV 4.12.0, and two OpenCV threads. The live application targets Windows 10 (2004+) / Windows 11 and BlueStacks at default map zoom.

## Grouped patrol, locks and one-click approach v16

**242 tests passed in Linux.** Both real-Tk screenshot simulations passed: movement enabled and the retained five-second hold mode. The preview UI simulation passed with grouped coverage of all 86 spots.

The default plan covers all 86 original spawn spots in 77 views. Coverage tests require every spot to remain at least 0.6 tiles inside its assigned rectangle, playable centres for every view, one view for Mirage Cauldron's three spots and one for all four Demonbind Tower spots. Additional cases check overlapping clusters, non-fitting chains, duplicate locations, different footprints and shifting an edge camera inward without losing its spawn.

Screenshot registration tests use actual atlas pixels around Forsaken Lotus Pond, Mirage Cauldron and snowy borders. An end-to-end navigation simulation removes absolute recognition after leaving the island, then requires visual overlap registration to continue panning, finish the next checks and reopen the map. Static HUD/background and blank images cannot establish a moving map pose.

Approach tests require exactly one horizontal tile of offset at different screenshot sizes, the inward screen side, no vertical fallback near HUD/chat, exactly one movement click followed by stop, the saved frame preceding movement, F10 cancellation, and cancellation when a fresh detection shows that the scene changed. Locked-map tests distinguish shading from the unlocked biome palettes and require skipping without view selection, gameplay inspection or history, then continuing to an unlocked spot.

UI simulations exercise both movement-enabled mode and the retained five-second hold mode with the actual detector, map images, history and screenshot writer. The overlay is required to draw while patrol is busy. Windows native input validation additionally displays the actual transparent overlay, requires capture exclusion, captures the window without marker pixels, and sends a click/drag through the overlay to the app's own test window. This checks OS input delivery, not game pathfinding.

The one-tile screen offset uses the measured approximate camera footprint. Live BlueStacks movement, locked shading on different accounts and total scan duration still need real-game verification. The user's latest inline map screenshots were used as visual references, not new imported pixel fixtures.

## Map reopening fix v15

Regression tests reproduce the reported failure: the first map starts open, inspection completes, then the old bottom-right opener fails to show the next map. The UI model accepts only clicks on the independently specified top-right minimap region, rather than trusting the application's own configured coordinates. Tests run four consecutive empty-location checks and require three successful minimap reopenings with no bottom-menu input. Additional tests cover upgrading legacy saved defaults, preserving Back/timing preferences and custom coordinates, and not repeatedly migrating explicitly saved modern configurations.

## Live camera patrol v14

The live engine is tested with an injected desktop backend and clock: selecting visible unchecked dots, choosing the nearest offscreen dot, bounded map drags, fresh/stable alignment after each pan, opening/closing the map, full-scene confirmation, one-step and automatic modes, immediate stop on a gem, fresh five-second capture, cooldown, stop cancellation and failure to align/close/pan. Input guard tests reject loss of focus, window resizing, covered points and cancellation before any mouse movement. A cancelled drag always sends button-up.

Patrol screenshots bypass character-minimap OCR and retain the selected camera area in history, labelled Camera view. The real detector, atlas recognition, UI, screenshot writer and history path are exercised together with simulated game input. The existing watcher/overlay tests remain included. Windows build validation additionally delivers real SendInput clicks/drags and F8/F10 hotkeys to an isolated native test window; it never sends test input to a game. Its report is input-check.json. Actual Sword x Staff/BlueStacks behaviour and total scan time still require the user's first live check.

## Runtime icon restoration v11

The original optimized transparent gem ICO is bundled unchanged, with all 16 native sizes and transparent corners. The app loads this ICO for its window/taskbar; the Windows build still embeds all eight white-badge ICO images in the executable. The native Windows GUI check now requires the transparent runtime ICO and a configured Win32 icon handle. No game logic, history schema or settings paths changed.

## Sighting map timers v10

**165 automated tests pass** in Linux. New coverage checks a fixed deadline of seen_at + 1,800 seconds, late OCR coordinates, coordinate corrections without changing time or screenshot, restart, fractional-second expiry, latest-record selection at a shared coordinate, deletion, suppressed late-capture resurrection, and query caching with immediate invalidation on edits. Renderer checks cover exact projected coordinates, panning, one-second countdown caching, disabled layers, excluded photo tests, missing coordinates, and coexistence with manual pickup timers.

The real Tk/history/renderer integration check passed with simulated game capture: pending coordinates produced no dot; completed metadata produced a 29:55 countdown from the original confirmation; editing at ten minutes moved the dot and retained 20:00; panning, the timer toggle, expiry, deleting a history row and keeping the original spotting time were verified. The existing detection/OCR/screenshot/history UI integration check also passed.


## History editing and date filters v8

**152 automated tests pass.** New coverage checks that editing only changes zone/X/Y (plus an internal manual-correction flag), preserves both timestamps, source, score, screenshot path and other entries, and survives restart. Invalid inputs and deleted entries leave data untouched. A delayed OCR result completes the screenshot without overwriting a manual correction. The additive schema migration retains older records. Date filtering is checked at exact local-midnight boundaries in Europe/Sofia, including 23-hour and 25-hour daylight-saving days.

The combined Tk application passed its virtual-display integration check using real image loading, detection, temporal confirmation, screenshot saving, OCR, database and history widgets. It exercised editing and invalid-input handling, date filters with older records, the removed CSV button, screenshot links, minimum-window layout and restart persistence. A separate Tk check displayed all 1,003 test rows in Show all, simulated the local midnight rollover, and verified timer cleanup and reopening the history window. The offline atlas/render/OCR self-check passed.

Windows desktop capture, visibility, sound and file opening are simulated in these UI checks; the actual Windows/BlueStacks integration remains a live-test limitation. The release contains no personal history databases or full source screenshots.

## Saving cooldown v7

**142 automated tests pass.** The new checks reproduce scan resets and a moved gem box within 20 seconds and assert exactly one history row and one saved PNG. Tests check the exact 20-second boundary, pause/resume, a ten-second absence, isolation from image tests, and a new permitted entry after 20 seconds while sound is still in its separate cooldown. Suppressed detections are not queued and do not replay when the saving cooldown ends.

The combined Tk application also passed its virtual-display integration check: real detection/OCR, immediate alert, a fresh five-second capture after movement, matching screenshot links, and restart persistence. The offline atlas/render/OCR self-check passed. This update adds no editing or screenshot-retake controls. Database schema and existing five-second screenshot/OCR behavior are unchanged from v6. Windows capture and actual BlueStacks behavior still require a live check on the user's PC.

## Location screenshots v6

The release has **136 automated tests**. New coverage checks immediate confirmation versus the five-second deadline, use of fresh pixels after movement, original spotting time versus later capture time, separate files/deadlines for different gems, pause/source/window/occlusion interruption (including a source change during capture), OCR failure retaining the image, old-schema migration, incomplete-capture recovery and replayed pending events not erasing a completed record. The requested row format is checked exactly. The real bundled ONNX models read generated minimap labels at two scales, retain narrow Roman suffixes, and reject a blank scene.

All **19 minimap labels in the supplied photos** matched manually reviewed zone/coordinate annotations in `tools/validate_location_examples.py`, including the no-gem image. These photos were used during development; this is a small reference set, not an independent accuracy estimate or a guarantee of live OCR. Reading one supplied label took roughly 0.35–1.0 seconds after the initial model load in the measured run.

The real detector, temporal gate, capture queue, ONNX OCR, database and Tk history passed a virtual-display integration check. Simulated live capture initially showed `Loong Haven I (100,100)`; the character label changed to `Loong Haven III (193,121)` after three seconds. The saved screenshot used the changed frame after the five-second deadline, while preserving the original spotting time. Source-cell clicks requested opening the correct test/live PNGs via the simulated Windows file opener, and reopening the database retained the files and formatted entries. The alert preceded the capture and continuously visible gems did not add duplicate rows.

Screenshots/OCR run locally on a single background worker. Game scans continue while OCR finishes. The original uploaded photos, saved personal screenshots/databases and generated UI artifacts are excluded from the release. PP-OCRv4 assets, license, attribution and SHA256 manifest are included. Windows capture, visibility checks, the actual image viewer and live BlueStacks behavior still need testing on the user's PC.

## Combined application v5

The combined release has **116 automated tests**. New coverage checks one confirmed sighting per visible encounter, new-pile recording during the sound cooldown, short flicker versus a ten-second absence, exclusion of recognized large maps, stale-source rejection, restart persistence, idempotent event retries, live/image-test filtering, CSV dates and explicit screen coordinates. Simulated native tests check first versus duplicate launch behavior and release of the instance handle after startup failure.

The real combined Tk window passed virtual-display UI checks with Windows display/audio APIs simulated. They verified two tabs, the fixed 45-FPS map-worker setting, grouped ingredients, removal of FPS/CSV/re-arm controls, preserved manual pickup controls, sighting history filtering, and shared exit. The real image loader, detector, confirmation gate, worker, database and UI were exercised together: a positive test image generated a dated test sighting and sound requests; a negative image remained quiet; switching to simulated live capture generated one live sighting while the Map tab was selected; continued visibility did not add duplicates; reopening the database retained both sources.

The batch launcher now starts `pythonw.exe` and exits. The `.pyw` entry point includes a native per-session instance guard and error dialog/log. **Actual Windows console detachment, foreground activation, native capture/audio and live BlueStacks behavior remain unverified here.** The launcher lifecycle tests simulate the Win32 calls; they are not Windows integration tests.

## Pickup history v4

**107 automated tests pass** for the combined release. New tests cover database restart persistence, separate pickup/reference coordinates, multiple pickups at one dot, delayed and same-time entries, rejection of invalid entries without data loss, local-day counts, CSV export, additive schema migration, timer projection during panning, expired reminders, custom coordinates, disabled layers, and transparency over interface areas. A stationary countdown reuses its surface until the displayed second changes.

The real Tk map panel and pickup/history windows passed a Linux virtual-display smoke check with a simulated Windows overlay/capture backend. It exercised blank-entry validation, a manual pickup, reference-dot selection, history display, CSV export, database reopening, preferences and panel layout. This confirms those local application paths; Windows rendering/capture and the live game remain untested here.

These checks do not establish a game's respawn interval. The 30-minute default is a user-selected reminder. Collection is always manually confirmed, and the detector never treats disappearance as a pickup.

## Map alignment v3

The additional map tests cover default-zoom portal geometry, false extra markers, rejection of insufficient/random/other-zoom constellations, synthetic portal pixels with an excluded legend icon, green/brown/snow terrain viewports, uniform-terrain rejection, calibration fallback dispatch and retained diagnostics after focus loss. A rendering regression checks that a gem at reference y=920 remains visible while navigation below y=938 is transparent. **82 automated tests pass** for the combined release.

Approximate portal centers read from the user's inline Nimbuville/Demonbind Tower map view fit the bundled portal coordinates with about 1.03 pixels mean error at 12.50 pixels/tile. This validates coordinate geometry, not pixel recognition of the original inline image, which was unavailable as a local file. Portal pixel recognition was exercised separately with synthetic markers.

Terrain matching was checked on seven crops of the packaged atlas, covering green, brown and snow areas. Accepted fits stayed within seven reference pixels of the expected crop pose. These are offline atlas checks and do not establish live-game readiness. The coarse terrain method can be less precise than feature or portal alignment. The original stitched atlas remains unchanged.

The full-map site `https://lootandwaifus.com/sword-x-staff-interactive-map/?map=14` returned proxy HTTP 403 in this environment. No new site data or coordinates were downloaded. The existing 86 candidate gem coordinates and ingredient data were preserved. Full-map pictures supplied inline were used as visual references, not imported as new pixel assets.

## Gem Watch addition

**64 automated tests passed** after the Gem Watch version 2 fix (the original 35 tests plus 29 Gem Watch tests). The tests check arbitrary screen positions, native-coordinate scaling, multiple gems, HUD/region exclusion, lookalike colors, confirmation, suppression of repeated alerts, disappearance, cooldown, pause and covered-window filtering. Version 2 adds regressions for wide sidebar layouts, actual image-mode detection and confirmation, negative photo tests, return to live mode and stale-source rejection.

The 19 supplied screenshots were evaluated against annotated gem positions: 19/19 piles found across 18 positive images, no extra detections, and zero detections in `MyLocationNoGems`. Three positive images supplied templates; the other 15 positives contained 16 piles and were held out from template extraction. The negative screenshot was used during development and is not an independent negative validation set.

The Gem Watch Tk panel passed a Linux virtual-display smoke check with simulated Windows backends, including start/pause, area selection, saved preferences, calls to the sound backend, layout and exit. Actual Windows sound, capture, visibility APIs and a live gameplay session remain untested. See `GEM_WATCH.md` for details.

The new Test image button was additionally exercised through the real image loader, detector, worker thread, confirmation gate and Tk panel, using `IMG_1427.png` and `MyLocationNoGems.png`. The positive photo produced a labeled confirmed test alert and calls to the simulated sound backend; the negative photo remained quiet; returning to live mode stopped photo scanning. Only Windows capture and audio were mocked in that check.

A reconstruction of the reported Media Manager layout (a 724-pixel-wide photo inside a 1377×1040 window, with a sidebar and dimming) reproduced zero detections in version 1. Version 2 detected both annotated piles with interface masking disabled. With the default HUD mask enabled the lower pile falls in the excluded bottom band. The dedicated Test image mode avoids that layout-specific exclusion. This is a reconstruction using the supplied source photograph, not validation on the user's actual desktop capture.

## Results

- **35 automated tests passed.** These exercise default-scale atlas alignment, rejection of nondefault zoom, motion tracking, title detection, cache recovery, CSV validation, rendering, transparent UI exclusion, background request limits, pause/focus handling, and rejection of recognition results from a previous map session.
- **Offline self-check passed:** 3/3 selected atlas viewports aligned, the packaged 86-gem dataset loaded, and transparent rendering completed.
- **Tk panel smoke check passed** on a virtual X display with a simulated Windows overlay backend. Layer toggles, dot size, opacity, pause/resume, preferences, initial layout, and exit were exercised. This does not test Windows native APIs.
- **Release archive CRC checked**, then extracted for the offline self-check and automated suite.

## Measured performance

These are microbenchmarks of **synthetic viewports cropped from the supplied atlas**. They do not establish detection accuracy on live screenshots or end-to-end latency on a user's PC. Each original matcher timing used six repetitions; each indexed matcher timing used twelve repetitions after warm-up.

| Atlas viewport origin | Original search median | Indexed search median | Ratio |
|---|---:|---:|---:|
| 900, 1300 | 304.56 ms | 52.12 ms | 5.84× |
| 1600, 1500 | 384.86 ms | 60.46 ms | 6.37× |
| 2000, 1700 | 308.11 ms | 51.78 ms | 5.95× |

At a 570×1029 render size with all four layers enabled, full rendering had a **0.659 ms median** over 60 repetitions. An unchanged frame returned the cached surface in **0.002 ms median** over 1,000 repetitions. Stationary optical flow had a **2.985 ms median** over 60 repetitions.

The measured index preparation run took 2.38 seconds; an earlier run took about 5 seconds. Later launches reuse an on-disk index. Performance varies with CPU, atlas cache state, map detail, emulator size, and other activity. Windows bitmap upload and screen capture costs were not measured here.

Reproduce the microbenchmarks using `python tools/benchmark.py`; detailed results are written into `artifacts/benchmark.json`.

## Required live checks still outstanding

These require the user's Windows / BlueStacks / game installation, which was unavailable here:

1. Launch with `RUN_LOONG_LENS.bat`, put the map at normal/default zoom, and bring BlueStacks to the foreground. Confirm that transparent markers appear at recognizable locations.
2. Pan across several areas. Confirm that dots and zone borders follow the terrain without persistent offsets.
3. Close/reopen the map, resize/move BlueStacks, switch to another app, and pause/resume. Confirm that markers disappear and reacquire correctly.
4. Confirm that mouse clicks pass through the overlay and that the overlay does not steal keyboard focus.
5. Compare candidate coordinates with the live map. The supplied community data is not a verified list of current spawns.

The game must be visible on the desktop for screenshot capture. Its title and fixed UI layout must match the supplied templates. If alignment is unavailable, restore normal zoom and use **Re-align**; inspect `%LOCALAPPDATA%\LoongLens\loonglens.log` for capture errors.

## Source availability

All location data and reference images were reused from the user's uploaded `SxSMapOverlay.rar`. Requests to the cited TapTap/HackMD guides and an interactive-map web search were blocked with proxy HTTP 403 responses. No additional online coordinates were downloaded or verified.
