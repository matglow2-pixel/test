"""Exercise the real Tk panel on Linux with a simulated Windows overlay backend.

Run with DISPLAY pointing to an X server. This checks the panel, not Win32 APIs.
"""
import os
from pathlib import Path
import sys
import types
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from tkinter import ttk
import cv2
import numpy as np
from PIL import Image
from mss.linux import MSS
from pose import Match
import tracker
import loong_lens
import time
from tkinter import messagebox
from pickup_history import PickupHistory
from resources import ResourceStore

OUT = Path(__file__).resolve().parents[1] / 'artifacts'
OUT.mkdir(exist_ok=True)
os.environ['XDG_CACHE_HOME'] = str(OUT / 'ui-settings')
opened=[]
messagebox.showinfo=lambda *args,**kwargs:None
os.startfile=lambda folder:opened.append(folder)
history_path = OUT/'ui-settings/LoongLens/pickups.sqlite3'
if history_path.exists():
    history_path.unlink()

class Overlay:
    hwnd = 1
    excluded_from_capture = True
    def hide(self): pass
    def close(self): pass
    def show_image(self, rect, image):
        image.save(OUT / 'overlay-demo.png')

class Worker:
    fps = 45
    def __init__(self, *args, **kwargs):
        self.paused = False
        assert kwargs['fps'] == 45
    def start(self): pass
    def close(self): pass
    def pause(self, paused): self.paused = paused
    def request_scan(self): pass
    def get_diagnostics(self):
        frame=np.full((1029,570,3),(112,184,152),np.uint8)
        return frame,dict(rect=[0,0,570,1029],title_score=.92,state='Following map',
                          scale=12.45,source='mock diagnostics',age_reference=time.perf_counter())
    def get(self):
        return dict(open=not self.paused, match=Match(12.45, -1650, 2250, 150, .2, [], 'demo'),
                    rect=(0,0,570,1029), state='Following map' if not self.paused else 'Paused',
                    info='12.45 px/tile · 150 visual landmarks', fps=30., scan_ms=60.)

tracker.VisualWorker = Worker
sys.modules['win_overlay'] = types.SimpleNamespace(PixelAlphaOverlay=Overlay, find_emulator=lambda: None,
    find_visible_emulator=lambda: None, window_visible_at=lambda *args: False)
sys.modules['winsound'] = types.SimpleNamespace(Beep=lambda *args: None, MessageBeep=lambda *args: None, MB_ICONEXCLAMATION=48)
original = tk.Tk.__init__
errors = []

def descendants(root):
    result = []
    for widget in root.winfo_children():
        result.append(widget)
        result.extend(descendants(widget))
    return result

def start(self, *args, **kwargs):
    original(self, *args, **kwargs)
    self.report_callback_exception = lambda *args: errors.append(args)
    def interact():
        widgets = descendants(self)
        buttons = {w.cget('text'): w for w in widgets if isinstance(w, ttk.Button)}
        notebook = next(w for w in widgets if isinstance(w, ttk.Notebook))
        assert len(notebook.tabs()) == 2
        assert 'Import CSV' not in buttons and 'Re-arm alert' not in buttons
        assert not any('FPS' in str(w.cget('values')) for w in widgets if isinstance(w, ttk.Combobox))
        buttons['Pause'].invoke()
        buttons['Mark collected'].invoke()
        popup = next(w for w in descendants(self) if isinstance(w, tk.Toplevel) and w.title() == 'Mark gem collected')
        popup_widgets = descendants(popup)
        save = next(w for w in popup_widgets if isinstance(w, ttk.Button) and w.cget('text') == 'Mark collected')
        save.invoke()  # Empty coordinates must not save anything.
        assert popup.winfo_exists()
        entries = [w for w in popup_widgets if type(w) is ttk.Entry]
        mx, my = ResourceStore().points['gems'][0] - .5
        for entry, value in zip(entries, (str(mx+1), str(my), '30', '0', 'Smoke test pickup')):
            entry.delete(0, 'end')
            entry.insert(0, value)
        combo = next(w for w in popup_widgets if isinstance(w, ttk.Combobox))
        assert combo.get().startswith(f'Known dot ({mx:g}, {my:g})')
        save.invoke()
        assert not popup.winfo_exists()
        with_history = PickupHistory(history_path)
        row = with_history.list()[0]
        assert row.x == mx+1 and row.marker_x == mx and row.timer_minutes == 30
        with_history.close()
        buttons['Pickup history'].invoke()
        history_popup = next(w for w in descendants(self) if isinstance(w, tk.Toplevel) and w.title() == 'Gem pickup history')
        tree = next(w for w in descendants(history_popup) if isinstance(w, ttk.Treeview))
        assert len(tree.get_children()) == 1
        assert tree.item(tree.get_children()[0], 'values')[1] == f'{mx+1:g}'
        # Export through the actual dialog callback, without an interactive chooser.
        from tkinter import filedialog
        exported = OUT/'ui-history-export.csv'
        filedialog.asksaveasfilename = lambda **kwargs: str(exported)
        next(w for w in descendants(history_popup) if isinstance(w, ttk.Button) and w.cget('text') == 'Export history CSV').invoke()
        assert exported.exists() and 'Smoke test pickup' in exported.read_text(encoding='utf-8-sig')
        history_popup.destroy()
        buttons['Save debug'].invoke()
        assert opened
        assert (OUT/'ui-settings/LoongLens/map-debug.png').exists()
        assert (OUT/'ui-settings/LoongLens/map-debug.json').exists()
        assert buttons['Pause'].cget('text') == 'Resume'
        buttons['Pause'].invoke()
        for w in widgets:
            if isinstance(w, ttk.Checkbutton) and w.cget('text') == 'Ingredients':
                w.invoke()
            if isinstance(w, ttk.Scale):
                w.set(6 if float(w.cget('to')) > 1 else .8)
        self.after(400, screenshot)
    def screenshot():
        self.update_idletasks()
        with MSS(display=os.environ['DISPLAY']) as screen:
            pixels = screen.grab(dict(left=self.winfo_rootx(), top=self.winfo_rooty(),
                                      width=self.winfo_width(), height=self.winfo_height()))
            Image.frombytes('RGB', pixels.size, pixels.rgb).save(OUT / 'panel-preview.png')
        widgets = descendants(self)
        # Ensure the last explanatory label fits inside the initial window.
        label = next(w for w in widgets if isinstance(w, ttk.Label) and str(w.cget('text')).startswith('Dots are candidate'))
        assert label.winfo_rooty() + label.winfo_height() <= self.winfo_rooty() + self.winfo_height()
        exit_button = next(w for w in widgets if isinstance(w, ttk.Button) and w.cget('text') == 'Exit')
        assert not errors, errors
        exit_button.invoke()
        import json
        saved = json.loads((OUT/'ui-settings/LoongLens/settings.json').read_text())
        assert len({saved['layers'][t] for t in ('common', 'rare', 'epic')}) == 1
        restarted = PickupHistory(history_path)
        assert len(restarted.list()) == 1 and restarted.latest_locations()[0].remaining(time.time()) > 1700
        restarted.close()
        print('Tk smoke check passed: manual pickup validation/save, separate timer anchor, history, CSV export, restart persistence, panel layout, controls and exit.')
    self.after(300, interact)
    self.after(6000, self.destroy)

tk.Tk.__init__ = start
sys.platform = 'win32'
sys.argv = ['loong_lens.py']
loong_lens.main()
if errors:
    raise RuntimeError(errors)
