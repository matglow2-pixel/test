import math
import numpy as np
import pytest
from types import SimpleNamespace
from camera_patrol import approach_click,Viewpoint,PatrolSettings
from patrol_live import LiveSettings,locked_at
from test_live_patrol import setup


@pytest.mark.parametrize('shape,center',[((1029,570,3),(285,531)),((2058,1140,3),(570,1062)),
                                        ((1029,570,3),(80,350)),((1029,570,3),(460,700))])
def test_movement_click_is_exactly_one_tile_from_gem_and_avoids_controls(shape,center):
    p=approach_click(center,shape);assert p is not None
    gx,gy=center[0]*570/shape[1],center[1]*1029/shape[0]
    settings=PatrolSettings()
    distance=math.hypot((p[0]-gx)/(570/settings.view_width),(p[1]-gy)/(996/settings.view_height))
    assert distance==pytest.approx(1.)
    assert p[1]==pytest.approx(gy)
    assert 40<p[0]<520 and 280<p[1]<760
    assert not (p[0]>420 and p[1]<470)
    assert math.dist(p,(gx,gy))>70  # Safely outside the small gem pile sprite.


def test_found_gem_saves_pre_movement_frame_clicks_once_then_stops():
    engine,backend,events=setup(positive=True)
    engine.settings=LiveSettings(approach_gem=True)
    message=engine.run(backend)
    assert len(backend.inputs)==3  # Map target, Back, then exactly one movement click.
    assert backend.inputs[-1][2] is False
    assert 'Clicked beside' in message and engine.checked=={0}
    capture=next(e for e in events if e['kind']=='capture')
    found=next(e['event'] for e in events if e['kind']=='found')
    assert capture['captured_at']-found['seen_at']==pytest.approx(0)
    assert 'before the movement click' in capture['event']['capture_note']
    assert any(e['kind']=='approached' for e in events)


def test_f10_after_detection_prevents_movement_click():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    def emit(event):
        events.append(event)
        if event['kind']=='found':engine.cancel.set()
    engine.emit=emit
    from patrol_windows import PatrolStopped
    with pytest.raises(PatrolStopped):engine.run(backend)
    assert len(backend.inputs)==2


def test_changed_scene_cancels_movement_instead_of_clicking_blindly():
    engine,backend,events=setup(positive=True);engine.settings=LiveSettings(approach_gem=True)
    original=engine.detector.detect;triggered=[]
    def detect(*args,**kw):return [] if triggered else original(*args,**kw)
    engine.detector.detect=detect
    def emit(event):
        events.append(event)
        if event['kind']=='found':triggered.append(True)
    engine.emit=emit
    assert 'Scene changed' in engine.run(backend)
    assert len(backend.inputs)==2


def test_locked_shading_does_not_confuse_unlocked_biomes_or_blank_capture():
    for color in [(44,47,46),(54,58,57)]:
        assert locked_at(np.full((1029,570,3),color,np.uint8),(285,500),12.45)
    for color in [(100,132,148),(116,188,156),(220,212,188),(68,92,124),(0,0,0),(1,1,1)]:
        assert not locked_at(np.full((1029,570,3),color,np.uint8),(285,500),12.45)


def test_locked_view_skips_selection_scene_inspection_and_history():
    engine,backend,events=setup();engine.views=(engine.views[0],)
    original=backend.capture
    def capture():
        frame=original()
        if backend.open:frame[400:600,180:390]=(44,47,46)
        return frame
    backend.capture=capture
    def detect(*a,**kw):pytest.fail('Locked area must not be opened or inspected')
    engine.detector.detect=detect
    engine.run(backend)
    assert backend.inputs==[] and engine.checked=={0} and engine.skipped=={0}
    assert not any(e['kind'] in ('found','capture') for e in events)


def test_locked_skip_continues_to_next_unlocked_location():
    engine,backend,events=setup()
    engine.views=(Viewpoint(100.5,100.5,'Locked',frozenset({(100,100)})),
                  Viewpoint(110.5,100.5,'Open',frozenset({(110,100)})))
    original=backend.capture
    def capture():
        frame=original()
        if backend.open:frame[470:535,250:320]=(44,47,46)
        return frame
    backend.capture=capture;engine.run(backend)
    assert engine.checked=={0,1} and engine.skipped=={0}
    assert len(backend.inputs)==2


def test_never_fall_back_to_vertical_click_near_hud_or_chat():
    assert approach_click((285,200),(1029,570,3)) is None
    assert approach_click((285,850),(1029,570,3)) is None


@pytest.mark.parametrize('gx', [45,80,180,350,460,510])
def test_choose_inward_side_of_screen(gx):
    target=approach_click((gx,531),(1029,570,3))
    assert target is not None
    assert target[0]>gx if gx<285 else target[0]<gx
    assert 0<target[0]<570 and target[1]==531
