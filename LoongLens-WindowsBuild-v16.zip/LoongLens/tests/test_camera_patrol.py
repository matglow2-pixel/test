import json
from pathlib import Path
import pytest
from camera_patrol import Spawn, PatrolSettings, build_plan, load_spawns, simulate_map_steps


@pytest.fixture(scope='module')
def spawns():
    data=json.loads((Path(__file__).parents[1]/'loong_haven_map_data.json').read_text())
    return load_spawns(data)


def test_groups_cover_all_86_spots_inside_actual_camera_rectangle(spawns):
    plan=build_plan(spawns)
    assert len(plan.spawns)==86 and len(plan.views)<86
    from camera_patrol import playable_ground
    ground=playable_ground()
    assert all(ground[int(v.y),int(v.x)] for v in plan.views)
    assert plan.cells==frozenset((int(s.x),int(s.y)) for s in spawns)
    assert sum(len(v.cells) for v in plan.views)==86
    for view in plan.views:
        left,bottom,right,top=view.bounds(plan.settings)
        for x,y in view.cells:
            assert left+.59 <= x+.5 <= right-.59
            assert bottom+.59 <= y+.5 <= top-.59
    assert plan.inspection_seconds==pytest.approx(len(plan.views)*1.2)


def test_mirage_and_all_four_tower_spots_each_share_one_view(spawns):
    plan=build_plan(spawns)
    for zone,count in [('Mirage Cauldron',3),('Demonbind Tower',4)]:
        cells=frozenset((int(s.x),int(s.y)) for s in spawns if s.zone==zone)
        matches=[v for v in plan.views if v.cells & cells]
        assert len(cells)==count and len(matches)==1
        assert cells<=matches[0].cells


def test_larger_rectangle_merges_more_checks_without_losing_spots(spawns):
    small=build_plan(spawns,PatrolSettings(view_width=2,view_height=2))
    large=build_plan(spawns,PatrolSettings(view_width=10,view_height=16))
    assert len(large.views)<len(small.views)
    assert large.cells==small.cells


def test_empty_and_duplicate_locations_need_no_duplicate_click():
    assert build_plan(()).views==()
    point=Spawn(100.5,100.5,'A')
    import numpy as np
    assert len(build_plan((point,point),ground=np.ones((280,280),bool)).views)==1


def test_shift_camera_into_playable_ground_while_retaining_edge_spawn():
    import numpy as np
    ground=np.zeros((280,280),bool);ground[:,20:]=True
    spawn=Spawn(20.5,100.5,'Edge')
    view=build_plan((spawn,),ground=ground).views[0]
    assert view.x>spawn.x and abs(view.y-spawn.y)<.5
    assert view.x-PatrolSettings().view_width/2+.59<spawn.x


def test_do_not_merge_chain_whose_end_spots_do_not_fit():
    import numpy as np
    points=tuple(Spawn(x,100.5,'A') for x in (100.5,104.5,108.5))
    plan=build_plan(points,ground=np.ones((280,280),bool))
    assert len(plan.views)==2 and sum(len(v.cells) for v in plan.views)==3


def test_open_ground_centres_group_near_middle():
    import numpy as np
    points=tuple(Spawn(x,100.5,'A') for x in (100.5,102.5,103.5))
    view=build_plan(points,ground=np.ones((280,280),bool)).views[0]
    assert abs(view.x-102)<.3 and abs(view.y-100.5)<.3


@pytest.mark.parametrize('values',[{'view_width':float('nan')},{'view_height':float('inf')},
                                 {'inspect_seconds':0},{'view_width':1},{'view_height':61}])
def test_invalid_settings(values):
    with pytest.raises(ValueError):PatrolSettings(**values)


@pytest.mark.parametrize('x,y',[(float('nan'),10),(10,280),(-1,10)])
def test_invalid_spawn_coordinates(x,y):
    with pytest.raises(ValueError):build_plan((Spawn(x,y,'invalid'),))


def test_reuse_map_viewport_for_nearby_dots():
    center=(100.,100.)
    target=(105.,102.)
    steps=simulate_map_steps(center,target)
    assert [s.action for s in steps]==['Open map','Select view','Close map','Inspect scene']
    assert all(s.center==center for s in steps)
    assert steps[1].end==pytest.approx((347.25,475.1))
    assert all(s.action!='Pan map' for s in simulate_map_steps(steps[-1].center,(107.,103.)))


def test_offscreen_location_requires_bounded_panning():
    start,target=(260.,5.),(10.,270.)
    steps=simulate_map_steps(start,target)
    previous=start
    drags=[s for s in steps if s.action=='Pan map']
    assert len(drags)>1
    for step in drags:
        a,b=step.start,step.end
        dx,dy=b[0]-a[0],b[1]-a[1]
        assert step.center==pytest.approx((previous[0]-dx/12.45,previous[1]+dy/12.45))
        previous=step.center
    assert previous==pytest.approx(target)
    assert steps[-3].end==pytest.approx((285.,500.))


@pytest.mark.parametrize('target',[(0.,0.),(280.,0.),(0.,280.),(280.,280.)])
def test_drag_endpoints_avoid_legend_and_zoom_bar(target):
    for step in simulate_map_steps((140.,140.),target):
        if step.action=='Pan map':
            x,y=step.end
            assert 14<x<519 and 233<y<788


def test_dot_behind_legend_requires_pan_even_inside_map_window():
    steps=simulate_map_steps((100.,100.),(112.,122.))
    assert any(s.action=='Pan map' for s in steps)
